from django.apps import AppConfig


class ExecutionCaseConfig(AppConfig):
    name = 'execution_case'
