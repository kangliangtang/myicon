from django.conf.urls import url, include
from . import views
from rest_framework import routers

router = routers.DefaultRouter(trailing_slash=False)
router.register(r'executionReport', views.ExecutionReportView, base_name='executionReport')
router.register(r'executionCase', views.ExecutionCaseView, base_name='executionCase')

urlpatterns = [
   url(r'', include(router.urls)),
   url(r'^report/image', views.ReportSummaryImageView.as_view(), name='report_image'),
]


