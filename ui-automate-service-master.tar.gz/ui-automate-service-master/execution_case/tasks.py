from celery import shared_task
from execution_case.models import ExecutionReportModel, ExecutionCaseModel
from project_crud.models import ProjectModel
from utils.web_ui_runner import WebUiRunner
from logging import getLogger
logger = getLogger('celery')


@shared_task
def runCaseTask(task_id, report_id, host_url, webdriver):
    """异步执行任务"""
    runner = WebUiRunner()
    task_obj = ExecutionCaseModel.objects.get(id=task_id)
    report_obj = ExecutionReportModel.objects.get(id=report_id)
    # test_file = task_obj.test_file
    # task_type = task_obj.task_type
    mapping = {"BASE_URL": host_url, "BASE_DRIVER": webdriver}
    runner.runTaskByPath(task_obj, report_obj, mapping)


@shared_task
def runTestTaskByPath(case_config, report_id=None, execution_id=None, project_id=None):
    """
    执行任务
    """
    try:
        uitest = WebUiRunner()
        case_host=case_config.get('case_host')
        webdriver = case_config.get('webdriver')
        report_obj = ExecutionReportModel.objects.get(id=report_id)
        execution_obj = ExecutionCaseModel.objects.get(id=execution_id)
        uitest_ = uitest.runCase(case_config, report_obj, execution_obj, mapping={"BASE_URL": case_host, "BASE_DRIVER": webdriver}, project_id=project_id)
    except Exception as e:
        logger.error("Task failed:{}".format(e))
        ExecutionReportModel.objects.filter(id=report_id).update(status = 'error')  # 用例执行异常 修改 执行用例和报告的状态  huazhong
        ExecutionCaseModel.objects.filter(id=execution_id).update(status = 'error')
        ProjectModel.objects.get(id=project_id).addfailCase()  # 用例运行失败数加一
        return '执行用例失败'
    # else:
    #     ProjectModel.objects.get(id=project_id).addSuessCase()  # 用例成功运行数加一
    #     return uitest_
    finally:
        ProjectModel.objects.get(id=project_id).addRunCase()  # 用例运行数加一
