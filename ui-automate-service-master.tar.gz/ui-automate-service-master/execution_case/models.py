import json
import os

from django.db import models, transaction
from utils.model import BaseModel
from user.models import UserModel

from utils.minio_service_file import MinioServiceFile
# from django.conf import settings
from automate_uitest_py3 import settings
# Create your models here.


class ExecutionCaseModel(BaseModel):
    """执行用例"""
    CHOICES_TASK_TYPE = (
        (1, '单用例'),
        (2, '多用例')
    )
    CHOICES_STATUS = (
        ('unexecuted', '未执行'),
        ('running', '执行中'),
        ('fail', '执行失败'),
        ('success', '执行成功'),
        ('error', '错误')
    )
    name = models.CharField(max_length=64, verbose_name='任务名')
    status = models.CharField(max_length=64, default='running', null=True, choices=CHOICES_STATUS, verbose_name='运行状态')
    test_file = models.CharField(max_length=512, verbose_name='测试文件')
    task_content = models.TextField(verbose_name='任务内容')
    task_type = models.SmallIntegerField(default=1, choices=CHOICES_TASK_TYPE, verbose_name='任务类型')
    level = models.IntegerField(default=1, null=True, verbose_name='用例等级')
    case_id_list = models.CharField(max_length=256, verbose_name='用例id列表')
    page = models.ForeignKey('page.PageModel', null=True, on_delete=models.CASCADE, verbose_name='所属页面')
    project = models.ForeignKey('project_crud.ProjectModel', on_delete=models.CASCADE, verbose_name='所属项目')
    user_exe = models.ForeignKey('user.UserModel', null=True, blank=True, on_delete=models.CASCADE, verbose_name='最后执行人')
    excel_file = models.CharField(max_length=512, null=True, blank=True, verbose_name='数据驱动文件')

    class Meta:
        db_table = 'tb_execution_case'
        verbose_name = '执行用例'
        verbose_name_plural = '执行用例'

    @transaction.atomic
    def setIsdeleteTrue(self):
        self.is_delete = True
        self.save()

    def getLasetRunTime(self):
        """最后运行时间"""
        if not ExecutionReportModel.objects.filter(task_case=self.id):
            return '--'
        else:
            return self.create_time

    def getStatus(self):
        """状态"""
        # 用例无报告时，改为'--'
        if not ExecutionReportModel.objects.filter(task_case=self.id):
            return '--'
        else:
            return self.status

    def getExecutor(self):
        if not ExecutionReportModel.objects.filter(task_case=self.id):
            return None
        else:
            # obj = ExecutionReportModel.objects.filter(task_case=self.id).order_by('create_time').first()
            # user_obj = obj.user_exe
            # user_name = user_obj.username
            # return user_name
            return self.user_exe.username

    def getDrivenStatus(self):
        if self.excel_file:
            return True
        else:
            return False


class ExecutionReportModel(BaseModel):
    """执行报告"""
    CHOICES_STATUS = (
        ('unexecuted', '未执行'),
        ('running', '执行中'),
        ('fail', '执行失败'),
        ('success', '执行成功'),
        ('error', '错误')
    )
    CHOICES_REPORT_TYPE = (
        (1, '单用例报告'),
        (2, '多用例报告')
    )
    name = models.CharField(max_length=64, verbose_name='报告名')
    report_file_path = models.FilePathField(max_length=512, null=True, verbose_name='报告路径')
    status = models.CharField(max_length=64, default='running', null=True, choices=CHOICES_STATUS, verbose_name='运行状态')
    task_case = models.ForeignKey('execution_case.ExecutionCaseModel', on_delete=models.CASCADE, verbose_name='所属执行用例任务')
    user_exe = models.ForeignKey('user.UserModel', on_delete=models.CASCADE, verbose_name='执行人')

    class Meta:
        db_table = 'tb_execution_report'
        verbose_name = '执行报告'
        verbose_name_plural = '执行报告'

    @transaction.atomic
    def setIsdeleteTrue(self):
        self.is_delete = True
        self.save()

    def reportDownUrl(self):
        report_down_url = ''
        if SummaryModel.objects.filter(result_report=self.id):
            summary_obj = SummaryModel.objects.get(result_report=self.id)
            report_down_url = summary_obj.report_down_url
        return report_down_url


class SummaryModel(BaseModel):
    result_report = models.OneToOneField('execution_case.ExecutionReportModel', null=True, on_delete=models.CASCADE, verbose_name='所属报告')
    task_result_report = models.OneToOneField('timed_task.TimedTaskReportModel', null=True, on_delete=models.CASCADE, verbose_name='定时任务所属报告')
    # summary_count = models.TextField(verbose_name='summary数据')
    summary_count_path = models.FilePathField(null=True, blank=True, verbose_name='测试文件路径')  # 默认max_length=100
    total_cases = models.IntegerField(null=True, blank=True, verbose_name='运行用例数量')
    # pass_cases = models.IntegerField(null=True, blank=True, verbose_name='运行成功的用例数量')
    report_down_url = models.CharField(max_length=512, null=True, blank=True, verbose_name='报告下载url')

    class Meta:
        db_table = 'tb_summary'
        verbose_name = '报告详情'
        verbose_name_plural = '报告详情'

    def summary_count(self):
        """获取summary_count 数据"""
        # summary_count = json.dumps('')
        # if self.summary_count_path:
        #     with open(self.summary_count_path, 'r') as f:
        #         summary_count = f.read()
        # return summary_count

        summary_count = json.dumps('')
        if self.summary_count_path:
            # todo 暂时先保留从本地获取，后期可删除
            if os.path.exists(self.summary_count_path):
                with open(self.summary_count_path, 'r') as f:
                    summary_count = f.read()
            else:
                # 从minio获取
                minio_obj = MinioServiceFile()
                # summary_count_path保存方式为 /桶名/文件名 示例：/bucket_name/test.json
                file_name = os.path.basename(self.summary_count_path)
                file_data = minio_obj.get_file_data(bucket_name=settings.REPORT_BUCKET_NAME, file_name=file_name)
                summary_count = file_data.decode()
        return summary_count

