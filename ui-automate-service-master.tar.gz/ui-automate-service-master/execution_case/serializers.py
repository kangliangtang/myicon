from rest_framework import serializers
from .models import ExecutionReportModel, ExecutionCaseModel, SummaryModel


class ExecutionCaseSerializer(serializers.ModelSerializer):
    """执行用例 序列化"""
    task_id = serializers.ReadOnlyField(source='id')
    # run_time = serializers.ReadOnlyField(source='getLasetRunTime')
    # run_status = serializers.ReadOnlyField(source='getStatus')
    run_time = serializers.ReadOnlyField(source='update_time')  # 最后运行时间
    run_status = serializers.ReadOnlyField(source='status')  # 最后运行状态
    executor = serializers.ReadOnlyField(source='user_exe.username')
    is_driven = serializers.ReadOnlyField(source='getDrivenStatus')

    class Meta:
        model = ExecutionCaseModel
        fields = ('task_id', 'name', 'level', 'run_time', 'run_status', 'executor', 'task_type', 'is_driven', 'create_time')
        # exclude = ('id', 'create_time', 'update_time')


class ExecutionCaseExecutorSerializer(serializers.ModelSerializer):
    """执行用例表中的所有执行人名 ID"""
    # 用于筛选表单
    creator_name = serializers.ReadOnlyField(source='user_exe.username')
    user_id = serializers.ReadOnlyField(source='user_exe.id')

    class Meta:
        model = ExecutionCaseModel
        fields = ('user_id', 'creator_name')


class ExecutionReportSerializer(serializers.ModelSerializer):
    """执行报告 序列化"""
    report_id = serializers.ReadOnlyField(source='id')
    user_name = serializers.ReadOnlyField(source='user_exe.username')
    run_time = serializers.ReadOnlyField(source='create_time')
    status = serializers.ChoiceField(choices=(('unexecuted', '未执行'), ('running', '执行中'), ('fail', '执行失败'), ('success', '执行成功'), ('error', '错误')))
    # 下载url
    report_down_url = serializers.ReadOnlyField(source='reportDownUrl')

    class Meta:
        model = ExecutionReportModel
        fields = ('report_id', 'name', 'status', 'user_name', 'run_time', 'report_down_url')


class SummaryCountSerializer(serializers.ModelSerializer):
    class Meta:
        model = SummaryModel
        fields = '__all__'


class SummarySerializer(serializers.ModelSerializer):
    """报告详情"""

    class Meta:
        model = SummaryModel
        fields = '__all__'

class ExecutionListSerializer(serializers.ModelSerializer):
    task_id = serializers.ReadOnlyField(source='id')

    class Meta:
        model = ExecutionCaseModel
        fields = ('task_id', 'name')
        # exclude = ('id', 'create_time', 'update_time')
