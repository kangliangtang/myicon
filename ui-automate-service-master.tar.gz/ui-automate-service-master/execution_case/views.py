import base64
import json
import os
import time
from datetime import datetime
from functools import reduce

from django.contrib.auth.models import Group
from django_filters.rest_framework.backends import DjangoFilterBackend
from rest_framework.decorators import list_route, detail_route

from utils.summary_handle import summary_result_simple
from utils.htmlreport import HTMLReport
from django.utils import timezone
import pytz
from django.http.response import FileResponse, HttpResponse
# from rest_framework.decorators import list_route, detail_route
from rest_framework.views import APIView
from rest_framework.generics import ListAPIView, DestroyAPIView
from rest_framework.viewsets import ModelViewSet
from case_manage.models import CaseManageTestModel
from execution_case.models import ExecutionCaseModel, ExecutionReportModel, SummaryModel
from execution_case.serializers import ExecutionCaseSerializer, ExecutionReportSerializer,ExecutionCaseExecutorSerializer,ExecutionListSerializer
from rest_framework import filters
# from rest_framework.filters import DjangoFilterBackend, OrderingFilter
from execution_case.tasks import runCaseTask,runTestTaskByPath
from rest_framework.response import Response
from rest_framework.status import HTTP_200_OK, HTTP_400_BAD_REQUEST
from project_crud.models import ProjectModel
from user.models import UserModel
from rest_framework import viewsets
from utils.case_dump import CaseDump
case_dump = CaseDump()

from automate_uitest_py3 import settings
from utils.write_excel import WriteExcel
from utils.read_excel import ReadExcelData
from utils.data_driven import read_jsonfile, find_params
from logging import getLogger
logger = getLogger('debug')



# Create your views here.


# # Equivalent FilterSet:
# class ExecutionCaseFilter(rest_framework.FilterSet):
#     class Meta:
#         model = ExecutionCaseModel
#         fields = ('task_type',)


class ExecutionCaseView(ModelViewSet):
    """执行用例"""
    serializer_class = ExecutionCaseSerializer
    queryset = None
    filter_backends = (filters.SearchFilter, DjangoFilterBackend, filters.OrderingFilter)
    search_fields = ('name',)
    filter_fields = ('task_type',)
    # filterset_class = ExecutionCaseFilter
    ordering = ('-create_time',)

    def get_queryset(self):
        project_id = self.kwargs['project_id']
        if project_id:
            # 权限控制
            if self.request.user.is_superuser:
                query_set = ExecutionCaseModel.objects.filter(is_delete=False)
            else:
                user_group = Group.objects.filter(user=self.request.user).all()
                query_set = ExecutionCaseModel.objects.filter(is_delete=False, project_id=project_id, project__user_group__in=user_group).all()

            try:
                query_set = query_set.filter(project=project_id)
                # 时间查询
                if self.request.query_params.get('start_time') and self.request.query_params.get('end_time'):
                    start_time_str = self.request.query_params.get('start_time')
                    end_time_str = self.request.query_params.get('end_time')
                    start_time = timezone.datetime.strptime(start_time_str, '%Y-%m-%dT%H:%M:%S.%fZ').replace(
                        tzinfo=pytz.utc)
                    end_time = timezone.datetime.strptime(end_time_str, '%Y-%m-%dT%H:%M:%S.%fZ').replace(
                        tzinfo=pytz.utc)
                    start_time += timezone.timedelta(hours=8)
                    end_time += timezone.timedelta(days=1, hours=8)
                    query_set = query_set.filter(create_time__range=(start_time, end_time))
                if self.request.query_params.get('user_id'):
                    user_exe = self.request.query_params.get('user_id')
                    query_set = query_set.filter(user_exe=user_exe)
                if self.request.query_params.get('name'):
                    name = self.request.query_params.get('name')
                    # query_set = query_set.filter(name=name)
                    query_set = query_set.filter(name__icontains=name)
                # 用例等级查询
                if self.request.query_params.get('level', ''):
                    level = self.request.query_params.get('level')
                    query_set = query_set.filter(level=level)
                return query_set.order_by('-create_time')
            except Exception:
                return ExecutionCaseModel.objects.none()
        else:
            return ExecutionCaseModel.objects.none()

    def partial_update(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"partial_update",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        return super(ExecutionCaseView, self).partial_update(request, *args, **kwargs)

    def retrieve(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"retrieve",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        return super(ExecutionCaseView, self).retrieve(request, *args, **kwargs)

    def list(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"list",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        return super(ExecutionCaseView, self).list(request, *args, **kwargs)

    def create(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"create",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        return Response({'message': '不支持新建'}, HTTP_200_OK)

    def update(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"update",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        return Response({'message': '不支持更新'}, HTTP_200_OK)

    @list_route(methods=['GET'])
    def getExecutorList(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"getExecutorList",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        project_id = self.kwargs['project_id']
        if project_id:
            query_set = self.get_queryset().order_by('-create_time')
            serializer = ExecutionCaseExecutorSerializer(query_set, many=True)
            data = json.loads(json.dumps(serializer.data))
            list_data = reduce(lambda x, y: x if y in x else x + [y], [[], ] + data)
            list_data = [name for name in list_data if name["user_id"]]
            return Response({'list': list_data}, status=HTTP_200_OK)
        else:
            return ExecutionCaseModel.objects.none()

    @list_route(methods=['GET'])
    def executionList(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"executionList",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        project_id = self.kwargs['project_id']
        if project_id:
            queryset = self.filter_queryset(self.get_queryset())   #筛选
            query_set = queryset.order_by('-create_time')
            serializer = ExecutionListSerializer(query_set, many=True)
            return Response({'list': serializer.data}, status=HTTP_200_OK)
        else:
            return ExecutionCaseModel.objects.none()

    def destroy(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"destory",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        obj = self.get_object()
        obj.setIsdeleteTrue()
        return Response({'message':'删除成功'}, HTTP_200_OK)

    @detail_route(methods=['GET'])
    def report(self, request, pk, *args, **kwargs):
        """
            {
            "permission":{
                "action":"report",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        execution_case_obj = self.get_object()
        execution_report_set = execution_case_obj.executionreportmodel_set.order_by('-create_time').all()
        if execution_report_set.count():
            serializer = ExecutionReportSerializer(execution_report_set, many=True, context={'request': request})
            return Response({'list': serializer.data}, HTTP_200_OK)
        else:
            return Response({"message": '没有报告'}, status=HTTP_400_BAD_REQUEST)

    @list_route(methods=['GET'])
    def envInfo(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"envInfo",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        project_id = self.kwargs['project_id']
        if ProjectModel.objects.filter(id=project_id, is_delete=False):
            project_obj = ProjectModel.objects.get(id=project_id, is_delete=False)
            env_info = project_obj.env_info
            if not isinstance(env_info, list):
                env_info = json.loads(env_info)
            return Response({'list': env_info}, status=HTTP_200_OK)
        else:
            return Response({'list': []}, status=HTTP_200_OK)

    @list_route(methods=['POST'])
    def run(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"run",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        data = request.data
        user_obj = self.request.user
        project_id = self.kwargs['project_id']
        case_host = data.get('env_host', '')
        webdriver = data.get('webdriver', '')
        task_id_list = data.get('task_id', '')
        task_name = data.get('name', '')
        level = data.get('level', '')
        if not all([project_id, case_host, task_id_list, task_name]):
            return Response({"message": "参数不完整"}, HTTP_400_BAD_REQUEST)

        try:
            if not isinstance(task_id_list, list):
                task_id_list = json.loads(task_id_list)
        except Exception:
            pass

        if task_id_list.__len__() == 1:
            if not ExecutionCaseModel.objects.filter(id=task_id_list[0]):
                return Response({"message": "执行任务ID不存在: task_id=%s" % task_id_list[0]}, HTTP_400_BAD_REQUEST)
            execution_obj = ExecutionCaseModel.objects.get(id=task_id_list[0])
            case_path = []
            # case_path.append(execution_obj.test_file)
            case_type = execution_obj.task_type
            case_path.append(execution_obj.test_file)
            # id为聚合任务
            try:
                if not (case_type == 1):
                    test_file = execution_obj.test_file
                    with open(test_file, 'r') as f:
                        data = f.read()
                        data = json.loads(data)
                        case_path = data.get("testcases", "")
            except Exception as e:
                return Response({"message": "获取用例失败Error:%s" % e}, HTTP_400_BAD_REQUEST)
            # 获取驱动用例(只适合单用例级别，不支持聚合)
            try:
                if (execution_obj.task_type == 1) and execution_obj.excel_file:
                    from utils.data_driven import DataDriven
                    data_driven_obj = DataDriven()
                    driven_case_path = data_driven_obj.driven_case_path(case_path=execution_obj.test_file,
                                                                        excel_path=execution_obj.excel_file)
                    case_path = driven_case_path
            except Exception as e:
                logger.error('Data driven error; message:project_id={0},ExecutionCase={1},request_data={2}, error_msg={3}'.format(project_id, execution_obj, data, e))
        elif task_id_list.__len__() > 1:
            ProjectModel.objects.get(id=project_id).addScen()  # 场景数加一
            case_type = 2
            content = {"config": {"name": task_name}, "testcases": []}
            try:
                _case_id_list = []
                for task_id in task_id_list:
                    case_id_list = ExecutionCaseModel.objects.get(id=task_id).case_id_list
                    if not isinstance(case_id_list, list):
                        case_id_list = json.loads(case_id_list)
                    for case_id in case_id_list:
                        _case_id_list.append(case_id)
                        case_manage_obj = CaseManageTestModel.objects.get(id=case_id)
                        case_path = case_manage_obj.case_path
                        content['testcases'].append(case_path)
            except Exception as e:
                return Response({"message": "获取用例失败Error:%s" % e}, HTTP_400_BAD_REQUEST)

            case_path = content['testcases']
            execution_obj = ExecutionCaseModel.objects.create(
                name=task_name,
                task_type=case_type,
                test_file=case_dump.dumpSenceCase(content),
                # level=5,
                level=level,
                status='running',
                case_id_list=_case_id_list,
                project_id=self.kwargs['project_id']
            )
        else:
            return Response({'message': '无用例id'}, status=HTTP_400_BAD_REQUEST)
        report_obj = ExecutionReportModel.objects.create(
            # name=data.get('name'),
            name=task_name,
            report_file_path='',
            status='running',
            task_case_id=execution_obj.id,
            # user_exe_id=1
            user_exe=user_obj
        )
        case_config = {
            "case_path": case_path,
            "case_type": case_type,
            "case_host": case_host,
            "webdriver": webdriver,
            "task_name": task_name
        }
        execution_obj.task_content = case_config
        execution_obj.status = 'running'
        # execution_obj.user_exe_id = 1
        execution_obj.user_exe = user_obj
        execution_id = execution_obj.id
        # 更新任务执行时间
        update_time = datetime.utcnow()
        if not settings.USE_TZ:
            update_time = datetime.now()
        execution_obj.update_time = update_time
        execution_obj.save(update_fields=['task_content', 'status', 'user_exe', 'update_time'])
        runTestTaskByPath.delay(case_config, report_obj.id, execution_id, project_id)

        return Response({'message': '已加入测试任务队列'})

    @detail_route(methods=['GET', "POST"])
    def drivenFile(self, request, pk, *args, **kwargs):
        """
            {
            "permission":{
                "action":"drivenFile",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        project_id = self.kwargs['project_id']
        if not project_id:
            return Response({'message': '项目不存在{}'.format(project_id)}, HTTP_400_BAD_REQUEST)
        if not ExecutionCaseModel.objects.filter(id=pk, is_delete=False):
            return Response({'message': '无效ID:{}'.format(pk)}, HTTP_400_BAD_REQUEST)
        executionCase_obj = ExecutionCaseModel.objects.get(id=pk)
        if request.method == 'GET':
            try:
                case_id_list = executionCase_obj.case_id_list
                if isinstance(case_id_list, str):
                    case_id_list = json.loads(case_id_list)
                case_id = case_id_list[0]
                case_file = CaseManageTestModel.objects.get(id=case_id, is_delete=False).case_path
                case_data = read_jsonfile(case_file)
                param_name_list = find_params(case_data)
                # 设置HttpResponse的类型
                response = HttpResponse(
                    content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
                response['Content-Disposition'] = 'attachment;filename={0}_{1}.xls'.format(executionCase_obj.id, int(time.time()))
                response['Access-Control-Expose-Headers'] = 'Content-Disposition'  # 网关 跨域获取  Content-Disposition
                if executionCase_obj.excel_file:
                    excel_data_list = ReadExcelData().read_all_excel(executionCase_obj.excel_file)
                    output = WriteExcel().write_old_driven_data(excel_data_list)
                else:
                    output = WriteExcel().write_dirven_file(param_name_list)
                response.write(output.getvalue())
                return response
            except Exception as e:
                logger.error('Down driven file error;error_msg={}'.format(e))
                return Response({'message': '驱动文件下载失败.Error:{}'.format(e)}, HTTP_400_BAD_REQUEST)
        elif request.method == 'POST':
            excel_file = request.FILES.get('excel_file')
            file_obj_name = excel_file.name.split('.')
            suffix = ''
            if len(file_obj_name) > 1:
                suffix = file_obj_name[-1]
            file_size = excel_file.size  # 单位：字节B
            if (suffix != 'xls') or (file_size > (1024 * 1024)):
                return Response({'message': '请上传.xls的文件，大小不超过1M'}, HTTP_400_BAD_REQUEST)
            file_name = str(time.time()).replace('.', '') + '.xls'
            file_path = os.path.join(settings.DRIVEN_EXCEL_DIR, file_name)
            with open(file_path, 'wb') as f:
                for data_ in excel_file.chunks():
                    f.write(data_)
            executionCase_obj.excel_file = file_path
            executionCase_obj.save(update_fields=['excel_file'])
            return Response({'message': '驱动文件上传成功'})


class ExecutionReportView(DestroyAPIView, viewsets.ViewSet):
    """执行报告"""
    serializer_class = ExecutionReportSerializer
    queryset = None

    def get_queryset(self):
        # user = self.request.user
        return ExecutionReportModel.objects.none()

    def retrieve(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"retrieve",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        execution_report_obj = ExecutionReportModel.objects.get(id=self.kwargs['pk'])
        if execution_report_obj.status == 'running':
            return Response({'message': '任务状态为运行中，请待运行结束，或联系平台管理员'}, HTTP_400_BAD_REQUEST)
        if execution_report_obj.status == 'unexecuted':
            return Response({'message': '任务状态为未运行，请先点击运行'}, HTTP_400_BAD_REQUEST)
        # todo 下载报告
        if request.query_params.get('download', None):
            summary_obj = SummaryModel.objects.get(result_report_id=execution_report_obj.id)
            # summary_count = summary_obj.summary_count
            summary_count = summary_obj.summary_count()
            file_name = '{0}.{1}'.format(int(time.time()), 'html')
            html_report = HTMLReport()
            html_data = html_report.generateHtmlData(summary_count)
            response = FileResponse(html_data.decode())
            response['Access-Control-Expose-Headers'] = 'Content-Disposition'
            response['Content-Type'] = 'application/octet-stream'
            response['Content-Disposition'] = 'attachment;filename={}'.format(file_name)
            return response

        if SummaryModel.objects.filter(result_report=execution_report_obj.id):
            summary_obj = SummaryModel.objects.get(result_report=execution_report_obj.id)
            # result_info = summary_obj.summary_count
            result_info = summary_obj.summary_count()
            result_info = summary_result_simple(result_info)
        else:
            result_info = {}
        return Response(result_info, status=HTTP_200_OK)

    def destroy(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"destory",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        obj = self.get_object()
        obj.setIsdeleteTrue()
        return Response({'message': '删除成功'}, HTTP_200_OK)


class ReportSummaryImageView(APIView):
    """报告详情 图片展示 -->弃用"""
    def get(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"get",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        img_url = self.request.query_params.get('img_url', '')
        if img_url:
            if not os.path.exists(img_url):
                return Response({'message': '图片不存在'}, HTTP_400_BAD_REQUEST)
            # img_url = settings.SCREENSHOT_DIR + '/11.png'
            # with open(img_url, 'rb') as f:
            #     data = base64.b64encode(f.read())
            # return Response({'img_base': data}, status=HTTP_200_OK)

            # 以二进制传送
            # with open(img_url, 'rb') as f:
            #     data = f.read()
            # response = FileResponse(data)
            # response['Content-Type'] = 'application/octet-stream'
            # file_name = os.path.basename(img_url)
            # response['Content-Disposition'] = 'attachment;filename={}'.format(file_name)
            # return response

            suffix = (img_url.split('.'))[-1]
            with open(img_url, 'rb') as f:
                data = f.read()
            if suffix == 'png':
                return HttpResponse(data, content_type='image/png', status=200)
            else:
                return HttpResponse(data, content_type='image/jpeg', status=200)
        else:
            return Response({'message': '图片路径为空'}, HTTP_400_BAD_REQUEST)

