from django.test import TestCase

# Create your tests here.

from selenium import webdriver

driver = webdriver.Remote("http://255.255.255.0:4444/wd/hub", webdriver.DesiredCapabilities.CHROME.copy())
# options = webdriver.ChromeOptions()
# driver = webdriver.Remote(desired_capabilities=options.to_capabilities())
driver.get("http://www.baidu.com")
driver.get_screenshot_as_file('/Screenshots/google.png')
