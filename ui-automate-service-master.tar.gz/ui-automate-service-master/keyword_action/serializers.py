from rest_framework.serializers import ModelSerializer
from .models import KeywordActionModel
from rest_framework import serializers


class KeywordActionSerializer(ModelSerializer):
    class Meta:
        model = KeywordActionModel
        exclude = ('is_delete', 'create_time', 'update_time')


class ActionNameSerializer(ModelSerializer):
    action_id = serializers.ReadOnlyField(source='id')
    action_name = serializers.ReadOnlyField(source='name')

    class Meta:
        model = KeywordActionModel
        # fields = ('action_id', 'action_name', 'description')
        fields = ('action_id', 'action_name', 'description', 'value_explain', 'image_type')
