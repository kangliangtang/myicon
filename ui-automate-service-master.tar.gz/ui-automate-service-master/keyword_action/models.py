from django.db import models
from utils.model import BaseModel

# Create your models here.


class KeywordActionModel(BaseModel):
    """关键字 动作"""
    CHOICES_IMAGE = (
        (0, '不支持'),
        (1, '支持')
    )
    name = models.CharField(unique=True, max_length=64, verbose_name='名称')
    description = models.TextField(verbose_name='描述信息')
    # value_explain = models.CharField(max_length=512, verbose_name='值说明')
    value_explain = models.SmallIntegerField(null=True, blank=True, verbose_name='值说明')
    weight = models.SmallIntegerField(null=True, blank=True, verbose_name='排序权重')
    image_type = models.SmallIntegerField(default=0, choices=CHOICES_IMAGE, null=True, blank=True, verbose_name='是否支持图片')

    class Meta:
        # managed = False
        db_table = 'tb_keyword_action'
        verbose_name = '关键字动作'
        verbose_name_plural = '关键字动作'
