from django.apps import AppConfig


class KeywordActionConfig(AppConfig):
    name = 'keyword_action'
