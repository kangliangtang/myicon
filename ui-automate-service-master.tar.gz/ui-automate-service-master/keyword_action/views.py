
from rest_framework.generics import ListAPIView

from .models import KeywordActionModel
from .serializers import KeywordActionSerializer, ActionNameSerializer
from rest_framework import filters
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.response import Response
from rest_framework.status import HTTP_200_OK


# Create your views here.


class KeywordActionView(ListAPIView):              # 只做展示功能
    """关键字/动作 视图"""
    serializer_class = KeywordActionSerializer
    queryset = None
    filter_backends = [filters.SearchFilter, filters.OrderingFilter, DjangoFilterBackend]
    search_fields = ('name', 'id')
    ordering = ('name',)

    def get_queryset(self):
        if self.kwargs['project_id']:
            return KeywordActionModel.objects.filter(is_delete=False)
        else:
            return KeywordActionModel.objects.none()


class ActionNameView(ListAPIView):
    """动作 名称"""
    # serializer_class = ActionNameSerializer
    # queryset = KeywordActionModel.objects.filter(is_delete=False).all()
    # ordering = ('name',)

    def get(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"list",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        if self.kwargs['project_id']:
            # query_set = KeywordActionModel.objects.filter(is_delete=False).all().order_by('name')
            query_set = KeywordActionModel.objects.filter(is_delete=False).all().order_by('-weight')
            serializer = ActionNameSerializer(query_set, many=True)
            return Response({'list': serializer.data}, HTTP_200_OK)
        else:
            return KeywordActionModel.objects.none()
