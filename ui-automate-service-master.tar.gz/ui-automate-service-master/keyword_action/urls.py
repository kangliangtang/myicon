from django.conf.urls import url, include
from .views import KeywordActionView, ActionNameView


urlpatterns = [
   url(r'^keywordAction$', KeywordActionView.as_view(), name='keywordAction'),
   url(r'^actionName', ActionNameView.as_view(), name='actionName'),
]


