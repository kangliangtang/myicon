from django.db import models, transaction
from utils.model import BaseModel
from page.models import PageModel
from django.conf import settings
# Create your models here.


class ElementModel(BaseModel):
    """元素管理"""
    name = models.CharField(max_length=64, verbose_name='元素名称')
    locmode = models.CharField(max_length=20, verbose_name='定位方式')
    location = models.CharField(max_length=512, verbose_name='定位标识')
    page = models.ForeignKey('page.PageModel', on_delete=models.CASCADE, verbose_name='所属页面')
    project = models.ForeignKey('project_crud.ProjectModel', on_delete=models.CASCADE, verbose_name='所属项目')
    creator = models.ForeignKey('user.UserModel', on_delete=models.CASCADE, verbose_name="创建人")
    note_info = models.CharField(max_length=512, null=True, verbose_name='备注信息')
    image_path = models.CharField(max_length=512, null=True, blank=True, verbose_name='元素图片')

    class Meta:
        db_table = 'tb_element'
        verbose_name = '元素管理'
        verbose_name_plural = '元素管理'

    @transaction.atomic
    def setIsdeleteTrue(self):
        self.is_delete = True
        self.save()

    def getImagePath(self):
        if self.image_path:
            image_url = settings.BASE_HOST + self.image_path
            return image_url
        else:
            return None


    # def getImageData(self):
    #     """获取图片数据"""
    #     if (self.locmode == 'image') and self.image_path:
    #         with open(self.image_path, 'rb') as f:
    #             image_data = f.read()
    #         return image_data
    #     else:
    #         return self.location
