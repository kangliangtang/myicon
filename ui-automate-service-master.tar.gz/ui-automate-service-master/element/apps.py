from django.apps import AppConfig


class ElementConfig(AppConfig):
    name = 'element'
