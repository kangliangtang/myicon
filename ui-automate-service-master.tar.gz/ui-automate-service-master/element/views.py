import json
from functools import reduce

from django.http import HttpResponse
from django.utils import timezone
import pytz
import os
import time
from django.contrib.auth.models import Group
from rest_framework.decorators import list_route, detail_route
from rest_framework.viewsets import ModelViewSet
from utils.get_elements import GetElements
from .models import ElementModel
from .serializers import ElementSerializer, ElementCreatorNameSerializer, ElementPageNameSerializer, \
    ElementNameSerializer
from rest_framework import filters
from rest_framework.filters import OrderingFilter
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.response import Response
from rest_framework.status import HTTP_200_OK, HTTP_400_BAD_REQUEST
from page.models import PageModel
from project_crud.models import ProjectModel
from django.conf import settings
from logging import getLogger
logger = getLogger('debug')
# Create your views here.


class ElementView(ModelViewSet):
    """元素管理 视图"""
    serializer_class = ElementSerializer
    queryset = None
    filter_backends = (filters.SearchFilter, DjangoFilterBackend, OrderingFilter)
    search_fields = ('name',)
    ordering = ('-create_time',)
    element_image_dir = settings.IMAGE_DIR

    def get_queryset(self):
        # user = self.request.user
        project_id = self.kwargs['project_id']
        if project_id:
            # 权限控制
            if self.request.user.is_superuser:
                query_set = ElementModel.objects.filter(is_delete=False)
            else:
                user_group = Group.objects.filter(user=self.request.user).all()
                query_set = ElementModel.objects.filter(is_delete=False, project_id=project_id, project__user_group__in=user_group).all()

            try:
                query_set = query_set.filter(project=project_id)
                # 时间查询
                if self.request.query_params.get('start_time') and self.request.query_params.get('end_time'):
                    start_time_str = self.request.query_params.get('start_time')
                    end_time_str = self.request.query_params.get('end_time')
                    tzinfo_ = None  # 因settings 中USE_TZ = False 2019-11-5
                    if settings.USE_TZ:
                        tzinfo_ = pytz.utc
                    start_time = timezone.datetime.strptime(start_time_str, '%Y-%m-%dT%H:%M:%S.%fZ').replace(
                        tzinfo=tzinfo_)
                    end_time = timezone.datetime.strptime(end_time_str, '%Y-%m-%dT%H:%M:%S.%fZ').replace(
                        tzinfo=tzinfo_)
                    # 前端日期插件，发送的时间比选择日期慢8h。 例如：选择2019-05-08，实际发送时间为2019-05-07T16:00:00.000Z
                    start_time += timezone.timedelta(hours=8)
                    end_time += timezone.timedelta(days=1, hours=8)
                    query_set = query_set.filter(create_time__range=(start_time, end_time))
                if self.request.query_params.get('user_id'):
                    user_id = self.request.query_params.get('user_id')
                    query_set = query_set.filter(creator=user_id)
                if self.request.query_params.get('name'):
                    name = self.request.query_params.get('name')
                    # query_set = query_set.filter(name=name)
                    query_set = query_set.filter(name__icontains=name)
                if self.request.query_params.get('page_id', ''):
                    page_id = self.request.query_params.get('page_id')
                    query_set = query_set.filter(page=page_id)
                return query_set.order_by('-create_time')
            except Exception:
                return ElementModel.objects.none()
        else:
            return ElementModel.objects.none()

    def partial_update(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"partial_update",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        return super(ElementView, self).partial_update(request, *args, **kwargs)

    def retrieve(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"retrieve",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        return super(ElementView, self).retrieve(request, *args, **kwargs)

    def list(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"list",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        return super(ElementView, self).list(request, *args, **kwargs)

    @list_route(methods=['GET'])
    def creatorNameList(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"creatorNameList",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        query_set = self.get_queryset().order_by('-create_time')
        serializer = ElementCreatorNameSerializer(query_set, many=True)
        data = json.loads(json.dumps(serializer.data))
        list_data = reduce(lambda x, y: x if y in x else x + [y], [[], ] + data)
        return Response({'list': list_data}, status=HTTP_200_OK)

    @list_route(methods=['GET'])
    def getPageList(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"getPageList",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        project_id = self.kwargs['project_id']
        if project_id:
            query_set = self.get_queryset().order_by('-create_time')
            serializer = ElementPageNameSerializer(query_set, many=True)
            data = json.loads(json.dumps(serializer.data))
            list_data = reduce(lambda x, y: x if y in x else x + [y], [[], ] + data)
            return Response({'list': list_data}, status=HTTP_200_OK)
        else:
            return ElementModel.objects.none()

    @detail_route(methods=['GET'])
    def elementNameList(self, request, pk, *args, **kwargs):
        """
            {
            "permission":{
                "action":"elementNameList",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        project_id = self.kwargs['project_id']
        # if PageModel.objects.filter(id=pk, is_delete=False).count() == 0:
        #     return Response({"message": "页面已不存在"}, HTTP_400_BAD_REQUEST)
        element_data = list()
        query_set = ElementModel.objects.filter(page_id=pk, is_delete=False, page__is_delete=False, page__is_public=False)
        if query_set:
            query_set = query_set.order_by('-create_time').all()
            serializer = ElementNameSerializer(query_set, many=True)
            element_data = json.loads(json.dumps(serializer.data))
        # 增加公共页面的下的所有元素
        public_element = []
        try:
            page_query = PageModel.objects.filter(name=settings.PUBLIC_PAGE_NAME, project_id=project_id, is_public=True, is_delete=False)
            if page_query:
                page_id = page_query.first().id
                public_element = list(ElementModel.objects.filter(page_id=page_id, is_delete=False).values('id', 'name'))
                public_element = [{'name': '(公共元素){0}'.format(name_dict['name']), 'element_id': name_dict['id']} for name_dict in public_element]
        except Exception as e:
            logger.error('Get public element error; project_id={0},page_id={1},error_msg={2}'.format(project_id, pk,e))
        element_data.extend(public_element)
        return Response({'list': element_data}, status=HTTP_200_OK)

    @list_route(methods=['GET'])
    def checkElementName(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"checkElementName",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        name = self.request.query_params.get('name', '')
        page_id = self.request.query_params.get('page', '')
        element_id = self.request.query_params.get('id', '')
        if all([name, page_id]):
            if element_id:
                if ElementModel.objects.exclude(id=element_id).filter(page_id=page_id, name=name, is_delete=False):
                    return Response({"message": "该页面下此元素名已存在"}, HTTP_400_BAD_REQUEST)
                return Response({'message': '校验通过'}, HTTP_200_OK)
            else:
                if ElementModel.objects.filter(page_id=page_id, name=name, is_delete=False):
                    return Response({"message": "该页面下此元素名已存在"}, HTTP_400_BAD_REQUEST)
                else:
                    return Response({'message': '校验通过'}, HTTP_200_OK)
        else:
            return Response({'message': '参数不完整'}, HTTP_400_BAD_REQUEST)

    @list_route(methods=['POST'])
    def uploadImage(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"uploadImage",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        try:
            if not self.request.FILES.get('image', None):
                return Response({"message": "未上传图片"}, HTTP_400_BAD_REQUEST)
            file_type = (self.request.FILES.get('image')).content_type
            if not file_type.startswith('image'):
                return Response({"message": "请上传图片文件类型"}, HTTP_400_BAD_REQUEST)

            image_obj = self.request.FILES.get('image')
            if image_obj.size > (1024 * 1024):
                return Response({"message": "图片大小应小于1M"}, HTTP_400_BAD_REQUEST)
            image_obj_name = image_obj.name.split('.')
            suffix = image_obj_name[-1]
            # 图片名称 采用16位时间戳
            new_image_name = '{0}.{1}'.format(int((time.time()) * 10 ** 6), suffix)
            image_file = os.path.join(self.element_image_dir, new_image_name)
            image_path = settings.IMAGE_PATH + new_image_name
            with open(image_file, 'wb') as f:
                for chunk in image_obj.chunks():
                    f.write(chunk)
            image_url = '{0}{1}'.format(settings.BASE_HOST, image_path)
            return Response({'image_url': image_url}, status=200)
        except Exception as e:
            return Response({'message':'上传图片失败Eroor:%s'%e}, status=HTTP_400_BAD_REQUEST)

    def create(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"create",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        data = self.request.data
        name = data.get('name', '')
        locmode = data.get('locmode', '')
        location = data.get('location', '')
        page_id = data.get('page', '')

        project_id = self.kwargs['project_id']
        if not all([name, locmode, page_id, project_id]):
            return Response({"message": "参数不完整"},  HTTP_400_BAD_REQUEST)
        user_obj = self.request.user
        note_info = data.get('note_info', '')
        if ElementModel.objects.filter(page_id=page_id, name=name, is_delete=False):
            return Response({"message": "同一页面下的元素名不能重复"},  HTTP_400_BAD_REQUEST)
        image_path = data.get('image_path', '')
        image_path = image_path.replace(settings.BASE_HOST, '')

        try:
            page_obj = PageModel.objects.get(id=page_id, is_delete=False)
            project_obj = ProjectModel.objects.get(id=project_id, is_delete=False, status=True)
            ElementModel.objects.create(
                name=name,
                locmode=locmode,
                location=location,
                page=page_obj,
                project=project_obj,
                creator=user_obj,
                note_info=note_info,
                image_path=image_path
            )
        except PageModel.DoesNotExist:
            return Response({"message": "元素保存失败, 页面(ID:{})不存在或已被删除".format(page_id)}, HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({"message": "元素保存失败 Error:%s" % e}, HTTP_400_BAD_REQUEST)
        else:
            return Response({'message': "保存成功"}, HTTP_200_OK)

    def destroy(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"destroy",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        obj = self.get_object()
        obj.setIsdeleteTrue()
        return Response({'message':'删除成功'}, HTTP_200_OK)

    def update(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"update",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        pk = kwargs['pk']
        data = self.request.data
        name = data.get('name', '')
        locmode = data.get('locmode', '')
        location = data.get('location', '')
        page_id = data.get('page', '')
        project_id = self.kwargs['project_id']
        if not all([name, locmode, page_id, project_id]):
            return Response({"message": "参数不完整"}, HTTP_400_BAD_REQUEST)
        note_info = data.get('note_info', '')
        if ElementModel.objects.exclude(id=pk).filter(page_id=page_id, name=name, is_delete=False):
            return Response({"message": "同一页面下的元素名不能重复"}, HTTP_400_BAD_REQUEST)
        image_path = data.get('image_path', '')
        image_path = image_path.replace(settings.BASE_HOST, '')

        try:
            page_obj = PageModel.objects.get(id=page_id, is_delete=False)
            project_obj = ProjectModel.objects.get(id=project_id, is_delete=False, status=True)
            ElementModel.objects.filter(id=pk).update(
                name=name,
                locmode=locmode,
                location=location,
                page=page_obj,
                project=project_obj,
                # creator=user_obj,
                note_info=note_info,
                image_path=image_path
            )
        except PageModel.DoesNotExist:
            return Response({"message": "修改失败, 页面(ID:{})不存在或已被删除".format(page_id)}, HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({"message": "修改失败 Error:%s" % e}, HTTP_400_BAD_REQUEST)
        else:
            return Response({"message": "修改成功"}, HTTP_200_OK)

    @list_route(methods=['POST'])
    def pageElements(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"pageElements",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        data = request.data
        host = data.get('env_host', '')
        page_id = data.get('page_id', '')
        if PageModel.objects.filter(id=page_id, is_delete=False):
            path = PageModel.objects.get(id=page_id).url
        else:
            return Response({"message": "该页面不存在"}, HTTP_400_BAD_REQUEST)
        login = data.get('login', False)
        try:
            elements_list = GetElements(host+path, login).getElements()
            if elements_list is False:
                return Response({"message": "登录失败，请重新确认URL或元素"}, HTTP_400_BAD_REQUEST)
            elements_list['page_id'] = page_id
            return Response( elements_list, HTTP_200_OK)
        except Exception as e:
            logger.error('get elements fail.{}'.format(e))
            return Response({"message": "获取元素失败"}, HTTP_400_BAD_REQUEST)

    @list_route(methods=['POST'])
    def saveElements(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"saveElements",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        project_id = self.kwargs['project_id']
        user_obj = self.request.user
        data = request.data
        elements = data.get('elements', '')
        page_id = data.get('page_id', '')
        for element in elements:
            if ElementModel.objects.filter(page_id=page_id, name=element['name'], is_delete=False):
                element['name'] = '{}_{}'.format(element['name'],int(time.time() * 1000))
            image_path = element.get('image_path', '')
            logger.info('image_path:{}'.format(image_path))
            image_path = image_path.replace(settings.BASE_HOST, '')
            ElementModel.objects.create(
                name=element['name'],
                locmode=element['locmode'],
                location=element.get('location', ''),
                page_id=page_id,
                project_id=project_id,
                creator=user_obj,
                note_info=element['note_info'],
                image_path=image_path
            )
        return Response({"message": "保存成功"}, HTTP_200_OK)
