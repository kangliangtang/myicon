from rest_framework import serializers
from .models import ElementModel


class ElementSerializer(serializers.ModelSerializer):
    page_name = serializers.ReadOnlyField(source='page.name')            # 页面名
    creator_name = serializers.ReadOnlyField(source='creator.username')  # 创建人姓名
    image_path = serializers.ReadOnlyField(source='getImagePath')

    class Meta:
        model = ElementModel
        # fields = ('id', 'name', 'create_time', 'note_info')
        # exclude = ('image_path',)
        fields = '__all__'


class ElementCreatorNameSerializer(serializers.ModelSerializer):
    """页面创建人"""
    # 用于筛选表单
    user_id = serializers.ReadOnlyField(source='creator.id')
    creator_name = serializers.ReadOnlyField(source='creator.username')  # 创建人姓名

    class Meta:
        model = ElementModel
        fields = ('user_id', 'creator_name')


class ElementPageNameSerializer(serializers.ModelSerializer):
    """元素表中的所有所属页面名称 ID"""
    # 用于筛选表单
    page_name = serializers.ReadOnlyField(source='page.name')  # 页面名
    page_id = serializers.ReadOnlyField(source='page.id')

    class Meta:
        model = ElementModel
        fields = ('page_id', 'page_name')


class ElementNameSerializer(serializers.ModelSerializer):
    """元素名称 id"""
    element_id = serializers.ReadOnlyField(source='id')

    class Meta:
        model = ElementModel
        fields = ('element_id', 'name')
