from django.apps import AppConfig


class ProjectCrudConfig(AppConfig):
    name = 'project_crud'
