import datetime

from django.db import models
from django.db.models import Manager
# Create your models here.
from user.models import UserModel
from utils.model import BaseModel
from django.contrib.auth.models import Group
# from utils import permission


class ProjectModelManager(Manager):

    def importProject(self, name, id, code,username ,user_id):
        if not self.model.objects.filter(id=id, is_delete=False).exists():
            obj = self.model.objects.create(
                id=id,
                name=name,
                code=code
            )
            obj.env_info=[]
            group_obj = obj.createProjectGroup()
            obj.user_group = group_obj
            # try:
            #     user = UserModel.objects.get(choerodon_id=user_id)
            # except UserModel.DoesNotExist as e:
            #     user = UserModel.objects.create(username=username, choerodon_id=user_id, email='none.email.com')
            user = self.create_user(username, user_id)
            group_obj.user_set.add(user)
            obj.save()
            return obj, user

    def create_user(self, username, user_id):
        try:
            user = UserModel.objects.get(choerodon_id=user_id)
        except UserModel.DoesNotExist as e:
            user = UserModel.objects.create(username=username, choerodon_id=user_id, email='none.email.com')
        return user


class ProjectModel(BaseModel):
    id = models.AutoField(primary_key=True, verbose_name='项目id')
    name = models.CharField(max_length=255, verbose_name='项目名称')
    owner = models.ManyToManyField('user.UserModel', verbose_name='项目owner')
    env_info = models.TextField(verbose_name='项目环境', null=True, blank=True)
    status = models.BooleanField(verbose_name='项目状态', default=True)
    organization_id = models.IntegerField(null=True, blank=True, verbose_name='组织id')
    code = models.CharField(max_length=32, null=True, blank=True, verbose_name='项目代码')
    user_group = models.OneToOneField(Group, on_delete=models.CASCADE, null=True, blank=True, verbose_name='组成员')

    objects = ProjectModelManager()

    class Meta:
        db_table = 'tb_project'
        verbose_name = '项目'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.name

    def setIsdeleteTrue(self):
        self.is_delete = True
        self.save()
    def addProjectUser(self, user_obj):
        self.user_group.user_set.add(user_obj)

    def addProjectLead(self, user):
        self.owner.add(user)
        # permission.projectLead(user)

    def stop(self):
        self.status = False
        self.save()

    def reopen(self):
        self.status = True
        self.save()

    def createProjectGroup(self):
        """
        创建项目组
        :return:
        """
        group_obj = Group.objects.create(
            name = self.name + '用户组_' + str(self.id)
        )
        # permission.groupPermissionList(group_obj)
        # project_leads = self.owner.all()
        # for project_lead in project_leads:
            # permission.projectLead(project_lead)
        return group_obj

    def removeUser(self, user_obj):
        self.user_group.user_set.remove(user_obj)
        self.owner.remove(user_obj)

    def addPage(self, n=1):
        self.projectdata.page_count += n
        self.projectdata.save()
        
    def deletePage(self, n=1):
        if self.projectdata.page_count > 0:
            self.projectdata.page_count -= n
            self.projectdata.save()

    def addCase(self, n=1):
        if hasattr(self, 'projectdata'):
            self.projectdata.case_count += n
            self.projectdata.save()
        else:
            ProjectData.objects.create(project=self, case_count=1)

    def deleteCase(self, n=1):
        if self.projectdata.case_count > 0:
            self.projectdata.case_count -= n
            self.projectdata.save()

    def addSuessCase(self, n=1):
        try:
            now_data = datetime.datetime.now()
            run_data_obj = self.project_run_data.filter(date=now_data)
            if run_data_obj.__len__() <= 0:
                run_data_obj = self.project_run_data.create(date=now_data,case_success_count=1)
            else:
                run_data_obj.update(case_success_count = run_data_obj.first().case_success_count + n)
        except Exception:
            pass

    def addfailCase(self, n=1):
        try:
            now_data = datetime.datetime.now()
            run_data_obj = self.project_run_data.filter(date=now_data)
            if run_data_obj.__len__() <= 0:
                run_data_obj = self.project_run_data.create(date=now_data, case_fail_count=1)
            else:
                run_data_obj.update(case_fail_count = run_data_obj.first().case_fail_count + n)
        except Exception:
            pass

    def addRunCase(self, n=1):
        try:
            now_data = datetime.datetime.now()
            run_data_obj = self.project_run_data.filter(date=now_data)
            if run_data_obj.__len__() <= 0:
                run_data_obj = self.project_run_data.create(date=now_data, case_run_count=1)
            else:
                run_data_obj.update(case_run_count = run_data_obj.first().case_run_count + n)
        except Exception:
            pass

    def addScen(self, n=1):
        self.projectdata.scene_count += n
        self.projectdata.save()

    def deleteScen(self, n=1):
        if self.projectdata.scene_count > 0:
            self.projectdata.scene_count -= n
            self.projectdata.save()


class ProjectData(models.Model):
    case_count = models.IntegerField(default=0)
    scene_count = models.IntegerField(default=0)
    page_count = models.IntegerField(default=0)
    project = models.OneToOneField(ProjectModel, on_delete=models.CASCADE, related_name='projectdata')

    class Meta:
        db_table='tb_project_data'


class ProjectRunData(models.Model):
    case_run_count = models.IntegerField(default=0)
    date = models.DateField(auto_now_add=True)
    case_success_count = models.IntegerField(default=0)
    case_fail_count = models.IntegerField(default=0)
    project = models.ForeignKey(ProjectModel, on_delete=models.CASCADE, related_name='project_run_data')

    class Meta:
        db_table = 'tb_project_run_data'


class SteamProjectModelManager(Manager):

    def importProject(self, name, id, code):
        if not self.model.objects.filter(id=id, is_delete=False).exists():
            obj = self.model.objects.create(
                id=id,
                name=name,
                code=code
            )
            group_obj = obj.createProjectGroup()
            obj.user_group = group_obj
            obj.save()
            return obj


class  SteamProject(BaseModel):
    """这个表不要了"""
    id= models.AutoField(primary_key=True, verbose_name='项目id')
    name = models.CharField(max_length=225, verbose_name='行云的项目名')
    code = models.CharField(max_length=32, verbose_name='项目code')
    status = models.BooleanField(default=True, verbose_name='项目状态')
    owner = models.ManyToManyField('user.UserModel', verbose_name='项目owner')
    user_group = models.OneToOneField(Group, on_delete=models.CASCADE, null=True, blank=True, verbose_name='组成员')
    objects = SteamProjectModelManager()

    class Meta:
        db_table = 'tb_steam_project'
        verbose_name = '项目'
        verbose_name_plural = verbose_name

    def addProjectUser(self, user_obj):
        self.user_group.user_set.add(user_obj)

    def addProjectLead(self, user):
        self.owner.add(user)
        # permission.projectLead(user)
        test_project_queryset = ProjectModel.objects.filter(project_steam_id=self.id)
        for test_project in test_project_queryset:
            test_project.addProjectLead(user)

    def removeUser(self, user_obj):
        self.user_group.user_set.remove(user_obj)
        test_project_queryset = ProjectModel.objects.filter(project_steam_id=self.id)
        for test_project in test_project_queryset:
            test_project.owner.remove(user_obj)

    def stop(self):
        self.status = False
        self.save()
        for test_project in ProjectModel.objects.filter(project_steam_id=self.id).all():
            test_project.stop()

    def reopen(self):
        self.status = True
        self.save()
        for test_project in ProjectModel.objects.filter(project_steam_id=self.id).all():
            test_project.reopen()

    def createProjectGroup(self):
        """
        创建项目组
        :return:
        """
        group_obj = Group.objects.create(
            name = self.name + '用户组_' + str(self.id)
        )
        # permission.groupPermissionList(group_obj)
        project_leads = self.owner.all()
        # for project_lead in project_leads:
            # permission.projectLead(project_lead)
        return group_obj

