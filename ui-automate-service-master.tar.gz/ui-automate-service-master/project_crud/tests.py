

from django.test import TestCase

# Create your tests here.
# import os
#
# from django.utils.datetime_safe import datetime
#
#
# def fun1():
#     os.environ.setdefault("DJANGO_SETTINGS_MODULE", "automate_uitest_py3.settings")
#
#     import django
#
#     django.setup()
#     from project_crud.models import ProjectModel, ProjectRunData
#     # print(ProjectRunData.objects.filter(date=datetime.now()).all())
#
#
#     project_obj = ProjectModel.objects.get(id=3)
#     project_obj.deleteCase()
#     project_obj.deleteScen()
#
# if __name__ == '__main__':
#     fun1()
