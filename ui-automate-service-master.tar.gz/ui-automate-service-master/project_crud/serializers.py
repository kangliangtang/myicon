from rest_framework.serializers import ModelSerializer
from rest_framework import serializers
from project_crud.models import ProjectModel, ProjectData, ProjectRunData
from user.models import UserModel
from user.serializers import OnwerSerializer, GroupSerializer
from utils.serializer import ZJsonField



class ImportProjectSerializer(serializers.ModelSerializer):
    name = serializers.ReadOnlyField()
    class Meta:
        model = ProjectModel
        fields = ('id','name','code','organization_id','status')


class ProjectListSerializer(serializers.Serializer):
    id = serializers.ReadOnlyField()
    name = serializers.ReadOnlyField()

    class Meta:
        model = ProjectModel
        fields = ('id', 'name')


class ProjectSerializer(ModelSerializer):
    name = serializers.ReadOnlyField()
    id = serializers.ReadOnlyField()
    env_info = ZJsonField()
    # owner = OnwerSerializer(many=True, read_only=True)
    # user_group = GroupSerializer(read_only=True)
    status = serializers.ReadOnlyField()

    def validate_leaders(self, values):
        del values
        return

    class Meta:
        model=ProjectModel
        fields = ("id","name","env_info","status")


class ProjectDataSerializer(serializers.ModelSerializer):

    class Meta:
        model=ProjectData
        fields = ('case_count', 'page_count','scene_count')


class ProjectRunDataSerializer(serializers.ModelSerializer):

    class Meta:
        model=ProjectRunData
        fields=('date', 'case_run_count')


class ProjectRunfailDataSerializer(serializers.ModelSerializer):

    class Meta:
        model=ProjectRunData
        fields=('date', 'case_fail_count', 'case_success_count')


