from django.conf.urls import url, include
from rest_framework.routers import DefaultRouter

from .api_views import *
from . import views

project_router = DefaultRouter(trailing_slash=False)
project_router.register(r'projects', views.ProjectAPIViewSet, base_name='project')
urlpatterns = [
   url(r'^group$', ProjectGroupAPIView.as_view()),
   url(r'^projects$', ImportProjectAPIView.as_view()),
   url(r'^projects/closed$', ClosedAPIView.as_view()),
   url(r'^projects/reopen$', ReopenAPIView.as_view()),
]

