import json
from logging import getLogger

from django.db import transaction
from project_crud.serializers import ImportProjectSerializer
from user.models import UserModel
from rest_framework.response import Response
from rest_framework.status import HTTP_200_OK, HTTP_201_CREATED, HTTP_400_BAD_REQUEST
from rest_framework.views import APIView
from project_crud.models import ProjectModel

debuglog = getLogger('debug')


class ImportProjectAPIView(APIView):
    authentication_classes = []
    permission_classes = []
    queryset = None
    serializer_class = ImportProjectSerializer

    def get_queryset(self):
        return ProjectModel.objects.all()

    @transaction.atomic
    def post(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"create",
            "menuLevel":null,
            "permissionLevel":null,
            "roles":[

            ],
            "permissionLogin":false,
            "permissionPublic":false,
            "permissionWithin":true
        },
        "label":null
        }"""
        project_data = request.data
        debuglog.info('post-project--创建项目-', project_data)
        instance, user_obj = ProjectModel.objects.importProject(
            id=project_data['projectId'],
            name=project_data['projectName'],
            code=project_data['projectCode'],
            username=project_data['userName'],
            user_id=project_data['userId'],
        )
        # 项目导入时，默认增加一个'公共页面'
        from page.models import PageModel
        from automate_uitest_py3 import settings
        if not PageModel.objects.filter(project_id=project_data['projectId'], name=settings.PUBLIC_PAGE_NAME, is_delete=False, is_public=True):
            PageModel.objects.create(
                name=settings.PUBLIC_PAGE_NAME,
                url='/',
                project_id=project_data['projectId'],
                creator_id=user_obj.id,
                is_public=True
            )
        return Response({'message': '导入项目成功','data': project_data}, status=HTTP_201_CREATED)

    @transaction.atomic
    def put(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"create",
            "menuLevel":null,
            "permissionLevel":null,
            "roles":[

            ],
            "permissionLogin":false,
            "permissionPublic":false,
            "permissionWithin":true
        },
        "label":null
        }"""
        project_data_ = request.data
        debuglog.info('update-project--更新项目-', project_data_)
        try:
            project_obj = ProjectModel.objects.get(
                id=project_data_['projectId']
            )
        except ProjectModel.DoesNotExist as e:
            debuglog.exception(e)
            return Response({'message': '项目不存在'}, status=HTTP_400_BAD_REQUEST)
        project_obj.name = project_data_['projectName']
        project_obj.code = project_data_['projectCode']
        project_obj.save()
        return Response({'message': '更新成功', 'data': project_data_}, status=HTTP_200_OK)

class ProjectGroupAPIView(APIView):
    authentication_classes = []
    permission_classes = []

    @transaction.atomic
    def post(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"post",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":false,
            "permissionPublic":false,
            "permissionWithin":true
        },
        "label":null
        }"""
        project_group_data_ = request.data
        debuglog.info('post--group--添加项目-',project_group_data_)
        for user in project_group_data_:
            if user.get('resourceType') == 'project':
                try:
                    project_obj = ProjectModel.objects.get(id=user.get('resourceId'), is_delete=False)
                except ProjectModel.DoesNotExist as e:
                    debuglog.exception(e)
                    return Response({'message': '项目不存在'} ,status=HTTP_400_BAD_REQUEST)
                else:
                    try:
                        user_obj = UserModel.objects.get(choerodon_id=user.get('userId'))
                    except UserModel.DoesNotExist:
                        user_obj = UserModel.objects.create(choerodon_id=user.get('userId'), username=user.get('username'))
                    project_obj.addProjectUser(user_obj)
        return Response({'message': '成功加入项目组',"data": project_group_data_}, status=HTTP_201_CREATED)

    @transaction.atomic
    def put(self, request):
        """
        {
        "permission":{
            "action":"delete",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":false,
            "permissionPublic":false,
            "permissionWithin":true
        },
        "label":null
        }"""
        project_group_data_ = request.data
        debuglog.info('delete--group-删除项目成员--', project_group_data_)
        for user in project_group_data_:
            if user.get('resourceType') == 'project':
                try:
                    project_obj = ProjectModel.objects.get(id=user.get('resourceId'), is_delete=False)
                except ProjectModel.DoesNotExist as e:
                    debuglog.exception(e)
                else:
                    try:
                        user_obj = UserModel.objects.get(choerodon_id=user.get('userId'))
                    except UserModel.DoesNotExist:
                        user_obj = UserModel.objects.create(choerodon_id=user.get('userId'), username=user.get('username'))
                    # 从项目中移除该名用户，不管是项目管理员还是项目成员
                    project_obj.removeUser(user_obj)
        return Response({"message": "已删除", "data": project_group_data_}, status=HTTP_200_OK)


class ClosedAPIView(APIView):
    authentication_classes = []
    permission_classes = []

    @transaction.atomic
    def post(self, request):
        """
        {
        "permission":{
            "action":"post",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":false,
            "permissionPublic":false,
            "permissionWithin":true
        },
        "label":null
        }"""
        project_data = request.data
        debuglog.info('stop--project--禁用项目',project_data)
        pk = project_data.get('projectId')
        try:
            ProjectModel.objects.get(id=pk).stop()
        except ProjectModel.DoesNotExist as e:
            debuglog.exception(e)
            return Response({'message': '冇找到项目', "data": project_data}, status=HTTP_400_BAD_REQUEST)
        else:
            return Response({'message': '已禁用项目', "data": project_data}, status=HTTP_200_OK)


class ReopenAPIView(APIView):
    authentication_classes = []
    permission_classes = []

    @transaction.atomic
    def post(self, request):
        """
        {
        "permission":{
            "action":"post",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        project_data = request.data
        debuglog.info('reopen--project--重新启用项目-', project_data)
        pk = project_data.get('projectId')
        try:
            ProjectModel.objects.get(id=pk).reopen()
        except ProjectModel.DoesNotExist as e:
            debuglog.exception(e)
            return Response({'message': '冇找到项目', "data": project_data}, status=HTTP_400_BAD_REQUEST)
        else:
            return Response({'message': '已启用项目', "data": project_data}, status=HTTP_200_OK)
