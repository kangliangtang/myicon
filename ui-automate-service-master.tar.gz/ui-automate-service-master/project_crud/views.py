from django.contrib.auth.models import Group
# from rest_framework.decorators import detail_route
from rest_framework.decorators import list_route, detail_route
from rest_framework.response import Response
from rest_framework.status import HTTP_403_FORBIDDEN, HTTP_200_OK
from rest_framework.viewsets import ModelViewSet

from project_crud.models import ProjectModel, ProjectData
from project_crud.serializers import ProjectSerializer, ProjectDataSerializer, ProjectRunDataSerializer, \
    ProjectRunfailDataSerializer, ProjectListSerializer


class ProjectAPIViewSet(ModelViewSet):
    pagination_class = None
    serializer_class = ProjectSerializer
    queryset = None
    lookup_field = 'project_id'

    def get_queryset(self):
        if self.request.user.is_superuser:
            return ProjectModel.objects.filter(is_delete=False)
        else:
            user_group = Group.objects.filter(user=self.request.user).all()
            return ProjectModel.objects.filter(is_delete=False, user_group__in=user_group, status=True).all()

    def retrieve(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"retrieve",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        self.lookup_field = 'id'
        self.kwargs['id'] = self.kwargs['project_id']
        return super(ProjectAPIViewSet, self).retrieve(request, *args, **kwargs)

    def list(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"list",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        self.serializer_class = ProjectListSerializer
        queryset = self.filter_queryset(self.get_queryset())
        serializer = self.get_serializer(queryset.values('id', 'name'), many=True)
        return Response({'list': serializer.data})

    def partial_update(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"partial_update",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        self.lookup_field = 'id'
        self.kwargs['id'] = self.kwargs['project_id']
        # return super(ProjectAPIViewSet, self).partial_update(request, *args, **kwargs)
        return Response({"message":"ok"})

    def update(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"update",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        import json
        data = request.data
        self.lookup_field = 'id'
        self.kwargs['id'] = self.kwargs['project_id']
        project_obj = ProjectModel.objects.get(id=self.kwargs['id'])
        project_obj.env_info = json.dumps(data['env_info'])
        project_obj.save(update_fields=['env_info',])
        # return super(ProjectAPIViewSet, self).update(request, *args, **kwargs)
        return Response({"message": "保存成功"})

    def create(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"create",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        # return super().create(request, *args, **kwargs)
        return Response({"message": "不能新建项目"}, status=HTTP_403_FORBIDDEN)

    def destroy(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"destory",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        self.lookup_field = 'id'
        self.kwargs['id'] = self.kwargs['project_id']
        # return super().destroy(request, *args, **kwargs)
        # self.get_object().setDeleteTrue()
        return Response({"message": "不能删除项目"}, status=HTTP_403_FORBIDDEN)

    @detail_route(methods=['GET'])
    def data(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"data",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        self.lookup_field = 'id'
        self.kwargs['id'] = self.kwargs['project_id']
        from django.utils.datetime_safe import datetime
        now_time = datetime.now()
        try:
            data_obj = self.get_object().projectdata
        except ProjectData.DoesNotExist :
            project_obj = self.get_object()
            data_obj = ProjectData.objects.create(project=self.get_object())
            project_obj.projectdata = data_obj
            project_obj.save()
        serializer = ProjectDataSerializer(data_obj)
        from dateutil.relativedelta import relativedelta
        import datetime
        last_date = datetime.date.today() - relativedelta(months=12)
        # run_data_obj = self.get_object().project_run_data.filter(date__year=now_time.year).all()
        run_data_obj = self.get_object().project_run_data.filter(date__gt=last_date).all()
        run_serizlier = ProjectRunDataSerializer(run_data_obj, many=True)
        run_fail_serizlier = ProjectRunfailDataSerializer(run_data_obj, many=True)
        return Response({
            'project_data': serializer.data,
            "case_run_data": run_serizlier.data,
            "case_run_fail_sues_data":run_fail_serizlier.data
        })

    @list_route(methods=['GET'])
    def projectMembers(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"projectMembers",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        project_id = self.kwargs['project_id']
        try:
            if project_id:
                from user.serializers import projecMembersSerializer
                user_group = ProjectModel.objects.filter(id=project_id).first().user_group
                user_all = user_group.user_set.all()
                serializer = projecMembersSerializer(user_all, many=True)
                return Response({'list': serializer.data}, HTTP_200_OK)
            else:
                return Response({'list': []}, HTTP_200_OK)
        except Exception:
            return Response({'list': []}, HTTP_200_OK)
