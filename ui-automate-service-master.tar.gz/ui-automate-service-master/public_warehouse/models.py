from django.db import models, transaction
from utils.model import BaseModel
import json
from logging import getLogger
logger = getLogger('debug')
# Create your models here.


class PublicFileModel(BaseModel):
    """文件管理"""
    file_name = models.CharField(max_length=256, verbose_name='文件名')
    suffix = models.CharField(max_length=64, null=True, verbose_name='文件名后缀')
    user = models.CharField(max_length=64, verbose_name='上传人')
    file_path = models.FilePathField(verbose_name='文件存储路径', null=True, blank=True)
    project = models.ForeignKey('project_crud.ProjectModel', on_delete=models.CASCADE, verbose_name='所属项目')

    class Meta:
        db_table = "tb_public_file"
        verbose_name = '文件管理'
        verbose_name_plural = '文件管理'

    @transaction.atomic
    def setIsdeleteTrue(self):
        self.is_delete = True
        self.save()


class PublicVariableModel(BaseModel):
    """公共变量"""
    CHOICES_TYPES = (
        ('Time', '时间戳'),
        ('Random', '随机数'),
        ('Str', '字符串'),
        ('Choices', '指定随机值')
    )
    name = models.CharField(max_length=64, verbose_name='变量名')
    variable_type = models.CharField(default='Str', max_length=64, choices=CHOICES_TYPES, null=True, verbose_name='变量类型')
    days = models.CharField(max_length=64, null=True, verbose_name='时间偏移天数')
    minnum = models.BigIntegerField(null=True, verbose_name='随机数开始值')
    maxnum = models.BigIntegerField(null=True, verbose_name='随机数结束值')
    array = models.CharField(max_length=128, null=True, blank=True, verbose_name='指定数组')
    # value = models.CharField(max_length=64, null=True, blank=True, verbose_name='参数值')
    value = models.CharField(max_length=256, null=True, blank=True, verbose_name='参数值')
    project = models.ForeignKey('project_crud.ProjectModel', null=True, on_delete=models.CASCADE, verbose_name='所属项目')
    time_format = models.CharField(max_length=512, null=True, blank=True, verbose_name='时间格式')

    class Meta:
        db_table = "tb_public_variable"
        verbose_name = '公共变量'
        verbose_name_plural = '公共变量'

    @transaction.atomic
    def setIsdeleteTrue(self):
        self.is_delete = True
        self.save()

    def getTimeOffset(self):
        if self.days:
            time_offset = 1
        else:
            time_offset = 0
        return time_offset


class PublicActionModel(BaseModel):
    """公共动作"""
    name = models.CharField(max_length=64, verbose_name='动作名')
    content = models.TextField(null=True, verbose_name='动作内容')
    creator = models.ForeignKey('user.UserModel', null=True, verbose_name='创建人')
    note_info = models.CharField(max_length=512, null=True, blank=True, verbose_name='备注信息')
    project = models.ForeignKey('project_crud.ProjectModel', null=True, blank=True, verbose_name='所属项目')

    class Meta:
        db_table = "tb_public_action"
        verbose_name = '公共动作'
        verbose_name_plural = '公共动作'

    @transaction.atomic
    def setIsdeleteTrue(self):
        self.is_delete = True
        self.save()

    def updateContentPageName(self):
        """更新page name"""
        try:
            from page.models import PageModel
            content_ = self.content
            if isinstance(self.content, str):
                content_ = json.loads(self.content)
            for content_dict in content_:
                page_id = content_dict["page_id"]
                page_name = PageModel.objects.get(id=page_id).name
                content_dict["page_name"] = page_name
            # self.content = json.dumps(content_)
            self.content = content_
        except Exception as e:
            logger.error('PublicActionModel updateContentPageName error:project={}, public_action_name={}, content={}, '
                         'error_msg={}'.format(self.project,self.name, self.content, e))
            self.content = list()
        finally:
            # return json.loads(self.content)
            return self.content
