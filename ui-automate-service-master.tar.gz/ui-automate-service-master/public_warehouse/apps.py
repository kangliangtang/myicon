from django.apps import AppConfig


class PublicWarehouseConfig(AppConfig):
    name = 'public_warehouse'
