#!/usr/bin/python
# -*- coding: utf-8 -*-

import json
import time
from functools import reduce
import chardet
from django.contrib.auth.models import Group
from django.utils import timezone
import pytz
from django.shortcuts import render

# Create your views here.
from django_filters.rest_framework.backends import DjangoFilterBackend
from rest_framework import viewsets, filters
# from rest_framework.decorators import list_route
# from rest_framework.filters import DjangoFilterBackend
from rest_framework.decorators import list_route
from rest_framework.generics import ListCreateAPIView, DestroyAPIView
from rest_framework.response import Response
from rest_framework.status import HTTP_200_OK, HTTP_400_BAD_REQUEST, HTTP_403_FORBIDDEN
from rest_framework.viewsets import ModelViewSet
from project_crud.models import ProjectModel
from public_warehouse.models import PublicFileModel, PublicActionModel, PublicVariableModel
from public_warehouse.serializers import PublicFileSerializer, PublicActionSerializer, PublicVariableSerializer, \
    PublicActionCreatorSerializer, PublicFileUserNameSerializer
# from django.conf import settings
from automate_uitest_py3 import settings
from logging import getLogger

from user.models import UserModel

debug_log = getLogger('debug')


class PublicFileAPIView(ListCreateAPIView, DestroyAPIView, viewsets.ViewSet):
    """文件上传 视图类"""
    serializer_class = PublicFileSerializer
    queryset = None
    filter_backends = [filters.SearchFilter, filters.OrderingFilter, DjangoFilterBackend]
    search_fields = ('file_name',)
    filter_fields = ('file_name', 'project_id')
    ordering = ('-create_time',)
    public_file_path = settings.PUBLIC_FILE_DIR

    def get_queryset(self):
        """获取当前项目下所有文件"""
        # user_obj = self.request.user
        if self.kwargs['project_id']:
            project_id = self.kwargs['project_id']
            # 权限控制
            if self.request.user.is_superuser:
                query_set = PublicFileModel.objects.filter(is_delete=False)
            else:
                user_group = Group.objects.filter(user=self.request.user).all()
                query_set = PublicFileModel.objects.filter(is_delete=False, project_id=project_id, project__user_group__in=user_group).all()
            try:
                query_set = query_set.filter(project_id=project_id)
                # 时间查询
                if self.request.query_params.get('start_time') and self.request.query_params.get('end_time'):
                    start_time_str = self.request.query_params.get('start_time')
                    end_time_str = self.request.query_params.get('end_time')
                    tzinfo_ = None  # 因settings 中USE_TZ = False 2019-11-5
                    if settings.USE_TZ:
                        tzinfo_ = pytz.utc
                    start_time = timezone.datetime.strptime(start_time_str, '%Y-%m-%dT%H:%M:%S.%fZ').replace(
                        tzinfo=tzinfo_)
                    end_time = timezone.datetime.strptime(end_time_str, '%Y-%m-%dT%H:%M:%S.%fZ').replace(
                        tzinfo=tzinfo_)
                    # 前端日期插件，发送的时间比选择日期慢8h。 例如：选择2019-05-08，实际发送时间为2019-05-07T16:00:00.000Z
                    start_time += timezone.timedelta(hours=8)
                    end_time += timezone.timedelta(days=1, hours=8)
                    query_set = query_set.filter(create_time__range=(start_time, end_time))
                if self.request.query_params.get('user'):
                    user = self.request.query_params.get('user')
                    query_set = query_set.filter(user=user)
                if self.request.query_params.get('name'):
                    name = self.request.query_params.get('name')
                    # query_set = query_set.filter(name=name)
                    query_set = query_set.filter(file_name__icontains=name)
                return query_set
            except Exception:
                return PublicFileModel.objects.none()
        else:
            return PublicFileModel.objects.none()


    def list(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"list",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        return super(PublicFileAPIView, self).list(request, *args, **kwargs)

    @list_route(methods=['GET'])
    def creatorNameList(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"creatorNameList",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        query_set = self.get_queryset().order_by('-create_time')
        serializer = PublicFileUserNameSerializer(query_set, many=True)
        data = json.loads(json.dumps(serializer.data))
        list_data = reduce(lambda x, y: x if y in x else x + [y], [[], ] + data)
        return Response({'list': list_data}, status=HTTP_200_OK)

    @list_route(methods=['GET'])
    def checkFileName(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"checkFileName",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        project_id = self.kwargs['project_id']
        name = self.request.query_params.get('name', '')
        if all([project_id, name]):
            file_obj_name = name.split('.')
            file_name = file_obj_name[0]
            suffix = ''
            if len(file_obj_name) > 1:
                file_name = '.'.join(file_obj_name[0:-1])
                suffix = file_obj_name[-1]
            if PublicFileModel.objects.filter(file_name=file_name, project_id=project_id, is_delete=False):
                return Response({'message': '此文件名已存在'}, HTTP_400_BAD_REQUEST)
            else:
                return Response({'message': '校验通过'}, HTTP_200_OK)
        else:
            return Response({'message': '校验参数不完整'}, HTTP_400_BAD_REQUEST)

    def create(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"create",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        project_id = self.kwargs['project_id']
        file_obj = self.request.FILES.get('file', None)
        if project_id is None:
            return Response({'message': '请选择项目'}, HTTP_400_BAD_REQUEST)
        if file_obj is None:
            return Response({'message': '未选择文件'}, HTTP_400_BAD_REQUEST)
        file_obj_name = file_obj.name.split('.')
        file_name = file_obj_name[0]
        suffix = ''
        if len(file_obj_name) > 1:
            file_name = '.'.join(file_obj_name[0:-1])
            suffix = file_obj_name[-1]
        # 同一项目下，文件名不可重复
        db_file_name = PublicFileModel.objects.filter(is_delete=False, project__id=project_id, file_name=file_name)
        if db_file_name:
            return Response({'message': '文件名重复'}, HTTP_400_BAD_REQUEST)
        file_size = file_obj.size                              # 单位：字节B
        if (suffix == 'exe') or (file_size > (1024*1024)):
            message = '不允许上传.exe的文件，文件大小不超过1M'
            return Response({'message': message}, HTTP_400_BAD_REQUEST)
        user_obj = self.request.user
        # file_path = '{0}/{1}'.format(self.public_file_path, file_obj.name)
        store_file_name = '{0}.{1}'.format(int(time.time()*10**3), suffix)  # 实际保存文件名
        file_path = '{0}/{1}'.format(self.public_file_path, store_file_name)
        project_obj = ProjectModel.objects.get(id=project_id)
        if not project_obj:
            return Response({'message': '项目不存在'}, status=HTTP_400_BAD_REQUEST)
        # if not project_obj.status:
        #     return Response({'message': '项目已停用'}, status=HTTP_400_BAD_REQUEST)
        try:
            with open(file_path, 'wb') as f:
                for chunk in file_obj.chunks():
                    f.write(chunk)
        except Exception as e:
            debug_log.exception(e)
            return Response({'message': '文件存储失败Error:%s' % e}, HTTP_400_BAD_REQUEST)
        else:
            PublicFileModel.objects.create(
                file_name=file_name,
                suffix=suffix,
                user=user_obj,
                file_path=file_path,
                project=project_obj
            )
        return Response({'message': '文件上传成功'}, HTTP_200_OK)

    def destroy(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"destroy",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        obj = self.get_object()
        obj.setIsdeleteTrue()
        return Response({'message':'删除成功'}, status=HTTP_200_OK)


class PublicVariableView(ModelViewSet):
    """公共变量视图"""
    serializer_class = PublicVariableSerializer
    queryset = None  #PublicVariableModel.objects.filter(is_delete=False)

    def get_queryset(self):
        # return super().get_queryset()
        project_id = self.kwargs['project_id']
        if project_id:
            # 权限控制
            if self.request.user.is_superuser:
                query_set = PublicVariableModel.objects.filter(is_delete=False)
            else:
                user_group = Group.objects.filter(user=self.request.user).all()
                query_set = PublicVariableModel.objects.filter(is_delete=False, project_id=project_id, project__user_group__in=user_group).all()
            try:
                # query_set = super().get_queryset().filter(project=project_id)
                query_set = query_set.filter(project=project_id)
                # 时间查询
                if self.request.query_params.get('start_time') and self.request.query_params.get('end_time'):
                    start_time_str = self.request.query_params.get('start_time')
                    end_time_str = self.request.query_params.get('end_time')
                    # start_time = timezone.datetime.strptime(start_time_str, '%Y-%m-%dT%H:%M:%S.%fZ').replace(
                    #     tzinfo=pytz.utc)
                    # end_time = timezone.datetime.strptime(end_time_str, '%Y-%m-%dT%H:%M:%S.%fZ').replace(
                    #     tzinfo=pytz.utc)
                    tzinfo_ = None  # 因settings 中USE_TZ = False 2019-11-5
                    if settings.USE_TZ:
                        tzinfo_ = pytz.utc
                    start_time = timezone.datetime.strptime(start_time_str, '%Y-%m-%dT%H:%M:%S.%fZ').replace(
                        tzinfo=tzinfo_)
                    end_time = timezone.datetime.strptime(end_time_str, '%Y-%m-%dT%H:%M:%S.%fZ').replace(
                        tzinfo=tzinfo_)
                    # 前端日期插件，发送的时间比选择日期慢8h。 例如：选择2019-05-08，实际发送时间为2019-05-07T16:00:00.000Z
                    start_time += timezone.timedelta(hours=8)
                    end_time += timezone.timedelta(days=1, hours=8)
                    query_set = query_set.filter(create_time__range=(start_time, end_time))
                if self.request.query_params.get('user_id'):
                    user_id = self.request.query_params.get('user_id')
                    query_set = query_set.filter(creator=user_id)
                if self.request.query_params.get('name'):
                    name = self.request.query_params.get('name')
                    # query_set = query_set.filter(name=name)
                    query_set = query_set.filter(name__icontains=name)
                # if self.request.query_params.get('page_id'):
                #     page_id = self.request.query_params.get('page_id')
                #     query_set = query_set.filter(page=page_id)
                return query_set.order_by('-create_time')
            except Exception:
                return PublicVariableModel.objects.none()
        else:
            return PublicVariableModel.objects.none()

    def partial_update(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"partial_update",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        return super(PublicVariableView, self).partial_update(request, *args, **kwargs)

    def retrieve(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"retrieve",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        return super(PublicVariableView, self).retrieve(request, *args, **kwargs)

    def list(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"list",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        return super(PublicVariableView, self).list(request, *args, **kwargs)

    @list_route(methods=['GET'])
    def checkVariableName(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"checkVariableName",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        project_id = self.kwargs['project_id']
        variable_id = request.query_params.get('id', '')
        name = request.query_params.get('name', '')
        if all([variable_id, project_id, name]):
            if PublicVariableModel.objects.exclude(id=variable_id).filter(project_id=project_id, name=name, is_delete=False):
                return Response({'message': '此公共变量名已存在'}, HTTP_400_BAD_REQUEST)
            else:
                return Response({'message': '校验通过'}, HTTP_200_OK)
        elif all([project_id, name]):
            if PublicVariableModel.objects.filter(project_id=project_id, name=name, is_delete=False):
                return Response({'message': '此公共变量名已存在'}, HTTP_400_BAD_REQUEST)
            else:
                return Response({'message': '校验通过'}, HTTP_200_OK)
        else:
            return Response({'message': '校验参数不完整'}, HTTP_400_BAD_REQUEST)

    def create(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"create",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        data = request.data
        variable_type = data.get('variable_type')
        value = data.get('value', None)
        array = data.get('array', None)
        if (variable_type == 'Str') and (not value):
            return Response({'message': '参数不完整'}, status=HTTP_400_BAD_REQUEST)
        if (variable_type == 'Choices') and (not array):
            return Response({'message': '参数不完整'}, status=HTTP_400_BAD_REQUEST)
        instance = super().create(request, *args, **kwargs)
        return Response({'message':'保存成功'}, status=HTTP_200_OK)

    def update(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"update",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        data = request.data
        variable_type = data.get('variable_type')
        value = data.get('value', None)
        array = data.get('array', None)
        if (variable_type == 'Str') and (not value):
            return Response({'message': '参数不完整'}, status=HTTP_400_BAD_REQUEST)
        if (variable_type == 'Choices') and (not array):
            return Response({'message': '参数不完整'}, status=HTTP_400_BAD_REQUEST)
        super().update(request, *args, **kwargs)
        return Response({'message':'修改成功'}, status=HTTP_200_OK)

    def destroy(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"destroy",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        obj = self.get_object()
        obj.setIsdeleteTrue()
        return Response({'message':'删除成功'}, status=HTTP_200_OK)


class PublicActionView(ModelViewSet):
    """公共动作 视图"""
    serializer_class = PublicActionSerializer
    queryset = None #PublicActionModel.objects.filter(is_delete=False)
    # filter_backends = [filters.SearchFilter, filters.OrderingFilter, DjangoFilterBackend]
    # search_fields = ('name',)
    # filter_fields = ('name',)
    # ordering = ('-create_time',)

    def get_queryset(self):
        # user_obj = self.request.user
        project_id = self.kwargs['project_id']
        if project_id:
            try:
                # 权限控制
                if self.request.user.is_superuser:
                    query_set = PublicActionModel.objects.filter(is_delete=False, project_id=project_id)
                else:
                    user_group = Group.objects.filter(user=self.request.user).all()
                    query_set = PublicActionModel.objects.filter(is_delete=False, project_id=project_id, project__user_group__in=user_group).all()
                # 时间查询
                if self.request.query_params.get('start_time') and self.request.query_params.get('end_time'):
                    start_time_str = self.request.query_params.get('start_time')
                    end_time_str = self.request.query_params.get('end_time')
                    # start_time = timezone.datetime.strptime(start_time_str, '%Y-%m-%dT%H:%M:%S.%fZ').replace(
                    #     tzinfo=pytz.utc)
                    # end_time = timezone.datetime.strptime(end_time_str, '%Y-%m-%dT%H:%M:%S.%fZ').replace(
                    #     tzinfo=pytz.utc)

                    tzinfo_ = None  # 因settings 中USE_TZ = False 2019-11-5
                    if settings.USE_TZ:
                        tzinfo_ = pytz.utc
                    start_time = timezone.datetime.strptime(start_time_str, '%Y-%m-%dT%H:%M:%S.%fZ').replace(
                        tzinfo=tzinfo_)
                    end_time = timezone.datetime.strptime(end_time_str, '%Y-%m-%dT%H:%M:%S.%fZ').replace(
                        tzinfo=tzinfo_)
                    # 前端日期插件，发送的时间比选择日期慢8h。 例如：选择2019-05-08，实际发送时间为2019-05-07T16:00:00.000Z
                    start_time += timezone.timedelta(hours=8)
                    end_time += timezone.timedelta(days=1, hours=8)
                    query_set = query_set.filter(create_time__range=(start_time, end_time))
                if self.request.query_params.get('user_id'):
                    user_id = self.request.query_params.get('user_id')
                    query_set = query_set.filter(creator=user_id)
                if self.request.query_params.get('name'):
                    name = self.request.query_params.get('name')
                    # query_set = query_set.filter(name=name)
                    query_set = query_set.filter(name__icontains=name)
                return query_set.order_by('-create_time')
            except Exception:
                return PublicActionModel.objects.none()
        else:
            return PublicActionModel.objects.none()

    def partial_update(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"partial_update",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        return super(PublicActionView, self).partial_update(request, *args, **kwargs)

    def retrieve(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"retrieve",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        try:
            project_id = self.kwargs['project_id']
            pk = self.kwargs['pk']
            public_action = PublicActionModel.objects.filter(project_id=project_id, id=pk, is_delete=False)
            if not public_action:
                return super(PublicActionView, self).retrieve(request, *args, **kwargs)
            # ----------------改变用例中的eleList为最新元素数据----------------------------------------------------
            from page.models import PageModel
            from element.models import ElementModel
            from element.serializers import ElementNameSerializer
            # 增加公共页面的下的所有元素
            public_page_query = PageModel.objects.filter(name=settings.PUBLIC_PAGE_NAME, project_id=project_id,
                                                         is_public=True, is_delete=False)
            if public_page_query:
                page_id = public_page_query.first().id
                public_element_ = ElementModel.objects.filter(page_id=page_id, is_delete=False).values('id', 'name')
                public_element = [{'name': '(公共元素){0}'.format(name_dict['name']), 'element_id': name_dict['id']} for
                                  name_dict in list(public_element_)]
            else:
                public_element = list()

            content_ = public_action.first().content
            if isinstance(content_, str):
                content_ = json.loads(content_)
            new_content_list = list()
            for content_dict in content_:
                new_content = dict()
                # 所属页面下的所有元素
                page_id = content_dict.get('page_id')
                page_query = PageModel.objects.filter(id=page_id, is_delete=False)
                if page_query:
                    new_content["page_id"] = page_id
                    new_content['page_name'] = page_query.first().name
                    new_content['data'] = content_dict.get("data")
                    element_query = ElementModel.objects.filter(page_id=page_id, is_delete=False, page__is_public=False)
                    query_set = element_query.order_by('-create_time').all()
                    serializer = ElementNameSerializer(query_set, many=True)
                    element_data = json.loads(json.dumps(serializer.data))
                    element_data.extend(public_element)
                    eleList = element_data
                    new_content["eleList"] = eleList
                    # new_content_list.append(new_content)
                else:
                    content_dict["eleList"] = list()
                    new_content = content_dict  # 页面删除时，用例中仍然保留原页面数据
                new_content_list.append(new_content)
            public_action.update(content=json.dumps(new_content_list))
        except Exception as e:
            debug_log.error('PublicActionView retrieve error:{}, request:{}'.format(e, request))
        return super(PublicActionView, self).retrieve(request, *args, **kwargs)

    def list(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"list",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        return super(PublicActionView, self).list(request, *args, **kwargs)

    @list_route(methods=['GET'])
    def creatorNameList(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"creatorNameList",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        query_set = self.get_queryset().order_by('-create_time')
        serializer = PublicActionCreatorSerializer(query_set, many=True)
        data = json.loads(json.dumps(serializer.data))
        list_data = reduce(lambda x, y: x if y in x else x + [y], [[], ] + data)
        return Response({'list': list_data}, status=HTTP_200_OK)

    @list_route(methods=['GET'])
    def checkActionName(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"checkActionName",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        action_id = request.query_params.get('id', '')
        # page_id = request.query_params.get('page', '')
        project_id = self.kwargs['project_id']
        name = request.query_params.get('name', '')
        if all([action_id, project_id, name]):
            if PublicActionModel.objects.exclude(id=action_id).filter(project_id=project_id, name=name, is_delete=False):
                return Response({'message': '此公共动作名已存在'}, HTTP_400_BAD_REQUEST)
            else:
                return Response({'message': '校验通过'}, HTTP_200_OK)
        elif all([project_id, name]):
            if PublicActionModel.objects.filter(project_id=project_id, name=name, is_delete=False):
                return Response({'message': '此公共动作名已存在'}, HTTP_400_BAD_REQUEST)
            else:
                return Response({'message': '校验通过'}, HTTP_200_OK)
        else:
            return Response({'message': '校验参数不完整'}, HTTP_400_BAD_REQUEST)

    def create(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"create",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        instance = super().create(request, *args, **kwargs)
        # return Response({'message':'保存成功'}, status=HTTP_200_OK)
        return Response({'message': '保存成功', 'id': (instance.data)["id"]},status=HTTP_200_OK)

    def update(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"update",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        super().update(request, *args, **kwargs)
        return Response({'message':'修改成功'}, status=HTTP_200_OK)

    def destroy(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"destroy",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        obj = self.get_object()
        obj.setIsdeleteTrue()
        return Response({'message': '删除成功'}, status=HTTP_200_OK)

    @list_route(methods=['GET'])
    def leadAction(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"leadAction",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        page_id = request.query_params.get('page', '')
        query_set = self.get_queryset().filter(page_id=page_id)
        if query_set:
            serializer = PublicActionSerializer(query_set, many=True)
            return Response({'list': serializer.data}, status=HTTP_200_OK)
        else:
            return Response({'message': '找不到该页面的公共动作'}, HTTP_400_BAD_REQUEST)

    @list_route(methods=['GET'])
    def leadActions(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"leadActions",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        project_id = self.kwargs['project_id']
        # query_set = self.get_queryset().filter(page_id__project_id=project_id)
        query_set = self.get_queryset().filter(project_id=project_id)
        if query_set:
            serializer = PublicActionSerializer(query_set, many=True)
            return Response({'list': serializer.data}, status=HTTP_200_OK)
        else:
            return Response({'message': '找不到该项目的公共动作'}, HTTP_400_BAD_REQUEST)
