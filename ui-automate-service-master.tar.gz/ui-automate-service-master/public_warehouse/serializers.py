import random
import re
import json

from django.db import transaction
from rest_framework.response import Response
from user.models import UserModel
from utils.common_parameter import get_timestamp, check_time_format
from rest_framework.serializers import ModelSerializer
from rest_framework import serializers
from public_warehouse.models import PublicFileModel, PublicVariableModel
from public_warehouse.models import PublicActionModel
# from utils.common_parameter import get_timestamp, ReplaceCommonParameter
from project_crud.models import ProjectModel
from utils.serializer import ZJsonField


class PublicFileSerializer(serializers.ModelSerializer, serializers.Serializer):
    class Meta:
        model = PublicFileModel
        fields = ('id', 'file_name', 'suffix', 'user', 'create_time')

    def create(self, validated_data):
        validated_data['project'] = ProjectModel.objects.get(id=self.context['view'].kwargs['project_id'])
        if PublicFileModel.objects.filter(name=validated_data['name'], project=validated_data['project'], is_delete=False):
            raise serializers.ValidationError({'message': '文件名已存在'})
        return super().create(validated_data)

    def update(self, instance, validated_data):
        if PublicFileModel.objects.exclude(id=instance.id).filter(name=validated_data['name'], project=validated_data['project'], is_delete=False):
            raise serializers.ValidationError({'message': '文件名已存在'})
        return super().update(instance, validated_data)


class PublicFileUserNameSerializer(serializers.ModelSerializer):
    """文件管理上传人"""
    # 仅用于筛选表单
    # user_id = serializers.ReadOnlyField(source='id')
    creator_name = serializers.ReadOnlyField(source='user')

    class Meta:
        model = PublicFileModel
        # fields = ('user_id', 'creator_name')
        fields = ('creator_name',)


class PublicVariableSerializer(ModelSerializer):
    """公共变量"""
    time_offset = serializers.ReadOnlyField(source='getTimeOffset')

    class Meta:
        model = PublicVariableModel
        fields = '__all__'


    def myvalidate(self, attrs):
        # attrs['project'] = ProjectModel.objects.get(id=self.context['request'].META.get('HTTP_PROJECTID'))
        # 　参数不支持中文和特殊符号
        re_name = re.findall(r"[^\-_ A-Za-z0-9]+", attrs['name'])
        if re_name:
            raise serializers.ValidationError({'message': '公共变量名不支持中文和特殊符号'})
        variable_type = attrs["variable_type"]
        if variable_type == 'Time':
            days = attrs.get('days', None)  # [(0, 当前时间), (1, '时间偏移天数')]
            time_format = attrs.get('time_format', None)
            if not check_time_format(time_format):
                raise serializers.ValidationError({'message': '时间格式输入有误'})
            timestamp = get_timestamp(days, time_format)
            if timestamp is None:
                raise serializers.ValidationError({'message': '时间偏移参数输入有误'})
            value = '--'
            attrs["value"] = value
        elif variable_type == 'Random':
            minnum = attrs.get('minnum', None)  # 起始数值 (可能为0)
            maxnum = attrs.get('maxnum', None)  # 结束数值
            if (minnum is not None) and (maxnum is not None):
                try:
                    minnum = int(minnum)
                    maxnum = int(maxnum)
                    # DB最大保存长度  models.BigIntegerField: (-9223372036854775808, 9223372036854775807)
                    if (minnum not in range(-9223372036854775808, 9223372036854775807)) or (
                            maxnum not in range(-9223372036854775808, 9223372036854775807)):
                        raise serializers.ValidationError({'message': '随机数值输入超长'})
                    random.randint(minnum, maxnum)
                except Exception as e:
                    raise serializers.ValidationError({'message': '随机数值输入有误'})
                value = '{0}-{1}'.format(minnum, maxnum)
                attrs["value"] = value
            else:
                raise serializers.ValidationError({'message': '参数不完整'})
        elif variable_type == 'Str':
            value = attrs.get('value')
            if not value:
                raise serializers.ValidationError({'message': '参数不完整'})
        elif variable_type == 'Choices':
            # 指定随机值的数组
            array_ = attrs.get('array')
            if not array_:
                raise serializers.ValidationError({'message': '参数不完整'})
            try:
                # array = ast.literal_eval(value)
                new_value = array_.replace('(', '').replace(')', '').replace('[', '').replace(']', '').replace(' ', '')
                new_array = new_value.split(',')
                random.choice(new_array)
            except Exception:
                raise serializers.ValidationError({'message': '参数有误'})
            attrs["array"] = array_
        else:
            raise serializers.ValidationError({'message': '参数类型暂不支持'})
        return attrs

    def create(self, validated_data):
        validated_data = self.myvalidate(validated_data)
        validated_data['project'] = ProjectModel.objects.get(id=self.context['view'].kwargs['project_id'])
        if PublicVariableModel.objects.filter(name=validated_data['name'], project=validated_data['project'], is_delete=False):
            raise serializers.ValidationError({'message': '公共变量名已存在'})
        return super().create(validated_data)

    def update(self, instance, validated_data):
        validated_data = self.myvalidate(validated_data)
        validated_data['project'] = ProjectModel.objects.get(id=self.context['view'].kwargs['project_id'])
        if PublicVariableModel.objects.exclude(id=instance.id).filter(name=validated_data['name'], project=validated_data['project'], is_delete=False):
            raise serializers.ValidationError({'message': '公共变量名已存在'})
        return super().update(instance, validated_data)


class PublicActionSerializer(serializers.ModelSerializer):
    # content = ZJsonField()
    content = serializers.ReadOnlyField(source='updateContentPageName')
    creator = serializers.ReadOnlyField(source='creator.username')

    class Meta:
        model = PublicActionModel
        fields = '__all__'

    def validated_content(self, content):
        if isinstance(content, str):
            try:
               json.loads(content)
            except (TypeError, ValueError):
                raise serializers.ValidationError({'message': 'content json格式错误'})
            return content
        return json.dumps(content)

    def create(self, validated_data):
        validated_data['creator'] = self.context['request'].user
        validated_data['project_id'] = self.context['view'].kwargs['project_id']
        validated_data['content'] = self.validated_content(self.context['request'].data.get('content', list()))
        if PublicActionModel.objects.filter(name=validated_data['name'], project_id=validated_data["project_id"], is_delete=False):
            raise serializers.ValidationError({'message': '此动作名已存在'})
        return super().create(validated_data)

    def update(self, instance, validated_data):
        # validated_data['creator'] = self.context['request'].user
        validated_data['project_id'] = self.context['view'].kwargs['project_id']
        validated_data['content'] = self.validated_content(self.context['request'].data.get('content', list()))
        if PublicActionModel.objects.exclude(id=instance.id).filter(name=validated_data['name'], project_id=validated_data["project_id"], is_delete=False):
            raise serializers.ValidationError({'message': '此动作名已存在'})
        return super().update(instance, validated_data)


class PublicActionCreatorSerializer(serializers.ModelSerializer):
    """公共动作创建人"""
    # 仅用于筛选表单
    user_id = serializers.ReadOnlyField(source='creator.id')
    creator_name = serializers.ReadOnlyField(source='creator.username')  # 创建人姓名

    class Meta:
        model = PublicActionModel
        fields = ('user_id', 'creator_name')
