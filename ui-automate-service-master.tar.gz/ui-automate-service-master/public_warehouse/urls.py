from django.conf.urls import url, include
from public_warehouse import views
from rest_framework import routers

router = routers.DefaultRouter(trailing_slash=False)
router.register(r'files', views.PublicFileAPIView, base_name='public_file')
router.register(r'variable', views.PublicVariableView, base_name='public_variable')
router.register(r'action', views.PublicActionView, base_name='public_action')


# urlpatterns = [
#    url(r'', include(router.urls)),
# ]
