from functools import reduce
import json
from automate_uitest_py3 import settings
from django.contrib.auth.models import Group
from django.utils import timezone
import pytz
from rest_framework.decorators import list_route
from rest_framework.status import HTTP_200_OK, HTTP_400_BAD_REQUEST
from rest_framework.viewsets import ModelViewSet
from case_manage.models import CaseManageTestModel
from project_crud.models import ProjectModel
from .serializers import PageSerializer, PageCreatorNameSerializer, PageNameSerializer
from .models import PageModel
from rest_framework import filters
from rest_framework.filters import OrderingFilter
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.response import Response
from project_crud.models import ProjectData


class PageView(ModelViewSet):
    """页面管理 视图"""
    serializer_class = PageSerializer
    queryset = None
    filter_backends = (filters.SearchFilter, DjangoFilterBackend, OrderingFilter)
    search_fields = ('name', )
    ordering = ('-is_public', '-create_time')

    def get_queryset(self):
        # user_obj = self.request.user
        # user_group_obj = Group.objects.filter(user=user_obj)
        if self.kwargs['project_id']:
            project_id = self.kwargs['project_id']
            # 权限控制
            if self.request.user.is_superuser:
                query_set = PageModel.objects.filter(is_delete=False)
            else:
                user_group = Group.objects.filter(user=self.request.user).all()
                query_set = PageModel.objects.filter(is_delete=False, project_id=project_id, project__user_group__in=user_group).all()

            try:
                query_set = query_set.filter(project=project_id)
                # 时间查询
                if self.request.query_params.get('start_time') and self.request.query_params.get('end_time'):
                    start_time_str = self.request.query_params.get('start_time')
                    end_time_str = self.request.query_params.get('end_time')
                    tzinfo_ = None    # 因settings 中USE_TZ = False 2019-11-5
                    if settings.USE_TZ:
                        tzinfo_ = pytz.utc
                    start_time = timezone.datetime.strptime(start_time_str, '%Y-%m-%dT%H:%M:%S.%fZ').replace(
                        tzinfo=tzinfo_)
                    end_time = timezone.datetime.strptime(end_time_str, '%Y-%m-%dT%H:%M:%S.%fZ').replace(
                        tzinfo=tzinfo_)

                    # 前端日期插件，发送的时间比选择日期慢8h。 例如：选择2019-05-08，实际发送时间为2019-05-07T16:00:00.000Z
                    start_time += timezone.timedelta(hours=8)
                    end_time += timezone.timedelta(days=1, hours=8)
                    query_set = query_set.filter(create_time__range=(start_time, end_time))
                if self.request.query_params.get('user_id'):
                    user_id = self.request.query_params.get('user_id')
                    query_set = query_set.filter(creator=user_id)
                if self.request.query_params.get('name'):
                    name = self.request.query_params.get('name')
                    # query_set = query_set.filter(name=name)
                    query_set = query_set.filter(name__icontains=name)
                return query_set
            except Exception:
                return PageModel.objects.none()
        else:
            return PageModel.objects.none()

    def partial_update(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"partial_update",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        return super(PageView, self).partial_update(request, *args, **kwargs)

    def retrieve(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"retrieve",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        return super(PageView, self).retrieve(request, *args, **kwargs)

    def list(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"list",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        return super(PageView, self).list(request, *args, **kwargs)

    @list_route(methods=['GET'])
    def creatorNameList(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"creatorNameList",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        query_set = self.get_queryset().order_by('-create_time')
        serializer = PageCreatorNameSerializer(query_set, many=True)
        data = json.loads(json.dumps(serializer.data))
        list_data = reduce(lambda x, y: x if y in x else x + [y], [[], ] + data)
        return Response({'list': list_data}, status=HTTP_200_OK)

    @list_route(methods=['GET'])
    def pageNameList(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"pageNameList",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        query_set = self.get_queryset().order_by('-create_time')
        serializer = PageNameSerializer(query_set, many=True)
        return Response({'list': serializer.data}, status=HTTP_200_OK)

    def create(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"create",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        data = request.data
        project_id = self.kwargs['project_id']
        user_obj = self.request.user
        name = data.get('name', '')
        url = data.get('url', '')
        if PageModel.objects.filter(name=name, is_delete=False, project_id=project_id):
            return Response({'message': '此页面名称已存在'}, HTTP_400_BAD_REQUEST)
        if len(url) > 2000:
            return Response({'message': 'url超长，限制长度2000'}, HTTP_400_BAD_REQUEST)
        if not all([name, url]):
            return Response({'message': '参数不完整'}, HTTP_400_BAD_REQUEST)
        note_info = data.get('note_info', '')
        try:
            project_obj = ProjectModel.objects.get(id=project_id, is_delete=False, status=True)
            if not ProjectData.objects.filter(project=project_obj):
                ProjectData.objects.create(project=project_obj)
            PageModel.objects.create(
                name=name,
                url=url,
                project=project_obj,
                creator=user_obj,
                note_info=note_info
            )
            project_obj.addPage()  # 页面加一
        except Exception as e:
            return Response({'message': '保存失败 Error:%s' % e}, HTTP_400_BAD_REQUEST)
        else:
            return Response({'message':'保存成功'}, HTTP_200_OK)

    def destroy(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"destory",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        obj = self.get_object()
        if obj.is_public:
            return Response({'message': '公共页面不允许删除'}, HTTP_400_BAD_REQUEST)
        obj.setIsdeleteTrue()
        return Response({'message':'删除成功'}, HTTP_200_OK)

    def update(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"update",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        pk = kwargs['pk']
        data = request.data
        project_id = self.kwargs['project_id']
        name = data.get('name', '')
        url = data.get('url', '')
        if PageModel.objects.exclude(id=pk).filter(name=name, is_delete=False, project_id=project_id):
            return Response({'message': '此页面名称已存在'}, HTTP_400_BAD_REQUEST)
        if len(url) > 2000:
            return Response({'message': 'url超长，限制长度2000'}, HTTP_400_BAD_REQUEST)
        if not all([name, url]):
            return Response({'message': '参数不完整'}, HTTP_400_BAD_REQUEST)
        note_info = data.get('note_info', '')
        try:
            project_obj = ProjectModel.objects.get(id=project_id, is_delete=False, status=True)
            PageModel.objects.filter(id=pk).update(
                name=name,
                url=url,
                project=project_obj,
                # creator=user_obj,
                note_info=note_info
            )
            case_obj = CaseManageTestModel.objects.filter(is_delete=False, project_id=project_id)
            for case in case_obj:
                case.updateCasePage(pk, name)      #更新用例中的页面名称
        except Exception as e:
            return Response({'message': '修改失败 Error:%s' % e}, HTTP_400_BAD_REQUEST)
        else:
            return Response({'message':'修改成功'}, HTTP_200_OK)



