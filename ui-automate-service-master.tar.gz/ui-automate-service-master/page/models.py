from django.db import models, transaction
from utils.model import BaseModel

# Create your models here.


class PageModel(BaseModel):
    """页面管理"""
    CHOICES_TYPES = (
        (0, False),
        (1, True)
    )
    name = models.CharField(max_length=64, verbose_name="页面名称")
    url = models.CharField(max_length=2000, verbose_name="页面url")
    project = models.ForeignKey("project_crud.ProjectModel", on_delete=models.CASCADE, verbose_name="所属项目")
    creator = models.ForeignKey('user.UserModel', on_delete=models.CASCADE, verbose_name="创建人")
    note_info = models.CharField(max_length=512, null=True, verbose_name='备注信息')
    is_public = models.SmallIntegerField(default=0, choices=CHOICES_TYPES, null=True, blank=True, verbose_name='公共页面')

    class Meta:
        db_table = 'tb_page'
        verbose_name = '页面管理'
        verbose_name_plural = '页面管理'

    def getElementCount(self):
        """获取元素数"""
        if not self.elementmodel_set.count():
            return None
        return self.elementmodel_set.filter(is_delete=False).count()

    def getCreatorUserID(self):
        """获取创建人的用户表ID"""
        return self.creator.id


    @transaction.atomic
    def setIsdeleteTrue(self):
        self.is_delete = True
        self.save()
        # 遍历删除此页面的所有元素
        self.project.deletePage() # 页面减一
        if hasattr(self, 'elementmodel_set'):
            for element_model in self.elementmodel_set.all():
                element_model.setIsdeleteTrue()
        # 删除用例
        # todo 这个需要优化
        if hasattr(self, 'casemanagetestmodel_set'):
            for case_manage in self.casemanagetestmodel_set.all():
                case_manage.setIsdeleteTrue()
        # 删除执行用例任务
        #TODO 这里需要优化
        if hasattr(self, 'executioncasemodel_set'):
            for execution_case in self.executioncasemodel_set.all():
                execution_case.setIsdeleteTrue()
        # 删除公共动作
        if hasattr(self, 'publicactionmodel_set'):
            for public_action in self.publicactionmodel_set.all():
                public_action.setIsdeleteTrue()

    def getCreatorName(self):
        if self.is_public:
            creator_name='默认'
        else:
            creator_name = self.creator.username
        return creator_name
