from rest_framework import serializers
from .models import PageModel


class PageSerializer(serializers.ModelSerializer):
    element_count = serializers.ReadOnlyField(source='getElementCount')  # 元素数
    # creator_name = serializers.ReadOnlyField(source='creator.username')  # 创建人姓名
    creator_name = serializers.ReadOnlyField(source='getCreatorName')  # 创建人姓名

    class Meta:
        model = PageModel
        fields = ('id', 'name', 'url', 'creator','create_time', 'element_count','creator_name','note_info', 'is_public')


class PageCreatorNameSerializer(serializers.ModelSerializer):
    """页面创建人"""
    # 用于筛选表单
    user_id = serializers.ReadOnlyField(source='creator.id')
    creator_name = serializers.ReadOnlyField(source='creator.username')  # 创建人姓名

    class Meta:
        model = PageModel
        fields = ('user_id', 'creator_name')


class PageNameSerializer(serializers.ModelSerializer):
    """页面名称 id"""
    page_id = serializers.ReadOnlyField(source='id')
    # 用于筛选表单
    class Meta:
        model = PageModel
        fields = ('page_id', 'name')
