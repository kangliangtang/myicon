import pytz
import time
from celery import shared_task
from django_celery_beat.models import PeriodicTask, CrontabSchedule
from automate_uitest_py3 import settings
import json
from django.db.models import Q
from execution_case.models import ExecutionCaseModel
from case_manage.models import CaseManageTestModel
from .models import TimedTaskModel, TimedTaskReportModel
from utils.web_ui_runner import WebUiRunner
from utils.htmlreport  import HTMLReport
from execution_case.models import SummaryModel
from utils.data_driven import dataDrivenCasePath
from logging import getLogger
logger = getLogger('celery')


@shared_task
def runTimeTask(case_task_id):
    """
    """
    task_instance = TimedTaskModel.objects.get(id=case_task_id)
    project_id = task_instance.project_id
    task_content = json.loads(task_instance.task_content)
    case_path = []
    if task_content.get('level', ''):
        for level in task_content['level']:
            if level.get('type', 0) == 0:  #type等于0是等级用level，1是用例用task_id
                exec_obj = ExecutionCaseModel.objects.filter(Q(level=level['level']) & Q(is_delete=False)& Q(project_id=project_id))
                for exec in exec_obj:
                    if exec.task_type == 2:
                        for case in json.loads(exec.case_id_list):
                            case_obj = CaseManageTestModel.objects.filter(is_delete=False, id=case)
                            if case_obj:
                                case_path.append(case_obj.first().case_path)
                    else:
                        # case_path.append(exec.test_file)
                        # 增加数据驱动 2019-11-20 klt
                        data_case_path = dataDrivenCasePath(exec, exec.test_file)
                        case_path.extend(data_case_path)
            else:
                exec_obj = ExecutionCaseModel.objects.filter(Q(id=level['task_id']) & Q(is_delete=False))
                for exec in exec_obj:
                    if exec.task_type == 2:
                        for case in json.loads(exec.case_id_list):
                            case_obj = CaseManageTestModel.objects.filter(is_delete=False,id=case)
                            if case_obj:
                                case_path.append(case_obj.first().case_path)
                    else:
                        # case_path.append(exec.test_file)
                        # 增加数据驱动 2019-11-20 klt
                        data_case_path = dataDrivenCasePath(exec, exec.test_file)
                        case_path.extend(data_case_path)

    task_content['case_path'] = case_path
    task_content['task_name'] = task_instance.name
    result_path = ''
    result = 'success'
    try:
        uitest = WebUiRunner()
        case_host=task_content.get('env_host') if task_content.get('env_host') else task_content.get('evn_host')    #evn_host修改名字为env_host
        webdriver = task_content.get('webdriver')
        report_obj = TimedTaskReportModel.objects.create(
            name=task_instance.name,
            task_case_id=task_instance.id,

        )
        result_path, result_data = uitest.runPath(task_content, report_obj, mapping={"BASE_URL": case_host, "BASE_DRIVER": webdriver}, project_id=project_id)
        result = result_data['baseinfo']['status']
        logger.info("result_path:{},result:{}".format(result_path,result_data['baseinfo']['status']))
    except Exception as e:
        logger.error("Task failed:{}".format(e))
        # return '执行用例失败'
    # todo 发送邮件（定时任务报告）
    # if result != 'success':
    try:
        env_host = task_content.get('env_host')  # 执行环境地址
        to_emails = task_instance.to_emails  # TaskModel 需新增字段to_emails
        if to_emails:
            to_emails = list(to_emails.split(';'))
            # 去空
            if not all(to_emails):
                to_emails = [email for email in to_emails if email]
            from utils.sendemail import SendEmail
            project_name = task_instance.project.name
            result_path = report_obj.task_report_html().split('.')[0] + '.html'
            logger.info('result_path={}'.format(result_path))
            # HTMLReport(file_path=result_path).generateHtmlReport(SummaryModel.objects.get(task_result_report_id=report_obj.id).summary_count)
            HTMLReport(file_path=result_path).generateHtmlReport(SummaryModel.objects.get(task_result_report_id=report_obj.id).summary_count())
            send_email_obj = SendEmail(subject='UI平台定时任务报告', to=to_emails, attachments=result_path)
            send_email_obj.send_task_email( project_name, task_name=task_instance.name, task_result_status=report_obj.status, task_time=result_data['baseinfo']['startTime'], env_host=env_host)

    except Exception as e:
        logger.error('send email fail.{}'.format(e))


class TimeTask():
    def __init__(self, schedule, case_task):
        self.schedule = schedule
        self.case_task = case_task
        self.schedule_list = []

    def timeTask(self):
        self.splitSchedule()
        schedule, _ = CrontabSchedule.objects.get_or_create(
            minute= self.schedule_list[0],
            hour= self.schedule_list[1],
            day_of_month= self.schedule_list[2],
            month_of_year= self.schedule_list[3],
            day_of_week=self.schedule_list[4],
            timezone=pytz.timezone(settings.TIME_ZONE)
        )
        task_ = PeriodicTask.objects.create(
            crontab=schedule,
            name=self.taskName,
            task='timed_task.tasks.runTimeTask',
            args = [self.case_task.id],
            enabled = True
        )
        return task_

    def updateTimeTask(self):
        self.splitSchedule()
        schedule, _ = CrontabSchedule.objects.get_or_create(
            minute=self.schedule_list[0],
            hour=self.schedule_list[1],
            day_of_month=self.schedule_list[2],
            month_of_year=self.schedule_list[3],
            day_of_week=self.schedule_list[4],
            timezone=pytz.timezone(settings.TIME_ZONE)
        )
        task_ = self.case_task.periodic_task
        task_.crontab = schedule
        task_.save()
        return task_

    def splitSchedule(self):
        self.schedule_list = self.schedule.strip().split()
        if len(self.schedule) == 5:
            return False
        return True

    @property
    def taskName(self):
        return time.time().__str__().replace('.', '')

    def run(self, *args, **kwargs):
        pass
