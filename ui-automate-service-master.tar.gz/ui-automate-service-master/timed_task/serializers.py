from rest_framework.serializers import ModelSerializer
from timed_task.models import TimedTaskModel,TimedTaskReportModel
from django.db import transaction
from rest_framework import serializers
from .tasks import TimeTask
from utils.serializer import ZJsonField


class TimedTaskSerializer(ModelSerializer):
    task_content = ZJsonField()
    task_status = serializers.ReadOnlyField(source='periodic_task.enabled')

    class Meta:
        model=TimedTaskModel
        exclude = ('is_delete', 'periodic_task', 'create_time', 'update_time')

    def validate_crontab_code(self, data):
        data_ = data.strip()
        if len(data_.split()) == 5:
            return data_
        else:
            raise serializers.ValidationError('无效的定时命令')

    def validata_task_content(self,data):
        if isinstance(data, dict):
            pass
        return data

    @transaction.atomic
    def create(self, validated_data):
        instance = super().create(validated_data)
        instance.periodic_task = TimeTask(instance.crontab_code, instance).timeTask()
        instance.save()
        return instance

    @transaction.atomic
    def update(self, instance, validated_data):
        TimeTask(validated_data['crontab_code'], instance).updateTimeTask()
        return super().update(instance, validated_data)

class TimedTaskReportSerializer(ModelSerializer):


    class Meta:
        model = TimedTaskReportModel
        exclude = ('is_delete',)

