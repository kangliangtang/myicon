from django.apps import AppConfig


class TimedTaskConfig(AppConfig):
    name = 'timed_task'
