from rest_framework.decorators import list_route, detail_route

from project_crud.models import ProjectModel
from timed_task.serializers import TimedTaskSerializer
from timed_task.models import TimedTaskModel, TimedTaskReportModel
from rest_framework.viewsets import ModelViewSet
from django.contrib.auth.models import Group
from rest_framework.response import Response

from rest_framework.status import HTTP_200_OK, HTTP_400_BAD_REQUEST
from .tasks import runTimeTask
from execution_case.models import SummaryModel
from utils.summary_handle import summary_result_simple
from automate_uitest_py3 import settings
from rest_framework.views import APIView
# Create your views here.


class TimedTaskAPIView(ModelViewSet):
    serializer_class = TimedTaskSerializer
    queryset = None
    ordering = ('-create_time',)

    def get_queryset(self):
        project_id = self.kwargs['project_id']
        user_obj = self.request.user
        if project_id:
            try:
                if user_obj.is_superuser:
                    query_set = TimedTaskModel.objects.filter(is_delete=False)
                else:
                    user_group = Group.objects.filter(user=user_obj).all()
                    query_set = TimedTaskModel.objects.filter(is_delete=False, project_id=project_id, project__user_group__in=user_group)
                if self.request.query_params.get('name'):
                    name = self.request.query_params.get('name')
                    # query_set = query_set.filter(name=name)
                    query_set = query_set.filter(name__icontains=name)
                return query_set.order_by('-create_time')
            except Exception as e:
                return TimedTaskModel.objects.none()
        return TimedTaskModel.objects.none()

    def partial_update(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"partial_update",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        return super(TimedTaskAPIView, self).partial_update(request, *args, **kwargs)

    def retrieve(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"retrieve",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        return super(TimedTaskAPIView, self).retrieve(request, *args, **kwargs)

    def list(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"list",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        return super(TimedTaskAPIView, self).list(request, *args, **kwargs)

    def create(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"create",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        project_id = self.kwargs['project_id']
        request.data['project'] = project_id
        instance = super().create(request, *args, **kwargs)
        return Response({'message': '保存成功'})

    def update(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"update",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        project_id = self.kwargs['project_id']
        request.data['project'] = project_id
        instance = super().update(request, *args, **kwargs)
        return Response({'message': '更新成功'})

    def destroy(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"destroy",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        obj = self.get_object()
        obj.setIsdeleteTrue()
        return Response({'message':'删除成功'})

    @detail_route(methods=['POST'])
    def start(self, request, pk, *args, **kwargs):
        """
            {
            "permission":{
                "action":"start",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        self.get_object().start()
        return Response({'message': '定时任务开启'}, status=HTTP_200_OK)

    @detail_route(methods=['POST'])
    def close(self, request, pk, *args, **kwargs):
        """
            {
            "permission":{
                "action":"close",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        self.get_object().close()
        return Response({'message': '定时任务关闭'}, HTTP_200_OK)

    @detail_route(methods=['POST'])
    def run(self, request, pk, *args, **kwargs):
        """
            {
            "permission":{
                "action":"run",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        task = self.get_object()
        runTimeTask.delay(task.id)
        return Response({'message': '加入运行队列'})

    @detail_route(methods=['GET'])
    def report(self, request, pk, *args, **kwargs):
        """
            {
            "permission":{
                "action":"report",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        task_report_obj = TimedTaskReportModel.objects.filter(task_case=pk).order_by('-create_time').first()
        if task_report_obj:
            request_host = settings.BASE_HOST
            if task_report_obj.status == 'running':
                return Response({'message':'任务状态为运行中，请待运行结束，或联系平台管理员'}, HTTP_400_BAD_REQUEST)
            # todo 下载报告
            if SummaryModel.objects.filter(task_result_report=task_report_obj.id):
                summary_obj = SummaryModel.objects.get(task_result_report=task_report_obj.id)
                # result_info = summary_obj.summary_count
                result_info = summary_obj.summary_count()
                # result_info = summary_result_simple(result_info, request_host)
                from utils.time_task_report_handle import task_result_simple
                start = int(request.query_params.get('start', 1))
                size = int(request.query_params.get('size', 10))
                result_info = task_result_simple(result_info, start, size)
                return Response(result_info, status=HTTP_200_OK)
            else:
                result_info = {'message': '未找到定时任务的报告详情'}
                return Response(result_info, status=HTTP_400_BAD_REQUEST)
        else:
            return Response({'message': '未找到定时任务的报告'}, status=HTTP_400_BAD_REQUEST)

