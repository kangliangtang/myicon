from django.db import models, transaction
from utils.model import BaseModel
from django_celery_beat.models import PeriodicTask
import os
from automate_uitest_py3 import settings
from utils.minio_service_file import MinioServiceFile

# Create your models here.


class TimedTaskModel(BaseModel):
    """定时任务管理"""
    name = models.CharField(max_length=64, verbose_name="定时任务名称")
    project = models.ForeignKey("project_crud.ProjectModel", on_delete=models.CASCADE, verbose_name="所属项目")
    task_content = models.TextField(max_length=258, verbose_name="定时任务内容")
    crontab_code = models.CharField(max_length=50, verbose_name='定时命令')
    to_emails = models.CharField(max_length=300, null=True, blank=True, verbose_name='收件邮件地址')
    periodic_task = models.OneToOneField(PeriodicTask, null=True, blank=True, on_delete=models.CASCADE,
                                         verbose_name='定时任务')

    class Meta:
        db_table = 'tb_timed_task'
        verbose_name = '定时任务'
        verbose_name_plural = '定时任务'

    @transaction.atomic
    def setIsdeleteTrue(self):
        self.is_delete = True
        self.save()
        p_task = self.periodic_task
        p_task.enabled = False
        p_task.save()

    def start(self):
        p_task = self.periodic_task
        p_task.enabled = True
        p_task.save()

    def close(self):
        p_task = self.periodic_task
        p_task.enabled = False
        p_task.save()


class TimedTaskReportModel(BaseModel):
    """定时任务报告"""
    CHOICES_STATUS = (
        ('unexecuted', '未执行'),
        ('running', '执行中'),
        ('fail', '执行失败'),
        ('success', '执行成功'),
        ('error', '错误')
    )
    name = models.CharField(max_length=64, verbose_name='报告名')
    report_file_path = models.FilePathField(max_length=512, null=True, verbose_name='报告路径')
    status = models.CharField(max_length=64, default='running', null=True, choices=CHOICES_STATUS, verbose_name='运行状态')
    task_case = models.ForeignKey('timed_task.TimedTaskModel', on_delete=models.CASCADE,
                                  verbose_name='所属定时任务')


    class Meta:
        db_table = 'tb_timed_task_report'
        verbose_name = '定时任务报告'
        verbose_name_plural = '定时任务报告'

    def task_report_html(self):
        """获取定时任务html文件"""
        if os.path.exists(self.report_file_path):
            return self.report_file_path

        file_path = ''
        if self.report_file_path:
            ret = self.report_file_path.split('/')
            bucket_name = ret[-2]
            file_name = ret[-1]
            minio_obj = MinioServiceFile()
            result = minio_obj.get_file(bucket_name=bucket_name, file_name=file_name, save_file_path=settings.REPORT_DIR)
            if result:
                # file_path = '{0}{1}'.format(settings.REPORT_DIR, self.report_file_path)
                file_path = '{0}/{1}'.format(settings.REPORT_DIR, file_name)
        return file_path
