from logging import getLogger
from django.http import StreamingHttpResponse
from rest_framework.decorators import list_route, detail_route
from rest_framework.viewsets import ModelViewSet
from rest_framework.response import Response
from rest_framework.status import HTTP_200_OK, HTTP_400_BAD_REQUEST
from django.contrib.auth.models import Group

from automate_uitest_py3 import settings
from project_crud.models import ProjectModel
from utils.case_dump import CaseDump
from utils.web_ui_runner import WebUiRunner
from rest_framework.filters import OrderingFilter, SearchFilter
from django_filters.rest_framework import DjangoFilterBackend
from case_manage.models import CaseManageTestModel
from public_warehouse.models import PublicActionModel
from case_manage.serializers import CaseManageSerializer, PageListSerializer, UserListSerializer
from page.models import PageModel
from django.db.models.query_utils import Q
from execution_case.models import ExecutionCaseModel,ExecutionReportModel
from django.utils import timezone
import pytz
import copy
import time
import json
from case_manage.tasks import runTestTaskByPath, runTestTaskByCase
case_dump = CaseDump()
web_runner = WebUiRunner()
debug_log = getLogger('debug')

class CaseManageAPIView(ModelViewSet):
    serializer_class = CaseManageSerializer
    queryset = None #CaseManageTestModel.objects.filter(is_delete=False)
    filter_backends = (DjangoFilterBackend, OrderingFilter)
    search_fields = ('name', 'case_type', 'user_exe')
    ordering = ('-create_time',)

    def get_queryset(self):
        project_id = self.kwargs['project_id'] #self.request.META.get('HTTP_PROJECTID', '')
        user_obj = self.request.user
        if project_id:
            try:
                if user_obj.is_superuser:
                    query_set = CaseManageTestModel.objects.filter(project=project_id, is_delete=False)
                else:
                    user_group = Group.objects.filter(user=user_obj).all()
                    query_set = CaseManageTestModel.objects.filter(project_id=project_id,project__user_group__in=user_group, is_delete=False)
                # 时间查询
                if self.request.query_params.get('start_time') and self.request.query_params.get('end_time'):
                    start_time_str = self.request.query_params.get('start_time')
                    end_time_str = self.request.query_params.get('end_time')
                    tzinfo_ = None  # 因settings 中USE_TZ = False 2019-11-5
                    if settings.USE_TZ:
                        tzinfo_ = pytz.utc
                    start_time = timezone.datetime.strptime(start_time_str, '%Y-%m-%dT%H:%M:%S.%fZ').replace(
                        tzinfo=tzinfo_)
                    end_time = timezone.datetime.strptime(end_time_str, '%Y-%m-%dT%H:%M:%S.%fZ').replace(
                        tzinfo=tzinfo_)
                    # 前端日期插件，发送的时间比选择日期慢8h。 例如：选择2019-05-08，实际发送时间为2019-05-07T16:00:00.000Z
                    start_time += timezone.timedelta(hours=8)
                    end_time += timezone.timedelta(days=1, hours=8)
                    query_set = query_set.filter(create_time__range=(start_time, end_time))
                if self.request.query_params.get('user_id'):
                    user_id = self.request.query_params.get('user_id')
                    query_set = query_set.filter(user_exe_id=user_id)
                if self.request.query_params.get('name'):
                    name = self.request.query_params.get('name')
                    # query_set = query_set.filter(name=name)
                    query_set = query_set.filter(name__icontains=name)
                if self.request.query_params.get('case_level'):
                    case_level = self.request.query_params.get('case_level')
                    query_set = query_set.filter(case_level=case_level)
                if self.request.query_params.get('page_id'):
                    page_id = self.request.query_params.get('page_id')
                    test_content = '"page_id": {}'.format(page_id)
                    query_set = query_set.filter(test_content__icontains = test_content)
                return query_set.order_by('-create_time')
            except Exception as e:
                return CaseManageTestModel.objects.none()
        return CaseManageTestModel.objects.none()

    def partial_update(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"partial_update",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        return super(CaseManageAPIView, self).partial_update(request, *args, **kwargs)

    def retrieve(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"retrieve",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""

        try:
            project_id = self.kwargs['project_id']
            pk = self.kwargs['pk']
            case_manage = CaseManageTestModel.objects.filter(project_id=project_id, id=pk, is_delete=False)
            if not case_manage:
                return super(CaseManageAPIView, self).retrieve(request, *args, **kwargs)
            # ----------------改变用例中的eleList为最新元素数据----------------------------------------------------
            from element.models import ElementModel
            from element.serializers import ElementNameSerializer
            # 增加公共页面的下的所有元素
            public_page_query = PageModel.objects.filter(name=settings.PUBLIC_PAGE_NAME, project_id=project_id,
                                                         is_public=True, is_delete=False)
            if public_page_query:
                page_id = public_page_query.first().id
                public_element_ = ElementModel.objects.filter(page_id=page_id, is_delete=False).values('id', 'name')
                public_element = [{'name': '(公共元素){0}'.format(name_dict['name']), 'element_id': name_dict['id']} for
                                  name_dict in list(public_element_)]
            else:
                public_element = list()

            content_ = case_manage.first().test_content
            if isinstance(content_, str):
                content_ = json.loads(content_)
            new_content_list = list()
            for content_dict in content_:
                new_content = dict()
                # 所属页面下的所有元素
                page_id = content_dict.get('page_id')
                page_query = PageModel.objects.filter(id=page_id, is_delete=False)
                if page_query:
                    new_content["page_id"] = page_id
                    new_content['page_name'] = page_query.first().name
                    new_content['data'] = content_dict.get("data")
                    element_query = ElementModel.objects.filter(page_id=page_id, is_delete=False, page__is_public=False)
                    query_set = element_query.order_by('-create_time').all()
                    serializer = ElementNameSerializer(query_set, many=True)
                    element_data = json.loads(json.dumps(serializer.data))
                    element_data.extend(public_element)
                    eleList = element_data
                    new_content["eleList"] = eleList
                    # new_content_list.append(new_content)
                else:
                    content_dict["eleList"] = list()
                    new_content = content_dict                   # 页面删除时，用例中仍然保留原页面数据
                new_content_list.append(new_content)
            case_manage.update(test_content=json.dumps(new_content_list))
        except Exception as e:
            debug_log.error('CaseManageAPIView retrieve error:{}, request:{}'.format(e, request))
        return super(CaseManageAPIView, self).retrieve(request, *args, **kwargs)

    def list(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"list",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        return super(CaseManageAPIView, self).list(request, *args, **kwargs)

    def destroy(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"destroy",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        project_id = self.kwargs['project_id']
        obj = self.get_object()
        obj.setIsdeleteTrue()
        if obj.case_type == 1:
            ProjectModel.objects.get(id=self.kwargs['project_id']).deleteCase()  # 用例数减一
        elif obj.case_type == 2:
            ProjectModel.objects.get(id=self.kwargs['project_id']).deleteScen()  # 场景数减一
        return Response({'message': '删除成功'})

    def create(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"create",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        intance = super().create(request, *args, **kwargs)
        return Response({'message': '保存成功', 'id': (intance.data)["id"]})

    def update(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"update",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        project_id = self.kwargs['project_id']
        data = request.data
        pk = kwargs['pk']
        case_path = CaseManageTestModel.objects.get(id=pk).case_path
        task_id = CaseManageTestModel.objects.get(id=pk).task_id
        test_data = copy.deepcopy(data)
        path = case_dump.updateCase(case_path, test_data)
        request.data['project'] = project_id
        request.data['case_path'] = case_path
        # request.data['user_exe'] = request.user.id
        request.data['user_exe'] = request.user
        request.data['case_type'] = 1
        intance = super().update(request, *args, **kwargs)
        execution_obj = ExecutionCaseModel.objects.get(id=task_id)
        execution_obj.level = request.data['case_level']
        execution_obj.name = request.data['name']
        execution_obj.save(update_fields=['level', 'name'])
        return Response({'message':'更新成功'})

    @list_route(methods=['POST'])
    def debug(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"debug",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        project_id = self.kwargs['project_id']
        data = request.data
        case_host = data.get('env_host')
        webdriver = data.get('webdriver')
        try:
            intance = case_dump.dumpTestCase(data)
        except Exception as e:
            return Response({'message': '用例内容不正确'}, HTTP_400_BAD_REQUEST)
        case_config = {
            "case_content": intance,
            "case_type": 0,
            "case_host": case_host,
            "webdriver": webdriver
        }
        result = runTestTaskByCase(case_config, project_id)
        if result is False:
            return Response({'message': '用例中存在元素或页面被删除'}, HTTP_400_BAD_REQUEST)
        return Response(result, status=HTTP_200_OK)

    @list_route(methods=['get'])
    def userList(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"userList",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        project_id = self.kwargs['project_id']
        if project_id:
            query_set = self.get_queryset().filter(is_delete=False, project_id=project_id).values('user_exe_id','user_exe_id__username').distinct().order_by('user_exe_id')
            serializer = UserListSerializer(query_set, many=True)
            return Response({'list': serializer.data}, status=HTTP_200_OK)
        else:
            return Response({'message': '项目不存在'}, HTTP_400_BAD_REQUEST)


    @detail_route(methods=['GET'])
    def exportCase(self, request, pk, *args, **kwargs):
        """
            {
            "permission":{
                "action":"exportCase",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        query_set = self.get_queryset().filter(id=pk)
        if query_set and request.query_params.get('download', None):
            case_path = query_set.get(id=pk).case_path
            file_name = '{0}.{1}'.format(int(time.time()), 'json')
            try:
                json_data = web_runner.load_json_file(case_path)
                CaseDump().fromIdToValue(json_data)
            except Exception as e:
                debug_log.error('dump case fail.{}'.format(e))
                return Response({'message': '用例导出失败'}, HTTP_400_BAD_REQUEST)
            json_data['config'].pop('page_id')
            response = StreamingHttpResponse(json.dumps(json_data, indent=4, ensure_ascii=False))
            response['Content-Type'] = 'application/octet-stream;charset=utf-8'
            response['Content-Disposition'] = 'attachment;filename={}'.format(file_name)
            return response
        else:
            return Response({'message': '用例不存在'}, HTTP_400_BAD_REQUEST)

    @list_route(methods=['GET'])
    def pageRelation(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"pageRelation",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        project_id = self.kwargs['project_id']
        if self.kwargs['project_id']:
            getquery = CaseManageTestModel.objects.filter(Q(project_id=project_id) & Q(is_delete=False))
            serializer = PageListSerializer(getquery, many=True)
            data = serializer.data
            page_relation = {'nodes':[], 'edges':[]}
            for pagelist in data:
                page = pagelist['pagelist']
                page_len = len(page)
                if page_len == 1:
                    if PageModel.objects.filter(id=page[0]['page_id'], is_delete=False) and page[0] not in page_relation['nodes']:
                        page_relation['nodes'].append(page[0])   #增加节点
                        continue
                for page_idx in range(page_len - 1):
                    page_source = page[page_idx]['page_id']
                    page_target = page[page_idx + 1]['page_id']
                    if PageModel.objects.filter(id=page_source, is_delete=False) and PageModel.objects.filter(id=page_target, is_delete=False):
                        if page[page_idx] in page_relation['nodes'] and {'source':page_source, 'target':page_target} not in page_relation['edges'] and page_source != page_target:   #判断节点是否存在且节点关系不存在
                            page_relation['edges'].append({'source':page_source, 'target':page_target})
                        if page[page_idx] not in page_relation['nodes'] and page_source != page_target:   #判断节点是否存在
                            page_relation['nodes'].append(page[page_idx])
                            page_relation['edges'].append({'source': page_source, 'target': page_target})
                        if page[page_idx+1] not in page_relation['nodes']:   #判断下个节点是否存在
                            page_relation['nodes'].append(page[page_idx+1])
            return Response( page_relation, status=HTTP_200_OK)
        else:
            return Response({'message': '未找到该项目'}, status=403)

    @detail_route(methods=['POST'])
    def toPublicAction(self, request, pk, *args, **kwargs):
        """
            {
            "permission":{
                "action":"toPublicAction",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        project_id = self.kwargs['project_id']
        user_obj = self.request.user
        if project_id:
            case_obj = self.get_object()
            # 公共动作重名校验
            if PublicActionModel.objects.filter(name=case_obj.name, project_id=project_id, is_delete=False):
                return Response({'message': '此公共动作名已存在'}, HTTP_400_BAD_REQUEST)
            PublicActionModel.objects.create(
                name=case_obj.name,
                creator=user_obj,
                content=case_obj.test_content,
                note_info=case_obj.case_details,
                project_id=project_id
            )
            return Response({'message': '公共动作保存成功'}, status=HTTP_200_OK)
        else:
            return Response({'message': '未找到该项目'}, status=403)
