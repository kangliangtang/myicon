from django.apps import AppConfig


class CaseManageConfig(AppConfig):
    name = 'case_manage'
