from celery import shared_task
from execution_case.models import ExecutionCaseModel,ExecutionReportModel
from utils.web_ui_runner import WebUiRunner
from logging import getLogger
logger = getLogger('debug')


@shared_task
def runTestTaskByPath(case_config, report_id=None, execution_id=None):
    """
    执行任务
    """
    try :
        uitest = WebUiRunner()
        case_host=case_config.get('case_host')
        webdriver = case_config.get('webdriver')
        report_obj = ExecutionReportModel.objects.get(id=report_id)
        execution_obj = ExecutionCaseModel.objects.get(id=execution_id)
        return uitest.runCase(case_config, report_obj, execution_obj, mapping={"BASE_URL": case_host, "BASE_DRIVER": webdriver})
    except Exception as e:
        print(e)
        logger.error("Task failed:{}".format(e))
        return {'message': '执行用例失败','code': 400}

@shared_task
def runTestTaskByCase(case_config, project_id=None):
    """
    执行任务
    """
    try :
        uitest = WebUiRunner()
        case_host=case_config.get('case_host')
        webdriver = case_config.get('webdriver')
        case_config = case_config.get('case_content')
        return uitest.runCase(case_config, mapping={"BASE_URL": case_host, "BASE_DRIVER": webdriver}, project_id=project_id)
    except Exception as e:
        logger.error("Task failed:{}".format(e))
        return {'message': '执行用例失败','code': 400}

