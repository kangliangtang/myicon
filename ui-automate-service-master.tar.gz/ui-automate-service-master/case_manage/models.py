from django.db import models

# Create your models here.

from utils.model import BaseModel
from django.db import models, transaction
from project_crud.models import ProjectModel
from user.models import UserModel
from page.models import PageModel
from execution_case.models import ExecutionCaseModel
import json


class CaseManageTestModel(BaseModel):
    CHOICES_LEVEL = (
        (1, '一级用例'),
        (2, '二级用例'),
        (3, '三级用例'),
        (4, '四级用例'),
        (5, '五级用例')
    )

    name = models.CharField(max_length=64, verbose_name='用例名称')
    test_content = models.TextField(null=True, verbose_name='用例内容')
    case_path = models.CharField(max_length=512, null=True, verbose_name='用例路径')
    case_type = models.IntegerField(verbose_name='用例类型', default=1)
    case_level = models.IntegerField(verbose_name='用例等级', choices=CHOICES_LEVEL, default=1)
    project = models.ForeignKey('project_crud.ProjectModel', null=True, on_delete=models.CASCADE, verbose_name='所属项目')
    user_exe = models.ForeignKey('user.UserModel', null=True, on_delete=models.CASCADE,  verbose_name='操作人')
    page = models.ForeignKey('page.PageModel', null=True, on_delete=models.CASCADE, verbose_name='页面id')
    case_details = models.CharField(max_length=512,verbose_name='用例备注', null=True, blank=True)
    task = models.OneToOneField('execution_case.ExecutionCaseModel', null=True, on_delete=models.CASCADE,  verbose_name='任务id')

    class Meta:
        db_table = 'tb_case_manage'
        verbose_name = '用例管理'
        verbose_name_plural = '用例管理'

    @transaction.atomic
    def setIsdeleteTrue(self):
        self.is_delete = True
        execution_obj = ExecutionCaseModel.objects.get(id=self.task_id)
        execution_obj.is_delete = True
        execution_obj.save(update_fields=['is_delete'])
        self.save()

    # def getTestContent(self):
    #     test_content = json.loads(self.test_content)
    #     for content in test_content:
    #         page_id = content['page_id']
    #         content['page_name'] = PageModel.objects.get(id=page_id).name
    #     return test_content

    def getPageList(self):
        page_list = []
        if isinstance(self.test_content,str):
            test_content = json.loads(self.test_content)
            for content in test_content:
                page_list.append({'page_id':content['page_id'], 'page_name':PageModel.objects.get(id=content['page_id']).name})
        return page_list

    def updateCasePage(self, pk, name):
        test_content = json.loads(self.test_content)
        for content in test_content:
            page_id = content['page_id']
            if page_id == int(pk):
                content['page_name'] = name
        self.test_content = json.dumps(test_content)
        self.save()