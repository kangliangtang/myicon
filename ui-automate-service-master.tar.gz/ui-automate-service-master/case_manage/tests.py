from project_crud.models import ProjectModel


def main():
    import django
    import os
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "automate_uitest_py3.settings")
    os.environ.setdefault("devops_env", "uat")
    django.setup()
    from case_manage.models import CaseManageTestModel,ExecutionCaseModel
    case_obj = CaseManageTestModel.objects.get(id=240)
    # task = case_obj.task
    o = ProjectModel.objects.get(id=1)
    o.owner.add()
    o.save()



    case_obj.setIsdeleteTrue()

    print(case_obj.name)

    CaseManageTestModel.objects.filter(id=240).update(name="test123")

    # case_obj = CaseManageTestModel.objects.get(id=240)
    case_obj.name='test123'
    case_obj.save()


if __name__ == '__main__':
    main()
