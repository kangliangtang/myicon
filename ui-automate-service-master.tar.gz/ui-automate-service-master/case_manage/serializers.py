from case_manage.models import CaseManageTestModel
from rest_framework import serializers
import json
from utils.serializer import ZJsonField
from execution_case.models import ExecutionCaseModel
from project_crud.models import ProjectModel
import copy
from django.db import transaction
from utils.case_dump import CaseDump
from logging import getLogger
case_dump = CaseDump()
debug_log = getLogger('debug')


class CaseManageSerializer(serializers.ModelSerializer):
    test_content = ZJsonField(default=[])
    # test_content = serializers.ReadOnlyField(source='getTestContent') #
    creator_name = serializers.ReadOnlyField(source='user_exe.username')
    case_level = serializers.ChoiceField(choices=((1, '一级用例'),(2, '二级用例'),(3, '三级用例'),(4, '四级用例'),(5, '五级用例')))

    class Meta:
            model = CaseManageTestModel
            exclude = ('is_delete','case_path', 'case_type', 'update_time','task', 'project', 'user_exe')
            # fields = ('id', 'name', 'case_level', 'create_time', 'user_exe', 'case_notes', 'test_content', 'case_type', 'creator_name', )

    def validate_test_content(self, data):
        try:
            data_ = json.loads(data)
        except Exception as e:
            raise serializers.ValidationError('json格式错误')
        if not isinstance(data_, list):
            raise serializers.ValidationError('格式错误，参数因为数组')
        return data

    @transaction.atomic
    def create(self, validated_data):
        request = self.context['request']
        test_data = copy.deepcopy(validated_data)
        test_data['test_content'] = json.loads(test_data['test_content'])
        try:
            path = case_dump.dumpCaseToPath(test_data)
            if path is False:
                raise serializers.ValidationError({'message': '用例内容中有元素或页面不存在，请重新确认'})
        except Exception as e:
            debug_log.info(e)
            # debug_log.exception(e)
            raise serializers.ValidationError({'message': '用例内容不正确，保存失败'})
        validated_data['case_path'] = path
        validated_data['case_type'] = 1
        validated_data['project_id'] = self.context['view'].kwargs['project_id']
        validated_data['user_exe_id'] = request.user.id
        instance = super().create(validated_data)
        case_id_list = []
        case_id_list.append(instance.id)
        execution_obj = ExecutionCaseModel.objects.create(
            name=instance.name,
            status='unexecuted',
            task_type=1,
            level=instance.case_level,
            test_file=instance.case_path,
            case_id_list=case_id_list,
            project_id=self.context['view'].kwargs['project_id']
        )
        ProjectModel.objects.get(id=self.context['view'].kwargs['project_id']).addCase()  # 用例数加一
        CaseManageTestModel.objects.filter(id=instance.id).update(task_id=execution_obj.id)
        return instance

    def update(self, instance, validated_data):
        request = self.context['request']
        request_data = request.data
        validated_data['project_id'] = self.context['view'].kwargs['project_id']
        validated_data['case_path'] = request_data["case_path"]
        # validated_data['user_exe'] = request_data["user_exe"]
        validated_data['case_type'] = request_data["case_type"]
        return super().update(instance, validated_data)


class PageListSerializer(serializers.ModelSerializer):
    pagelist = serializers.ReadOnlyField(source='getPageList')

    class Meta:
        model = CaseManageTestModel
        # exclude = ('is_delete', 'test_content', 'update',)
        fields = ('pagelist',)

class UserListSerializer(serializers.ModelSerializer):
    # test_content = ZJsonField(default=[])
    creator_name = serializers.ReadOnlyField(source='user_exe_id__username')
    user_id = serializers.ReadOnlyField(source='user_exe_id')
    class Meta:
        model = CaseManageTestModel
        # exclude = ('is_delete', 'test_content', 'update',)
        fields = ('id', 'user_id', 'creator_name')
