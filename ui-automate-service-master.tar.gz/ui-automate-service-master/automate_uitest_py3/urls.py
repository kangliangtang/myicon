"""uiautotest URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url, include

from automate_uitest_py3.swagger_views import get_swagger_view
schema_view = get_swagger_view(title='Pastebin API')
from system.views import EurekaHelthAPIView
from case_manage.urls import router as case_router
from page.urls import router as page_router
from uisystem.urls import router as system_router
from element.urls import router as element_router
from project_crud.urls import project_router
from project_crud import api_views
from public_warehouse.urls import router as warehouse_router
from timed_task.urls import router as timedtask_router

urlpatterns = [
    url(r'^api/projects/(?P<project_id>\d+)/', include(case_router.urls)),
    url(r'^api/projects/(?P<project_id>\d+)/', include(page_router.urls)),
    url(r'^api/projects/(?P<project_id>\d+)/', include(system_router.urls)),
    url(r'^api/projects/(?P<project_id>\d+)/', include(element_router.urls)),
    url(r'^api/projects/(?P<project_id>\d+)/', include('keyword_action.urls')),
    url(r'^api/projects/(?P<project_id>\d+)/user/', include('user.urls')),
    url(r'^api/', include(project_router.urls)),
    url(r'^api/projects/(?P<project_id>\d+)/', include('execution_case.urls')),
    url(r'^api/projects/(?P<project_id>\d+)/', include(timedtask_router.urls)),
    url(r'^api/projects/(?P<project_id>\d+)/public/', include(warehouse_router.urls)),
    url(r'^sync/', include('project_crud.urls')),
    # url(r'^api/public/(?P<project_id>[^/.]+)/', include(warehouse_router.urls)),
    url(r'^health', EurekaHelthAPIView.as_view()),
    url(r'^v2/choerodon/api-docs$', schema_view),
    url(r'^$', schema_view),
]
