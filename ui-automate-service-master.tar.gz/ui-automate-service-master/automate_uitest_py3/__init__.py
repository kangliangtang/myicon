from __future__ import absolute_import, unicode_literals
from .celery import app as celery_app
import pymysql


__all__ = ('celery_app',)  #确保当django项目运行时，这个app总是被import
pymysql.install_as_MySQLdb()
