from django.shortcuts import render

# Create your views here.
from rest_framework.renderers import JSONRenderer
from rest_framework.response import Response
from rest_framework.status import HTTP_200_OK

from rest_framework.views import APIView

from utils.steam_authentication import SwaggerAuthentication


class EurekaHelthAPIView(APIView):

    renderer_classes = [JSONRenderer]
    permission_classes = []
    authentication_classes = [SwaggerAuthentication]


    def get(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"get",
            "menuLevel":null,
            "permissionLevel":null,
            "roles":[

            ],
            "permissionLogin":false,
            "permissionPublic":true,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return Response(data={"status": "UP"}, status=HTTP_200_OK)
