from utils import summary_handle


class HtmlTemplate(object):
    """HTML报告模板"""
    DOCTYPE = r"""<!DOCTYPE html>
    <html>"""

    HEAD = r"""<head>
    	<meta charset="utf-8">
    	<title>report</title>
    	<style>
        * {
          margin: 0;
          padding: 0;
        }
        * {
          box-sizing: border-box
        }
        *::before,
        *::after {
          box-sizing: inherit;
        }
        body {
          font-family: Arial, Helvetica, sans-serif;
          color: #666;
          font-size: 0.875rem;
          padding: 1rem;
          line-height: 1.5;
        }
        a {
          color: #ff6f4b;
          text-decoration: none;
        }
        a:hover {
          color: #ff8c6f;
        }
        .row {
          display: flex;
        }
        .col {
          flex: 1 1 auto
        }
        .mb-1 {
          margin-bottom: 1rem;
        }
        .table {
          width: 100%;
          color: #666;
          border-collapse: separate;
          border-spacing: 0;
          text-align: center;
        }
        .table td,
        .table th {
          border: 0;
          padding: 10px 0
        }
        .table th {
          background: #f5f5f5;
          font-weight: bold;
          border-bottom: 1px solid #f5f5f5;
        }
        .table td {
          border-bottom: 1px solid #f5f5f5
        }
        .table tr:last-child td {
          border-bottom: 0
        }
        .title {
          margin-bottom: 1rem;
        }
        .tag {
          display: inline-block;
          min-width: 60px;
          padding: 5px 8px;
          font-size: 14px;
          border: 1px solid transparent;
          text-align: center;
          font-weight: normal;
          line-height: 1;
        }
       .success {
        color: #4ccd79;
        border-color: #4ccd79;
       }
       .fail {
         color: #f10000;
         border-color: #f10000;
        }
        .error {
          color: #f0a100;
          border-color: #f0a100;
        }
    		.reportTable{
    			border:1px solid #ccc;
    			text-align: center;
    		}
        .modal-open {
          overflow: hidden;
        }
    		.dialog {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          z-index: 100;
          display: none;
        }
        .mask {
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: linear-gradient(0deg,rgba(0,0,0,.75),rgba(0,0,0,.85));
        }
        .dialog-container {
          width: 100%;
          height: 100%;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .dialog-content {
          position: relative;
          z-index: 10;
          background: #fff;
          width: 100%;
          height: 100%;
        }
        .dialog-header {
          text-align: right;
          padding: 10px 16px 0
        }
        .dialog-body {
          padding: 2rem;
        }
        .close-btn {
          position: relative;
          display: inline-block;
          width: 1.5rem;
          height: 1.5rem;
          cursor: pointer;
        }
        .close-btn::before,
        .close-btn::after {
          content: ' ';
          position: absolute;
          top: 50%;
          margin-top: -1px;
          display: block;
          width: 100%;
          height: 2px;
          background: #d8d8d8;
        }
        .close-btn::before {
          transform: rotate(45deg)
        }
        .close-btn::after {
          transform: rotate(-45deg)
        }
        .close-btn:hover::before,
        .close-btn:hover::after {
          background: #ff6f4b
        }
        .img-wrap img {
          display: block;
          max-width: 100%;
        }

        .error-text {
          text-align: center;
          padding: 10px;
        }
    	</style>
    </head>"""

    BODY = r"""<body>"""

    TITLE = r"""<h2>%(title)s</h2>
    <div class="row mb-1"></div>"""  # (title)

    BASEINFO_DIV = r"""<div>
    	<!-- 基本信息 -->
    	<div class="basicInfo">
        <div class="row mb-1">
          <div class="col">开始时间: %(startTime)s</div>
          <div class="col">执行耗时: %(duration)s</div>
          <div class="col">浏览器: %(webdriver)s</div>
        </div>
        <div class="row mb-1">
          <div class="col">总脚本数: %(Total)s</div>
        </div>
        <div class="row mb-1">
          <div class="col">成功脚本数: %(Success)s</div>
        </div>
        <div class="row mb-1">
          <div class="col">失败脚本数: %(Fail)s</div>
        </div>
    	</div>

      <div id="detailBox"></div>

      <div id="dialog" class="dialog">
        <div class="dialog-container">
          <div class="mask" onclick="hideDialog()"></div>
          <div class="dialog-content">
            <div class="dialog-header">
              <div class="close-btn" onclick="hideDialog()"></div>
            </div>
            <div class="dialog-body">
              <div id="img" class="img-wrap">
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>"""   # (startTime, duration,webdriver, Total, Success, Fail)

    BODY_SCRIPT_LETARR = r"""<script type="text/javascript">
    	let arr = %(letarr)s"""  # (letarr)

    BODY_SCRIPT_LET = r"""
      let detailBox = document.getElementById('detailBox')
      let dialog = document.getElementById('dialog')
      let imgContainer = document.getElementById('img')
    
      function formatResult(data) {
        switch (data) {
          case 'success':
            return '成功'
            break
          case 'fail':
            return '失败'
            break
          case 'error':
            return '错误'
            break
        }
      }
    
    
      function mainTemplate(data) {
        let html = ''
        for (let i = 0; i < data.length; i++) {
          html = html + `<h4 class="title">
    					<span>${data[i].title}</span>
    					<span class="tag ${data[i].status}">${data[i].status}</span>
    				</h4> ${tableTemplate(data[i].tableData)}` 
        }
        return html
      }

      function tableTemplate(data) {
        let html = `<table class="table mb-1" summary="report" rules="all" cellpadding="5" width="80%" align="center">
    					<thead>
    						<tr>
    							<th>元素</th>
    							<th>动作</th>
    							<th>值</th>
    							<th>结果</th>
    							<th>操作</th>
    							<th>错误信息</th>
    						</tr>
    					</thead><tbody>`
        for (let i = 0; i < data.length; i++) {
          html = html + `
    						<tr>
    							<td width="140"><span>${data[i].eleName}</span></td>
    							<td width="140"><span>${data[i].action}</span></td>
    							<td width="180"><span>${data[i].value}</span></td>
    							<td width="140"><span class="tag ${data[i].result}">${formatResult(data[i].result)}</span></td>
    							<td width="180"><a class="viewBtn" href="${data[i].viewImg}">显示图片</a></td>
    							<td><span>${data[i].errorInfo}</span></td>
    						</tr>`
        }
        html = html + `</tbody></table>`
        return html
      }

      function showDialog(url) {
        dialog.style.display = 'block'
      }

      function hideDialog() {
        dialog.style.display = 'none'
      }

      function loadImg(url) {
        const img = new Image()
        img.onload = function () {
          imgContainer.removeChild(imgContainer.firstChild)
          imgContainer.appendChild(img)
        }
        img.onerror = function () {
          imgContainer.removeChild(imgContainer.firstChild)
          imgContainer.innerHTML = '<div class="error-text">图片加载失败</div>'
        }
        img.src = url
        imgContainer.innerHTML = '<div class="error-text">加载中...</div>'
      }
      // bootrap
      detailBox.innerHTML = mainTemplate(arr)

      detailBox.addEventListener('click', function (event) {
        const target = event.target
        if (target.classList.contains('viewBtn')) {
          event.preventDefault()
          showDialog()
          target.href && loadImg(target.href)
        }
      }, false)

    </script>"""

    END = r"""</body>
    </html>"""


class HTMLReport(HtmlTemplate):
    """生成HTML报告文件"""
    def __init__(self, title='测试报告', file_path=None):
        self.title = title
        self.file_path = file_path
        super().__init__()

    def __generateLetArr(self, result_data):
        """将summary数据转化为html模板对应格式"""
        let_arr = []
        for case_result in result_data:
            let_arr_dict = dict()
            tableData = list()
            let_arr_dict['title'] = case_result['title']
            let_arr_dict['status'] = case_result['case_status']
            details = case_result['details']
            for step_data in details:
                tableData_dict = dict()
                tableData_dict["eleName"] = step_data["element_name"]
                tableData_dict["action"] = step_data["action"]
                tableData_dict["value"] = step_data["value"]
                tableData_dict["result"] = step_data["step_status"]
                tableData_dict["viewImg"] = step_data["attachment"]
                tableData_dict["errorInfo"] = step_data["detail"]
                tableData.append(tableData_dict)
            let_arr_dict['tableData'] = tableData
            let_arr.append(let_arr_dict)
        return let_arr

    def _generateBaseInfo(self, baseinfo):
        """基本信息"""
        html_baseInfo = self.BASEINFO_DIV % dict(
            startTime=baseinfo["startTime"],
            duration=baseinfo["duration"],
            webdriver=baseinfo["webdriver"],
            Total=str(baseinfo["Total"]),
            Success=str(baseinfo["Success"]),
            Fail=str(baseinfo["Fail"])
        )
        return html_baseInfo

    def _generateResult(self, result):
        """详细信息"""
        letarr = self.__generateLetArr(result)
        html_script_letarr = self.BODY_SCRIPT_LETARR % dict(letarr=letarr)
        return html_script_letarr

    def generateHtmlReport(self, summary_count):
        """生成HTML报告文件"""
        try:
            data = summary_handle.summary_result_simple(summary_count)
            baseinfo = data["baseinfo"]
            result = data['result']
            file_name = self.file_path
            self.TITLE_ = self.TITLE % dict(title=self.title)
            with open(file_name, 'w', encoding='utf8') as f:
                f.write(self.DOCTYPE)
                f.write(self.HEAD)
                f.write(self.BODY)
                f.write(self.TITLE_)
                f.write(self._generateBaseInfo(baseinfo))
                f.write(self._generateResult(result))
                f.write(self.BODY_SCRIPT_LET)
                f.write(self.END)
        except Exception as e:
            print('---报告文件生成错误---%s' % e)
            pass

    def generateHtmlData(self, summary_count):
        """生成HTML数据 (bytes)"""
        try:
            data = summary_handle.summary_result_simple(summary_count)
            baseinfo = data["baseinfo"]
            result = data['result']
            self.TITLE_ = self.TITLE % dict(title=self.title)
            self.BASE_INFO = self._generateBaseInfo(baseinfo)
            self.RESULT = self._generateResult(result)
            str_ = str()
            html_data_list = [self.DOCTYPE, self.HEAD, self.BODY, self.TITLE_, self.BASE_INFO, self.RESULT,
                              self.BODY_SCRIPT_LET, self.END]
            for html_data in html_data_list:
                str_ += html_data
            return str_.encode()
        except Exception as e:
            return b''


if __name__ == '__main__':
    summary_count = {'result': [{'webdriver': 'Chrome', 'details': [{'step': {'data': {'action': 'admin'}, 'verify': [], 'id': 1, 'action': {'type': 'inputText'}, 'element': {'type': 'xpath', 'value': '//*[@id="password"]', 'id': 11, 'name': '密码'}}, 'attachment': '/app/ui-automate-data/screenshot/1565061643938.png', 'detail': 'pass', 'duration': '0.80s', 'status': 'success'}], 'startTime': '2019-08-06 11:20:42', 'duration': '1.62s', 'testcases': {'Success': 1, 'Fail': 0, 'Total': 1}, 'case_status': 'success', 'url': 'http://home.crc.com.cn/oauth/login', 'title': '调试1111'}, {'webdriver': 'Chrome', 'details': [{'step': {'data': {'action': '${{nn}}'}, 'verify': [], 'id': 1, 'action': {'type': 'sendKeys'}, 'element': {'type': 'id', 'value': 'username', 'id': 10, 'name': '用户名'}}, 'attachment': '/app/ui-automate-data/screenshot/1565061657216.png', 'detail': '未找到该元素id=username.或执行动作失败', 'duration': '10.69s', 'status': 'error'}], 'startTime': '2019-08-06 11:20:46', 'duration': '11.48s', 'testcases': {'Success': 0, 'Fail': 1, 'Total': 1}, 'case_status': 'fail', 'url': 'http://home.crc.com.cn/oauth/login', 'title': '调试测试'}, {'webdriver': 'Chrome', 'details': [{'step': {'data': {'action': ''}, 'verify': [], 'id': 1, 'action': {'type': 'clickImage'}, 'element': {'type': 'image', 'value': '/static/image/1564969654611262.png', 'id': 45, 'name': '1080华润阅读'}}, 'attachment': '/app/ui-automate-data/screenshot/1565061662212.png', 'detail': 'pass', 'duration': '2.11s', 'status': 'success'}], 'startTime': '2019-08-06 11:20:59', 'duration': '2.89s', 'testcases': {'Success': 1, 'Fail': 0, 'Total': 1}, 'case_status': 'success', 'url': 'http://home.crc.com.cn/', 'title': 'test'}], 'baseinfo': {'title': 'test222', 'status': 'fail', 'webdriver': 'Chrome', 'startTime': '2019-08-06 11:20:42', 'duration': '15.99s', 'Success': 2, 'Fail': 1, 'Total': 3}}
    obj = HTMLReport(title='定时任务报告', file_path='./test22.html')
    obj.generateHtmlReport(summary_count)


