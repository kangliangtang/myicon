import json
from django.utils.translation import ugettext_lazy as _
from rest_framework import serializers



class ZJsonField(serializers.JSONField):
    """
    Color objects are serialized into 'rgb(#, #, #)' notation.
    """
    default_error_messages = {
        'invalid_json': _('无效的json格式.')
    }
    def to_representation(self, value):
        try:
            value = json.loads(value)
        except Exception as e:
            print('utils-->serializer--->',e)
            value = None
        return value

    def to_internal_value(self, data):

        if isinstance(data, str):
            try:
               json.loads(data)
            except (TypeError, ValueError):
                self.fail('invalid_json')
            return data
        return json.dumps(data)