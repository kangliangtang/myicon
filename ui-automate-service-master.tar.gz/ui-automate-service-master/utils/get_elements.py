import time
from lxml import etree
from automate_uitest_py3 import settings
import cv2,os
from utils import base_selenium
from utils.common_parameter import ReplaceCommonParameter
from page.models import PageModel
from public_warehouse.models import PublicActionModel
from element.models import ElementModel
import copy
import json
from logging import getLogger
debug_log = getLogger('debug')
driver = base_selenium.BaseSelenium()


class GetElements():
    def __init__(self,url, login=False):
        # self.page_source = ''
        self.element_list = []
        self.elements = []
        self.driver = driver
        self.path = ''
        self.img = ''
        self.url = url
        self.login_id = login

    def getElements(self):
        debug_log.info('open url:{}'.format(self.url))
        self.openUrl()
        if self.login_id:
            debug_log.info('login')
            status = self.login()
            if status is False:
                return False
        debug_log.info('dumpElements')
        time.sleep(2)
        self.dumpElements()
        debug_log.info('markElements')
        element = self.markElements()
        debug_log.info('quitWeb')
        try:
            self.driver.closeWeb()
        except Exception as e:
            debug_log.error('quit web fail.{}'.format(e))
        return element

    def dumpElements(self):
        data = etree.HTML(self.driver.getPageSource())
        htree = etree.ElementTree(data)
        li_elements = data.xpath('//li')
        elements = copy.copy(li_elements)
        for element in elements:
            li = element.getparent()
            if li.__len__() == 0:
                continue
            if li.tag == 'a' or li.tag == 'button' or li.tag == 'input':
                li_elements.remove(element)
        a_elements = data.xpath('//a')
        elements = copy.copy(a_elements)
        for element in elements:
            a = element.getparent()
            if a.__len__() == 0:
                continue
            if a.tag == 'li' or a.tag == 'button' or a.tag == 'input':
                a_elements.remove(element)
        all_elements =data.xpath('//input') + data.xpath('//button') + a_elements + li_elements
        location = [{'x': 0, 'y': 0}]
        for element in all_elements:

            if element.attrib.get('type', '') == 'hidden' or 'aria-hidden' in element.attrib.keys() or element.attrib.get('style', '') == 'display: none;':
                continue
            path = htree.getpath(element)
            try:
                element = self.driver.findElementByXpath(path)
            except:
                continue
            e_location = element.location
            if e_location in location:
                continue
            location.append(e_location)
            rect = element.size
            rect.update(e_location)
            self.element_list.append({'xpath':path, 'element':element, 'rect':rect})

    # @profile
    def markElements(self):
        try:
            self.path = self.driver.screensHotAsFile()
            self.img = cv2.imread(self.path)
            img = copy.deepcopy(self.img)
            self.width = img.shape[1]
            self.heigh = img.shape[0]
            n = 1
            for element in self.element_list:
                xpath = element['xpath']
                rect = element['rect']
                x1 = rect['x'] + rect['width']
                y1 = rect['y'] + rect['height']
                if x1==0 or y1==0:
                    continue
                if x1 >= self.width or y1 >= self.heigh:
                    continue
                cv2.rectangle(img, (int(rect['x']), int(rect['y'])), (int(x1), int(y1)), (0,255,0), 2)
                cv2.putText(img, str(n), (int(rect['x']), int(rect['y'] + 12)), cv2.FONT_HERSHEY_TRIPLEX, 0.5,(0, 0, 255))
                # print(str(n)+'---'+xpath+"-------------"+json.dumps(rect))
                path = self.splitImage(int(rect['x']), int(rect['y']), int(x1), int(y1))
                name = element['element'].text
                if name:
                    element_name = '{}_{}'.format(n, name)
                else:
                    element_name = '{}'.format(n)
                elements = {"name":element_name , "locmode": "image", "image_path": path, "note_info": "xpath={}".format(xpath)}
                n += 1
                self.elements.append(elements)
            rq = int(time.time() * 1000)
            screen_name = str(rq) + '.png'
            path = os.path.join(settings.IMAGE_DIR, screen_name)
            cv2.imwrite(path, img)
            image_path = settings.BASE_HOST + path.split('ui-automate-data')[1]
            return {'image':image_path, 'elements':self.elements}
        except Exception as e:
            debug_log.error('mark element fail.{}'.format(e))
            return {'image': '', 'elements': self.elements}

        # print(self.elements)

    # @profile
    def splitImage(self,x,y,x1,y1):
        rq = int(time.time() * 1000)
        screen_name = str(rq) + '.png'
        path = os.path.join(settings.IMAGE_DIR, screen_name)
        if x<20:
            x = 0
        else:
            x = x-20
        if y<20:
            y = 0
        else:
            y = y-20
        if self.heigh-y1<20:
            y1 = self.heigh
        else:
            y1 = y1+20
        if self.width-x1<20:
            x1 = self.width
        else:
            x1 = x1+20
        img = self.img[int(y):int(y1),int(x):int(x1)]
        cv2.imwrite(path, img)
        # print(image_match.findImageByThreshold(0.9,path,self.path))
        image_path = settings.BASE_HOST + os.path.join(settings.IMAGE_PATH, screen_name)
        return image_path


    def openUrl(self):
        try:
            self.driver.startWeb('', '', self.url)
        except Exception as e:
            debug_log.error('open url fail.{}'.format(e))
            self.driver = base_selenium.BaseSelenium()
            self.driver.startWeb('', '', self.url)
        # time.sleep(3)
        # self.page_source = self.driver.getPageSource()

    def getPage(self,url,data):
        import urllib.request as request
        request_data = request.Request(url,headers=data)
        # request_data.add_header(data)
        response = request.urlopen(request_data)
        # time.sleep(3)
        html = response.read().decode("utf-8")
        print(html)
        return html

    def login(self):
        content = PublicActionModel.objects.get(id=self.login_id).content
        # update 增加公共动作中公共变量的替换 klt
        try:
            # page_id = PublicActionModel.objects.get(id=self.login_id).page_id
            # project_id = PageModel.objects.get(id=page_id).project_id
            project_id = PublicActionModel.objects.get(id=self.login_id).project_id
            repalce_obj = ReplaceCommonParameter(project_id=project_id)
            content = repalce_obj.json_common_param(content)
        except Exception as e:
            debug_log.error('Element assistant replacement common variable Error:{}'.format(e))

        content = json.loads(content)
        element_obj = ElementModel.objects.filter(is_delete=False)
        for page in content:
            for data in page.get('data',''):
                by = ''
                value = ''
                element_id=data.get('element_id', '')
                if element_id:
                    element = element_obj.get(id=element_id)
                    by = element.locmode
                    value = element.image_path if element.locmode == 'image' else element.location
                action = data.get('action', '')
                text = data.get('data','')
                print(by,value,text)
                if action:
                    try:
                        func = getattr(self.driver, action)
                        func(by, value, text)
                    except Exception as e:
                        debug_log.error('login fail.{}.action={}.by={}.value={}.text={}'.format(e,action, by, value, text))
                        return False
        # time.sleep(5)
        # self.page_source = self.driver.getPageSource()
