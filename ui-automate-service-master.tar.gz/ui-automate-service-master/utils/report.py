import time
import os
from automate_uitest_py3 import settings
import json
from utils import summary_handle
from utils.minio_service_file import MinioServiceFile
from utils.htmlreport import HTMLReport


def get_summary(Result):
    """UI测试报告结果"""
    _summary = {
        "title": Result.title,
        "url":Result.test_url,
        "startTime": Result.startTime,
        "duration": Result.case_duration,
        "testcases": Result.testcases,
        "details": Result.details,
        "webdriver": Result.webdriver,
        "case_status": Result.case_status
    }
    return _summary


class TestResult(object):
    def __init__(self, title, webdriver="Firefox", url=""):
        self.start_time = time.time()
        self.step_time = time.time()
        self.end_time = time.time()
        self.title = title
        self.Total = 0
        self.Success = 0
        self.Fail = 0
        self._testcases = {}
        self.details = []
        self.webdriver = webdriver  # 浏览器类型 todo 加版本号
        self.test_url = url
        self.case_status = 'fail'   # 用例状态

    @property
    def startTime(self):
        return time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(self.start_time))

    @property
    def stepStartTime(self):
        self.step_time = time.time()
        return self.step_time

    def record_step(self, step_name, status, detail, attachment):
        """执行步骤记录"""
        data = {
            "step": step_name,
            "duration": self.stepDuration,
            "status": status,
            "detail": "{}".format(detail),
            "attachment": attachment  # 截图
        }
        self.details.append(data)

    def addSuccess(self, step, detail="pass", attachment=''):
        self.Success += 1
        self.record_step(step, "success", detail, attachment)

    def addFail(self, step, detail, attachment=''):
        self.Fail += 1
        self.record_step(step, "fail", detail, attachment)

    def addError(self, step, detail, attachment=''):
        self.Fail += 1
        self.record_step(step, 'error', detail, attachment)

    @property
    def testcases(self):
        self.Total = (self.Success + self.Fail)
        if self.Total == self.Success:
            self.case_status = 'success'
        self._testcases = {"Total": self.Total, "Success": self.Success, "Fail": self.Fail}
        return self._testcases

    @property
    def case_duration(self):
        return '%.2f' % (self.end_time - self.start_time) + 's'

    @property
    def stepDuration(self):
        return '%.2f' % (time.time() - self.step_time) + 's'

    def countData(self, summary):
        self.execute_time = 0
        self.status = 'success'
        self.total_case = len(summary)
        self.fail_case = 0
        self.success_case = 0
        self.all_start_time = summary[0]['startTime']
        for _sum in summary:
            # self.success_case += _sum['testcases']['Success']
            # self.fail_case += _sum['testcases']
            if _sum['case_status'] == 'success':
                self.success_case += 1

            elif _sum['case_status'] == 'fail':
                self.status = 'fail'
                self.fail_case += 1
            else:
                self.status = 'error'
                self.fail_case += 1
            exec_time = _sum['duration'].strip('s')
            self.execute_time += float(exec_time)
        self.execute_time = '%.2f' %self.execute_time + 's'
        info = {
            'Total':self.total_case,
            'Fail':self.fail_case,
            'Success':self.success_case,
            'startTime':self.all_start_time,
            'duration':self.execute_time,
            'status':self.status,
            "webdriver": self.webdriver
        }
        return info

    def dumpResultJson(self, summary, title):
        case_name = '{}.json'.format(str(time.time()).replace('.', ''))
        file_path = os.path.join(settings.REPORT_DIR, case_name)
        result = {}
        result['baseinfo'] = self.countData(summary)
        result['baseinfo']['title'] = title
        result['result'] = summary
        with open(file_path, 'w', ) as f:
            f.write(json.dumps(result, indent=4))
        print("---------------report:" + file_path)
        self.countData(summary)
        # return file_path, result

        # update 增加Mioio服务 2019-09-03 20:05:29
        minio_obj = MinioServiceFile()
        # 上传测试报告 .json
        put_json_file = minio_obj.put_file(bucket_name=settings.REPORT_BUCKET_NAME, put_file_path=file_path)
        if put_json_file:
            os.remove(file_path)   # 删除本地报告文件
            file_path = '/{0}/{1}'.format(settings.REPORT_BUCKET_NAME, case_name)

        # 生成html报告
        html_report_name = '{}.html'.format(str(time.time()).replace('.', ''))
        html_report_file = os.path.join(settings.REPORT_DIR, html_report_name)
        htmlreport_obj = HTMLReport(file_path=html_report_file)
        htmlreport_obj.generateHtmlReport(result)
        # minio_obj = MinioServiceFile()
        report_down_url = ''
        put_ret = minio_obj.put_file(bucket_name=settings.REPORT_BUCKET_NAME, put_file_path=html_report_file)
        if put_ret:
            os.remove(html_report_file)     # 删除本地html报告
            report_down_url = minio_obj.get_file_url(bucket_name=settings.REPORT_BUCKET_NAME, file_name=html_report_name)
        return file_path, result, report_down_url

    def dumpResult(self, summary):
        result = {}
        result['baseinfo'] = self.countData(summary)
        result['baseinfo']['title'] = summary[0].get('title','')
        result['result'] = summary
        result_simple = settings.BASE_HOST
        result_simple = summary_handle.summary_result_simple(result,result_simple)
        return result_simple

