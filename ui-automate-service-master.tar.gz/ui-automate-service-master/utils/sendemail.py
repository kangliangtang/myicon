
from django.conf import settings
from django.core.mail import EmailMultiAlternatives, send_mass_mail

from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import formataddr
from utils import smtplibthrsix
import os


class SendEmail(object):
    """发送邮件"""
    def __init__(self, subject='', body='', bodytype='plain', from_email=settings.DEFAULT_FROM_EMAIL, to=None,  attachments=None):
        self.subject = subject                  # 邮件主题
        self.body = body                        # 邮件正文
        self.bodytype = bodytype                # 邮件正文格式（plain/html）;默认纯文本plain
        self.from_email = from_email            # 发件邮箱
        self.to = to                            # 接收邮箱(List); 示例['13579@qq.com', '24681@qq.com']
        self.attachments = attachments          # 附件(示例 D://test.json); 多个附件时,采用列表传参. 示例 ['D://file1.txt', 'D://file2.txt']

    # def send_email(self):
    #     """发送邮件"""
    #     datatuple = ((self.subject, self.body, self.from_email, self.to),)
    #     send_mass_mail(datatuple)

    def send_task_email(self, project_name, task_name=None, task_result_status=None, task_time=None, env_host=None):
        """ 发送定时任务结果报告 邮件
        :param project_name:           项目名称
        :param task_name:             任务名称
        :param task_result_status:    任务执行结果状态
        :param task_time:             任务执行时间
        :return:
        """
        # 邮件内容(文本格式)
        text_content = '{0}项目下的定时任务{1}已执行完成,执行环境为{2},执行结果为{3},执行时间为{4}。详细测试结果见附件'.format(project_name, task_name, env_host, task_result_status,task_time)
        # 邮件内容(html格式)
        html_content = '<b>{0}</b>项目下的定时任务<b>{1}</b>已执行完成,执行环境为<b>{2}</b>,执行结果为<b>{3}</b>,执行时间为<b>{4}</b>。详细测试结果见附件'
        html_content = html_content.format(project_name, task_name, env_host, task_result_status, task_time)
        if self.bodytype == 'html':
            self.body = html_content
        else:
            self.body = text_content

        # 改使用 python3.5 smtp
        self.send_email()

    def send_email(self):
        """发送邮件 python3.5 环境下使用"""
        try:
            emailhost = settings.EMAIL_HOST
            username = settings.EMAIL_HOST_USER
            password = settings.EMAIL_HOST_PASSWORD
            from_addr = self.from_email
            port = settings.EMAIL_PORT
            msg = MIMEMultipart()
            msg['subject'] = self.subject
            # 邮件正文
            if self.bodytype == "html":
                msg.attach(MIMEText(self.body, _subtype='html', _charset='utf-8'))
            else:
                txt = MIMEText(self.body, 'plain', 'utf-8')
                msg.attach(txt)
            # 添加附件
            if self.attachments:
                if isinstance(self.attachments, list):
                    for attachment in self.attachments:
                        file_path = attachment
                        file_name = os.path.basename(file_path)
                        part = MIMEApplication(open(file_path, 'rb').read())
                        part.add_header('Content-Disposition', 'attachment', filename=file_name) # filename给附件重命名,默认与原文件名一样
                        msg.attach(part)
                else:
                    file_path = self.attachments
                    file_name = os.path.basename(file_path)
                    part = MIMEApplication(open(file_path, 'rb').read())
                    part.add_header('Content-Disposition', 'attachment', filename=file_name)
                    msg.attach(part)

            # 邮件发/收件人显示中文
            msg['From'] = formataddr(pair=(settings.EMAIL_FROM_NAME, settings.EMAIL_HOST_USER))
            msg['To'] = ','.join(self.to)
            server = None
            try:
                server = smtplibthrsix.SMTP(emailhost, port)
                # server = smtplibthrsix.SMTP_SSL(emailhost, port=465)  # 用SSL的方式去登录得用SMTP_SSL，端口号465或587
                server.ehlo()
                server.starttls()
                server.login(username, password)
                server.sendmail(from_addr, self.to, str(msg))
                return True  # 发送成功
            except Exception as e:
                print('send email fail,Error:%s' % e)
                return False
            finally:
                # 删除本地附件
                if os.path.isfile(self.attachments) and os.path.exists(self.attachments):
                    os.remove(self.attachments)
                server.quit()
        except Exception as e:
            print('send email fail,Error:%s' % e)
            return False
