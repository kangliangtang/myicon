# coding=utf-8

from rest_framework import renderers
from rest_framework.compat import (
    INDENT_SEPARATORS, LONG_SEPARATORS, SHORT_SEPARATORS, coreapi,
    pygments_css
)
from django.utils import six
import json

code_dic = {400: u'不合法的输入', 401: u'用户未登录', 403: u'用户未授权', 405: u'不被支持的操作类型'}  # 注意4xx,5xx的错误


class APIRenderer(renderers.JSONRenderer):
    charset = 'utf-8'

    def render(self, data_, accepted_media_type=None, renderer_context=None):
        """
        方法中，code 为 业务码 或者 http状态码（如果没有业务码，就就是）
        :param data_:
        :param accepted_media_type:
        :param renderer_context:
        :return:
        """
        if isinstance(data_, dict):
            status_code = renderer_context['response'].status_code
            if status_code not in code_dic.keys():
                data_["code"] = 20000
            data = dict()
            data["code"] = data_.pop('code') if data_.get('code', None) else status_code
            if data_.get('message'):
                data['message'] = data_.pop('message')
            elif status_code in code_dic.keys():
                data['message'] = data_.get('message') if data_.get('message', None) else code_dic[status_code]
            data["data"] = data_
        else:
            data = data_
        renderer_context = renderer_context or {}
        indent = self.get_indent(accepted_media_type, renderer_context)
        if indent is None:
            separators = SHORT_SEPARATORS if self.compact else LONG_SEPARATORS
        else:
            separators = INDENT_SEPARATORS

        ret = json.dumps(
            data, cls=self.encoder_class,
            indent=indent, ensure_ascii=self.ensure_ascii,
            separators=separators  # allow_nan=not self.strict,
        )

        if isinstance(ret, six.text_type):
            # We always fully escape \u2028 and \u2029 to ensure we output JSON
            # that is a strict javascript subset. If bytes were returned
            # by json.dumps() then we don't have these characters in any case.
            # See: http://timelessrepo.com/json-isnt-a-javascript-subset
            ret = ret.replace('\u2028', '\\u2028').replace('\u2029', '\\u2029')
            return bytes(ret.encode('utf-8'))
        return ret

