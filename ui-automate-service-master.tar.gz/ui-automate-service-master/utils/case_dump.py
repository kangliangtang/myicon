import time
import json
import os
import copy
from automate_uitest_py3 import settings
from page.models import PageModel
from element.models import ElementModel
from django.db.models.query_utils import Q
from logging import getLogger
logger_debug = getLogger('debug')


class CaseDump():
    def __init__(self):
        self.test_case_tem = {}
        super().__init__()

    def dumpTestCase(self, data):
        """
        根据用户传递参数 生成用例

        :param:
        :return:
        """
        self.dumpCase(data)
        # case_json = json.dumps(self.test_case_tem, ensure_ascii=False)
        return self.test_case_tem

    def dumpCaseToPath(self, data):
        """
        根据用户传递参数 生成用例json

        :param:
        :return:
        """

        if self.dumpCase(data) is False:
            return False
        try:
            case_json = json.dumps(self.test_case_tem, indent=4)
        except Exception as e:
            logger_debug.info("json.dumps(self.test_case_tem, indent=4, ensure_ascii=False)-----{}".format(e))
            # logger_debug.exception("json.dumps(seelf.test_case_tem, indent=4)-----{}".format(e))
        case_name = '{}.json'.format(str(time.time()).replace('.', ''))
        file_path = os.path.join(settings.TESTCASE_DIR, case_name)
        # logger_debug.info('yonglidizhi-------》{}'.format(file_path))
        with open(file_path, 'w') as f:
            f.write(case_json)
        return file_path

    def dumpCase(self,data):
        content = {}
        content['testcases'] = data.get('test_content', [])
        content['name'] = data.get('name')
        content['page_id'] = data.get('test_content')[0]['page_id']
        # logger_debug.info("dumpCase-data:{}".format(data))
        self.dumpConfig(content)
        self.dumpTest(content)


    def dumpConfig(self, content):
        # url = PageModel.objects.get(id=content['page_id']).url
        name = content.get('name')
        conf_dict = {
            'page_id': content['page_id'],
            "url": "$BASE_URL",
            "webdriver": "$BASE_DRIVER",
            "name": name
        }
        self.test_case_tem["config"] = conf_dict

    def dumpTest(self, content):
        testcases = content['testcases']
        self.test_case_tem["testcases"] = []
        # logger_debug.info("dumpTest-content:{}".format(content))
        for data in testcases:
            page_obj = PageModel.objects.filter(Q(id=data['page_id']) & Q(is_delete=False))
            if page_obj.count() == 0:
                # testcases.remove(data)
                return False
            data['page_name'] = page_obj.first().name
            # data.pop('page_id') 保留可进行校验页面是否被删除了
            page_id = data['page_id']
            page_name = data['page_name']
            for case in data['data']:
                case['page_id'] = page_id
                case['page_name'] = page_name
                # if case.get('action',{'type':""}):
                case['action'] = {'type':case['action']}
                # if case.get('data',{'action':""}):
                case['data'] = copy.deepcopy({'action':case['data']}) #{'action':case['data']}
                # case.pop('element_id')
                self.test_case_tem["testcases"].append(case)
        return True

    def getPageUrl(self, page_id):
        url = ''
        page_query = PageModel.objects.filter(id=page_id, is_delete=False)
        if page_query:
            url = page_query.first().url
        return url

    def getElementObj(self, element_id):
        element_obj = None
        element_query = ElementModel.objects.filter(id=element_id)
        if element_query:
            element_obj = element_query.first()
        return element_obj

    def fromIdToValue(self,content):
        # if content['config'].get('name', None) is None:
            # content['config']['name'] = PageModel.objects.get(id=content['config'][''])
        # url = PageModel.objects.get(Q(id=content['config']['page_id']) & Q(is_delete=False)).url
        url = self.getPageUrl(page_id=content['config']['page_id'])
        content['config']['url'] = "$BASE_URL{}".format(url)
        # element_obj = ElementModel.objects.filter(is_delete=False)
        for case in content['testcases']:
            page_id = case.get('page_id')
            page_name = case.get('page_name')
            if page_id and (not self.getPageUrl(page_id)):
                case['page_info'] = {'page_id': page_id, 'page_name': page_name, 'is_delete': True}
                break
            case['page_info'] = {'page_id': page_id, 'page_name': page_name, 'is_delete': False}
            element_id = case.get('element_id', '')
            if not element_id:
                case['element'] = {}
            else:
                # element_obj = ElementModel.objects.get(Q(id=element_id) & Q(is_delete=False))
                # case['element'] = self.dumpElement(element_obj.get(id=element_id))
                element_obj = self.getElementObj(element_id)
                if element_obj:
                    case['element'] = self.dumpElement(element_obj, page_id)
                else:
                    case['element'] = {"element_id": element_id, "is_delete": True}
                    break
                case.pop('element_id')
            if case.get('verify'):
                verify_list = case.get('verify')
                for verify in verify_list:
                    verify_form = verify.get('comparison', '')
                    if verify_form == '':
                        verify_list = []
                        break
                    verify_element_id = verify.get('element_id', '')
                    if not verify_element_id:
                        verify['element'] = {}
                    else:
                        # element_obj = ElementModel.objects.get(id=verify_element_id)
                        # verify['element'] = self.dumpElement(element_obj.get(id=verify_element_id))
                        verify_element_obj = self.getElementObj(verify_element_id)
                        if verify_element_obj:
                            verify['element'] = self.dumpElement(verify_element_obj, page_id)
                        else:
                            verify['element'] = dict()
                    verify.pop('element_id')
                case['verify'] = verify_list

    def dumpElement(self, element_obj, page_id):
        element = {
            # "id":element_obj.id,
            "name":element_obj.name,
            "type":element_obj.locmode,
            "value":element_obj.image_path if element_obj.locmode == 'image' else element_obj.location,  # 如果是图片元素 value就是 图片路径
            "is_delete":element_obj.is_delete,
            "element_id":element_obj.id,
            "page_id":element_obj.page_id
        }
        if page_id is not None:
            if page_id != element["page_id"]:
                # 若为公共页面时，视为当前页面下没被删除
                if not PageModel.objects.filter(id=element["page_id"], is_public=1, is_delete=False):
                    element["is_delete"] = True
        return element


    def dumpSenceCase(self, content):
        """
        生成场景用例
        """
        case_json = json.dumps(content, indent=4,)
        # print('用例-------》', case_json)
        case_name = '{}.json'.format(str(time.time()).replace('.', ''))
        file_path = os.path.join(settings.TESTCASE_DIR, case_name)
        with open(file_path, 'w') as f:
            f.write(case_json)
        return file_path

    def updateCase(self,path, data):
        self.dumpCase(data)
        case_json = json.dumps(self.test_case_tem, indent=4)
        # print('用例-------》', case_json)
        with open(path, 'w') as f:
            f.write(case_json)
        return path


if __name__ == "__main__":
    runner = CaseDump()
    runner.dumpCase({'case_level': 1, 'name': '123', 'page_id': 4, 'test_content': [{'data': [{'action': '', 'element_id': 6, 'data': '', 'verify': [{'comparison': '', 'element_id': '', 'data': ''}]}], 'page_id': 4, 'page_name': '22', 'eleList': []}], 'case_details': ''}
)
    #用例
    # runner.parse_datas("./15619703190328505.json")
    # runner.runCase("/home/zby/workspace/testcases/15626595799055786.json")
    # print(report.get_summary(runner.report))