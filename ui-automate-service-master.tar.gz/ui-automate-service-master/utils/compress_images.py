import cv2
import os
import math

IMAGES_SIZE = 0.8  # 压缩图片大小 （单位 M）


def get_doc_size(path):
    size = os.path.getsize(path)
    return get_mb_size(size)


def get_mb_size(bytes):
    bytes = float(bytes)
    mb = bytes / 1024 / 1024
    return mb


def delete_file(path):
    if file_exist(path):
        os.remove(path)
    else:
        pass


def file_exist(path):
    return os.path.exists(path)


def resize_rate(path, resize_path, fx, fy):
    image = read_image(path)
    im_resize = cv2.resize(image, None, fx=fx, fy=fy)
    delete_file(resize_path)
    save_image(resize_path, im_resize)


def save_image(path, image):
    cv2.imwrite(path, image)


def read_image(path):
    return cv2.imread(path)


def compress_images(path, resize_path):
    """压缩图片
    :param path 原图片文件
    :param resize_path 压缩后图片
    :return True 压缩成功, False 压缩失败
    """
    try:
        size = get_doc_size(path)
        filesize = IMAGES_SIZE               # 压缩比例
        while size > filesize:
            rate = math.ceil((size / filesize) * 10) / 10 + 0.1
            rate = 1.0 / (math.sqrt(rate))
            if file_exist(resize_path):
                resize_rate(resize_path, resize_path, rate, rate)
            else:
                resize_rate(path, resize_path, rate, rate)
            size = get_doc_size(resize_path)
    except Exception:
        return False
    else:
        return True


if __name__ == '__main__':
    path = r'C:\Users\hand\Desktop\1.png'          # 被压缩图片的绝对路径
    resize_path = r'C:\Users\hand\Desktop\1.png'   # 压缩后图片
    ret = compress_images(path, resize_path)
    print(ret)

