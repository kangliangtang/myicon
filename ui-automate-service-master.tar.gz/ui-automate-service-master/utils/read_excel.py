from datetime import datetime
import xlrd
from xlrd import xldate_as_tuple


class ReadExcelData(object):
    """读取EXCel表数据"""
    def __init__(self):
        self.sheet = None

    def decode(self, filename, sheetname):
        try:
            filename = filename.decode('utf-8')
            sheetname = sheetname.decode('utf-8')
        except Exception:
            pass
        return filename, sheetname

    def type_change(self, rows, cols, start_col=0):
        all_content = []
        for i in range(rows):
            row_content = []
            for j in range(start_col, cols):                     # 初始列为0
            # for j in range(cols):
                ctype = self.sheet.cell(i, j).ctype        # 表格的数据类型EXCEL_TYPE={0:empty,1:string,2:number,3:date,4:boolean,5:Error}
                cell = self.sheet.cell_value(i, j)
                if ctype == 2 and cell % 1 == 0:           # 如果是整形
                    cell = int(cell)
                elif ctype == 3:
                    # 转成datetime对象
                    date = datetime(*xldate_as_tuple(cell, 0))
                    cell = date.strftime('%Y-%d-%m %H:%M:%S')
                elif ctype == 4:
                    cell = True if cell == 1 else False
                else:
                    pass
                row_content.append(cell)
            if not self.blank_line(row_content):
                continue
            all_content.append(row_content)
        return all_content

    def blank_line(self,row_content):
        return [val for val in row_content if val]

    def read_excel(self, filename, sheetname=None):
        """获取excel数据，默认读取第一张表"""
        filename, sheetname = self.decode(filename, sheetname)
        rbook = xlrd.open_workbook(filename)
        if sheetname:
            self.sheet = rbook.sheet_by_name(sheetname)
        else:
            self.sheet = rbook.sheet_by_index(0)
        rows = self.sheet.nrows
        cols = self.sheet.ncols
        return self.type_change(rows, cols, start_col=1)

    def read_all_excel(self, filename, sheetname=None):
        filename, sheetname = self.decode(filename, sheetname)
        rbook = xlrd.open_workbook(filename)
        if sheetname:
            self.sheet = rbook.sheet_by_name(sheetname)
        else:
            self.sheet = rbook.sheet_by_index(0)
        rows = self.sheet.nrows
        cols = self.sheet.ncols
        return self.type_change(rows, cols)



if __name__ == '__main__':
    eh = ReadExcelData()
    filename = r'./test.xls'
    sheetname = 'Sheet1'
    # ret = eh.read_excel(filename, sheetname)
    ret1 = eh.read_excel(filename)
    ret2 = eh.read_all_excel(filename)
    print('--ret1--',ret1)
    print('--ret2--',ret2)
    # 返回结果格式为
    # excel_data = [
    #     ['${变量名}', '${name}', '${password}'],
    #     ['变量值1', 'admin', 'admin'],
    #     ['变量值2', 'htt', 123456]
    # ]