from utils.base_selenium import BaseSelenium
from utils import report
import time
from utils.common_parameter import ReplaceCommonParameter
import json
from utils.case_dump import CaseDump
from utils import parse
import io
from execution_case.models import SummaryModel
from logging import getLogger
logger_debug = getLogger('celery')


class WebUiRunner():
    def __init__(self):
        self.test_case_tem = {}
        self.title = ""
        self.data = {}
        # self.assert_list = {"notFindElement":"没有找到元素！", "assertFail":"断言失败！", "notFindAssertElement":"没有找到断言元素！"}
        super().__init__()

    def runCase(self,case_config,report_obj=None, execution_obj=None, mapping=None, project_id=None):
        """区分用例和场景, case_path:用例地址or用例,
        type=0：直接用例运行,适用debug
        type=1: 单用例允许
        type=2: 多用例运行"""
        case_path=case_config.get('case_path')
        case_type=case_config.get('case_type', 0)
        summary = []

        if case_type != 0:
            for _case_path in case_path:
                data = self.load_json_file(_case_path)
                self.result = report.TestResult(data['config']['name'])
                try:
                    CaseDump().fromIdToValue(data)
                except Exception:
                    report_obj.status = 'error'
                    execution_obj.status = 'error'
                    self.result.addError({'id': 0,'element':'','action':'','data':''}, "执行任务的用例中存在页面或元素被删除，运行用例失败", '')
                    summary.append(report.get_summary(self.result))
                    continue
                if mapping:
                    data['config']['variables'] = mapping
                try:
                    self.runByCase(data, project_id)
                except Exception as e:
                    logger_debug.exception('执行用例失败data={},error={}'.format(data, e))
                    report_obj.status = 'error'
                    execution_obj.status = 'error'
                    self.result.addError({'id': 0, 'element': '', 'action': '', 'data': ''},
                                         "执行用例失败，浏览器异常", '')
                summary.append(report.get_summary(self.result))
            if len(summary) != 0:
                # result_path, result = self.result.dumpResultJson(summary, case_config.get('task_name', ''))
                result_path, result, report_down_url = self.result.dumpResultJson(summary, case_config.get('task_name', ''))
                if report_obj:
                    report_obj.report_file_path = result_path
                    report_obj.status = result['baseinfo']['status']
                    execution_obj.status = result['baseinfo']['status']
                    summary_obj = SummaryModel.objects.create(
                        result_report_id=report_obj.id,
                        # summary_count=result,
                        summary_count_path=result_path,
                        report_down_url=report_down_url,
                        total_cases=result['baseinfo']['Total'],
                        # pass_cases=result['baseinfo']['Success']     # 运行成功用例数
                    )
                    summary_obj.save()
                    # execution_obj.save()
                    # report_obj.save()
                    execution_obj.save(update_fields=['status'])
                    report_obj.save(update_fields=['status'])

                    from project_crud.models import ProjectModel
                    if report_obj.status == 'success':
                        ProjectModel.objects.get(id=project_id).addSuessCase()
                    elif report_obj.status == 'fail' or report_obj.status == 'error':
                        ProjectModel.objects.get(id=project_id).addfailCase()
                    else:
                        pass

                return result_path
        else:
            data = case_config
            if mapping:
                data['config']['variables'] = mapping
            try:
                CaseDump().fromIdToValue(data)
            except:
                return False
            title = data['config'].get('name', '')
            self.result = report.TestResult(title)
            try:
                self.runByCase(data, project_id)
            except Exception as e:
                logger_debug.exception('执行用例失败data={},error={}'.format(data, e))
                self.result.addError({'id': 0, 'element': '', 'action': '', 'data': ''},
                                     "执行用例失败，浏览器异常", '')
            summary.append(report.get_summary(self.result))
            return self.result.dumpResult(summary)

    def runPath(self,case_config,report_obj=None,mapping=None, project_id=None):
        case_path=case_config.get('case_path')
        summary = []
        result_path = ''
        result = 'error'
        for _case_path in case_path:
            data = self.load_json_file(_case_path)
            self.result = report.TestResult(data['config']['name'])
            try:
                CaseDump().fromIdToValue(data)
            except Exception:
                report_obj.status = 'error'
                self.result.addError({'id': 0,'element':'','action':'','data':''}, "执行任务的用例中存在页面或元素被删除，运行用例失败", '')
                summary.append(report.get_summary(self.result))
                continue
            if mapping:
                data['config']['variables'] = mapping
            self.runByCase(data, project_id)
            summary.append(report.get_summary(self.result))
        if len(summary) != 0:
            # result_path, result = self.result.dumpResultJson(summary, case_config.get('task_name', ''))
            result_path, result, report_down_url = self.result.dumpResultJson(summary, case_config.get('task_name', ''))
            if report_obj:
                report_obj.report_file_path = result_path
                report_obj.status = result['baseinfo']['status']
                summary_obj = SummaryModel.objects.create(
                    task_result_report_id=report_obj.id,
                    # summary_count=result,
                    summary_count_path=result_path,
                    report_down_url=report_down_url,
                    total_cases=result['baseinfo']['Total'],
                    # pass_cases=result['baseinfo']['Success']     # 运行成功用例数
                )
                summary_obj.save()
                # report_obj.save()
                report_obj.save(update_fields=['status', 'report_file_path'])
        return result_path,result

    def runByCase(self,data, project_id=None):
        # 获取驱动类型并启动url
        logger_debug.info("-----start case-----------")
        data = parse.parse_datas(data)
        logger_debug.info('replace project ID:%s common_param' % project_id)
        if project_id:
            try:
                self.common_replace_obj = ReplaceCommonParameter(project_id)
                data = self.common_replace_obj.json_common_param(json.dumps(data))
                self.data = json.loads(data)
            except Exception as e:
                logger_debug.error('replace common_param error; %s' % e)
        logger_debug.info("-----start webdriver-----------")
        if 'webdriver' in self.data["config"].keys():
            driver = self.data["config"]["webdriver"]
            self.result.webdriver = driver
            try:
                self.d = BaseSelenium(driver)
            except Exception as e:
                self.result.addError({'id': 0,'element':'','action':'','data':''}, "启动{}浏览器失败，运行用例失败".format(driver), '')
                logger_debug.error("启动{}浏览器失败，运行用例失败, error={}".format(driver, e))
                return False
        if 'url' in self.data["config"].keys():
            url = self.data["config"]["url"]
            #记录时间
            logger_debug.info("-----start url-----------")
            self.result.test_url = url
            self.result.start_time = time.time()
            try:
                self.d.startWeb('', '', url)
            except Exception as e:
                self.result.addError({'id': 0, 'element': '', 'action': '', 'data': ''},"打开url={}超时，运行用例失败".format(url), '')
                logger_debug.error("打开url={}超时，运行用例失败, error={}".format(url, e))
                try:
                    self.d.quitWeb()  # 关闭浏览器
                except Exception as e:
                    logger_debug.error("WebSocket closed; Close chrome error{}".format(e))
                return False
        step = 1
        logger_debug.info("-----start test-----------")
        for idx in range(len(self.data["testcases"])):
            #todo 打印日至，增加步骤时间
            # logger_debug.info("-----action:{}------steps:{}".format(str(step)))
            self.result.stepStartTime
            status = self._runCase(self.data["testcases"][idx], step, project_id=project_id)
            if status == "Error":
                break
            logger_debug.info("-----action:{}------results:{}".format(str(step), status))
            step += 1
        logger_debug.info(time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time())))
        self.result.end_time = time.time()
        # self.d.closeWeb() #close是关闭chromium，而quit则是关闭chromedriver
        # 用户在用例中有输入关闭页面的动作
        try:
            self.d.closeWeb()
        except Exception:
            pass
        self.d.quitWeb()

    def _runCase(self, case_step, step, project_id=None):
        # action
        # print('-----------case_step[action]:{}'.format(case_step['action']))
        if isinstance(case_step['action'], dict):
            action = case_step['action'].get('type', "")
        else:
            action = case_step['action']
        # data
        if isinstance(case_step['data'], dict):
            data = case_step['data'].get('action', "")
        else:
            data = case_step['data']

        page_is_delete = case_step['page_info'].get('is_delete', '')
        if page_is_delete:
            page_id = case_step['page_info'].get('page_id')
            page_name = case_step['page_info'].get('page_name')
            self.result.addError({'id': step, 'element': '', 'action': action, 'data': ''},
                                 "此页面不存在或已被删除(ID:{0},页面名:{1})".format(page_id, page_name), '')
            return 'Error'

        element_is_delete = case_step['element'].get('is_delete', '')
        if element_is_delete:
            page_name = case_step['page_info'].get('page_name')
            element_id = case_step['element'].get('element_id', '')
            element_name = case_step['element'].get('name', '')
            self.result.addError({'id': step, 'element': element_name, 'action': action, 'data': ''},
                                 "此元素不存在或已被删除(ID:{0},元素名:{1},所属页面:{2})".format(element_id, element_name, page_name), '')
            return 'Error'

        # element
        by = case_step['element'].get('type', "")
        value = case_step['element'].get('value', "")
        status = False
        screenhot = ''
        # print('-----------action:{}'.format(action))
        try:
            # a.上传文件方法需要传project_id
            if action == 'uploadFile':
                func = getattr(self.d, action)
                func(by, value, data, project_id)
                status = True
                screenhot = self.d.screensHot()

            # b.通用方法
            elif action != "":
                func = getattr(self.d, action)
                result = func(by, value, data, project_id)
                if result != None and result[0] == True:
                    text = result[1]
                    self.data = self.common_replace_obj.replace_case_param(data, text, self.data)
                if result==False:
                    screenhot = self.d.screensHot()
                    step_content = case_step
                    step_content["id"] = step
                    self.result.addError(step_content, "未找到该元素{}={}.或执行动作失败".format(by,value), screenhot)
                    return 'Error'
                status = True
                screenhot = self.d.screensHot()
        except Exception as e:  # todo
            # logger_debug.error("执行步骤失败,未找到该元素{}".format(e))
            screenhot = self.d.screensHot()
            step_content = case_step
            step_content["id"] = step
            self.result.addError(step_content, "未找到该元素{}={}.或执行动作失败".format(by,value), screenhot)
            return 'Error'
        # verify
        if isinstance(case_step['verify'], list):
            for verify in case_step['verify']:
                if verify.get("comparison")  == '':
                    break
                verify_data = verify.get("data", "")
                verify_by = verify['element'].get('type')
                verify_value = verify['element'].get('value')

                # 判断断言中的元素是否删除
                verify_element_is_delete = verify['element'].get('is_delete')
                if verify_element_is_delete:
                    element_id = verify['element'].get('element_id', '')
                    element_name = verify['element'].get('name', '')
                    screenhot = self.d.screensHot()
                    step_content = case_step
                    step_content["id"] = step
                    self.result.addFail(step_content,"断言失败, 断言中元素不存在或已被删除(ID:{0},元素名:{1})".format(element_id, element_name),screenhot)
                    status = False
                else:
                    verify_form = verify.get("comparison")
                    message = ''
                    try:
                        status, message = self.d.getElementText(verify_by, verify_value)
                        if not status:
                            # logger_debug.error("断言失败,没找到断言元素。")
                            screenhot = self.d.screensHot()
                            step_content = case_step
                            step_content["id"] = step
                            self.result.addFail(step_content, message, screenhot)
                        else:
                            assertData = getattr(self.d, verify_form)
                            status, message = assertData(verify_by, verify_value, verify_data, message)
                            if not status:
                                step_content = case_step
                                step_content["id"] = step
                                self.result.addFail(step_content, message, screenhot)
                    except Exception as e:
                        # logger_debug.error("断言失败。{}".format(e))
                        screenhot = self.d.screensHot()
                        status = False
                        step_content = case_step
                        step_content["id"] = step
                        self.result.addFail(step_content, "断言失败,预期值={},实际值={}.".format(verify_data, message), screenhot)
        if status:
            step_content = case_step
            step_content["id"] = step
            self.result.addSuccess(step_content, attachment=screenhot)
        return status

    def load_json_file(self,json_file):
        """ load json file and check file content format
        """

        with io.open(json_file, encoding='utf-8') as data_file:
            # json_content = {}
            try:

                json_content = json.load(data_file)
            except Exception as e:
                logger_debug.exception(e)
                logger_debug.error('失败jsonfile------{}'.format(json_file))
                return False
            return json_content


if __name__ == "__main__":
    pass
    # runner = WebUiTest()
    #用例
    # runner.parse_datas("./15619703190328505.json")
    # runner.runCase("/home/zby/workspace/testcases/15626595799055786.json")
    # print(report.get_summary(runner.report))


    # runner.dumpTestCase(cases)
    # 场景
    # runner.runCase("./15619695778042383.json", 1)
    # print(report.get_summary(runner.report))