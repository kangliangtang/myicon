import os
from django.conf import settings
import json

# 域名地址
BASE_HOST_ = settings.BASE_HOST
# 截图相对路径 '/screenshot/'
SCREENSHOT_PATH_ = settings.SCREENSHOT_PATH


def summary_result_simple(summary_dict, request_host=None):
    """将报告结果详细信息简化 ->传给前端"""
    new_summary_dict = {}
    if isinstance(summary_dict, str):
        # summary_dict = eval(summary_dict)
        summary_dict = json.loads(summary_dict)
    if not summary_dict:
        return new_summary_dict
    new_summary_dict["baseinfo"] = summary_dict["baseinfo"]
    summary_result_list = summary_dict["result"]
    new_summary_result_list = []
    action_name_dict = action_name()
    for case_result_dict in summary_result_list:
        new_case_result = {}
        new_case_result["title"] = case_result_dict["title"]
        new_case_result["case_status"] = case_result_dict["case_status"]
        case_result_details = case_result_dict["details"]
        new_case_result_details = []
        for case_step in case_result_details:
            new_case_step = {}
            new_case_step["step_id"] = case_step["step"]["id"]
            new_case_step["element_name"] = case_step["step"]["element"]                             # 元素名
            if isinstance(new_case_step["element_name"], dict):
               new_case_step["element_name"] = case_step["step"]["element"].get("name", "")
            new_case_step["action"] = case_step["step"]["action"]  # 动作
            if isinstance(new_case_step["action"], dict):
                new_case_step["action"] = case_step["step"]["action"].get("type", "")
            # 动作名替换为英文
            # new_case_step["action"] = replaceActionName(action_name=new_case_step["action"])
            action = new_case_step["action"]
            new_case_step["action"] = action_name_dict.get(action)
            new_case_step["value"] = case_step["step"]["data"]                                            # 值
            if isinstance(new_case_step["value"], dict):
                new_case_step["value"] = case_step["step"]["data"].get("action","")
            new_case_step["step_status"] = case_step["status"]                                            # 结果（成功 or 失败）
            # image_name = os.path.basename(case_step["attachment"])
            ## new_case_step["attachment"] = '{}{}{}'.format(request_host, '/screenshot/', image_name)
            # new_case_step["attachment"] = '{0}{1}{2}'.format(BASE_HOST_, SCREENSHOT_PATH_, image_name)
            if os.path.exists(case_step["attachment"]):
                image_name = os.path.basename(case_step["attachment"])
                new_case_step["attachment"] = '{0}{1}{2}'.format(BASE_HOST_, SCREENSHOT_PATH_, image_name)
            else:
                new_case_step["attachment"] = case_step["attachment"]

            new_case_step["detail"] = case_step["detail"]                                                  # 错误信息
            new_case_result_details.append(new_case_step)
        new_case_result["details"] = new_case_result_details
        new_summary_result_list.append(new_case_result)
    new_summary_dict["result"] = new_summary_result_list
    return new_summary_dict


def replaceActionName(action_name):
    """替换动作名 英文->中文"""
    try:
        from keyword_action.models import KeywordActionModel
        action_name = KeywordActionModel.objects.get(name=action_name).description
    except Exception:
        pass
    finally:
        return action_name


def action_name():
    action_name_dict = dict()
    from keyword_action.models import KeywordActionModel
    action_name_descriptions = KeywordActionModel.objects.filter(is_delete=0).all().values('name', 'description')
    for name_description in action_name_descriptions:
        action_name_dict[name_description["name"]] = name_description['description']
    return action_name_dict
