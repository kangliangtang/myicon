import xlwt

# Excel 单元格样式设置
VERT_TOP = 0x00         # 上端对齐
VERT_CENTER = 0x01      # 居中对齐（垂直方向上）
VERT_BOTTOM = 0x02      # 低端对齐
HORZ_LEFT = 0x01        # 左端对齐
HORZ_CENTER = 0x02      # 居中对齐（水平方向上）
HORZ_RIGHT = 0x03       # 右端对齐


class WriteExcel(object):
    """写入Excel数据"""
    def write_excel(self, data_list, excel_file, sheet_name='Sheet1'):
        """将数据写入Excel
        :param data_list 格式[[0,1,2],[1,2,3]]
        """
        # new一个文件
        workbook = xlwt.Workbook(encoding='utf-8')
        # new一个sheet
        worksheet = workbook.add_sheet(u'{}'.format(sheet_name))
        for row, row_data in enumerate(data_list):
            for col, cell_data in enumerate(row_data):
                worksheet.write(row, col, cell_data)
                worksheet.col(col).width = 256 * 20    # 设置列宽20
        # worksheet.write_merge(0, 0, 0, 3, 'First Merge')  # 合并单元格Merges row 0's columns 0 through 3.
        workbook.save(excel_file)

    def write_dirven_file(self, param_name_list, sheet_name='Sheet1'):
        """将变量名写入驱动文件"""
        wb = xlwt.Workbook(encoding='utf-8')
        sheet = wb.add_sheet(u'{}'.format(sheet_name))
        row = col = 0
        sheet.write(row, col, u'变量名')
        sheet.write(1, col, u'变量值1')
        sheet.write(2, col, u'变量值2')
        for idx, param_name in enumerate(param_name_list):
            col = idx + 1
            sheet.write(row, col, param_name)
            sheet.col(col).width = 256 * 20  # Set the column widt 20
        # 写出到IO, 用于返回给前端excel文件下载
        import io
        output = io.BytesIO()
        wb.save(output)
        output.seek(0)
        return output

    def write_old_driven_data(self, excel_data_list, sheet_name='Sheet1'):
        """将旧数据表写入下载的表中"""
        workbook = xlwt.Workbook(encoding='utf-8')
        worksheet = workbook.add_sheet(u'{}'.format(sheet_name))
        style = xlwt.XFStyle()    # 创建一个样式对象，初始化样式
        al = xlwt.Alignment()
        al.horz = HORZ_LEFT
        # al.vert = VERT_CENTER
        style.alignment = al
        for row, row_data in enumerate(excel_data_list):
            for col, cell_data in enumerate(row_data):
                worksheet.write(row, col, cell_data, style)
                worksheet.col(col).width = 256 * 20
        # workbook.save('./test.xls')
        # 写出到IO, 用于返回给前端excel文件下载
        import io
        output = io.BytesIO()
        workbook.save(output)
        output.seek(0)
        return output


if __name__ == '__main__':
    obj = WriteExcel()
    # obj.write_excel(data_list=[[0,1,2],[1,2,3]], excel_file='./rerete.xls')
    excel_data = [
        ['变量名', '${name}', '${password}'],
        ['变量值1', 'admin', 'admin'],
        ['变量值2', 'htt', 123456]
    ]
    obj.write_old_driven_data(excel_data_list=excel_data)



