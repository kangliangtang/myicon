import ast
import random
import re
import datetime
import time
from public_warehouse.models import PublicVariableModel
import json
from logging import getLogger
logger = getLogger('debug')


def get_timestamp(days=None, time_format=None):
    """获取时间戳
    :param  days 天数差值
    :return timestamp  失败时返回 None
    """
    now_time = datetime.datetime.now()                  # 本地时间
    if days:
        days = str(days)
        days = days.replace(' ','').replace('\n', '').replace('\t','')
        days = re.match(r'(\+|\-)?(\d+)$', days, re.I|re.S)
        if days is None:
            # 时间偏移参数输入有误
            timestamp = None
            return timestamp
        add_or_cut = days.group(1)
        num = days.group(2)
        # 最大偏移天数值days=9999
        if int(num) > 9999:    # OverflowError: days=1111111111; must have magnitude <= 9999
            timestamp = None
            return timestamp
        if add_or_cut == '-':
            now_time = now_time - datetime.timedelta(days=int(num))
        else:
            now_time = now_time + datetime.timedelta(days=int(num))
    if time_format:
        array = time.strptime(now_time.strftime('%Y-%m-%d %H:%M:%S'), '%Y-%m-%d %H:%M:%S')
        time_format = str(time_format).replace('YYYY', '%Y').replace('YY', '%y').replace('MM', '%m').replace('DD', '%d').replace('hh', '%H').replace('mm', '%M').replace('ss', '%S')
        timestamp = time.strftime(time_format, array)
    else:
        timestamp = int(time.mktime(now_time.timetuple()) * 1000.0 + now_time.microsecond / 1000.0)
    return timestamp


def check_time_format(time_format=None):
    """时间格式校验"""
    if time_format is None:
        return True
    # 年YYYY 月MM 日DD 时hh 分mm 秒ss
    time_format = str(time_format)
    if not time_format:
        return True
    time_format = time_format.replace('YYYY', '%Y').replace('YY', '%y').replace('MM', '%m').replace('DD', '%d').replace('hh', '%H').replace('mm', '%M').replace('ss', '%S')
    dt = time.strftime(time_format, time.localtime())
    if dt == time_format:
        return False
    else:
        return True


class ReplaceCommonParameter(object):
    def __init__(self, project_id):
        self.project_id = project_id
        self.regexp = re.compile(r"\$\{\{([\-_ A-Za-z0-9]+)+\}\}", re.S)      # 公共参数提取规则

    def get_common_value(self, param_name):
        """获取公共参数的value"""
        param = None
        common_parameter_obj = PublicVariableModel.objects.get(name=param_name, project_id=self.project_id,is_delete=False)
        variable_type = common_parameter_obj.variable_type
        if variable_type == "Time":
            days = common_parameter_obj.days
            time_format = common_parameter_obj.time_format
            param = get_timestamp(days=days, time_format=time_format)
        if variable_type == "Random":
            minnum = common_parameter_obj.minnum   # 起始数值 (可能为0)
            maxnum = common_parameter_obj.maxnum   # 结束数值
            param = random.randint(int(minnum), int(maxnum))
        if variable_type == "Str":
            param = common_parameter_obj.value
        if variable_type == "Choices":                            # 指定数组中选取随机值
            array_ = common_parameter_obj.array
            if array_:
                # array = ast.literal_eval(value)
                new_value = array_.replace('(', '').replace(')', '').replace('[', '').replace(']', '').replace(' ', '')
                new_array = new_value.split(',')
                param = random.choice(new_array)
                try:
                    param = int(param)
                except Exception:
                    pass
        return param

    def common_param(self, param):
        """公共参数替换
        :param   param 需要替换的参数；格式${{name}}
        :return  tb_common_parameter表中的value值； 不存在时返回原值
        """
        try:
            new_param = param.replace('\n', '').replace('\t', '')
            ret_list = re.findall(self.regexp, new_param)
            if not ret_list:
                return param
            # 查库-公共参数表，存在则替换
            for ret in ret_list:
                common_param = self.get_common_value(param_name=ret)
                if common_param is not None:
                    param = param.replace('${{%s}}' % ret, str(common_param))
            return param
        except Exception as e:
            print('公共参数获取失败: %s' % e)
            return param

    def json_common_param(self, json_data):
        """json数据中的公共参数提取替换"""
        try:
            if isinstance(json_data, str):
                ret_list = re.findall(self.regexp, json_data)
                if ret_list:
                    common_param_name = list(PublicVariableModel.objects.filter(project_id=self.project_id, is_delete=False).values_list('name', flat=True))
                    for param in ret_list:
                        if param in common_param_name:
                            # 查库-公共参数表，存在则替换
                            common_param = self.get_common_value(param_name=param)
                            if common_param is not None:
                                if isinstance(common_param, int):
                                    regex = re.compile(r'"\$\{\{%s\}\}"' % param, re.S)
                                    ret = re.findall(regex, json_data)
                                    if not ret:
                                        regex = re.compile(r"\$\{\{%s\}\}" % param, re.S)
                                        json_data = re.sub(regex, str(common_param), json_data, count=1)
                                    else:
                                        json_data = re.sub(regex, str(common_param), json_data, count=1)
                                else:
                                    regex = re.compile(r"\$\{\{%s\}\}" % param, re.S)
                                    json_data = re.sub(regex, str(common_param), json_data, count=1)

                    return json_data
                else:
                    return json_data
            else:
                return json_data
        except Exception as e:
            return json_data

    def replace_case_param(self, param, value,json_data):
        if not isinstance(json_data, str):
            json_data = json.dumps(json_data)
        try:
            common_param = value
            if common_param is not None:
                if isinstance(common_param, int):
                    regex = re.compile(r'"\$\{\{%s\}\}"' % param, re.S)
                    ret = re.findall(regex, json_data)
                    if not ret:
                        regex = re.compile(r"\$\{\{%s\}\}" % param, re.S)
                        json_data = re.sub(regex, str(common_param), json_data)
                    else:
                        json_data = re.sub(regex, str(common_param), json_data)
                else:
                    regex = re.compile(r"\$\{\{%s\}\}" % param, re.S)
                    json_data = re.sub(regex, str(common_param), json_data)
        except Exception as e:
            logger.error('replace_case_param fail.param={},value={},json_data={}.e={}'.format(param,value,json_data,e))
        if isinstance(json_data, str):
            json_data = json.loads(json_data)
        return json_data






if __name__ == '__main__':
    print(ReplaceCommonParameter(1).replace_case_param(param='ni',value='fangxiao5',json_data=[{'element': {'name': '1_1568086061727', 'value': '/html/body/div[1]/div[5]/div/div[2]/div/form/div[1]/div/div/input', 'type': 'xpath'}, 'action': {'type': 'inputText'}, 'id': 1, 'data': {'action': 'fangxiao5'}, 'verify': []}, {'element': {'name': '2_1568086061737', 'value': '/html/body/div[1]/div[5]/div/div[2]/div/form/div[2]/div/div/input', 'type': 'xpath'}, 'action': {'type': 'inputText'}, 'id': 2, 'data': {'action': '123456test222${{ni}}'}, 'verify': []}, {'element': {'name': '1_1568086061727', 'value': '/html/body/div[1]/div[5]/div/div[2]/div/form/div[1]/div/div/input', 'type': 'xpath'}, 'action': {'type': 'getElementText'}, 'id': 2, 'data': {'action': 'namebao'}, 'verify': []}, {'element': {'name': '1_1568086061727', 'value': '/html/body/div[1]/div[5]/div/div[2]/div/form/div[1]/div/div/input', 'type': 'xpath'}, 'action': {'type': 'inputText'}, 'id': 3, 'data': {'action': 'test222${{ni}}'}, 'verify': []}]))