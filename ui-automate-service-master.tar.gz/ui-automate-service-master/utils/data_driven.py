import re
import json
import os
from utils.read_excel import ReadExcelData
REGEXP = re.compile(r"\$\{([\-_ A-Za-z0-9]+)+\}", re.S)   # 变量名提取规则


def find_params(json_data):
    re_list = list()
    re_result = re.findall(REGEXP, json_data)
    if re_result:
        re_list = list(set(re_result))
        # re_list = ['${{{}}}'.format(ret) for ret in re_list]
    return re_list


def read_jsonfile(json_file):
    with open(json_file, 'r') as f:
        json_data = f.read()
    return json_data


def write_jsonfile(json_data, file_path):
    with open(file_path, 'w') as f:
        f.write(json_data)
    return file_path


class DataDriven(object):
    """数据驱动"""
    def __init__(self):
        self.regexp = REGEXP   # 变量名提取规则
        self.param_names = list()

    def replace_driven_parameter(self, case_data, driven_row_data):
        json_data = case_data
        for key, val in driven_row_data.items():
            if key and (key in self.param_names):
                if (val != '') and (val is not None):
                    if isinstance(val, int):
                        regex = re.compile(r'"\$\{%s\}"' % key, re.S)
                        ret = re.findall(regex, json_data)
                        if not ret:
                            regex = re.compile(r"\$\{%s\}" % key, re.S)
                            json_data = re.sub(regex, str(val), json_data)
                        else:
                            json_data = re.sub(regex, str(val), json_data)
                    else:
                        regex = re.compile(r"\$\{%s\}" % key, re.S)
                        json_data = re.sub(regex, str(val), json_data)
        return json_data

    def excel_data_handler(self, excel_list):
        new_excel_list = list()
        if isinstance(excel_list, list) and len(excel_list) > 1:
            first_line = self.excel_first_param_name(excel_list[0])
            if not first_line:
                return new_excel_list
            for line_idx, line_list in enumerate(excel_list):
                excel_dict = dict()
                if line_idx == 0:
                    continue
                for param_idx, param_name in enumerate(first_line):
                    excel_dict[param_name] = line_list[param_idx]
                new_excel_list.append(excel_dict)
        return new_excel_list

    def excel_first_param_name(self, excel_first):
        param_name_list = list()
        for param in excel_first:
            param = '${%s}' % param
            re_result = re.match(self.regexp, param)
            if re_result:
                param_name = re_result.group(1)
            else:
                param_name = ''
            param_name_list.append(param_name)
        self.param_names = [param_name for param_name in param_name_list if param_name]
        if not self.param_names:
            return None
        return param_name_list

    def driven_case_path(self, case_path, excel_path):
        """获取数据驱动的用例文件"""
        read_excel_obj = ReadExcelData()
        case_path_list = []
        file_dir = os.path.dirname(case_path)
        case_file_name = os.path.basename(case_path)
        case_data = read_jsonfile(case_path)
        # 用例中未填写驱动参数
        case_driven_params = find_params(case_data)
        if not case_driven_params:
            return [case_path]
        excel_data = read_excel_obj.read_excel(filename=excel_path)
        driven_list = self.excel_data_handler(excel_data)
        if not driven_list:
            return [case_path]
        driven_params = [param for param in self.param_names if param in case_driven_params]
        if not driven_params:
            return [case_path]
        self.param_names = driven_params

        for driven_idx, driven_row_data in enumerate(driven_list):
            driven_json = self.replace_driven_parameter(case_data, driven_row_data)
            driven_file_name = 'driven_{}_{}'.format(driven_idx, case_file_name)
            driven_file_path = os.path.join(file_dir, driven_file_name)
            write_jsonfile(driven_json, driven_file_path)
            case_path_list.append(driven_file_path)
        return case_path_list


def dataDrivenCasePath(execution_obj, case_path):
    """获取数据驱动后的用例路径"""
    case_path = [case_path]
    try:
        if (execution_obj.task_type == 1) and execution_obj.excel_file:
            data_driven_obj = DataDriven()
            case_path = data_driven_obj.driven_case_path(case_path=execution_obj.test_file, excel_path=execution_obj.excel_file)
    except Exception:
        pass
    finally:
        return case_path


if __name__ == '__main__':
    # excel_data = [
    #     ['${变量名}', '${name}', '${password}'],
    #     ['变量值1', 'admin', 'admin'],
    #     ['变量值2', 'htt', 123456]
    # ]
    obj = DataDriven()
    # ret = obj.driven_case_path(case_path='./test_driven.json', excel_path='./test.xls')
    # print(ret)
    json_data = read_jsonfile('./test_driven.json')
    ret = find_params(json_data)
    print(ret)


