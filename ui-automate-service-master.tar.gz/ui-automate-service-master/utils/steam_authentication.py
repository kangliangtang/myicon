import base64
import json
from logging import getLogger

from django.contrib.auth.models import AnonymousUser
from rest_framework import authentication
from rest_framework.exceptions import AuthenticationFailed
from rest_framework.permissions import DjangoModelPermissions, IsAuthenticated
from rest_framework.response import Response
from rest_framework.status import HTTP_401_UNAUTHORIZED

from user.models import UserModel
from user.serializers import SteamVerifyJSONWebTokenSerializer, UserTokenSeralizer

logger_debug = getLogger('debug')

class SteamAuthentication(authentication.BaseAuthentication):

    def authenticate(self, request):
        token = request.META.get("HTTP_AUTHORIZATION")
        if token is None or token == '':
            # return None
            raise AuthenticationFailed('token is None')
        import requests
        headers = {
            'Authorization':token
        }
        from automate_uitest_py3 import settings
        result = requests.get(url=settings.STEAM_AUTHENTICATION_URL, headers=headers)
        # print(result.text)
        try:
            result = requests.get(url=settings.STEAM_AUTHENTICATION_URL, headers=headers)
            user_info = result.json()['data']
            try:
                user = UserModel.objects.get(choerodon_id=user_info['id'])
            except UserModel.DoesNotExist:
                user = UserModel.objects.create(choerodon_id=user_info['id'], username=user_info['loginName'], email=user_info["email"])
            else:
                if user.email != user_info["email"]:
                    user.email = user_info["email"]
                    user.save()
                if user.username != user_info["loginName"]:
                    user.username = user_info["loginName"]
                    user.save()
        except Exception as e:
            logger_debug.exception(e)
            # return UserModel.objects.get(id=1), None
            raise AuthenticationFailed('token is validate')
        return user, None

    def authenticate_header(self, request):
         return Response(status=HTTP_401_UNAUTHORIZED)


class SteamTokenAuthentication(authentication.BaseAuthentication):

    def authenticate(self, request):
        meta = request._request.META
        token = meta.get('HTTP_TOKEN')
        # print('token-----',token)
        # print(meta)
        if token is None or token == '':
            return AnonymousUser(), None
        user_info = base64.b64decode(token.encode('utf-8')).decode('utf-8')
        print('解密token数据',user_info)
        user_dict = json.loads(user_info)
        serializer = UserTokenSeralizer(data=user_dict)
        try:
            serializer.is_valid(raise_exception=True)
        except Exception as e:
            logger_debug.exception(e)
            raise e
        user = serializer.get_user()
        return user, None

    def authenticate_header(self, request):
        return Response(status=HTTP_401_UNAUTHORIZED)


class NoAuthentication(authentication.BaseAuthentication):

    def authenticate(self, request):
        user = UserModel.objects.get(username='admin')
        return user, None

    def authenticate_header(self, request):
        return Response(status=HTTP_401_UNAUTHORIZED)



class SwaggerAuthentication(authentication.BaseAuthentication):

    def authenticate(self, request):
        from django.contrib.auth.models import AnonymousUser
        return AnonymousUser(), None

    def authenticate_header(self, request):
        return Response(status=HTTP_401_UNAUTHORIZED)


class AutoPlatformPermission(IsAuthenticated):

    def has_permission(self, request, view):
       if isinstance(request.user, AnonymousUser):
           return True
       super(AutoPlatformPermission, self).has_permission(request, view)
