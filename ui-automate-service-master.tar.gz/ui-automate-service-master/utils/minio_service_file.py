from datetime import timedelta
from automate_uitest_py3 import settings
import os
from minio import Minio


class MinioServiceFile(object):
    """Mionio 文件服务"""
    def __init__(self):
        self.minioClient = Minio(settings.MINIO_ENDPOINT,
                                 access_key=settings.MINIO_ACCESS_KEY,
                                 secret_key=settings.MINIO_SECRET_KEY,
                                 secure=settings.MINIO_SECURE
                                 )

    def put_file(self, bucket_name, put_file_path):
        """ 上传文件
        :param bucket_name: 桶名（minio服务端的桶名）
        :param put_file_path: 要上传的文件路径
        :return: 上传成功 True;  失败 False
        """
        try:
            # 桶名不存在则创建
            if not self.minioClient.bucket_exists(bucket_name):
                self.minioClient.make_bucket(bucket_name)
                # 更改桶权限 设置公共可下载
                policy = '{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"AWS":["*"]},"Action":["s3:GetBucketLocation","s3:ListBucket"],"Resource":["arn:aws:s3:::%s"]},{"Effect":"Allow","Principal":{"AWS":["*"]},"Action":["s3:GetObject"],"Resource":["arn:aws:s3:::%s/*"]}]}' % (bucket_name, bucket_name)
                self.minioClient.set_bucket_policy(bucket_name=bucket_name, policy=policy)

            # 若文件服务器已存在此文件,则会直接覆盖
            object_name = os.path.basename(put_file_path)
            self.minioClient.fput_object(bucket_name=bucket_name, object_name=object_name, file_path=put_file_path)
        except Exception as e:
            return False
        else:
            return True

    def fput_get_url(self, bucket_name, put_file_path):
        """ 上传文件 返回可直接下载的url
        :param bucket_name: 桶名（minio服务端的桶名）
        :param put_file_path: 要上传的文件路径
        :return: 可直接下载的url
        """
        down_url = None
        try:
            ret = self.put_file(bucket_name, put_file_path)
            if ret:
                file_name = os.path.basename(put_file_path)
                down_url = self.get_file_url(bucket_name=bucket_name, file_name=file_name)
        except Exception as e:
            pass
        finally:
            return down_url

    def get_file(self, bucket_name, file_name, save_file_path):
        """ 下载文件到本地
        :param bucket_name:  桶名
        :param file_name: 文件名
        :param save_file_path: (下载后)文件保存目录 例：'/home/Temp/'
        :return:
        """
        try:
            file_path = os.path.join(save_file_path, file_name)
            self.minioClient.fget_object(bucket_name=bucket_name,object_name=file_name, file_path=file_path)
        except Exception as e:
            return False
        else:
            return True

    def get_file_data(self, bucket_name, file_name):
        """ 获取文件数据（文件流 bytes）
        :param bucket_name: 桶名
        :param file_name: 文件名
        :return:
        """
        file_data = b''
        try:
            file_data = self.minioClient.get_object(bucket_name=bucket_name, object_name=file_name)
            file_data = file_data.data
        except Exception as e:
            pass
        finally:
            return file_data

    def get_file_url(self, bucket_name, file_name):
        """ 获取文件的下载地址
        :param bucket_name: 桶名
        :param file_name: 文件名
        :return: 文件的下载地址 （点击直接下载）
        """
        file_url = ''
        try:
            # file_url = self.minioClient.presigned_get_object(bucket_name=bucket_name, object_name=file_name)
            file_header = 'http://'
            if settings.MINIO_SECURE is True:
                file_header = 'https://'
            # 修改为公共url
            file_url = '{0}{1}/{2}/{3}'.format(file_header, settings.MINIO_ENDPOINT, bucket_name, file_name)
        except Exception as e:
            pass
        finally:
            return file_url

    def remove_file(self, bucket_name, file_name):
        """ 删除文件
        :param bucket_name:
        :param file_name:
        :return: 删除成功 True ; 失败 False
        """
        try:
            self.minioClient.remove_object(bucket_name=bucket_name, object_name=file_name)
        except Exception as e:
            return False
        else:
            return True
