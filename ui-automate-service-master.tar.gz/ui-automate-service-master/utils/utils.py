import base64
from automate_uitest_py3 import settings
import os
from Crypto.Cipher import PKCS1_v1_5 as Cipher_pkcs1_v1_5


class SteamAPI():

    def __init__(self, token):
        self.token = token
    pass
    def getUserInfo(self):
        import requests
        pass
    def requestSteamApi(self):
        pass



class EncryptionAndDecryption(object):
    """公私钥加解密"""

    def __init__(self, SECRET_KEY):
        self.SECRET_KEY = SECRET_KEY

    def generatPrivateKey(self):
        """
        生成私钥
        :return:
        """
        from Crypto.PublicKey import RSA
        from Crypto import Random
        random_generator = Random.new().read
        rsa = RSA.generate(1024, random_generator)   # 1024 key的最大值
        self.rsa = rsa
        private_pem = rsa.exportKey()
        self.private_key = private_pem
        return private_pem

    def savePrivateKey(self, file_path = None):
        """
        保存私钥
        :param file_path:
        :return:
        """
        file_path = file_path if file_path else os.path.join(settings.PEM_FILE_PATH, 'private_key.pem')
        with open(file_path, 'wb') as f:
            f.write(self.private_key)

    def generatPubliKey(self):
        """
        生成公钥
        :return:
        """
        publi_key = self.rsa.publickey().exportKey()
        self.publi_key = publi_key
        return publi_key

    def savePubliKey(self, file_path=None):
        """
        保存公钥
        :param file_path:
        :return:
        """
        file_path = file_path if file_path else os.path.join(settings.PEM_FILE_PATH, 'public_key.pem')
        with open(file_path, 'wb') as f:
            f.write(self.publi_key)

    def signerData_(self, data=None, public_key_file_path=None):
        """
        加密数据
        :param message:
        :return:
        """
        from Crypto.PublicKey import RSA
        if public_key_file_path is None:
            public_key_file_path = os.path.join(settings.PEM_FILE_PATH, 'public_key.pem')
        with open(public_key_file_path) as f:
            key = f.read()
            rsakey = RSA.importKey(str(key))
            cipher = Cipher_pkcs1_v1_5.new(rsakey)
            if not isinstance(data, bytes):
                data = data.encode('utf-8')
            cipher_text = cipher.encrypt(data)
        return cipher_text

    def signerData(self, data=None, public_key_file_path=None):
        return base64.b64encode(self.signerData_(data=data, public_key_file_path=public_key_file_path))

    def rsa_long_encrypt(self, data):
        """
        分段加密
        :param data:
        :return:
        """
        data = data.encode('utf-8')
        length = len(data)
        default_length = 117
        # 公钥加密

        # 长度不用分段
        if length < default_length:
            return base64.b64encode(self.signerData_(data))
        # 需要分段
        offset = 0
        res = []
        while length - offset > 0:
            if length - offset > default_length:
                res.append(self.signerData_(data[offset:offset + default_length]))
            else:
                res.append(self.signerData_(data[offset:]))
            offset += default_length
        byte_data = b''.join(res)

        return base64.b64encode(byte_data)

    def decryptData_(self, data, private_key_file_path=None):
        """
        解密数据
        :param data: 密文
        :param secret_key: 安全密钥 默认是django的 SECRET_KEY
        :return:
        """
        from Crypto.PublicKey import RSA
        from Crypto.Cipher import PKCS1_v1_5 as Cipher_pkcs1_v1_5
        if private_key_file_path is None:
            private_key_file_path = os.path.join(settings.PEM_FILE_PATH, 'private_key.pem')
        if self.cipher is None:
            with open(private_key_file_path) as f:
                key = f.read()
                rsakey = RSA.importKey(key)
                self.cipher = Cipher_pkcs1_v1_5.new(rsakey)
        text = self.cipher.decrypt(data,self.SECRET_KEY)
        return text # 返回解密的数据

    def decryptData(self, data, private_key_file_path=None):
        data = base64.b64decode(data)
        return self.decryptData_(data, private_key_file_path)

    def rsa_long_decrypt(self, data, private_key_file_path=None):
        """
        分段解密
        :param data:
        :param private_key_file_path:
        :return:
        """
        result_data = []
        default_len = 128
        data = base64.b64decode(data)
        private_key_file_path = os.path.join(settings.PEM_FILE_PATH, 'private_key.pem')
        with open(private_key_file_path) as f:
            key = f.read()
            from Crypto.PublicKey import RSA
            rsakey = RSA.importKey(key)
            self.cipher = Cipher_pkcs1_v1_5.new(rsakey)

        while True:
            if data[:default_len].__len__():
                data_ = data[:default_len]
                result_data.append(self.decryptData_(data=data_))
            else:
                break
            data = data[default_len:]
        return b''.join(result_data)
