#!/bin/bash

echo "==============migrate Database==============="


if [[ $@ == '' ]];then
   python manage.py migrate
   exec uwsgi -i uwsgi.ini
fi

exec $@
