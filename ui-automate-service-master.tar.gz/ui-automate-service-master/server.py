import json
import re
import time
import tornado.web
import tornado.websocket
from tornado.ioloop import IOLoop
from tornado import gen
import tornado.options
from websocket_tornado import report
from websocket_tornado.base_selenium import BaseSelenium
from websocket_tornado.parse import parse_datas
from websocket_tornado.dump_case import DumpCase
from websocket_tornado import setting
from websocket_tornado.logs import log
from concurrent.futures import ThreadPoolExecutor
from tornado.concurrent import run_on_executor
import pymysql


class ExecutorBase():
    executor = ThreadPoolExecutor(4)


class DebugWebsocket(tornado.websocket.WebSocketHandler, ExecutorBase):
    def __init__(self, application, request, **kwargs):
        super(DebugWebsocket, self).__init__(application, request, **kwargs)
        self.d = None
        # self.d = BaseSelenium()
        self.result = None
        self.mysql_connect = None
        self.data = dict()

    def check_origin(self, origin):
        """校验权限"""
        return True

    def open(self):
        """开启连接"""
        self.mysql_connect = pymysql.Connect(
            host=setting.MYSQL_HOST,
            port=setting.MYSQL_PORT,
            user=setting.MYSQL_USER,
            passwd=setting.MSYQL_PASSWORD,
            db=setting.MYSQL_DB,
            charset=setting.MYSQL_CHARSET
        )
        log.logging.info("WebSocket opened")

    @gen.coroutine
    def on_message(self, message):
        """连接通信"""
        # try:
        data = json.loads(message)
        # 报告初始值
        initializationReport = {
            "baseinfo": {"Fail": 0, "Success": 0, "Total": 0, "duration": "", "startTime": "", "status": "",
                         "title": "", "webdriver": data['webdriver']},
            "result": [],
            "debug_end": False
            }
        self.write_message(json.dumps(initializationReport))
        project_id = data["project_id"]
        case_data_ = self.case_data(data)
        self.data = self.replace_common_parameter(case_data_, project_id)
        self.start_url(self.data)
        step = 1
        length = len(self.data["testcases"])
        for idx in self.data["testcases"]:
            resp, debug_end = yield self.step_run(idx, step,length, project_id=project_id)
            self.write_message(json.dumps(resp))
            if debug_end:
                break
            step += 1
        self.d.closeWeb()  # close是关闭chromium，而quit则是关闭chromedriver

    def on_close(self):
        try:
            self.d.quitWeb()  # 关闭浏览器

        except Exception as e:
            log.logging.error("WebSocket closed; Close chrome error{}".format(e))
        log.logging.info("WebSocket closed")
        try:
            self.mysql_connect.close()
        except Exception:
            log.logging.info("closed mysqlconnect is fail")

    def case_data(self, data):
        """转化为可执行数据"""
        log.logging.info('Case data handler.')
        dump_case_obj = DumpCase()
        intance = dump_case_obj.dumpCase(data, self.mysql_connect)
        case_host = data.get('env_host')
        webdriver = data.get('webdriver')
        case_config = {
            "case_content": intance,
            "case_type": 0,
            "case_host": case_host,
            "webdriver": webdriver
        }
        case_config = case_config.get('case_content', '')
        data = case_config
        mapping = {"BASE_URL": case_host, "BASE_DRIVER": webdriver}
        if mapping:
            data['config']['variables'] = mapping
        data = parse_datas(data)
        return data

    def replace_common_parameter(self, data, project_id=None):
        """替换公共参数"""
        if project_id:
            log.logging.info('replace project ID:%s common_param' % project_id)
            try:
                from websocket_tornado.common_parameter import ReplaceCommonParameter
                common_replace_obj = ReplaceCommonParameter(project_id)
                data_ = common_replace_obj.json_common_param(json.dumps(data), self.mysql_connect)
                data = json.loads(data_)
            except Exception as e:
                log.logging.info('Replace Common Parameter Error: %s' % e)
        return data

    def start_url(self, data):
        if 'webdriver' in data["config"].keys():
            driver = data["config"]["webdriver"]
            self.result = report.TestResult(data['config']['name'])
            self.result.webdriver = driver
            # log.logging.info("--Start ChromeDriver")
            log.logging.info("--Start Driver:{}".format(driver))
            try:
                self.d = BaseSelenium(driver, mysql_client=self.mysql_connect)
            except Exception as e:
                self.result.addError({'id': 0,'element':'','action':'','data':''}, "启动{}浏览器失败，运行用例失败".format(driver), '')
                log.logging.error("启动{}浏览器失败，运行用例失败, error={}".format(driver, e))
                return False
            log.logging.info("windows size:{}".format(self.d.driver.get_window_size()))
        if 'url' in data["config"].keys():
            url = data["config"]["url"]
            # 记录时间
            self.result.test_url = url
            self.result.start_time = time.time()
            try:
                self.d.startWeb('', '', url)
            except Exception as e:
                self.result.addError({'id': 0, 'element': '', 'action': '', 'data': ''},"打开url={}超时，运行用例失败".format(url), '')
                log.logging.error("打开url={}超时，运行用例失败, error={}".format(url, e))
                return False

    @run_on_executor
    def step_run(self, idx, step, length, project_id=None):
        debug_end = False
        self.result.stepStartTime
        idx = self.data["testcases"][step-1]
        # log.logging.info('case step{}:{}'.format(step, idx))
        status = self._runCase(idx, step, project_id=project_id)

        self.result.end_time = time.time()
        summary = []
        summary.append(report.get_summary(self.result))
        resp_data = self.result.dumpResult(summary)
        if (step == length) or (status == "Error"):
            debug_end = True
        resp_data['debug_end'] = debug_end
        return resp_data, debug_end

    def _runCase(self, case_step, step, project_id=None):
        # 获取动作名
        if isinstance(case_step['action'], dict):
            action = case_step['action'].get('type', "")
        else:
            action = case_step['action']
        if isinstance(case_step['data'], dict):
            data = case_step['data'].get('action', "")
        else:
            data = case_step['data']

        page_is_delete = case_step['page_info'].get('is_delete', '')
        if page_is_delete:
            page_id = case_step['page_info'].get('page_id')
            page_name = case_step['page_info'].get('page_name')
            self.result.addError({'id':step, 'element': '', 'action': action, 'data': ''},
                                 "此页面不存在或已被删除(ID:{0},页面名:{1})".format(page_id, page_name), '')
            return 'Error'


        element_is_delete = case_step['element'].get('is_delete', '')
        if element_is_delete:
            page_name = case_step['page_info'].get('page_name')
            element_id = case_step['element'].get('element_id', '')
            element_name = case_step['element'].get('name', '')
            self.result.addError({'id': step, 'element': element_name, 'action': action, 'data': ''},
                                 "此元素不存在或已被删除(ID:{0},元素名:{1},所属页面:{2})".format(element_id, element_name, page_name), '')
            return 'Error'


        status = False
        screenhot = ''
        try:
            by = case_step['element'].get('type', "")
            value = case_step['element'].get('value', "")
            # a.上传文件方法需要传project_id
            if action == 'uploadFile':
                func = getattr(self.d, action)
                # func(by, value, data, project_id)
                func(by, value, data, project_id, self.mysql_connect)
                status = True
                screenhot = self.d.screensHot()

            # b.通用方法
            elif action != "":
                func = getattr(self.d, action)
                result = func(by, value, data, project_id)
                if isinstance(result, tuple) and result.__len__() > 1:
                    if result[0] == True:
                        text = result[1]
                        self.data = self.replace_case_param(data, text, self.data)
                if result == False:
                    screenhot = self.d.screensHot()
                    step_content = case_step
                    step_content["id"] = step
                    self.result.addError(step_content, "未找到该元素{}={}.或执行动作失败".format(by,value), screenhot)
                    return 'Error'
                status = True
                screenhot = self.d.screensHot()
        except Exception as e:
            log.logging.error('_runCase() error; action={},error_msg={}'.format(action, e))
            screenhot = self.d.screensHot()
            step_content = case_step
            step_content["id"] = step
            self.result.addError(step_content, "未找到该元素{}={}.或执行动作失败".format(by,value), screenhot)
            return 'Error'
        # 断言
        if isinstance(case_step['verify'], list):
            for verify in case_step['verify']:
                if verify.get("comparison") == '':
                    break
                verify_data = verify.get("data", "")
                verify_by = verify['element'].get('type')
                verify_value = verify['element'].get('value')
                # 判断断言中的元素是否删除
                verify_element_is_delete = verify['element'].get('is_delete')
                if verify_element_is_delete:
                    element_id = verify['element'].get('element_id', '')
                    element_name = verify['element'].get('name', '')
                    screenhot = self.d.screensHot()
                    step_content = case_step
                    step_content["id"] = step
                    self.result.addFail(step_content, "断言失败, 断言中元素不存在或已被删除(ID:{0},元素名:{1})".format(element_id, element_name), screenhot)
                    status = False
                else:
                    verify_form = verify.get("comparison")
                    message = ''
                    try:
                        status, message = self.d.getElementText(verify_by, verify_value)
                        if not status:
                            # logger_debug.error("断言失败,没找到断言元素。")
                            screenhot = self.d.screensHot()
                            step_content = case_step
                            step_content["id"] = step
                            self.result.addFail(step_content, message, screenhot)
                        else:
                            assertData = getattr(self.d, verify_form)
                            status, message = assertData(verify_by, verify_value, verify_data, message)
                            if not status:
                                step_content = case_step
                                step_content["id"] = step
                                self.result.addFail(step_content, message, screenhot)
                    except Exception as e:
                        # logger_debug.error("断言失败。{}".format(e))
                        screenhot = self.d.screensHot()
                        status = False
                        step_content = case_step
                        step_content["id"] = step
                        self.result.addFail(step_content, "断言失败,预期值={},实际值={}.".format(verify_data, message), screenhot)
        if status:
            step_content = case_step
            step_content["id"] = step
            self.result.addSuccess(step_content, attachment=screenhot)
        return status

    def replace_case_param(self, param, value,json_data):
        if not isinstance(json_data, str):
            json_data = json.dumps(json_data)
        try:
            common_param = value
            if common_param is not None:
                if isinstance(common_param, int):
                    regex = re.compile(r'"\$\{\{%s\}\}"' % param, re.S)
                    ret = re.findall(regex, json_data)
                    if not ret:
                        regex = re.compile(r"\$\{\{%s\}\}" % param, re.S)
                        json_data = re.sub(regex, str(common_param), json_data)
                    else:
                        json_data = re.sub(regex, str(common_param), json_data)
                else:
                    regex = re.compile(r"\$\{\{%s\}\}" % param, re.S)
                    json_data = re.sub(regex, str(common_param), json_data)
        except Exception as e:
            log.logging.error('replace_case_param fail.param={},value={},json_data={}.e={}'.format(param, value, json_data, e))
        if isinstance(json_data, str):
            json_data = json.loads(json_data)
        return json_data


def make_app():
    """路由"""
    tornado.options.parse_command_line()
    return tornado.web.Application([
        (r"/debug/websocket", DebugWebsocket),
    ], setting.SETTINGS)


def start(port=setting.PORT):
    """启动"""
    app = make_app()
    app.listen(port=port)
    IOLoop.current().start()


if __name__ == '__main__':
    print(123)
    start()

