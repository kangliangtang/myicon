
### 启动uwsgi服务器
```shell
10.0.99.136 上启动
uwsgi --ini uwsgi_99_136.ini
重启
uwsgi --reload uwsgi.pid
停止
uwsgi --stop uwsgi.pid
```
### 启动/重启celery
```bash
方法1
celery -A automate_uitest_py3 worker -l info
方法2
celery -A automate_uitest_py3 multi start w1 --logfile=../logs/celerylog.log
停止
celery -A automate_uitest_py3 multi stop w1 --logfile=../logs/celerylog.log

```