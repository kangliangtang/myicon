from rest_framework.serializers import ModelSerializer, Serializer
from rest_framework_jwt.serializers import VerifyJSONWebTokenSerializer
from rest_framework import serializers
from user.models import UserModel
from django.contrib.auth.models import Group


class UserSeralizer(ModelSerializer):

    class Meta:
        model=UserModel
        fields = "__all__"

class UserTokenSeralizer(Serializer):
    userId = serializers.IntegerField()
    username = serializers.CharField(max_length=128)
    email = serializers.EmailField(default='steam@example.org')

    class Meta:
        fields = ('userId', 'username', 'email')

    def get_user(self):
        try:
            user = UserModel.objects.get(choerodon_id=self.data['userId'])
        except UserModel.DoesNotExist:
            user = UserModel.objects.create(username=self.data.get('username'), choerodon_id=self.data.get('userId'), email=self.data.get('email'))
        return user


class OnwerSerializer(ModelSerializer):

    class Meta:
        model=UserModel
        fields = ("id","username")


class GroupSerializer(ModelSerializer):

    class Meta:
        model=Group
        fields=("id", "name")

class SteamVerifyJSONWebTokenSerializer(VerifyJSONWebTokenSerializer):

    def validate(self, token):
        token = self._token(token['token'])
        payload = self._check_payload(token=token)
        user = self._check_user_by_user_id(payload=payload)
        return {"user": user}

    def _check_user_by_user_id(self, payload):
        user_id = int(payload.get('userId', None))
        try:
            user = UserModel.objects.get(choerodon_id=user_id)
        except UserModel.DoesNotExist as e:
            username = payload.get('username', None)
            email = payload.get('email', None)
            user = UserModel.objects.create(choerodon_id=user_id,username=username,email=email)
        return user

    def _token(self, data):
        if data.startswith('Bearer '):
            data = data.split('Bearer ', 1)[-1]
        return data


class projecMembersSerializer(ModelSerializer):
    user_id = serializers.ReadOnlyField(source='id')

    class Meta:
        model = UserModel
        fields = ("user_id", "username")
