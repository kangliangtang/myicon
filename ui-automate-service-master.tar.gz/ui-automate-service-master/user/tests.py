# from django.test import TestCase
# from future.backports.datetime import timedelta
# # Create your tests here.
# import minio
# from minio.error import InvalidArgumentError
# from minio.helpers import is_valid_bucket_name, is_non_empty_string, get_target_url
# from minio.signer import presign_v4
#
#
# class Test(minio.Minio):
#     def setM(self):
#         global _MAX_EXPIRY_TIME
#         _MAX_EXPIRY_TIME=10000
#
#     def presigned_url(self, method,
#                       bucket_name,
#                       object_name,
#                       expires=timedelta(days=7),
#                       response_headers=None,
#                       request_date=None):
#
#         is_valid_bucket_name(bucket_name)
#         is_non_empty_string(object_name)
#         print(_MAX_EXPIRY_TIME)
#         if expires.total_seconds() < 1 or \
#                         expires.total_seconds() > _MAX_EXPIRY_TIME:
#             raise InvalidArgumentError('Expires param valid values'
#                                        ' are between 1 sec to'
#                                        ' {0} secs'.format(_MAX_EXPIRY_TIME))
#
#         region = self._get_bucket_region(bucket_name)
#         url = get_target_url(self._endpoint_url,
#                              bucket_name=bucket_name,
#                              object_name=object_name,
#                              bucket_region=region)
#
#         return presign_v4(method, url,
#                           self._access_key,
#                           self._secret_key,
#                           session_token=self._session_token,
#                           region=region,
#                           expires=int(expires.total_seconds()),
#                           response_headers=response_headers,
#                           request_date=request_date)
#
#
# minioClient = Test('minio.steamsit.crcloud.com',
#                           access_key='admin',
#                           secret_key='etImnEJYl',
#                           secure=False)
#
# minioClient.setM()
#
#
# bucket_name = 'ui-service'
# page_url = minioClient.presigned_get_object(bucket_name=bucket_name, object_name='0722.jpg', expires=timedelta(days=10))
# print(page_url)
