from django.shortcuts import render

# Create your views here.
from rest_framework.response import Response
from rest_framework.status import HTTP_200_OK
from rest_framework.views import APIView

class UserAPIView(APIView):

    def get(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"get",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[
                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        user = request.user
        return Response({"id":user.id,
                         "username":user.username,
                         "is_superuser":user.is_superuser
                         },status=HTTP_200_OK)

