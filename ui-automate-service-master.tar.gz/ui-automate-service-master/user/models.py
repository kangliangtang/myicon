from django.db import models

# Create your models here.
from django.contrib.auth.models import AbstractUser

from utils.model import BaseModel


class UserModel(AbstractUser):
    choerodon_id = models.IntegerField('行云中的用户ID', null=True, blank=True)

    class Meta:
        db_table = 'tb_user'
        verbose_name='用户'
        verbose_name_plural=verbose_name


class Organization(models.Model):
    name = models.CharField('组织名', max_length=255)
    code = models.CharField('组织编码', max_length=120)
    user = models.ManyToManyField(UserModel)

    class Meta:
        db_table = 'tb_organization'
        verbose_name = '组织'
        verbose_name_plural = '组织'