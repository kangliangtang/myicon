from django.conf.urls import url, include

from user.views import UserAPIView
from . import views
from rest_framework import routers

urlpatterns = [
   url(r'^info$', UserAPIView.as_view()),
]


