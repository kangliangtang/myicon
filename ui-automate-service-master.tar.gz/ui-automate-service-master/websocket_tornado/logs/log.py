from websocket_tornado.setting import log_path
import os
import logging
logging.basicConfig(level=logging.INFO,
                    filename= os.path.join(log_path, 'webscoket.logs'),
                    filemode='a+',
                    format='%(asctime)s - %(pathname)s[line:%(lineno)d] - %(levelname)s: %(message)s'
                    )
