import cv2
import numpy as np

# def matchImage(image_template_path=None, image_source_path=None) -> tuple:
#     print('template_path',image_template_path)
#     print('image_path',image_source_path)
#     img = cv2.imread(image_source_path, 0) # 0 表示以黑白图方式打开
#     img_template = cv2.imread(image_template_path,0)
#     w, h = img_template.shape[::-1]
#     res = cv2.matchTemplate(img,img_template,1)
#     location = cv2.minMaxLoc(res)
#     width,height = location[2]
#     return width, height, w, h

def matchImage(threshold, image_template_path=None, image_source_path=None) -> tuple:
    print('template_path',image_template_path)
    print('image_path',image_source_path)
    img_rgb = cv2.imread(image_source_path)
    img_gray = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)
    img_template = cv2.imread(image_template_path,0)
    w, h = img_template.shape[::-1]
    res = cv2.matchTemplate(img_gray,img_template, cv2.TM_CCOEFF_NORMED)
    location = cv2.minMaxLoc(res)
    width,height = location[3]
    threshold = int(threshold * 100)
    for threshold_ in range(100, threshold, -1):
        loc = np.where(res >= (threshold_ / 100))
        if loc[0].__len__() > 0:
            print(threshold_)
            return width, height, w, h
    return 0,


def findImageByThreshold(threshold, source_image_path, template_image_path) -> bool:
    template = cv2.imread(template_image_path, 0)
    img_rgb = cv2.imread(source_image_path)
    img_gray = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)
    res = cv2.matchTemplate(img_gray, template, cv2.TM_CCOEFF_NORMED)
    threshold = int(threshold * 100)
    for threshold_ in range(100,threshold,-1):
        loc = np.where(res >= (threshold_ / 100))
        if loc[0].__len__() > 0:
            return True
    else:
        return False


image_template_path =r'C:\Users\chenhuazhong6\ui-automate-service\utils\index.png'
image_source_path = r'C:\Users\chenhuazhong6\ui-automate-service\utils\indexsource.png'
def matchImageTest(image_template_path=None, image_source_path=None) -> tuple:
    print('template_path',image_template_path)
    print('image_path',image_source_path)
    img = cv2.imread(image_source_path, 0) # 0 表示以黑白图方式打开
    img_template = cv2.imread(image_template_path,0)
    # cv2.namedWindow("openCV")
    # cv2.imwrite('messigray.jpg', img)
    w, h = img_template.shape[::-1]
    # print(w)
    # print(h)
    print(img_template.shape[0])
    print(img_template.shape[1])

    cv2.imshow('ima1', img)  # 显示图片
    cv2.imshow('ima_template', img_template)  # 显示图片
    cv2.waitKey(0)  # 等待输入一个键  0 为等待时间无从大   1 为等1秒  以此类推
    cv2.destroyAllWindows()  # 删除窗口
    res = cv2.matchTemplate(img,img_template,1)
    cv2.imshow('res',res)
    location = cv2.minMaxLoc(res)
    print(location)
    width,height = location[2]
    cv2.rectangle(img,location[2],(width + w ,height +h),(0,0,0),2)
    cv2.imshow('ima2', img)  # 显示图片/
    cv2.waitKey(0)  # 等待输入一个键  0 为等待时间无从大   1 为等1秒  以此类推
    cv2.destroyAllWindows()  # 删除窗口
    return width, height, w, h


# matchImageTest(image_template_path, image_source_path)

if __name__ == '__main__':
    # print(
    #     findImageByThreshold(threshold=0.95, source_image_path=image_source_path, template_image_path=image_template_path))
    # # matchImageTest(image_template_path, image_source_path)
    # data = matchImage(0.7,'E:\\workspace\\ui-automate-data\\screenshot\\1566269811310.png','E:\\workspace\\ui-automate-data\\screenshot\\1566269758405.png')
    data = matchImage(0.7,'D:\\Work\\dev\\ui-automate-service-feature_liangtang\\ui-automate-data\\static\\image\\1568682901211.png','D:\\Work\\dev\\ui-automate-service-feature_liangtang\\ui-automate-data\\screenshot\\20190918112819.png')


    print(data)
    # data = findImageByThreshold(0.9, 'E:\\workspace\\ui-automate-data\\screenshot\\1566269758405.png',
    #                   'E:\\workspace\\ui-automate-data\\screenshot\\1566269811310.png')
    # print(data)