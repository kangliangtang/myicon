import os
import json
from websocket_tornado import setting


BASE_HOST_ = setting.BASE_HOST_
SCREENSHOT_PATH_ = setting.SCREENSHOT_PATH_
# 动作名
ACTION_NAME = {
    "switchWindows":"切换窗口",
    "startWeb":"打开网页",
    "closeWeb":"关闭当前页",
    "quitWeb":"关闭浏览器",
    "backWeb":"后退一步",
    "forwardWeb":"前进一步",
    "screensHot":"将当前窗口的屏幕截图保存到PNG图像文件",
    "screensHotAsFile":"将当前窗口的屏幕截图保存到PNG图像文件",
    "refreshWeb":"刷新页面",
    "getCurrentUrl":"获取当前页的URL",
    "getCurrentHandle":"获取当前窗口句柄",
    "getCurrentHandles":"获取所有窗口句柄",
    "getTitle":"获取title",
    "getPageSource":"获取页面源码",
    # "switchFarme":"指定元素位置",
    "switchFarme":"切换至iframe",
    "findElementByID":"通过id获取元素",
    "findElementByXpath":"通过xpath方式获取元素",
    "findElementByText":"通过链接文本（精确匹配）查找元素",
    "findElementByCss":"通过css查找元素",
    "findElementByClassName":"通过classname查找元素",
    "findElementByTagName":"通过tag name查找元素",
    "findElementByPartialText":"通过partial link text（模糊匹配）查找元素",
    "findElementByName":"通过name查找元素",
    "findElement":"自定义指定定位方式获取元素",
    "findElements":"自定义指定定位方式获取元素,返回结果为list",
    "clickElement":"点击元素",
    "inputText":"输入文本内容",
    "isDisplay":"元素是否可见",
    "isEdit":"元素是否可编辑",
    "isSelected":"元素是否被选中",
    "submitForm":"提交表单",
    "moveToOffset":"鼠标移动至指定坐标",
    "moveToElement":"鼠标移动至指定元素",
    "mouseRightClick":"右击",
    "twiceClick":"双击",
    "drapToDrop":"元素拖动",
    "clickEnter":"enter按键",
    "clickEsc":"esc按键",
    "clickBackspace":"BackSpace按键",
    "clickSpace":"Space按键",
    "sendKeys":"发送内容",
    "selectByIndex":"索引定位下拉",
    "selectByText":"文本定位下拉",
    "selectByValue":"值定位下拉",
    "getAlertText":"获取弹出框的文本",
    "clickAlertAccept":"弹框确定",
    "clickAlertDismiss":"弹框取消",
    "inputAlertText":"弹框文本输入",
    "useJs":"js脚本",
    "verifyElementExits":"检查元素是否存在",
    "getElementText":"提取参数",
    "waitTime":"时间等待",
    "clickImage":"图片定位",
    "scrollPage":"鼠标滚动",
    "uploadFile":"文件上传",
    "quitFarme":"退出iframe",
    "":""
}


def summary_result_simple(summary_dict):
    """将报告结果详细信息简化 ->传给前端"""
    new_summary_dict = {}
    if isinstance(summary_dict, str):
        # summary_dict = eval(summary_dict)
        summary_dict = json.loads(summary_dict)
    if not summary_dict:
        return new_summary_dict
    new_summary_dict["baseinfo"] = summary_dict["baseinfo"]
    summary_result_list = summary_dict["result"]
    new_summary_result_list = []
    for case_result_dict in summary_result_list:
        new_case_result = {}
        new_case_result["title"] = case_result_dict["title"]
        new_case_result["case_status"] = case_result_dict["case_status"]
        case_result_details = case_result_dict["details"]
        new_case_result_details = []
        for case_step in case_result_details:
            new_case_step = {}
            new_case_step["step_id"] = case_step["step"]["id"]
            new_case_step["element_name"] = case_step["step"]["element"]                             # 元素名
            if isinstance(new_case_step["element_name"], dict):
               new_case_step["element_name"] = case_step["step"]["element"].get("name", "")
            new_case_step["action"] = case_step["step"]["action"]                                     # 动作
            if isinstance(new_case_step["action"], dict):
                new_case_step["action"] = case_step["step"]["action"].get("type", "")
            # 动作名替换为中文
            new_case_step["action"] = ACTION_NAME[new_case_step["action"]]
            new_case_step["value"] = case_step["step"]["data"]                                            # 值
            if isinstance(new_case_step["value"], dict):
                new_case_step["value"] = case_step["step"]["data"].get("action","")
            new_case_step["step_status"] = case_step["status"]                                            # 结果（成功 or 失败）
            # image_name = os.path.basename(case_step["attachment"])
            ## new_case_step["attachment"] = '{}{}{}'.format(request_host, '/screenshot/', image_name)
            # new_case_step["attachment"] = '{0}{1}{2}'.format(BASE_HOST_, SCREENSHOT_PATH_, image_name)
            if os.path.exists(case_step["attachment"]):
                image_name = os.path.basename(case_step["attachment"])
                new_case_step["attachment"] = '{0}{1}{2}'.format(BASE_HOST_, SCREENSHOT_PATH_, image_name)
            else:
                new_case_step["attachment"] = case_step["attachment"]

            new_case_step["detail"] = case_step["detail"]                                                  # 错误信息
            new_case_result_details.append(new_case_step)
        new_case_result["details"] = new_case_result_details
        new_summary_result_list.append(new_case_result)
    new_summary_dict["result"] = new_summary_result_list
    return new_summary_dict




