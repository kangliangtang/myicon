import ast
import json
import re

variable_regexp = r"\$([\w_]+)"
function_regexp = r"\$\{([\w_]+\([\$\w\.\-/_ =,]*\))\}"
function_regexp_compile = re.compile(r"^([\w_]+)\(([\$\w\.\-/_ =,]*)\)$")


def parse_datas(content):
    """ 替换参数化参数
    """
    data = json.dumps(content)
    variales = content['config'].get('variables', {})
    # function
    function = re.findall(function_regexp, data)
    if variales:
        for key, value in variales.items():
            data = re.sub(r"\${}".format(key), value, data)

    for func in function:
        func_meta = parse_function(func)
        func_name = getattr(func_meta['func_name'])
        value = func_name(*func_meta['args'], **func_meta['kwargs'])
        data = data.replace(r"${%s}" % func, value)
    data = json.loads(data)
    return data


def parse_function(content):
    matched = function_regexp_compile.match(content)
    if not matched:
        pass
        # logger_debug.error("not find function.{}")

    function_meta = {
        "func_name": matched.group(1),
        "args": [],
        "kwargs": {}
    }

    args_str = matched.group(2).strip()
    if args_str == "":
        return function_meta

    args_list = args_str.split(',')
    for arg in args_list:
        arg = arg.strip()
        if '=' in arg:
            key, value = arg.split('=')
            function_meta["kwargs"][key.strip()] = parse_string_value(value.strip())
        else:
            function_meta["args"].append(parse_string_value(arg))

    return function_meta


def parse_string_value(str_value):
    """ parse string to number if possible
    e.g. "123" => 123
         "12.2" => 12.3
         "abc" => "abc"
         "$var" => "$var"
    """
    try:
        return ast.literal_eval(str_value)
    except ValueError:
        return str_value
    except SyntaxError:
        # e.g. $var, ${func}
        return str_value

def gen_random(*args, **kwargs):
    import random
    str = ""
    str = random.randint(int(args[0]), args[1])
    print(str)
    return str

def gen_timestamp(*args, **kwargs):
    import time
    return time.time()
