from websocket_tornado import setting
# mysql_connect = setting.MYSQL_CONNECT
# import pymysql
# mysql_connect = pymysql.Connect(
#     host=setting.MYSQL_HOST,
#     port=setting.MYSQL_PORT,
#     user=setting.MYSQL_USER,
#     passwd=setting.MSYQL_PASSWORD,
#     db=setting.MYSQL_DB,
#     charset=setting.MYSQL_CHARSET
# )


class DumpCase():
    def __init__(self):
        self.test_case_tem = {}

    def dumpCase(self,data, mysql_connect):
        content = {}
        content['testcases'] = data.get('test_content', [])
        content['name'] = data.get('name')
        content['page_id'] = data.get('test_content')[0]['page_id']
        self.dumpConfig(content)
        self.dumpTest(content)
        return self.fromIdToValue(content=self.test_case_tem, mysql_connect=mysql_connect)

    def dumpConfig(self, content):
        name = content.get('name')
        conf_dict = {
            'page_id': content['page_id'],
            "url": "$BASE_URL",
            "webdriver": "$BASE_DRIVER",
            "name": name
        }
        self.test_case_tem["config"] = conf_dict

    def dumpTest(self, content):
        testcases = content['testcases']
        self.test_case_tem["testcases"] = []
        for data in testcases:
            page_id = data['page_id']
            page_name = data['page_name']
            for case in data['data']:
                case['page_id'] = page_id
                case['page_name'] = page_name
                case['action'] = {'type':case['action']}
                import copy
                case['data'] = copy.deepcopy({'action':case['data']}) #{'action':case['data']}
                self.test_case_tem["testcases"].append(case)
        return True

    def fromIdToValue(self,content, mysql_connect):
        url, is_public = self.getPageUrl(page_id=content['config']['page_id'], mysql_connect=mysql_connect)
        content['config']['url'] = "$BASE_URL{}".format(url)
        for case in content['testcases']:
            page_id = case.get('page_id')
            page_name = case.get('page_name')
            ret, is_public = self.getPageUrl(page_id, mysql_connect)
            if not ret:
                case['page_info'] = {'page_id':page_id, 'page_name':page_name, 'is_delete':True}
                break
            case['page_info'] = {'page_id': page_id, 'page_name': page_name, 'is_delete': False}

            element_id = case.get('element_id', None)
            if not element_id:
                case['element'] = {}
            else:
                case['element'] = self.dumpElement(element_id, mysql_connect, page_id)
                case.pop('element_id')
            if case.get('verify'):
                verify_list = case.get('verify')
                for verify in verify_list:
                    verify_form = verify.get('comparison', '')
                    if verify_form == '':
                        verify_list = []
                        break
                    verify_element_id = verify.get('element_id', None)
                    if not verify_element_id:
                        verify['element'] = {}
                    else:
                        verify['element'] = self.dumpElement(verify_element_id, mysql_connect, page_id)
                    verify.pop('element_id')
                case['verify'] = verify_list
        return content

    def dumpElement(self, element_id, mysql_connect, page_id):
        cursor = mysql_connect.cursor()
        # element_sql = "select name,locmode, location, image_path from %s where id='%s' AND is_delete='0';" % ('tb_element', element_id)
        element_sql = "select name,locmode, location, image_path, is_delete,page_id from %s where id='%s';" % ('tb_element', element_id)
        sql_ret = cursor.execute(element_sql)
        element = dict()
        if sql_ret:
            result = cursor.fetchall()[0]
            element['name'] = result[0]
            element['type'] = result[1]
            element['value'] = result[3] if result[1] == 'image' else result[2]
            element['is_delete'] = result[4]
            element['page_id'] = result[5]
            element['element_id'] = element_id

        if page_id and (page_id != element['page_id']):
            # 若为公共页面，则视为此元素在当前页面没有被删除
            url_, is_public = self.getPageUrl(page_id=element['page_id'], mysql_connect=mysql_connect)
            if not is_public:
                element['is_delete'] = True

        mysql_connect.commit()
        cursor.close()
        # mysql_connect.close()
        return element

    def getPageUrl(self, page_id, mysql_connect):
        page_url = ''
        is_public = 0
        if not page_id:
            return page_url
        cursor = mysql_connect.cursor()
        page_url_sql = "select url, is_public from %s where id='%s' AND is_delete='0';" % ('tb_page', page_id)
        sql_ret = cursor.execute(page_url_sql)
        if sql_ret:
            page_url_is_public = cursor.fetchall()[0]
            page_url = page_url_is_public[0]
            is_public = page_url_is_public[1]
        mysql_connect.commit()
        cursor.close()
        # mysql_connect.close()
        return page_url, is_public
