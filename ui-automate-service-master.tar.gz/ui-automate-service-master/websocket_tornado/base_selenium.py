import shutil
import time
import os

from pymysql import Connect
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium import webdriver
from selenium.webdriver.support.select import Select
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import UnexpectedAlertPresentException
import threading

from selenium.webdriver.chrome.service import Service
import sys
SYSTEM_TYPE = sys.platform

# from utils.image_match import matchImage as matchImageFun, findImageByThreshold
from websocket_tornado.image_match import matchImage as matchImageFun, findImageByThreshold
from websocket_tornado import setting

SCREENSHOT_DIR = setting.SCREENSHOT_DIR
UI_AUTOMATE_DATA_DIR = setting.UI_AUTOMATE_DATA_DIR
DEFAULT_THRESHOLD = 0.9  # 图像匹配 阈值
IMAGE_CLICK_THRESHOLD = 0.7  # 图像点击 阈值
from websocket_tornado.logs import log
# mysql_connect = setting.MYSQL_CONNECT


"""信号被无视（ignore）或忽略，在该状态下，调用进程的子进程将不产生僵尸进程"""
import signal
signal.signal(signal.SIGCLD, signal.SIG_IGN)


class BaseSelenium():
    def __init__(self, driver="Chrome", over_time=15, mysql_client=None):
        if driver == "Chrome":
            # binary_location = "C:/Users/zhangbaoyuan3/AppData/Local/Google/Chrome/Application"
            if 'linux' in sys.platform:
                options = webdriver.ChromeOptions()
                # options.binary_location = binary_location  # 谷歌地址
                options.add_argument('--no-sandbox')
                options.add_argument('--disable-dev-shm-usage')
                options.add_argument('--headless')
                options.add_argument('--disable-gpu') #谷歌文档提到需要加上这个属性来规避bug
                options.add_argument('--ignore-certificate-errors')  # 设置允许不安全的证书
                options.add_argument('--window-size=1920,1080')
                # self.executable_path = os.path.join(os.path.dirname(settings.BASE_DIR), 'driver/chromedriver')
                self.executable_path = "/bin/chromedriver" #/app/uiautomate/driver/chromedriver
                # logger_debug.info("chromedriver:" + self.executable_path)
                self.driver = webdriver.Chrome(executable_path=self.executable_path, chrome_options=options)
            else:
                options = webdriver.ChromeOptions()
                options.add_argument('--headless')
                options.add_argument('--window-size=1920,1080')
                self.driver = webdriver.Chrome(chrome_options=options)
        elif driver == "Ie":
            cur = mysql_client.cursor()
            cur.execute('select id, remote_driver_service_ip, remote_driver_service_port from tb_web_driver where web_driver_type="Ie";')
            ie_driver_dict = cur.fetchall()[0]
            cur.close()
            remote_ip = ie_driver_dict[1]
            remote_port = ie_driver_dict[2]
            webdriver.DesiredCapabilities.INTERNETEXPLORER['ignoreProtectedModeSettings'] = True
            self.driver = webdriver.Remote(command_executor="http://{}:{}/wd/hub".format(remote_ip, remote_port),
                                           desired_capabilities=webdriver.DesiredCapabilities.INTERNETEXPLORER.copy())
        else:
            if 'linux' in sys.platform:
                options = webdriver.FirefoxOptions()
                options.add_argument('--headless')
                options.add_argument('--window-size=1920,1080')
                self.executable_path = "/bin/geckodriver"  # /app/uiautomate/driver/chromedriver
                self.driver = webdriver.Firefox(executable_path=self.executable_path, firefox_options=options)
            else:
                self.driver = webdriver.Firefox()

        self.driver.implicitly_wait(over_time)
        self.driver.maximize_window()
        self.driver.set_page_load_timeout(10)
        self.mouse = ActionChains(self.driver)

    def waitForAjax(self):
        driver = self.driver
        wait = WebDriverWait(driver, 10)
        try:
            # wait.until(lambda driver: driver.execute_script('return jQuery.active') == 0)
            wait.until(lambda driver: driver.execute_script('return document.readyState') == 'complete')
        except Exception as e:
            print(e)

    def switchWindows(self, *args, **kwargs):
        """
        切换窗口，输入窗口index
        :param args:
        :param kwargs:
        :return:
        """
        handles = args[2]
        window_handles = self.getCurrentHandles()
        self.driver.switch_to.window(window_handles[int(handles)-1])

    def waitTime(self, *args, **kwargs):
        """显示等待。输入等待时间"""
        wait_time = args[2]
        if not isinstance(wait_time, int):   # 等待时间只接受整数
            wait_time = 1
        if wait_time > 10:
            wait_time = 10
        time.sleep(wait_time)

    def startWeb(self, by, value, url, *args, **kwargs):
        """
        启动浏览器
        :param url: 测试地址
        :return:
        """
        print('--startWeb--', url)
        log.logging.info('startWeb url:{}'.format(url))
        self.driver.get(url)

    def closeWeb(self, *args, **kwargs):
        """关闭当前网页"""
        self.driver.close()

    def quitWeb(self, *args, **kwargs):
        """关闭浏览器"""
        self.driver.quit()

    def backWeb(self, *args, **kwargs):
        """后退"""
        self.driver.back()

    def forwardWeb(self, *args, **kwargs):
        """前进"""
        self.driver.forward()

    def screensHot(self, *args, **kwargs):
        """截图"""
        rq = int(time.time()*1000)  # 按格式获取当前时间
        screen_name = str(rq) + '.png'  # 拼接截图文件名
        # path = os.path.join(settings.SCREENSHOT_DIR, screen_name)

        path = os.path.join(SCREENSHOT_DIR, screen_name)

        log.logging.info('jietu:%s' % path)
        print("---------------jietu:"+path)
        # noinspection PyBroadException
        try:
            log.logging.info("screensHot start")
            self.driver.save_screenshot(path)
            log.logging.info("screensHot success")
            # if compress_images(path, path):   # 压缩图片
            #     # 上传minio服务器
            #     image_url = minio_obj.fput_get_url(bucket_name=settings.SCREENSHOTS_BUCKET_NAME, put_file_path=path)
            #     os.remove(path)
            #     path = image_url
            return path
        # except UnexpectedAlertPresentException:
        #     self.driver.switch_to.alert.accept()
        except Exception as e:
            log.logging.error("screensHot fail; msg={}".format(e))
            return ''


    def screensHotAsFile(self, *args, **kwargs):
        """截图,不存在minio，用于图片比对和标准"""
        rq = time.strftime('%Y%m%d%H%M%S', time.localtime(time.time()))  # 按格式获取当前时间
        screen_name = rq + '.png'  # 拼接截图文件名
        # print(screen_name)
        path = os.path.join(SCREENSHOT_DIR, screen_name)
        # path = os.path.join('./', screen_name)
        # noinspection PyBroadException
        print("-----------jietu::" + path)
        log.logging.info('jietu:%s' % path)
        try:
            log.logging.info("screensHot start")
            self.driver.get_screenshot_as_file(path)
            log.logging.info("screensHot success")
            return path
        except UnexpectedAlertPresentException:
            self.driver.switch_to.alert.accept()
        try:
            log.logging.info("screensHot start")
            self.driver.get_screenshot_as_file(path)
            log.logging.info("screensHot success")
            return path
        except BaseException as e:
            pass
            # logger_debug.error("screensHot fail", exc_info=1)

    def refreshWeb(self, *args, **kwargs):
        """刷新页面"""
        self.driver.refresh()

    def getCurrentUrl(self, *args, **kwargs):
        """获取当前url"""
        return self.driver.current_url

    def getCurrentHandle(self, *args, **kwargs):
        """获取当前窗口句柄"""
        return self.driver.current_window_handle

    def getCurrentHandles(self, *args, **kwargs):
        """获取所有窗口句柄"""
        return self.driver.window_handles

    def getTitle(self, *args, **kwargs):
        """获取title"""
        return self.driver.title

    def getPageSource(self, *args, **kwargs):
        """获取页面源码"""
        return self.driver.page_source

    def switchFarme(self, *args, **kwargs):
        """切换frame"""
        element = self.findElement(args[0], args[1])
        # noinspection PyBroadException
        try:
            self.driver.switch_to.frame(element)
        except BaseException:
            pass
            # logger_debug.error('switch frame fail', exc_info=1)

    def quitFarme(self, *args, **kwargs):
        self.driver.switch_to.default_content()

    def findElementByID(self, *args, **kwargs):
        """通过id查找元素"""
        element = None
        try:
            # ui.WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by=by, value=value))
            element = self.driver.find_element_by_id(args[0])
            if element:
                self.driver.execute_script("arguments[0].scrollIntoView();", element)  # 页面拖动到可见的元素去
        except:
            # logger_debug.error('not find element')
            self.screensHot()
        return element

    def findElementByXpath(self, *args, **kwargs):
        """通过xpath查找元素"""
        element = None
        try:
            # ui.WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by=by, value=value))
            element = self.driver.find_element_by_xpath(args[0])
            # if element:
            #     self.driver.execute_script("arguments[0].scrollIntoView();", element)  # 页面拖动到可见的元素去
        except:
            # logger_debug.error('not find element')
            self.screensHot()
        return element

    def findElementByText(self, text):
        """通过link_text（精确匹配）查找元素"""
        element = None
        try:
            # ui.WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by=by, value=value))
            element = self.driver.find_element_by_link_text(text)
            if element:
                self.driver.execute_script("arguments[0].scrollIntoView();", element)  # 页面拖动到可见的元素去
        except:
            # logger_debug.error('not find element')
            self.screensHot()
        return element

    def findElementByCss(self, css):
        """通过css查找元素"""
        element = None
        try:
            # ui.WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by=by, value=value))
            element = self.driver.find_element_by_css_selector(css)
            if element:
                self.driver.execute_script("arguments[0].scrollIntoView();", element)  # 页面拖动到可见的元素去
        except:
            # logger_debug.error('not find element')
            self.screensHot()
        return element

    def findElementByClassName(self, name):
        """通过classname查找元素"""
        element = None
        try:
            # ui.WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by=by, value=value))
            element = self.driver.find_element_by_class_name(name)
            if element:
                self.driver.execute_script("arguments[0].scrollIntoView();", element)  # 页面拖动到可见的元素去
        except:
            # logger_debug.error('not find element')
            self.screensHot()
        return element

    def findElementByTagName(self, name):
        """通过tag name查找元素"""
        element = None
        try:
            # ui.WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by=by, value=value))
            element = self.driver.find_element_by_tag_name(name)
            if element:
                self.driver.execute_script("arguments[0].scrollIntoView();", element)  # 页面拖动到可见的元素去
        except:
            # logger_debug.error('not find element')
            self.screensHot()
        return element

    def findElementByPartialText(self, text):
        """通过partial link text（模糊匹配）查找元素"""
        element = None
        try:
            # ui.WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by=by, value=value))
            element = self.driver.find_element_by_partial_link_text(text)
            if element:
                self.driver.execute_script("arguments[0].scrollIntoView();", element)  # 页面拖动到可见的元素去
        except:
            # logger_debug.error('not find element')
            self.screensHot()
        return element

    def findElementByName(self, name):
        """通过name查找元素"""
        element = None
        try:
            # ui.WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by=by, value=value))
            element = self.driver.find_element_by_name(name)
            if element:
                self.driver.execute_script("arguments[0].scrollIntoView();", element)  # 页面拖动到可见的元素去
        except:
            # logger_debug.error('not find element')
            self.screensHot()
        return element

    def findElement(self, *args, **kwargs):
        """定位元素"""
        element = None
        if args[0] in ['id', 'name', 'class', 'tag', 'link', 'plink', 'css', 'xpath', 'image']:
            # noinspection PyBroadException
            try:
                # ui.WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by=by, value=value))
                by_name = args[0]
                by = self.by_to_selenium(by_name)
                element = self.driver.find_element(by=by, value=args[1])
                if element:
                    if not element.is_displayed():
                        self.driver.execute_script("arguments[0].scrollIntoView();", element)  # 页面拖动到可见的元素去
                return element
            except:
                pass
                # logger_debug.error('not find element')
                # self.screensHot()  # 调用截图
        else:
            pass
            # logger_debug.error('input error')

    @staticmethod
    def by_to_selenium(by_name):
        """by转化为selenium可用的by"""
        by_dict = {'id': 'id',
                   'name': 'name',
                   'class': 'class name',
                   'tag': 'tag name',
                   'link': 'link text',
                   'plink': 'partial link text',
                   'css': 'css selector',
                   'xpath': 'xpath',
                   'image': 'image'
             }
        return by_dict[by_name]



    def findElements(self, *args, **kwargs):
        """定位元素,返回list"""
        element = None
        if args[0] in ['id', 'name', 'class', 'tag', 'link', 'plink', 'css', 'xpath', 'image']:
            # noinspection PyBroadException
            try:
                by_name = args[0]
                by = self.by_to_selenium(by_name)
                element = self.driver.find_elements(by=by, value=args[1])
                return element
            except:
                # logger_debug.error('not find element')
                self.screensHot()  # 调用截图
        else:
            pass
            # logger_debug.error('input error')

    def clickImage(self, *args, **kwargs):
        return self.clickImage_(*args, **kwargs)

    def clickImage_(self, *args, **kwargs):
        try:
            image_source_path = self.screensHotAsFile()
            # logger_debug.info('screensHot success')
            # image_template_path = settings.UI_AUTOMATE_DATA_DIR + args[1]
            image_template_path = UI_AUTOMATE_DATA_DIR + args[1]

            location = self.macthImage(image_template_path, image_source_path)
            x, y = location[2] / 2 + location[0], location[3] / 2 + location[1]
            print('x', x)
            print('y', y)
            print('location---', location)
            # logger_debug.info('click success')
            self.clickByOffset2(x, y)
            return True
        except Exception as e:
            # logger_debug.error('input text error', exc_info=1)
            self.screensHot()
            return False

    def imageInputText(self, *args, **kwargs):
        try:
            image_source_path = self.screensHotAsFile()
            # logger_debug.info('screensHot success')
            # image_template_path = settings.UI_AUTOMATE_DATA_DIR + args[1]
            image_template_path = UI_AUTOMATE_DATA_DIR + args[1]
            print('---image_template_path---', image_template_path)
            print('-image_source_path-', image_source_path)

            location = self.macthImage(image_template_path, image_source_path)
            x, y = location[2] / 2 + location[0], location[3] / 2 + location[1]
            print('x', x)
            print('y', y)
            print('location---', location)
            self.mouseInputText(x,y,args[2])
            # logger_debug.info('click success')
        except Exception as e:
            # logger_debug.error('input text error', exc_info=1)
            self.screensHot()
            return False

    def mouseInputText(self,x,y,text):
        # self.mouse.move_by_offset(0, 0).click().perform()
        self.mouse = ActionChains(self.driver)
        self.mouse.move_by_offset(x, y).click().send_keys(text).perform()
        self.mouse = ActionChains(self.driver)  #self.mouse.reset_actions()
        self.mouse.move_by_offset(-x, -y).click().perform()
        self.mouse.reset_actions()

    def macthImage(self,image_template_path=None, image_source_path=None, *args, **kwargs) -> tuple:
        """
        返回一个元组，该元组为该模板图片的上左点和下右点的位置
        :param image_template_path: 模板图片路径 - - 小图
        :param image_source_path: 原图片路径 - - 大图
        :param args:
        :param kwargs:
        :return:
        """
        result_location = matchImageFun(IMAGE_CLICK_THRESHOLD, image_template_path, image_source_path)
        print('---result_location--', result_location)
        return result_location

    def clickElement(self, *args, **kwargs):
        """点击元素"""
        element = self.findElement(args[0], args[1])
        element.click()
        # self.driver.execute_script("arguments[0].click();", element)
        # logger_debug.info('click success')

    def assertEqual(self, *args, **kwargs):
        """元素是否被选中"""
        if args[2] == args[3]:
            return True, "断言成功,预期值={},实际值={}".format(args[2], args[3])
        else:
            return False,"断言失败,预期值={},实际值={}".format(args[2], args[3])

    def assertNotEqual(self, *args, **kwargs):
        """元素是否被选中"""
        if args[2] == args[3]:
            return False, "断言失败,预期值={},实际值={}".format(args[2], args[3])
        else:
            return True, "断言成功,预期值={},实际值={}".format(args[2], args[3])

    def assertIn(self, *args, **kwargs):
        """元素是否被选中"""
        if args[2] in args[3]:
            return True, "断言成功,预期值={},实际值={}".format(args[2], args[3])
        else:
            return False,"断言失败,预期值={},实际值={}".format(args[2], args[3])

    def assertNotIn(self, *args, **kwargs):
        """元素是否被选中"""
        if args[2] in args[3]:
            return False, "断言失败,预期值={},实际值={}".format(args[2], args[3])
        else:
            return True, "断言成功,预期值={},实际值={}".format(args[2], args[3])

    def inputText(self, *args, **kwargs):
        """清空输入，然后输入内容"""
        if args[0] == 'image':
            try:
                return self.imageInputText(*args, **kwargs)
            except Exception:
                print('不能点击输入')
                return False
        else:
            element = self.findElement(args[0], args[1])
            # print(element.text)
            element.clear()
            # logger_debug.info('clear text')
            # noinspection PyBroadException
            try:
                element.send_keys(args[2])
                # logger_debug.info('input text:%s' % args[2])
            except BaseException:
                # logger_debug.error('input text error', exc_info=1)
                self.screensHot()

    def isDisplay(self, *args):
        """元素是否存在"""
        element = self.findElement(args[0], args[1])
        status = element.is_displayed()
        return status

    def isEdit(self, *args, **kwargs):
        """元素是否可编辑"""
        element = self.findElement(args[0], args[1])
        status = element.is_enabled()
        return status

    def isSelected(self, *args, **kwargs):
        """元素是否被选中"""
        element = self.findElement(args[0], args[1])
        status = element.is_selected()
        return status

    def submitForm(self, *args, **kwargs):
        """提交表单"""
        element = self.findElement(args[0], args[1])
        status = element.submit()
        return status

    def moveToOffset(self, *args, **kwargs):
        """鼠标移动到指定位置上"""
        offset = args[2]
        offset = offset.split(',')
        x = offset[0]
        y = offset[1]
        self.mouse.move_by_offset(0, 0).perform()
        return self.mouse.move_by_offset(x,y)

    def clickByOffset(self, *args, **kwargs):
        """鼠标移动到指定位置上并点击"""
        offset = args[2]
        print("---------get offset:{}".format(offset))
        offset = offset.split(',')
        x = offset[0]
        y = offset[1]
        self.mouse = ActionChains(self.driver)
        self.mouse.move_by_offset(0, 0).click().perform()
        self.mouse.move_by_offset(x, y).click().perform()
        self.mouse = ActionChains(self.driver)
        self.mouse.move_by_offset(-x, -y).click().perform()

    def clickByOffset2(self, x, y):
        """鼠标移动到指定位置上并点击"""
        self.mouse = ActionChains(self.driver)
        self.mouse.move_by_offset(0, 0).click().perform()
        self.mouse.move_by_offset(x, y).click().perform()
        self.mouse = ActionChains(self.driver)
        self.mouse.move_by_offset(-x, -y).click().perform()


    def moveToElement(self, *args, **kwargs):
        """鼠标移动到指定元素上"""
        element = self.findElement(args[0], args[1])
        self.mouse = ActionChains(self.driver)
        self.mouse.move_to_element(element).perform()

    def mouseRightClick(self, *args, **kwargs):
        """鼠标右击"""
        element = self.findElement(args[0], args[1])
        self.mouse = ActionChains(self.driver)
        self.mouse.context_click(element).perform()

    def twiceClick(self, *args, **kwargs):
        """鼠标双击"""
        element = self.findElement(args[0], args[1])
        self.mouse = ActionChains(self.driver)
        self.mouse.double_click(element).perform()

    def scrollByOffset(self, *args, **kwargs):
        """鼠标滚动"""
        # args[0]为横轴方向，左右滚动; args[1]纵轴方向，上下滚动
        self.driver.execute_script("window.scrollBy(%s, %s)" % (args[0], args[1]))

    def scrollPage(self, by, value, times, *args, **kwargs):
        try:
            times = int(times)
        except:
            times = 1
        if times > 100:
            times = 100
        for number in range(0, times):
            self.driver.execute_script("window.scrollBy(0, 540)" )

    def drapToDrop(self, by, value, to_by, to_value):
        """元素拖动"""
        src_element = self.findElement(by, value)
        target_element = self.findElement(to_by, to_value)
        self.mouse.drag_and_drop(src_element, target_element).perform()

    def clickEnter(self, *args, **kwargs):
        """点击键盘上的enter"""
        element = self.findElement(args[0], args[1])
        element.send_keys(Keys.ENTER)

    def clickEsc(self, *args, **kwargs):
        """点击键盘上的esc"""
        element = self.findElement(args[0], args[1])
        element.send_keys(Keys.ESCAPE)

    def clickBackspace(self, *args, **kwargs):
        """点击键盘上的BackSpace"""
        element = self.findElement(args[0], args[1])
        element.send_keys(Keys.BACK_SPACE)

    def clickSpace(self, *args, **kwargs):
        """点击键盘上的Space"""
        element = self.findElement(args[0], args[1])
        element.send_keys(Keys.SPACE)

    def sendKeys(self, *args, **kwargs):
        """点击键盘上的指定按键"""
        self.findElement(args[0], args[1]).send_keys(args[2])

    def selectByIndex(self, by, value, index):
        """通过索引定位下拉框"""
        element = self.findElement(by, value)
        select = Select(element)
        select.select_by_index(index)

    def selectByText(self, by, value, text):
        """通过文本定位下拉框"""
        element = self.findElement(by, value)
        select = Select(element)
        select.select_by_visible_text(text)

    def selectByValue(self, by, value, s_value):
        """通过值定位下拉框"""
        element = self.findElement(by, value)
        select = Select(element)
        select.select_by_value(s_value)

    def getAlertText(self, *args, **kwargs):
        """获取弹出框的文本"""
        return self.driver.switch_to.alert.text

    def clickAlertAccept(self, *args, **kwargs):
        """点击弹出框的确定"""
        self.driver.switch_to.alert.accept()

    def clickAlertDismiss(self, *args, **kwargs):
        """点击弹出框的取消"""
        self.driver.switch_to.alert.dismiss()

    def inputAlertText(self, *args, **kwargs):
        """在弹出框的文本框输入文本"""
        self.driver.switch_to.alert.send_keys(args[2])

    def useJs(self, by, value, js, *args, **kwargs):
        """调用js"""
        # noinspection PyBroadException
        try:
            self.driver.execute_script(js)
        except Exception as e:
            log.logging.error('use js fail.js={},exception={}'.format(js, e))
            return False

    def assertElementExits(self, *args, **kwargs):
        """断言元素存在"""
        element = self.findElements(args[0], args[1])
        if len(element) == 0:
            return False, "元素不存在"
        else:
            return True, ''

    def assertElementExist(self, *args, **kwargs):
        """断言元素存在"""
        element = self.findElements(args[0], args[1])
        if len(element) == 0:
            return False, "元素不存在"
        else:
            return True, ''

    def assertElementNotExits(self, *args, **kwargs):
        """断言元素不存在"""
        element = self.findElements(args[0], args[1])
        if len(element) == 0:
            return True,''
        else:
            return False, "元素存在"

    def assertElementEditable(self, *args, **kwargs):
        """元素是否可编辑"""
        try:
            element = self.findElement(args[0], args[1])
        except:
            return False,"没找到断言元素{}={}".format(args[0], args[1])
        status = element.is_enabled()
        return status,"元素{}={}不可编辑".format(args[0], args[1])

    def assertImageExits(self, *args, **kwargs):
        """断言当前截图中存在参考图片"""
        print('图片断言开始')
        self.waitForAjax()
        status = False
        # threshold = settings.DEFAULT_THRESHOLD  # 阈值 ---》 图像精确度 设置
        threshold = 0.8  # 阈值 ---》 图像精确度 设置
        print('threshold--:{}'.format(threshold))
        try:
            for index in range(5):
                get_image = self.screensHotAsFile()
                # src_image = settings.UI_AUTOMATE_DATA_DIR + args[1] # 获取用户指定的参考图片的方法
                src_image = UI_AUTOMATE_DATA_DIR+ args[1] # 获取用户指定的参考图片的方法
                # 调用图片比对方法,传入参考图片及当前截图
                print('path-',src_image)
                status = findImageByThreshold(threshold, get_image, src_image)
                print(status)
                if status:   #断言到当前截图中存在参考图片
                    print('断言成功')
                    return True, ''
                time.sleep(1)
            return False,'当前页面未找到参考图'
        except:
            return False,"图片比对出错"

    def assertImageExist(self, *args, **kwargs):
        """断言当前截图中存在参考图片"""
        print('图片断言开始')
        self.waitForAjax()
        status = False
        # threshold = settings.DEFAULT_THRESHOLD  # 阈值 ---》 图像精确度 设置
        threshold = 0.8  # 阈值 ---》 图像精确度 设置
        print('threshold--:{}'.format(threshold))
        try:
            for index in range(5):
                get_image = self.screensHotAsFile()
                # src_image = settings.UI_AUTOMATE_DATA_DIR + args[1] # 获取用户指定的参考图片的方法
                src_image = UI_AUTOMATE_DATA_DIR+ args[1] # 获取用户指定的参考图片的方法
                # 调用图片比对方法,传入参考图片及当前截图
                print('path-',src_image)
                status = findImageByThreshold(threshold, get_image, src_image)
                print(status)
                if status:   #断言到当前截图中存在参考图片
                    print('断言成功')
                    return True, ''
                time.sleep(1)
            return False,'当前页面未找到参考图'
        except:
            return False,"图片比对出错"

    def assertImageNotExits(self, *args, **kwargs):
        """断言当前截图中不存在参考图片"""
        self.waitForAjax()
        status = False
        # threshold = settings.DEFAULT_THRESHOLD  # 阈值 ---》 图像精确度 设置
        threshold = 0.8  # 阈值 ---》 图像精确度 设置
        try:
            for index in range(5):
                get_image = self.screensHotAsFile()
                # src_image = settings.UI_AUTOMATE_DATA_DIR + args[1] # 获取用户指定的参考图片的方法
                src_image = UI_AUTOMATE_DATA_DIR + args[1] # 获取用户指定的参考图片的方法
                #  调用图片比对方法,传入参考图片及当前截图
                status = findImageByThreshold(threshold, get_image, src_image)
                if status:  #断言到当前截图中存在参考图片
                    return False, '当前页面找到了参考图'
                time.sleep(1)
            return True, ''
        except:
            return False, "图片比对出错"

    def assertElementSelected(self, *args, **kwargs):
        """元素是否被选中"""
        try:
            element = self.findElement(args[0], args[1])
        except:
            return False, "没找到断言元素{}={}".format(args[0], args[1])
        status = element.is_selected()
        return status,"元素{}={}未被选中".format(args[0], args[1])

    def getElementText(self, *args, **kwargs):
        try:
            element = self.findElement(args[0], args[1])
            if element.tag_name == 'input':
                return True, element.get_attribute('value')
            else:
                return True,element.text
        except Exception as e:
            log.logging.error('getElementText() error; data={},{},error_msg={}'.format(args[0],args[1], e))
            return False, "没找到断言元素{}={},或元素没有text或value值.".format(args[0], args[1])

    @staticmethod
    def get_file_path(project_id, file_name, mysql_connect):
        # 从数据库查询文件路径
        file_path = ''
        suffix = ''
        file_sql = "SELECT file_path, suffix FROM %s WHERE project_id='%s' AND file_name='%s' AND is_delete='0';" % ('tb_public_file', project_id, file_name)
        mysql_cursor = mysql_connect.cursor()
        sql_ret = mysql_cursor.execute(file_sql)
        if sql_ret:
            ret = mysql_cursor.fetchall()[0]
            file_path = ret[0]
            suffix = ret[1]
        mysql_cursor.close()
        mysql_connect.commit()
        # mysql_connect.close()
        return file_path, suffix

    def _change_file_name(self, file_path, file_name):
        """修改文件名"""
        try:
            temp_file_dir = os.path.join(setting.UI_AUTOMATE_DATA_DIR, 'publicfile/Temp')
            # 修改文件名为用户上传的文件名
            if not os.path.exists(temp_file_dir):
                os.makedirs(temp_file_dir)
            new_file_path = os.path.join(temp_file_dir, file_name)
            shutil.copyfile(file_path, new_file_path)
        except Exception as e:
            log.logging.error('Change file name error;msg={}'.format(e))
            return file_path
        else:
            return new_file_path

    def uploadFile(self, *args, **kwargs):
        """上传文件"""
        try:
            location = args[1]
            file_name = args[2]
            file_name = file_name.replace(' ','').replace('\n', '').replace('\t','')
            project_id = args[3]
            mysql_connect = args[4]
            # 从数据库查询文件路径
            # file_path = self.get_file_path(project_id, file_name)
            file_path, suffix = self.get_file_path(project_id, file_name, mysql_connect)
            # 修改文件名为用户上传的文件名
            if suffix:
                file_name = '{}.{}'.format(file_name, suffix)
            file_path = self._change_file_name(file_path, file_name)
            if (location.split('/')[-1] == 'input') or (location.split('/')[-1] == 'file'):
                self.driver.find_element(args[0], args[1]).send_keys(file_path)
            elif args[0] == 'image':
                self.clickImage(*args, **kwargs)   # 需预先点击图片
                time.sleep(0.5)
                self.driver.find_element(By.NAME, "file").send_keys(file_path)
            else:
                self.driver.find_element(args[0], args[1]).click()
                time.sleep(0.5)
                self.driver.find_element(By.NAME, "file").send_keys(file_path)
            time.sleep(1)
            # 删除临时文件
            temp_file_path = os.path.join(setting.UI_AUTOMATE_DATA_DIR, 'publicfile/Temp', file_name)
            if os.path.isfile(temp_file_path):
                os.remove(temp_file_path)
        except Exception as e:
            log.logging.error('upload file error:location={0}, file_name={1},project_id={2}, error_info:{3}'.format(args[1], args[2], args[3], e))
            self.screensHot()


if __name__ == "__main__":
    driver = BaseSelenium()
    driver.startWeb('http://api.steam.crcloud.com/oauth/login')
    # driver.screensHot()
    driver.assertImageExits('','C://Users/zhangbaoyuan3/Desktop/0808.png')


