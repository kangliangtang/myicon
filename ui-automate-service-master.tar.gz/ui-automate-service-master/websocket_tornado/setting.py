import os

env = os.environ.get('devops_env', 'uat')
if env == 'production':
    SETTINGS = {
        'debug': False,
    }
else:
    SETTINGS = {
        'debug': True,
    }
print('\033[1;35m now env is ---->{}\033[0m!'.format(env))

# BASE_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_DIR = os.path.dirname(os.path.abspath('.'))
# BASE_DIR = os.path.dirname(os.path.abspath('..'))


# 截图存储路径设置
# SCREENSHOT_DIR = os.path.join(BASE_DIR, 'ui-automate-data/screenshot')
SCREENSHOT_DIR = os.path.join(BASE_DIR, 'ui-automate-data/screenshot/debug')
UI_AUTOMATE_DATA_DIR = os.path.join(BASE_DIR, 'ui-automate-data')

if not os.path.exists(SCREENSHOT_DIR):
    os.makedirs(SCREENSHOT_DIR)

# 截图相对路径 '/screenshot/'
SCREENSHOT_PATH_ = '/screenshot/debug/'

# webscoket日志
log_path = os.path.join(BASE_DIR, 'ui-automate-data/logs')

# mysql配置
MYSQL_DB = os.environ.get("DB_NAME", "ui_automate_test_uat")
MYSQL_USER = os.environ.get("DB_USER", "root")
MSYQL_PASSWORD = os.environ.get("DB_PASSWORD", "Mysql!23")
MYSQL_HOST = os.environ.get("DB_HOST", "10.0.99.136")
MYSQL_PORT = int(os.environ.get("DB_PORT", 3306))
MYSQL_CHARSET= 'utf8'
PORT = 8000

BASE_HOST_ = os.environ.get('BASE_HOST', 'http://cwt.devopsuat.crc.com.cn')