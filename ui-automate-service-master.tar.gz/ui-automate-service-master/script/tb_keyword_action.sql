/*

*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for tb_keyword_action
-- ----------------------------
DROP TABLE IF EXISTS `tb_keyword_action`;
CREATE TABLE `tb_keyword_action` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `description` longtext,
  `value_explain` int(11) DEFAULT NULL,
  `is_delete` int(11) NOT NULL DEFAULT '0',
  `weight` int(11) DEFAULT NULL,
  `image_type` int(11) NOT NULL DEFAULT '0',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_keyword_action
-- ----------------------------
INSERT INTO `tb_keyword_action` VALUES ('1', 'switchWindows', '切换窗口', '1', '0', '8', '1', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('2', 'startWeb', '打开网页;\n参数\n url:网页地址', '1', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('3', 'closeWeb', '关闭当前网页', '0', '0', '1', '1', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('4', 'quitWeb', '关闭浏览器', '0', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('5', 'backWeb', '后退;在浏览器历史记录中后退一步', '0', '0', '6', '1', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('6', 'forwardWeb', '前进；在浏览器历史记录中前进一步', '0', '0', '6', '1', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('7', 'screensHot', '将当前窗口的屏幕截图保存到PNG图像文件', '0', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('8', 'screensHotAsFile', '将当前窗口的屏幕截图保存到PNG图像文件', '0', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('9', 'refreshWeb', '刷新页面', '0', '0', '5', '1', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('10', 'getCurrentUrl', '获取当前页的URL', '0', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('11', 'getCurrentHandle', '获取当前窗口句柄', '0', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('12', 'getCurrentHandles', '获取所有窗口句柄', '0', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('13', 'getTitle', '获取title', '0', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('14', 'getPageSource', '获取页面源码', '0', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('15', 'switchFarme', '焦点切换至指定元素位置', '0', '0', '8', '1', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('16', 'findElementByID', '通过id获取元素', '1', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('17', 'findElementByXpath', '通过xpath方式获取元素', '1', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('18', 'findElementByText', '通过链接文本（精确匹配）查找元素', '1', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('19', 'findElementByCss', '通过css查找元素', '1', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('20', 'findElementByClassName', '通过classname查找元素', '1', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('21', 'findElementByTagName', '通过tag name查找元素', '1', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('22', 'findElementByPartialText', '通过partial link text（模糊匹配）查找元素', '1', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('23', 'findElementByName', '通过name查找元素', '1', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('24', 'findElement', '自定义指定定位方式获取元素', '2', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('25', 'findElements', '自定义指定定位方式获取元素,返回结果为list', '2', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('26', 'clickElement', '点击元素', '0', '0', '10', '1', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('27', 'inputText', '清空输入，然后输入内容', '0', '0', '10', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('28', 'isDisplay', '元素是否可见', '0', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('29', 'isEdit', '元素是否可编辑', '0', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('30', 'isSelected', '元素是否被选中', '0', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('31', 'submitForm', '提交表单', '0', '0', '3', '1', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('32', 'moveToOffset', '鼠标移动至指定坐标\n参数\n   xoffset:移动到的X偏移量，作为正整数或负整数。\n   yoffset: 移动到的Y偏移量，作为正整数或负整数。', '2', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('33', 'moveToElement', '鼠标移动到指定元素上', '0', '0', '9', '1', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('34', 'mouseRightClick', '鼠标右击', '2', '0', '7', '1', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('35', 'twiceClick', '鼠标双击', '2', '0', '7', '1', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('36', 'drapToDrop', '元素拖动', '2', '1', '0', '0', '2019-08-14 09:53:16', '2019-08-14 10:06:39');
INSERT INTO `tb_keyword_action` VALUES ('37', 'clickEnter', '点击键盘上的enter', '2', '0', '6', '1', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('38', 'clickEsc', '点击键盘上的esc', '2', '0', '6', '1', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('39', 'clickBackspace', '点击键盘上的BackSpace', '2', '0', '6', '1', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('40', 'clickSpace', '点击键盘上的Space', '2', '0', '6', '1', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('41', 'sendKeys', '模拟输入元素;\n 参数：\n   send_value: 输入的值', '1', '0', '10', '0', '2019-08-14 09:53:16', '2019-08-16 03:13:14');
INSERT INTO `tb_keyword_action` VALUES ('42', 'selectByIndex', '通过索引定位下拉框\n参数\n   index:指定索引', '1', '0', '2', '0', '2019-08-14 09:53:16', '2019-08-16 03:14:58');
INSERT INTO `tb_keyword_action` VALUES ('43', 'selectByText', '通过文本定位下拉框\n参数\n   text: 指定文本', '1', '0', '2', '0', '2019-08-14 09:53:16', '2019-08-16 03:15:00');
INSERT INTO `tb_keyword_action` VALUES ('44', 'selectByValue', '通过值定位下拉框;(例如：当给定“foo”时，将选择如下选项：<option value=“foo”>bar)\n参数\n   value:指定值\'', '1', '0', '2', '0', '2019-08-14 09:53:16', '2019-08-14 10:06:50');
INSERT INTO `tb_keyword_action` VALUES ('45', 'getAlertText', '获取弹出框的文本', '0', '1', '0', '0', '2019-08-14 09:53:16', '2019-08-16 03:15:03');
INSERT INTO `tb_keyword_action` VALUES ('46', 'clickAlertAccept', '点击弹出框的确定按钮', '0', '0', '4', '1', '2019-08-14 09:53:16', '2019-08-16 03:15:04');
INSERT INTO `tb_keyword_action` VALUES ('47', 'clickAlertDismiss', '点击弹出框的取消按钮', '0', '0', '4', '1', '2019-08-14 09:53:16', '2019-08-16 03:15:05');
INSERT INTO `tb_keyword_action` VALUES ('48', 'inputAlertText', '在弹出框的文本框输入文本;\n参数\n  text:输入文本内容', '1', '0', '8', '0', '2019-08-14 09:53:16', '2019-08-16 03:15:06');
INSERT INTO `tb_keyword_action` VALUES ('49', 'useJs', '调用js脚本\n参数\n    script：脚本内容\'', '1', '0', '5', '0', '2019-08-14 09:53:16', '2019-08-16 03:15:07');
INSERT INTO `tb_keyword_action` VALUES ('50', 'verifyElementExits', '检查元素是否存在;返回True（存在）或False（不存在）', '2', '1', '0', '0', '2019-08-14 09:53:16', '2019-08-16 03:15:09');
INSERT INTO `tb_keyword_action` VALUES ('51', 'getElementText', '获取元素内容', '2', '1', '0', '0', '2019-08-14 09:53:16', '2019-08-16 03:15:10');
INSERT INTO `tb_keyword_action` VALUES ('52', 'waitTime', '设置等待时间\n参数\n wait_time:等待时间（s）', '1', '0', '10', '1', '2019-08-14 09:53:16', '2019-08-16 03:15:10');
INSERT INTO `tb_keyword_action` VALUES ('53', 'clickImage', '点击图片定位到的位置', '0', '0', '10', '1', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('54', 'scrollByOffset', '鼠标滚动;\n参数\n   xoffset:移动到的X偏移量，作为正整数或负整数。\n   yoffset: 移动到的Y偏移量，作为正整数或负整数。\n', '2', '1', '8', '1', '2019-08-14 09:53:16', '2019-08-16 10:54:23');
INSERT INTO `tb_keyword_action` VALUES ('55', 'uploadFile', '文件上传;\n参数\n  filename: 文件名(不带后缀)', '1', '0', '8', '1', '2019-08-16 03:15:37', '2019-08-16 05:52:59');
