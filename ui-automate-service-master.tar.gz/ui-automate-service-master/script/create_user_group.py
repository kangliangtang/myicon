

def main():
    import os
    os.environ.setdefault("devops_env", "production")
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "automate_uitest_py3.settings")
    import django
    django.setup()
    from project_crud.models import ProjectModel
    from django.contrib.auth.models import Group

    project_set = ProjectModel.objects.all()
    for project in project_set:
        group_obj = Group.objects.create(name='{}_用户组_{}_'.format(project.name,project.id))
        project.user_group = group_obj
        project.save()



def update_project():
    import os
    os.environ.setdefault("devops_env", "production")
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "automate_uitest_py3.settings")
    import django
    django.setup()
    from project_crud.models import ProjectModel

    project_set = ProjectModel.objects.all()
    for project in project_set:
        if project.env_info is None:
            project.env_info = []
            project.save()


if __name__ == '__main__':
    update_project()
