
import pymysql

def import_project():
    """
    行云项目组
    :return:
    """
    import os
    os.system('mysqldump -uautomate -pautomate0412 -h10.0.13.40 -P3307 uiautomate >./test_.sql')
    # # os.system('mysqldump -uroot -p -h10.0.99.136 ui_automate_uat_8_26 >./test.sql')
    # cont = pymysql.Connect(host='10.0.99.136', database='ui_automate_uat_8_26', user='root',
    #                        password='Mysql!23', port=3306)
    cont = pymysql.Connect(host='10.0.13.40', database='uiautomate', user='automate',
                           password='automate0412', port=3307)
    cur = cont.cursor()
    cur.execute('SET FOREIGN_KEY_CHECKS=0')
    cont.commit()
    cur.execute('update tb_user_groups set group_id= group_id + 20000')
    cur.execute('update tb_user_groups set usermodel_id= usermodel_id + 20000')
    cont.commit()
    # os.system('mysql -uroot -pMysql!23 -h10.0.99.136 ui_automate_uat_8_26 <./ui_project_group.sql')
    project_id_group_id_list = project_set()
    # 修改 group_id
    try:
        for project_id, group_id in project_id_group_id_list:
            cur.execute('update tb_user_groups set group_id = {} where group_id={}'.format(group_id,project_id + 20000))
    except Exception:
        cont.rollback()
    else:
        cont.commit()
        # 查询user_id  该user_id 为行云的 id 要替换为我们的user_id
    # 通过行云的 choerodon_id 查找 userid 并替换
    cur.execute('select DISTINCT usermodel_id from tb_user_groups')
    try:
        for steam_user_id in cur.fetchall():
            cur.execute('select id from tb_user where choerodon_id={}'.format(int(steam_user_id[0]) - 20000))
            try:
                user_id = int(cur.fetchone()[0])
                cur.execute('update tb_user_groups set usermodel_id = {} where usermodel_id={}'.format(user_id,int(steam_user_id[0])))
                cont.commit()
            except Exception as e:
                print('错误的steam——user——id',steam_user_id[0])
                print('错误的user——id',user_id)
                raise e
    except Exception:
        cont.rollback()
    else:
        cont.commit()
    cur.execute('SET FOREIGN_KEY_CHECKS=1')
    cont.commit()
    # cont.rollback()


def project_set():
    import os
    os.environ.setdefault("devops_env", "production")
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "automate_uitest_py3.settings")
    import django
    django.setup()
    from project_crud.models import ProjectModel
    project_set = ProjectModel.objects.all()
    tuple_set = []
    for project in project_set:
        tuple_set.append((project.id,project.user_group.id))
    return tuple_set

if __name__ == '__main__':
    import_project()