
def main():
    from django_celery_beat.models import PeriodicTask, PeriodicTasks
    PeriodicTask.objects.all().update(last_run_at=None)
    for task in PeriodicTask.objects.all():
        PeriodicTasks.changed(task)


def fun1():
    from timed_task.models import TimedTaskModel
    tim_set = TimedTaskModel.objects.all()
    for _ in tim_set:
        _.delete()
    from django_celery_beat.models import PeriodicTask, PeriodicTasks,CrontabSchedule
    per_set = PeriodicTask.objects.all()
    for _ in per_set:
        _.delete()
    cron_set = CrontabSchedule.objects.all()
    for _ in cron_set:
        _.delete()


if __name__ == '__main__':
    import os
    import django

    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "automate_uitest_py3.settings")
    os.environ.setdefault("devops_env", "production")

    # os.environ.setdefault("DB_Name", "uiautomate")
    # os.environ.setdefault("DB_User", "automate")
    # os.environ.setdefault("DB_Password", "automate0412")
    # os.environ.setdefault("DB_Host", "10.0.13.40")
    # os.environ.setdefault("PORT", "3307")
    django.setup()
    main()
