/*
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for tb_keyword_action
-- ----------------------------
DROP TABLE IF EXISTS `tb_keyword_action`;
CREATE TABLE `tb_keyword_action` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `description` longtext,
  `value_explain` int(11) DEFAULT NULL,
  `is_delete` int(11) NOT NULL DEFAULT '0',
  `weight` int(11) DEFAULT NULL,
  `image_type` int(11) NOT NULL DEFAULT '0',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_keyword_action
-- ----------------------------
INSERT INTO `tb_keyword_action` VALUES ('1', 'switchWindows', '切换窗口', '1', '0', '8', '1', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('2', 'startWeb', '打开网页', '1', '1', '0', '0', '2019-08-14 09:53:16', '2019-09-12 05:40:28');
INSERT INTO `tb_keyword_action` VALUES ('3', 'closeWeb', '关闭当前页', '0', '0', '1', '1', '2019-08-14 09:53:16', '2019-09-12 05:35:40');
INSERT INTO `tb_keyword_action` VALUES ('4', 'quitWeb', '关闭浏览器', '0', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('5', 'backWeb', '后退一步', '0', '0', '6', '1', '2019-08-14 09:53:16', '2019-09-12 05:35:13');
INSERT INTO `tb_keyword_action` VALUES ('6', 'forwardWeb', '前进一步', '0', '0', '6', '1', '2019-08-14 09:53:16', '2019-09-12 05:35:31');
INSERT INTO `tb_keyword_action` VALUES ('7', 'screensHot', '截图', '0', '1', '0', '0', '2019-08-14 09:53:16', '2019-09-23 01:33:49');
INSERT INTO `tb_keyword_action` VALUES ('8', 'screensHotAsFile', '截图保存为文件', '0', '1', '0', '0', '2019-08-14 09:53:16', '2019-09-23 01:34:10');
INSERT INTO `tb_keyword_action` VALUES ('9', 'refreshWeb', '刷新页面', '0', '0', '5', '1', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('10', 'getCurrentUrl', '获取当前页的URL', '0', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('11', 'getCurrentHandle', '获取当前窗口句柄', '0', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('12', 'getCurrentHandles', '获取所有窗口句柄', '0', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('13', 'getTitle', '获取title', '0', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('14', 'getPageSource', '获取页面源码', '0', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('15', 'switchFarme', '指定元素位置', '0', '0', '8', '1', '2019-08-14 09:53:16', '2019-09-12 05:36:07');
INSERT INTO `tb_keyword_action` VALUES ('16', 'findElementByID', '通过id获取元素', '1', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('17', 'findElementByXpath', '通过xpath获取元素', '1', '1', '0', '0', '2019-08-14 09:53:16', '2019-09-23 01:36:58');
INSERT INTO `tb_keyword_action` VALUES ('18', 'findElementByText', '通过链接文本查找元素', '1', '1', '0', '0', '2019-08-14 09:53:16', '2019-09-23 01:36:52');
INSERT INTO `tb_keyword_action` VALUES ('19', 'findElementByCss', '通过css查找元素', '1', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('20', 'findElementByClassName', '通过classname查找元素', '1', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('21', 'findElementByTagName', '通过tag name查找元素', '1', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('22', 'findElementByPartialText', '通过partial link text查找元素', '1', '1', '0', '0', '2019-08-14 09:53:16', '2019-09-23 01:36:50');
INSERT INTO `tb_keyword_action` VALUES ('23', 'findElementByName', '通过name查找元素', '1', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('24', 'findElement', '获取元素', '2', '1', '0', '0', '2019-08-14 09:53:16', '2019-09-23 01:34:29');
INSERT INTO `tb_keyword_action` VALUES ('25', 'findElements', '获取元素,返回结果为list', '2', '1', '0', '0', '2019-08-14 09:53:16', '2019-09-23 01:34:33');
INSERT INTO `tb_keyword_action` VALUES ('26', 'clickElement', '点击元素', '0', '0', '10', '1', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('27', 'inputText', '输入文本内容', '0', '0', '10', '0', '2019-08-14 09:53:16', '2019-09-17 10:45:44');
INSERT INTO `tb_keyword_action` VALUES ('28', 'isDisplay', '元素是否可见', '0', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('29', 'isEdit', '元素是否可编辑', '0', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('30', 'isSelected', '元素是否被选中', '0', '1', '0', '0', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('31', 'submitForm', '提交表单', '0', '0', '3', '1', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('32', 'moveToOffset', '鼠标移动至指定坐标', '2', '1', '0', '0', '2019-08-14 09:53:16', '2019-09-23 01:52:12');
INSERT INTO `tb_keyword_action` VALUES ('33', 'moveToElement', '鼠标移动到指定元素上', '0', '0', '9', '1', '2019-08-14 09:53:16', null);
INSERT INTO `tb_keyword_action` VALUES ('34', 'mouseRightClick', '右击', '2', '0', '7', '1', '2019-08-14 09:53:16', '2019-09-12 05:36:56');
INSERT INTO `tb_keyword_action` VALUES ('35', 'twiceClick', '双击', '2', '0', '7', '1', '2019-08-14 09:53:16', '2019-09-12 05:36:58');
INSERT INTO `tb_keyword_action` VALUES ('36', 'drapToDrop', '元素拖动', '2', '1', '0', '0', '2019-08-14 09:53:16', '2019-08-14 10:06:39');
INSERT INTO `tb_keyword_action` VALUES ('37', 'clickEnter', 'enter按键', '2', '0', '6', '1', '2019-08-14 09:53:16', '2019-09-12 05:37:18');
INSERT INTO `tb_keyword_action` VALUES ('38', 'clickEsc', 'esc按键', '2', '0', '6', '1', '2019-08-14 09:53:16', '2019-09-12 05:37:26');
INSERT INTO `tb_keyword_action` VALUES ('39', 'clickBackspace', 'BackSpace按键', '2', '0', '6', '1', '2019-08-14 09:53:16', '2019-09-12 05:37:33');
INSERT INTO `tb_keyword_action` VALUES ('40', 'clickSpace', 'Space按键', '2', '0', '6', '1', '2019-08-14 09:53:16', '2019-09-12 05:37:39');
INSERT INTO `tb_keyword_action` VALUES ('41', 'sendKeys', '发送内容', '1', '0', '10', '0', '2019-08-14 09:53:16', '2019-09-17 11:27:35');
INSERT INTO `tb_keyword_action` VALUES ('42', 'selectByIndex', '索引定位下拉', '1', '0', '2', '0', '2019-08-14 09:53:16', '2019-09-12 05:38:23');
INSERT INTO `tb_keyword_action` VALUES ('43', 'selectByText', '文本定位下拉', '1', '0', '2', '0', '2019-08-14 09:53:16', '2019-09-12 05:38:29');
INSERT INTO `tb_keyword_action` VALUES ('44', 'selectByValue', '值定位下拉', '1', '0', '2', '0', '2019-08-14 09:53:16', '2019-09-12 05:38:53');
INSERT INTO `tb_keyword_action` VALUES ('45', 'getAlertText', '获取弹出框的文本', '0', '1', '0', '0', '2019-08-14 09:53:16', '2019-08-16 03:15:03');
INSERT INTO `tb_keyword_action` VALUES ('46', 'clickAlertAccept', '弹框确定', '0', '0', '4', '1', '2019-08-14 09:53:16', '2019-09-12 05:39:16');
INSERT INTO `tb_keyword_action` VALUES ('47', 'clickAlertDismiss', '弹框取消', '0', '0', '4', '1', '2019-08-14 09:53:16', '2019-09-12 05:39:24');
INSERT INTO `tb_keyword_action` VALUES ('48', 'inputAlertText', '弹框文本输入', '1', '0', '8', '0', '2019-08-14 09:53:16', '2019-09-12 05:39:44');
INSERT INTO `tb_keyword_action` VALUES ('49', 'useJs', 'js脚本', '1', '0', '5', '0', '2019-08-14 09:53:16', '2019-09-12 05:39:54');
INSERT INTO `tb_keyword_action` VALUES ('50', 'verifyElementExits', '检查元素存在', '2', '1', '0', '0', '2019-08-14 09:53:16', '2019-09-23 01:35:01');
INSERT INTO `tb_keyword_action` VALUES ('51', 'getElementText', '提取参数', '1', '0', '10', '0', '2019-08-14 09:53:16', '2019-09-16 07:46:48');
INSERT INTO `tb_keyword_action` VALUES ('52', 'waitTime', '时间等待', '1', '0', '10', '1', '2019-08-14 09:53:16', '2019-09-12 05:41:19');
INSERT INTO `tb_keyword_action` VALUES ('53', 'clickImage', '图片定位', '0', '0', '10', '1', '2019-08-14 09:53:16', '2019-09-12 05:40:14');
INSERT INTO `tb_keyword_action` VALUES ('54', 'scrollByOffset', '鼠标滚动', '2', '1', '8', '1', '2019-08-14 09:53:16', '2019-09-23 01:52:24');
INSERT INTO `tb_keyword_action` VALUES ('55', 'uploadFile', '文件上传', '1', '0', '8', '1', '2019-08-16 03:15:37', '2019-09-12 05:40:20');
