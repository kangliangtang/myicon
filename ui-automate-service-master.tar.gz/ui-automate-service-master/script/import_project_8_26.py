import pymysql

def import_project():
    """
    导入行云项目
    :return:
    """
    import os
    # os.system('mysqldump -uroot -pMysql!23 -h10.0.99.136 ui_automate_uat_8_26 >./test.sql')
    # os.system('mysqldump -uautomate -pautomate0412 -h10.0.13.40 uiautomate >./production_backend.sql')
    # cont = pymysql.Connect(host='10.0.99.136', database='ui_automate_uat_8_26', user='root',
    #                        password='Mysql!23', port=3306)
    # cont = pymysql.Connect(host='10.0.13.40', database='uiautomate', user='automate',
    #                       / password='automate0412', port=3307)

    # cur = cont.cursor()
    # cur.execute('SET FOREIGN_KEY_CHECKS=0')
    # cont.commit()
    # cur.execute('update tb_project set id= id + 20000')
    #
    # for _ in ("tb_case_manage", "tb_element", "tb_execution_case", "tb_page", "tb_project_data", "tb_project_run_data",
    #           "tb_public_file", "tb_public_variable", "tb_timed_task"):
    #     cur.execute('update {} set project_id = project_id + 20000'.format(_))

    # cont.commit()
    # for new_project_id,old_project_id in [(3, 1)]:  # (new_project_id, old_project_id)
    # for _ in ("tb_case_manage","tb_element","tb_execution_case","tb_page","tb_project_data","tb_project_run_data","tb_public_file","tb_public_variable","tb_timed_task"):
    #     cur.execute('update {} set project_id= project_id + 20000'.format(_))

    # cur.execute('SET FOREIGN_KEY_CHECKS=1')
    # cont.commit()
    # os.system('mysql -uroot -pMysql!23 -h10.0.99.136 ui_automate_uat_8_26 <./ui_project_data.sql')
    os.system('mysql -uautomate -pautomate0412 -h10.0.13.40 -P3307 uiautomate <./project_data_pro.sql')


if __name__ == '__main__':
    import_project()
