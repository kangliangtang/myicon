from django.db import models

# Create your models here.
from utils.model import BaseModel


class WebDriverModel(BaseModel):
    PLATFORM = (
        ('linux', 'linux'),
        ('windows', 'windows'),
        ('mac', 'mac')
    )
    WEBDRIVERTYPE = (
        ('Ie', 'Ie'),
        ('Chrome', 'Chrome'),
        ('firefox', 'firefox')
    )
    name = models.CharField(max_length=64, verbose_name='浏览器名称')
    # driver_file_path = models.FilePathField(null=True, blank=True, verbose_name='驱动文件路经')
    web_driver_type = models.CharField(max_length=64, choices=WEBDRIVERTYPE, verbose_name='浏览器类型')
    platform = models.CharField(max_length=64, choices=PLATFORM, default='linux')
    remote = models.BooleanField(default=False, verbose_name='是否远程驱动')
    remote_driver_service_ip = models.GenericIPAddressField(null=True, blank=True, verbose_name='远程浏览器驱动地址')
    remote_driver_service_port = models.PositiveIntegerField(null=True, blank=True, verbose_name='端口')

    class Meta:
        db_table='tb_web_driver'
        verbose_name='浏览器驱动'
        verbose_name_plural = '浏览器驱动'
