from django.apps import AppConfig


class UisystemConfig(AppConfig):
    name = 'uisystem'
