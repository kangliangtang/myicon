from django.shortcuts import render

# Create your views here.
from rest_framework import viewsets

from uisystem.models import WebDriverModel
from uisystem.serializers import WEBDriverSerializer


class WEBDriverAPIView(viewsets.ReadOnlyModelViewSet):
    queryset = None
    serializer_class = WEBDriverSerializer

    def get_queryset(self, *args, **kwargs):
        return WebDriverModel.objects.filter(is_delete=False)

    def retrieve(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"retrieve",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        return super(WEBDriverAPIView, self).retrieve(request, *args, **kwargs)

    def list(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"list",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        return super(WEBDriverAPIView, self).list(request, *args, **kwargs)

