from rest_framework import serializers

from uisystem.models import WebDriverModel


class WEBDriverSerializer(serializers.ModelSerializer):

    class Meta:
        model = WebDriverModel
        fields = ('id', 'name', 'web_driver_type')