'use strict';
app.constant('PEAK_TYPE',{
	toppeak:'COMMON.TARIFF.TOPPEAK',
	onpeak:'COMMON.TARIFF.ONPEAK',
	offpeak:'COMMON.TARIFF.OFFPEAK',
	midpeak:'COMMON.TARIFF.MIDPEAK'
});
app.constant('TARIFF_TYPE',{
	block:'SETTING.BLOCK',
	timeofuse:'SETTING.TIMEOFUSE'
});