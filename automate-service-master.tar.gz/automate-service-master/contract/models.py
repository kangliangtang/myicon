from django.db import models

# Create your models here.

from utils.model import BaseModel
from django.db import models, transaction


class ContractTestModel(BaseModel):
    interface = models.ForeignKey('interface.InterfaceModel', on_delete=models.CASCADE, verbose_name='接口id')
    report = models.ForeignKey('result_report.ResultReportModel', on_delete=models.CASCADE, verbose_name='报告id')
    task = models.ForeignKey('case_flow.TestTaskModel', on_delete=models.CASCADE, verbose_name='任务id', null=True)
    project = models.ForeignKey('project_caud.TestProjectModel', on_delete=models.CASCADE, verbose_name='所属项目',null=False)
    # email_to = models.CharField(max_length=521, verbose_name='邮件通知人',null=True)


    class Meta:
        db_table = 'tb_contract'
        verbose_name = '契约测试'
        verbose_name_plural = '契约测试'

    @transaction.atomic
    def setIsdeleteTrue(self):
        self.is_delete = True
        self.save()


class ContractTestResModel(BaseModel):
    contract = models.ForeignKey('ContractTestModel', on_delete=models.CASCADE, verbose_name='契约测试id')
    result = models.TextField(verbose_name='结果数据')
    project = models.ForeignKey('project_caud.TestProjectModel', on_delete=models.CASCADE, verbose_name='所属项目',
                                  null=False)
    email_to = models.CharField(max_length=521, verbose_name='邮件通知人', null=True)


    class Meta:
        db_table = 'tb_contract_result'
        verbose_name = '契约测试结果'
        verbose_name_plural = '契约测试结果'

    @transaction.atomic
    def setIsdeleteTrue(self):
        self.is_delete = True
        self.save()

    def getResult(self):
        import json
        res_dict = {"interface_path":"", "task_name":"","cur_time":"","src_time":"","content":""}
        res = self.result.split("接口地址: ")[1].split("任务名称：")
        res_dict["interface_path"] = res[0].strip()
        res = res[1].split("当前报告时间：")
        res_dict["task_name"] = res[0].strip()
        res = res[1].split("参考报告时间：")
        res_dict["cur_time"] = res[0].strip()
        res = res[1].split("对比后发生改变的内容: ")
        res_dict["src_time"] = res[0].strip()
        res_dict["content"] = res[1]
        return res_dict

