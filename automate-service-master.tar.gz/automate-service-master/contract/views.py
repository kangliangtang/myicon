from rest_framework import mixins
from rest_framework.viewsets import GenericViewSet
from contract.models import ContractTestModel, ContractTestResModel
from result_report.models import ResultReportModel
from contract.serializers import ContractSerializer, ContractGetTimeSerializer
from rest_framework.response import Response
from rest_framework.status import HTTP_200_OK
from rest_framework.decorators import list_route
from rest_framework.filters import OrderingFilter
from django_filters.rest_framework import DjangoFilterBackend
from utils.operation_log import OperationLogDecorator

logde = OperationLogDecorator()


class ContractAPIView(mixins.ListModelMixin, GenericViewSet):
    serializer_class = ContractSerializer
    queryset = None
    filter_backends = (DjangoFilterBackend, OrderingFilter)
    ordering = ('-create_time',)

    def get_queryset(self):
        try:
            # project_id = self.request.META.get('HTTP_PROJECTID')
            project_id = self.kwargs['project_id']
            return ContractTestResModel.objects.filter(is_delete=False).filter(project_id=project_id)
        except Exception as e:
            return ContractTestModel.objects.none()

    def destroy(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"destroy",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        obj = self.get_object()
        obj.setIsdeleteTrue()
        return Response('删除成功', status=HTTP_200_OK)

    def list(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"list",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super(ContractAPIView, self).list(request, *args, **kwargs)

    @list_route(methods=['GET'])
    def getReportTime(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"getReportTime",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        task_id = request.data.get('task_id')
        get_time = ResultReportModel.objects.filter(testCaseTask_id=task_id,status="true").order_by('-create_time').all()
        serializer = ContractGetTimeSerializer(get_time, many=True)
        return Response(serializer.data, status=HTTP_200_OK)
