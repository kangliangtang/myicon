from django.apps import AppConfig


class ContractConfig(AppConfig):
    name = 'contract'
