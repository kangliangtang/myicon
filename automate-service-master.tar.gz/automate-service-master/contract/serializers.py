import json

from contract.models import ContractTestModel, ContractTestResModel
from rest_framework import serializers
from django.db import transaction
from result_report.models import ResultReportModel


class ContractSerializer(serializers.ModelSerializer):
    name = serializers.ReadOnlyField(source='contract.interface.name')
    project_name = serializers.ReadOnlyField(source='contract.project.project_name')
    result = serializers.ReadOnlyField(source='getResult')
    # email_to = serializers.ReadOnlyField(source='reportid.create_time')


    class Meta:
        model = ContractTestResModel
        # exclude = ('is_delete',)
        fields = ('id', 'name', 'project_name', 'result', 'email_to', 'create_time')

    @transaction.atomic
    def create(self, validated_data):
        validated_data['project_id'] = self.context['view'].kwargs['project_id']
        instance = super().create(validated_data)
        return instance

    @transaction.atomic
    def update(self, instance, validated_data):
        validated_data['project_id'] = self.context['view'].kwargs['project_id']
        return super().update(instance, validated_data)


class ContractGetTimeSerializer(serializers.ModelSerializer):


    class Meta:
        model = ResultReportModel
        fields = ('id', 'create_time')