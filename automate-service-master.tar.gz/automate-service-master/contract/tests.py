from django.test import TestCase

# Create your tests here.
'''            id=project_data['projectId'],
            name=project_data['projectName'],
            code=project_data['projectCode'],
            username=project_data['userName'],
            user_id=project_data['userId'],'''

if __name__ == '__main__':
    import requests
    url = 'http://127.0.0.1:8000/sync/projects'
    requests.post(url, json={"projectId": 175, "projectName":"示例项目", "projectCode": "example","userName":"example","userId":123})
