#
# def main():
#     import json
#     from case_flow.models import TestTaskModel
#     task = TestTaskModel.objects.filter(id=4000).first()
#     # print(task.first()['name'])
#     # print(json.loads(task.task_content))
#     case_content = task.task_content
#     from interface.models import InterfaceModel
#     if isinstance(case_content, str):
#         case_content = json.loads(case_content)
#     for index, case in enumerate(case_content):
#         interface_id = case['interface_id']
#         interface_set = InterfaceModel.objects.filter(id=interface_id, is_delete=False).values('name')
#         case_content[index]['case_name'] = interface_set.first()['name']
#         case_content[index]['name'] = interface_set.first()['name']
#     return case_content
#
#
#
#
# if __name__ == '__main__':
#     import os
#     os.environ.setdefault("DJANGO_SETTINGS_MODULE", "automate_test_py3.settings")
#     import django
#     django.setup()
#     print(main())