import json

from django.db import models, transaction

# Create your models here.
from utils.model import BaseModel


class FlowTree(BaseModel):
    data = models.TextField('节点数据')
    project = models.OneToOneField('project_caud.TestProjectModel', on_delete=models.CASCADE, verbose_name='所属项目')

    class Meta:
        db_table = 'tb_flow_tree'
        verbose_name = '流程'
        verbose_name_plural = '流程'

    def deleteInterface(self, interface_id):
        data_obj = json.loads(self.data)
        for node_index, nodes in enumerate(data_obj.get('nodes')):
            for interface in nodes.get('interfaces').copy():
                if interface.get('id') == int(interface_id):
                    data_obj['nodes'][node_index].get('interfaces').remove(interface)
        self.data = json.dumps(data_obj)
        self.save()

    def updateInterface(self, interface_id, interface_name):
        data_obj = json.loads(self.data)
        for node_index, nodes in enumerate(data_obj.get('nodes')):
            for interface_index, interface in enumerate(nodes.get('interfaces')):
                if interface.get('id') == int(interface_id):
                    data_obj['nodes'][node_index]['interfaces'][interface_index]["name"] = interface_name
        self.data = json.dumps(data_obj)
        self.save()


class TestTaskModel(BaseModel):
    CHOICES_LEVEL = (
        (1, '一级任务'),
        (2, '二级任务'),
        (3, '三级任务'),
        (4, '四级任务'),
        (5, '五级任务')
    )
    CHOICES_CASE_TYPE = (
        (1, '单接口'),
        (2, '多接口'),
        (3, '聚合任务'),
        (4, '参数驱动')
    )
    CHOICES_STATUS = (
        ('running', '执行中'),
        ('false', '执行失败'),
        ('true', '执行成功'),
        ('error', '出错了'),
        ('unexecuted', '未运行')
    )
    name = models.CharField(max_length=128, verbose_name='任务名')
    project = models.ForeignKey('project_caud.TestProjectModel', on_delete=models.CASCADE, verbose_name='所属项目')
    level = models.SmallIntegerField(default=5, choices=CHOICES_LEVEL, verbose_name='任务分级')
    task_content = models.TextField(verbose_name='任务内容')
    case_type = models.SmallIntegerField(default=1, choices=CHOICES_CASE_TYPE, verbose_name='测试任务类型')
    case_file_path = models.FilePathField(null=True, blank=True, verbose_name='任务用例路径')
    publish_case = models.CharField(max_length=64, verbose_name='公共用例类型和状态') # {"login": True}
    interface = models.ForeignKey('interface.InterfaceModel', null=True, blank=True, on_delete=models.CASCADE, verbose_name='所属接口')
    excel_file_path = models.FilePathField(null=True, blank=True, verbose_name='参数驱动表格的文件路径')
    job_id = models.IntegerField(null=True, blank=True, verbose_name='ci触发的自动化测试对应的job_id')
    user_exc = models.CharField(max_length=68, null=True, blank=True, verbose_name='最后执行人')
    task_exc_time = models.DateTimeField(null=True,blank=True,verbose_name='最后执行时间')
    task_status = models.CharField(default='unexecuted', max_length=20, choices=CHOICES_STATUS, verbose_name='测试执行状态')
    creator = models.CharField(max_length=128, null=True, blank=True, verbose_name='创建人')

    class Meta:
        db_table = 'tb_test_task'
        verbose_name = '测试任务'
        verbose_name_plural = '测试任务'

    def getTaskExcUser(self):
        return self.user_exc

    def getTaskExcTime(self):
        return self.task_exc_time

    def getTaskExcStatus(self):
        return self.task_status

    @transaction.atomic
    def setIsdeleteTrue(self):
        self.is_delete = True
        self.save()
        self.resultreportmodel_set.update(is_delete=True)
        report_obj = self.resultreportmodel_set.filter()
        from interface.models import InterfaceExecutionTimeModel, InterfaceModel
        for report in report_obj:
            report_id = report.id
            interface_time_obj = InterfaceExecutionTimeModel.objects.filter(is_delete=False, report_id=report_id)
            for interface_time in interface_time_obj:
                interface_time.is_delete = True
                interface_time.save(update_fields=['is_delete',])
        scene_content = json.loads(self.task_content)
        for i in scene_content:
            interface_objs = InterfaceModel.objects.filter(id=i['interface_id'], is_delete=False).all()
            for interface_obj in interface_objs:
                interface_obj.use_case -= 1
                interface_obj.use_case = interface_obj.use_case if interface_obj.use_case > 0 else 0
                interface_obj.save(update_fields=['use_case', ])


    def getDataDrivenStatus(self):
        if self.excel_file_path:
            return True
        else:
            return False

    def getInterfaceTaskContent(self):
        """获取接口path & method"""
        try:
            new_task_content = json.loads(self.task_content)
            task_content = []
            if self.case_type == 1:
                for task in new_task_content:
                    task["interface_path"] = self.interface.path
                    task["interface_method"] = self.interface.method
                    task_content.append(task)
            elif self.case_type == 2:
                from interface.models import InterfaceModel
                for task in new_task_content:
                    # interface_obj = InterfaceModel.objects.get(id=task["interface_id"])
                    interface_obj = InterfaceModel.objects.filter(id=task["interface_id"])
                    if not interface_obj:
                        continue
                    interface_obj = interface_obj.first()
                    task["interface_path"] = interface_obj.path
                    task["interface_method"] = interface_obj.method
                    task_content.append(task)
            else:
                task_content = new_task_content
            return task_content
        except Exception:
            return list()
