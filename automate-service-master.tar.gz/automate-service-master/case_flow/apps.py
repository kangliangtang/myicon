from django.apps import AppConfig


class CaseFlowConfig(AppConfig):
    name = 'case_flow'
