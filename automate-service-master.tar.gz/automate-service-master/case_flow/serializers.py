import datetime
import json

import pytz
from django.db import transaction
from rest_framework import serializers

from case_flow.models import FlowTree, TestTaskModel
from case_flow.tasks import runTestTask_task
from project_caud.models import TestProjectModel
from result_report.models import ResultReportModel
from utils.runcore import HttpRunnerCore
from utils.serializer import ZJsonField


class FlowTreeSerializer(serializers.ModelSerializer):
    data = ZJsonField()  # json专用序列化器

    class Meta:
        model = FlowTree
        # fields = '__all__'
        exclude = ('is_delete', 'project')

    def create(self, validated_data):
        # project_id = self.context['request'].META.get('HTTP_PROJECTID')
        project_id = self.context['view'].kwargs['project_id']
        validated_data['project'] = TestProjectModel.objects.get(id=project_id)
        return super().create(validated_data)

    def update(self, instance, validated_data):
        if validated_data.get('project'):
            del validated_data['project']
        return super().update(instance, validated_data)


class TaskListSerializer(serializers.ModelSerializer):
    # user_exc = serializers.ReadOnlyField(source='getTaskExcUser')
    # task_Exc_time = serializers.ReadOnlyField(source='getTaskExcTime')
    # task_status = serializers.ReadOnlyField(source='getTaskExcStatus')
    task_content = ZJsonField()
    data_driven = serializers.ReadOnlyField(source='getDataDrivenStatus')
    class Meta:
        model = TestTaskModel
        fields = ('user_exc','task_exc_time','task_status','name','level','case_type', 'id', 'task_content', 'data_driven','creator')
        # fields = ('name','level','case_type', 'id')


class TestTaskSerializer(serializers.ModelSerializer):
    # user_exc = serializers.ReadOnlyField(source='getTaskExcUser')
    # task_Exc_time = serializers.ReadOnlyField(source='getTaskExcTime')
    # task_status = serializers.ReadOnlyField(source='getTaskExcStatus')
    task_content = ZJsonField()
    publish_case = ZJsonField()

    class Meta:
        model = TestTaskModel
        # fields = '__all__'
        # exclude = ('is_delete', 'case_file_path')

        # update 增加接口
        exclude = ('is_delete', 'case_file_path', 'interface', 'excel_file_path','update_time','create_time')

    def validate_publish_case(self, data):
        """
        默认的登陆参数检验
        如果 login=True，则查询项目下有没有没有默认的登陆
        没有默认登陆公共用例，抛出异常
        :param data:
        :return:
        """
        if json.loads(data).get('login') == True:
            # project_id = self.context['request'].META.get('HTTP_PROJECTID')
            project_id = self.context['view'].kwargs['project_id']
            project_obj = TestProjectModel.objects.get(id=project_id)
            if not  project_obj.publishcasemodel_set.filter(case_type=0, is_delete=False, is_default=True).exists():
                raise serializers.ValidationError('没有找到默认的登陆公共用例')
        return data

    def create(self, validated_data):

        # update 增加接口绑定
        # HttpRunnerCore_obj = HttpRunnerCore(validate=validated_data, project_id=self.context['request'].META.get('HTTP_PROJECTID'))
        with transaction.atomic():
            HttpRunnerCore_obj = HttpRunnerCore(validate=validated_data, project_id=self.context['view'].kwargs['project_id'])
            case_file_path = HttpRunnerCore_obj.dumpTestCase()

            validated_data['case_file_path'] = case_file_path
            interface_obj = HttpRunnerCore_obj.get_interface_obj()
            HttpRunnerCore_obj.interface_use_case_count()
            validated_data['interface'] = interface_obj
            instance = super().create(validated_data)
        project_obj = instance.project
        env_id = self.context['request'].data.get('env_id', None)
        if project_obj.env.filter(is_delete=False, id=env_id).exists():
                # 异步执行 用例
                report_obj = ResultReportModel.objects.create(
                    project=project_obj,
                    name=instance.name,
                    testCaseTask = instance,
                    user_exe = self.context['request'].user
                )
                instance.user_exc = self.context['request'].user.username
                instance.creator = self.context['request'].user.username
                instance.task_exc_time = datetime.datetime.now(tz=pytz.UTC)
                instance.save(update_fields=['user_exc','creator','task_exc_time'])
                runTestTask_task.delay(test_task_id=instance.id, env_id=env_id, report_id=report_obj.id, project_id=project_obj.id)
        else:
            instance.task_status = 'unexecuted'          # 任务暂存时，状态修改为未运行
            instance.creator = self.context['request'].user.username
            instance.save(update_fields=['task_status','creator'])
        return instance

    def update(self, instance, validated_data):

        # case_file_path = HttpRunnerCore(validate = validated_data, instance=instance).updateTestCase()
        # validated_data['case_file_path'] = case_file_path

        # update 增加接口绑定
        with transaction.atomic():
            HttpRunnerCore_obj = HttpRunnerCore(validate=validated_data, instance=instance, project_id=self.context['view'].kwargs['project_id'])
            if instance.excel_file_path is None:
                case_file_path = HttpRunnerCore_obj.updateTestCase()
                validated_data['case_file_path'] = case_file_path
            interface_obj = HttpRunnerCore_obj.get_interface_obj()
            HttpRunnerCore_obj.interface_use_case_count()
            validated_data['interface'] = interface_obj
            instance = super().update(instance, validated_data)
        project_obj = instance.project
        env_id = self.context['request'].data.get('env_id', None)
        if project_obj.env.filter(is_delete=False, id=env_id).exists():
                    # 异步执行 用例
                    report_obj=ResultReportModel.objects.create(
                        project=project_obj,
                        name=instance.name,
                        testCaseTask=instance,
                        user_exe=self.context['request'].user
                    )
                    runTestTask_task.delay(test_task_id=instance.id, env_id=env_id, report_id=report_obj.id, project_id=project_obj.id)
        return instance


class TaskTimeListSerializer(serializers.ModelSerializer):
    task_id = serializers.ReadOnlyField(source='id')

    class Meta:
        model = TestTaskModel
        fields = ('task_id', 'name')


class CasesSerializer(serializers.ModelSerializer):
    # task_content = ZJsonField()
    task_content = serializers.ReadOnlyField(source='getInterfaceTaskContent')

    class Meta:
        model = TestTaskModel
        fields = ('id', 'name', 'level', 'case_type', 'task_content')
