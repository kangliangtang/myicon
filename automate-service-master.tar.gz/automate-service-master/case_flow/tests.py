# # # import os
# # # import shutil
# # #
# # # from django.test import TestCase
# # #
# # # # Create your tests here.
# # #
# # #
# # # def copyCase(old_path, new_par_path):
# # #     # if os.path.isdir(old_path):
# # #     #     list_dir_ = os.listdir(old_path)
# # #         # shutil.copyfile()
# # #     shutil.copy(new_par_path,old_path)
# # #     shutil.copy2()
# # #         # for file_name in list_dir_:
# # #         #     new_path = os.path.join(new_par_path, file_name)
# # #         #     if os.path.isfile(new_path):
# # #         #         with open(old_path, 'r') as f:
# # #         #             file_ = f.read()
# # #         #         with open(new_path, 'w') as f:
# # #         #             f.write(file_)
# # #     # else:
# # #     #     new_path = os.path.join(new_par_path, old_path.split('/')[-1])
# # #     #     with open(old_path, 'r') as f:
# # #     #         file_ = f.read()
# # #     #     with open(new_path, 'w') as f:
# # #     #         f.write(file_)
# # #
# # #
# # #
# # # def copyfi(old_path,new_par_path):
# # #     if os.path.isdir(old_path):
# # #         list_dir_ = os.listdir(old_path)
# # #         for file_name in list_dir_:
# # #             if os.path.isfile(file_name):
# # #                 new_path = os.path.join(new_par_path, file_name)
# # #                 open(new_path, "w")
# # #                 shutil.copyfile(file_name, new_path)
# # #
# # # if __name__ == '__main__':
# # #     copyCase('../logs','../logss')
# #
# #
# # '''
# # /home/python/gitlab/testcases/15592983679567263.json   file
# # /home/python/gitlab/testcases/15592983914607067.json   keyvalues
# # /home/python/gitlab/testcases/15592984255658846.json   raw
# # /home/python/gitlab/testcases/15592984692217865.json
# # '''
# # # def main():
# # import json
# #
# # from utils.util import ExeclSerializer
# #
# #
# # def run_test_body_data():
# #     # update 增加接口绑定
# #     import os
# #     os.environ.setdefault("DJANGO_SETTINGS_MODULE", "automate_test_py3.settings")
# #     import django
# #     django.setup()
# #     from utils.runcore import HttpRunnerCore
# #
# #     task_content = '[{"nodeId": "5929cab0", "status": "enable", "id": 889, "case_params": [], "case_name": "\u6d4b\u8bd5\u63a5\u53e3", "case_body_type": "xml", "exampleList": [], "case_validate": [{"value": "200", "editRow": ["key", "value", "type"], "key": "status_code", "assert": "eq"}], "extract": [], "case_body_data": [{"value": "", "type": "String", "key": "codede"}], "interface_id": 889, "case_header_info": [], "name": "\u6d4b\u8bd5\u63a5\u53e3"}]'
# #     validated_data = {
# #         "name":"test_body_data",
# #         "level":1,
# #         "task_content": task_content,
# #         "publish_case":'{"login":false}'
# #     }
# #     HttpRunnerCore_obj = HttpRunnerCore(validate=validated_data, project_id=6)
# #     case_file_path = HttpRunnerCore_obj.dumpTestCase()
# #     print(case_file_path)
# #
# # def runtest_delete_flow_interface():
# #
# #     data = '{"nodes": [{"width": 100, "index": 4, "interfaces": [{"name": "\u4f60\u597d", "id": 964}, {"name": "hello", "id": 963}, {"name": "\u6d4b\u8bd5\u9000\u51fa22", "id": 919}, {"name": "aaaa", "id": 961}, {"name": "\u67e5\u8be2\u63a5\u53e3", "id": 962}, {"name": "\u54c8\u54c8\u54c8", "id": 969}, {"name": "11111", "id": 964}], "height": 200, "shape": "customNode", "x": -263.5, "status": "", "name": "\u65b0\u589e\u8282\u70b9", "y": 10, "id": "31e8a9c5"}]}'
# #     interface_id = 964
# #
# #     def deleteInterface(interface_id, data):
# #         data_obj = json.loads(data)
# #         for nodes in data_obj.get('nodes'):
# #             for index_, interface in enumerate(nodes.get('interfaces')):
# #                 if interface.get('id') == int(interface_id):
# #                     nodes['interfaces'].pop(index_)
# #         data__ = json.dumps(data_obj)
# #         print(data__)
# #
# #     deleteInterface(interface_id, data)
# #
# #
# #
# # def test1():
# #     import xlwt
# #     workbook = xlwt.Workbook()
# #     worksheet = workbook.add_sheet('My sheet')
# #     # 合并第0行的第0列到第3列。
# #     worksheet.write_merge(0, 0, 0, 3, 'First Merge')
# #     font = xlwt.Font()
# #     font.blod = True
# #
# #     pattern_top = xlwt.Pattern()
# #     pattern_top.pattern = xlwt.Pattern.SOLID_PATTERN
# #     pattern_top.pattern_fore_colour = 5
# #
# #     style = xlwt.XFStyle()
# #     style.font = font
# #     style.pattern = pattern_top
# #
# #     # 合并第1行到第2行的第0列到第3列。
# #     worksheet.write_merge(1, 2, 0, 3, 'Second Merge', style)
# #
# #     worksheet.write_merge(4, 6, 3, 6, 'My merge', style)
# #
# #     workbook.save('Merge_cell.xls')
# # import xlrd
#
# # if __name__ == '__main__':
#
#     # # execl_obj = ExeclSerializer()
#     # # execl_obj.writeExeclMain()
#     # # execl_obj.close()
#     # # from utils.util import ExeclSerializer
#     #
#     # import xlsxwriter
#     # wbobj = xlsxwriter.Workbook('tst.xlsx')
#     # sh = wbobj.add_worksheet()
#     # sh.write_comment(2,0, 'int', {'visible': True})
#     # wbobj.close()
#     #
#     # wb = xlrd.open_workbook('tst.xlsx')
#     # sheet = wb.sheet_by_index(0)
#     # note_ = sheet.cell_note_map.get((2, 0)).text
#     # print(note_)
#     #
# from urllib.request import urlopen
#
#
# def fun2():
#     eureka_app_name = "automate-service"
#     your_rest_server_port = 8007
#     eureka_service = "http://register-server.c7n-system:8000/eureka/"
#     # eureka_service = "http://127.0.0.1:8000/eureka/"
#     try:
#         import py_eureka_client.eureka_client as eureka_client
#         eureka_client.init(
#             eureka_server=eureka_service,
#             app_name=eureka_app_name,
#             instance_port=your_rest_server_port
#         )
#     except Exception as e:
#         print(e)
#         print('注册网关失败--init')
#     else:
#         print('suess2')
#
#
# fun2()
#
#
# def fun2():
#     import py_eureka_client.eureka_client as eureka_client
#
#     eureka_client.init_discovery_client("http://192.168.3.116:8761/eureka/, http://192.168.3.116:8762/eureka/")
#
#
# import py_eureka_client.http_client as http_client
#
# # 1. Inherit the `HttpClient` class in `py_eureka_client.http_client`.
# class MyHttpClient(http_client.HttpClient):
#
#     # 2. Rewrite the `urlopen` method in your class.
#     # If you want to raise an exception, please make sure that the exception is an `urllib.error.HTTPError` or `urllib.error.URLError`
#     # (urllib2.HTTPError or urllib2.URLError in python 2), or it may cause some un-handled errors.
#     def urlopen(self):
#
#         import requests
#         # requests.get()
#         # The flowing code is the default implementation, you can see what fields you can use. you can change your implementation here
#         res = urlopen(self.request, data=self.data, timeout=self.timeout,
#                               cafile=self.cafile, capath=self.capath,
#                               cadefault=self.cadefault, context=self.context)
#
#         return None
#
# # 3. Set your class to `py_eureka_client.http_client`.
# http_client.set_http_client_class(MyHttpClient)


def testExecl_(file_path=None):
    from utils.util import ExeclSerializer
    execl_serializer = ExeclSerializer(file_path=file_path)
    execl_serializer.readExeclMain()
    arg_generator = execl_serializer.argsValueGenerator()
    [print(value) for value in arg_generator]
    # print(1)
    # print(execl_serializer.argsValues)



if __name__ == '__main__':
    import os
    import django
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "automate_test_py3.settings")
    django.setup()

    testExecl_('/home/python/Desktop/15743074485355582.xlsx')

