from logging import getLogger

from celery import shared_task


from case_flow.models import TestTaskModel
from result_report.models import ResultReportModel, SummaryModel
from utils.runcore import HttpRunnerCore
from project_caud.models import TestProjectModel
log = getLogger('celery')


@shared_task
def runTestTask_task(test_task_id, env_id, report_id, project_id):
    try:
        runner = HttpRunnerCore()
        test_task_obj = TestTaskModel.objects.get(id=test_task_id)
        test_task_obj.task_status = 'running'
        test_task_obj.save(update_fields=['task_status'])
        report_obj = ResultReportModel.objects.get(id=report_id)
        suumarry_obj = SummaryModel.objects.create(result_report=report_obj)
        runner.runCaseByPath(test_task_obj.case_file_path, env_id=env_id, report_obj=report_obj,
                             suumarry_obj=suumarry_obj, project_id=project_id, task_id=test_task_id)
    except Exception as e:
        log.exception(e)
        log.error('error -- task_id:{}'.format(test_task_id))
        ResultReportModel.objects.filter(id=report_id).update(status='error')
        TestTaskModel.objects.filter(id=test_task_id).update(task_status='error')
    else:
        # 更新数据看板的执行用例数
        # TestProjectModel.objects.get(id=project_id).addRunCase(n=suumarry_obj.total_cases)
        TestProjectModel.objects.get(id=project_id).addRunCase(n=1)  # 场景、聚合场景均视为运行用例1次
        TestProjectModel.objects.get(id=project_id).addInterfaceResult(env_id=env_id, status=report_obj.status)
    finally:
        test_task_obj = TestTaskModel.objects.get(id=test_task_id)
        if test_task_obj.task_status == 'unexecuted':
            test_task_obj.task_status = 'error'
            test_task_obj.save(update_fields=['task_status'])
