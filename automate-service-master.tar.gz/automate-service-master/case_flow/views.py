import datetime
import io
import json
import os
import re
import time

import pytz
from django.contrib.auth.models import Group
from django.db import transaction
from django.db.models.query_utils import Q
from django.http.response import HttpResponse
from logging import getLogger

from rest_framework import filters
from rest_framework.decorators import list_route, detail_route
from rest_framework.response import Response
from rest_framework.status import HTTP_200_OK, HTTP_400_BAD_REQUEST
from rest_framework.viewsets import ModelViewSet
from rest_framework.generics import ListAPIView
from django_filters.rest_framework import DjangoFilterBackend

from automate_test_py3 import settings
from case_flow.models import FlowTree, TestTaskModel
from case_flow.serializers import FlowTreeSerializer, TestTaskSerializer, TaskListSerializer,TaskTimeListSerializer, CasesSerializer
from case_flow.tasks import runTestTask_task
from interface.models import InterfaceModel
from project_caud.models import TestProjectModel
from result_report.models import ResultReportModel
from result_report.serializers import ResultReportSerializer
from utils import util
from rest_framework.filters import OrderingFilter

from utils.runcore import CaseDump

# 操作日志
from utils.operation_log import OperationLogDecorator
from django.utils.decorators import method_decorator

# 自定义函数
from utils.defined_function import DefinedFunction, FORBID_STRING_RULE, DEF_RULE, JS_FORBID_STRING_RULE, FUNCTION_RULE
from utils import defined_function
from utils.util import AssertKeyError, DescribetionModelViewSet

logde = OperationLogDecorator()

logger_debug = getLogger('log')

class FlowAPIView(ModelViewSet):
    serializer_class = FlowTreeSerializer
    queryset = None
    filter_backends = (filters.SearchFilter, DjangoFilterBackend, OrderingFilter)
    ordering = ('-create_time',)
    # permission_classes = (AutoPlatformPermission,)

    def get_queryset(self):
        try:
            project_id = self.kwargs['project_id']
            user_obj = self.request.user
            user_group_obj = Group.objects.filter(user=user_obj)
            project_obj = TestProjectModel.objects.get(id=project_id)
            query_set = FlowTree.objects.filter(is_delete=False).filter(project=project_obj)
            if self.request.user.isSuperUser:
                return query_set
            else:
                query_set.filter(project__user_group__in=user_group_obj)
            return FlowTree.objects.filter(is_delete=False)
        except Exception as e:
            return FlowTree.objects.none()

    @method_decorator(logde.createFlowAPI)
    def create(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"create",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super().create(request, *args, **kwargs)

    @method_decorator(logde.updateFlowAPI)
    def partial_update(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"partial_update",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super().partial_update(request, *args, **kwargs)


class TestTaskModelView(DescribetionModelViewSet):
    serializer_class = TestTaskSerializer
    queryset = None
    filter_backends = (filters.SearchFilter, DjangoFilterBackend, OrderingFilter)
    ordering = ('-create_time', )
    search_fields = ('name',)    # 用例类别分类
    filter_fields = ('name', 'case_type', 'task_status')
    # permission_classes = (AutoPlatformPermission,)

    def get_queryset(self):
        user_obj = self.request.user
        user_group_obj = Group.objects.filter(user=user_obj)
        project_id = self.kwargs['project_id']
        try:
            project_obj = TestProjectModel.objects.get(id=project_id)
            query_set = TestTaskModel.objects.filter(is_delete=False).filter(project=project_obj)
            if self.request.user.isSuperUser:
                return query_set
            else:
                return query_set.filter(project__user_group__in=user_group_obj)
        except Exception as e:
            return TestTaskModel.objects.none()

    def list(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"list",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        self.serializer_class = TaskListSerializer
        return super().list(request, *args, **kwargs)

    def retrieve(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"retrieve",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        instance = self.get_object()
        instance.task_content = self.update_task(case_content=instance.task_content)
        serializer = self.get_serializer(instance)
        return Response(serializer.data)

    def update_task(self, case_content):
        from interface.models import InterfaceModel
        if isinstance(case_content, str):
            case_content = json.loads(case_content)
        new_case_content = list()
        for index, case in enumerate(case_content):
            interface_id = case['interface_id']
            interface_set = InterfaceModel.objects.filter(id=interface_id, is_delete=False).values('name')
            # if interface_set.__len__() == 0:
                # case_content[index]['case_name'] += '(接口已删除)'
                # case_content[index]['name'] += '(接口已删除)'
                # case_content.pop(index)
            if interface_set:
                new_case = case
                interface_name = interface_set.first()['name']
                new_case['case_name'] = interface_name
                new_case['name'] = interface_name
                new_case_content.append(new_case)
        return json.dumps(new_case_content)

    @list_route(methods=['GET'])
    def caselist(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"caselist",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        # """获取指定接口下的所有用例"""
        query_set = self.get_queryset()
        try:
            if not query_set:
                serializer = TestTaskSerializer(query_set, many=True)
                return Response({'list': serializer.data}, status=HTTP_200_OK)
            # update 增加指定接口查询,只展示单个任务用例(case_type=1)
            interface_id = self.request.query_params.get('interface_id', None)
            if interface_id is not None:
                interface_obj = InterfaceModel.objects.get(id=interface_id)
                query_set = query_set.filter(interface=interface_obj, case_type=1).order_by('-create_time')
                # 支持name搜索，不支持分页查询
                if self.request.query_params.get('search'):
                    name = self.request.query_params.get('search')
                    query_set = query_set.filter(name__icontains=name)
            else:
                query_set = TestTaskModel.objects.none()
        except Exception:
            query_set = TestTaskModel.objects.none()
        finally:
            serializer = TestTaskSerializer(query_set, many=True)
            return Response({'list': serializer.data}, status=HTTP_200_OK)

    @list_route(methods=['GET'])
    def taskList(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"taskList",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        # project_id = self.request.META.get('HTTP_PROJECTID', '')
        project_id = self.kwargs['project_id']
        if project_id:
            queryset = self.filter_queryset(self.get_queryset())  # 筛选
            query_set = queryset.order_by('-create_time')
            serializer = TaskTimeListSerializer(query_set, many=True)
            return Response({'list': serializer.data}, status=HTTP_200_OK)
        else:
            return Response({'message': '未找到该项目'}, status=HTTP_400_BAD_REQUEST)

    def destroy(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"destroy",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        obj =self.get_object()
        obj.setIsdeleteTrue()
        return Response('删除成功', status=HTTP_200_OK)

    def create(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"create",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        response = super().create(request, *args, **kwargs)
        return response

    def checkTaskID(self, project_id, task_id_list):
        project_obj = TestProjectModel.objects.get(id=project_id)
        for _id in task_id_list:
            if not project_obj.testtaskmodel_set.filter(id = _id).exists():
                return False
        return True

    @list_route(methods=['POST'])
    def run(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"run",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        name = request.data.get('name')
        test_task_id_list = request.data.get('test_task_id_list')
        env_id = request.data.get('env_id')
        # project_id = request.META.get('HTTP_PROJECTID')
        project_id = self.kwargs['project_id']
        level = request.data.get('level', '')

        # ***********单独的权限控制*********#
        # 通过查询集来过滤 拥有权限的 项目
        user_obj = request.user
        user_group_obj_set = Group.objects.filter(user=user_obj)
        if user_obj.isSuperUser:
            project_obj = TestProjectModel.objects.get(id=project_id)
        else:
            project_obj = TestProjectModel.objects.filter(id=project_id, user_group__in=user_group_obj_set).first()
        if project_obj is None:
            return Response({'message': '无该项目权限'}, status=403)
        # *******************权限控制××××××××××××××× #

        if not self.checkTaskID(project_id, test_task_id_list):
            return Response('错误的任务id', status=HTTP_400_BAD_REQUEST)
        project_obj = TestProjectModel.objects.get(id=project_id)
        if project_obj.project_statu == False:
            return Response('项目已停用', status=HTTP_400_BAD_REQUEST)
        if not project_obj.env.filter(is_delete=False, id=env_id).exists():
            return Response('找不到项目环境(host)', status=HTTP_400_BAD_REQUEST)
        # 异步执行 用例
        #如何是单个任务 直接异步执行
        #如果是多个任务 创建聚合任务后 运行聚合任务
        if test_task_id_list.__len__() == 1:
            #单个任务
            test_task_obj = TestTaskModel.objects.get(id=test_task_id_list[0])
            test_task_obj.user_exc = request.user.username
            test_task_obj.task_exc_time = datetime.datetime.now(tz=pytz.UTC)
            test_task_obj.save(update_fields=['user_exc', 'task_exc_time', 'update_time'])
        else:
            #聚合任务
            casedump = CaseDump()
            # name_set = set()
            task_json_file_path = casedump.copyTaskJsonFileToTempFileDIR(test_task_id_list)
            casedump.update_case_json_file(task_json_file_path)
            test_task_obj = TestTaskModel.objects.create(
                name=name,
                project=project_obj,
                task_content=[],
                case_type=3,
                case_file_path=task_json_file_path,
                level=level,
                user_exc=request.user.username,
                task_exc_time=datetime.datetime.now(tz=pytz.UTC),
                creator=request.user.username
            )
        report_obj = ResultReportModel.objects.create(
            project=project_obj,
            name=name,
            user_exe=request.user,
            testCaseTask=test_task_obj
        )
        # runTestTask_task.delay(test_task_id = test_task_obj.id, host_url = host_url, report_id = report_obj.id)
        runTestTask_task.delay(test_task_id=test_task_obj.id, env_id=env_id, report_id=report_obj.id, project_id=project_obj.id)
        return Response({'message': '已加入测试任务队列'}, status=HTTP_200_OK)

    @detail_route(methods=['GET'])
    def report(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"report",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        task_obj = self.get_object()
        result_report_set = task_obj.resultreportmodel_set.order_by('-create_time').all()
        if result_report_set.count():
            page = self.paginate_queryset(result_report_set)
            if page is not None:
                serializer = ResultReportSerializer(page, many=True, context={'request': request})
                return self.get_paginated_response(serializer.data)
        else:
            return Response({"message": '没有报告'}, status=HTTP_400_BAD_REQUEST)

    @detail_route(methods=['GET', "POST"])
    @transaction.atomic
    def parameters(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"parameters",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        # project_id = request.META.get('HTTP_PROJECTID')
        project_id = self.kwargs['project_id']
        from utils.util import ExeclSerializer
        case_obj = self.get_object()
        if request.method == 'GET':
            case_obj = self.get_object()
            taskcontent_obj = json.loads(case_obj.task_content)
            if (case_obj.case_type == 1) and (taskcontent_obj.__len__() == 1):
                taskcontent_obj = taskcontent_obj[0]
                if taskcontent_obj.get('case_body_type') == 'raw':
                    args = [util.Args('json数据', 'String')]
                elif taskcontent_obj.get('case_body_type') == 'x-formdata':
                    args = [util.Args(body_.get('key'),body_.get('type')) for body_ in taskcontent_obj.get('case_body_data')]

                elif taskcontent_obj.get('case_body_type') == 'x-formdata-file':
                    args = [util.Args(body_.get('key'), body_.get('type')) for body_ in taskcontent_obj.get('case_body_data')]
                elif taskcontent_obj.get('case_body_type') == 'xml':
                    args = [util.Args('xml数据', 'String')]
                else:
                    return Response({'message': 'body中无参数需要做参数驱动'}, status=HTTP_400_BAD_REQUEST)
                try:
                    output = io.BytesIO()
                    execl_obj = ExeclSerializer(args=args)
                    execl_obj.writeExeclMain(out_io=output)  # 写入模板数据
                    # 读取原表格数据
                    if case_obj.excel_file_path is not None:
                        read_obj = ExeclSerializer(file_path=case_obj.excel_file_path)
                        read_obj.openExcelFile(model='r')
                        read_obj.selectSheet()
                        read_obj.readHeader()
                        # 将数据写入到新表格中
                        execl_obj.writeData(case_name_list = read_obj.caseName, old_value=read_obj.excelValue)
                    execl_obj.close()
                except Exception as e:
                    logger_debug.exception(e)
                    return Response({"message":"参数驱动错误"},status=HTTP_400_BAD_REQUEST)
                output.seek(0)
                filename = str(time.time()).replace('.', '') + '.xlsx'
                response = HttpResponse(
                    output,
                    content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8'
                )
                response['Content-Disposition'] = 'attachment; filename=%s' % filename
                response['Access-Control-Expose-Headers'] = 'Content-Disposition'  # 网关 跨域获取  Content-Disposition
                return response
            else:
                return Response({"message": "用例类型任务不支持参数驱动"}, status=HTTP_400_BAD_REQUEST)

        elif request.method == 'POST':
            xml_file = request.FILES.get('xml_file')
            upload_file_path = os.path.join(settings.TESTCASE_DIR, 'xlsx')
            if not os.path.exists(upload_file_path):
                os.mkdir(upload_file_path)
            file_name = str(time.time()).replace('.', '') + '.xlsx'
            file_path = os.path.join(upload_file_path, file_name)
            with open(file_path, 'wb') as f:
                for data_ in xml_file.chunks():
                    f.write(data_)
            # 表格路径保存到case_obj 对象中， 该路径是个文件夹 文件夹中有一个或者多个用例

            sid1 = transaction.savepoint()  # 创建保存点  做数据回滚用
            case_obj.excel_file_path = file_path
            case_obj.save()
            try:
                execl_serializer = ExeclSerializer(file_path=file_path)
                execl_serializer.readExeclMain()
                task_content = json.loads(case_obj.task_content)
                arg_generator = execl_serializer.argsValueGenerator()
                from utils.runcore import HttpRunnerCore
                file_dir_path = os.path.join(settings.TESTCASE_DIR, str(time.time()).replace('.', ''))
                os.mkdir(file_dir_path)
                case_obj.case_file_path = file_dir_path
                case_obj.save()
                for case_name in arg_generator:
                    body_data = arg_generator.__next__()
                    case_body_type = json.loads(case_obj.task_content)[0]["case_body_type"]
                    if (case_body_type == 'x-formdata') or (case_body_type == 'x-formdata-file'):
                        # fromdata 和 key-value的body数据 带有数据类型type 后续优化可将其写入到表格中
                        # 目前是需要从源数据中获取 type
                        case_body_data = json.loads(case_obj.task_content)[0]["case_body_data"]
                        for body_data_value in body_data:
                            # 这里需要优化算法
                            for case_body_ in case_body_data:
                                if case_body_['key'] == body_data_value['key']:
                                    case_body_['value'] = util.formatData(case_body_['type'], body_data_value['value'])
                                    break
                    else:
                        case_body_data = body_data
                    task_content[0]['case_body_data'] = case_body_data  # 生成body数据
                    assert_data = arg_generator.__next__()         # 生成断言数据
                    task_content[0]['case_validate'] = assert_data
                    task_content_str =json.dumps(task_content)
                    validata = {
                        "task_content": task_content_str,
                        "name": case_obj.name,
                        "project":case_obj.project,
                        "level": case_obj.level,
                        "case_type":case_obj.case_type,
                        "case_file_path":case_obj.case_file_path,
                        "publish_case":case_obj.publish_case,
                        "interface":case_obj.interface
                    }
                    # 生成用例的json文件，
                    runner = HttpRunnerCore(validate=validata, project_id=project_id)
                    runner.dumpTestCaseByPath(file_path=file_dir_path, case_name=str(case_name))
            except AssertKeyError as ae:
                transaction.savepoint_rollback(sid1)
                return Response({"message": ae.message})
            except Exception as e:
                logger_debug.exception(e)
                transaction.savepoint_rollback(sid1)
                return Response({"message": "创建数据驱动失败"})
            else:
                transaction.savepoint_commit(sid1)
            return Response({"message": "创建参数驱动成功"})

    @list_route(methods=['POST'])
    def checkcode(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"checkcode",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        # """自定义函数代码检测"""
        data = self.request.data
        # code = data["code"]
        code = data.get('code', None)
        programlang = data.get("programlang", None)
        if not programlang:
            return Response({'message': '请选择程序语言', 'success': False}, HTTP_200_OK)
        # print('代码内容：%s' % code)

        # project_id = request.META.get('HTTP_PROJECTID', None)
        project_id = self.kwargs['project_id']
        if project_id is None:
            return Response({'message': '请选择项目', 'success': False}, HTTP_200_OK)

        # ***********单独的权限控制*********#
        # 通过查询集来过滤 拥有权限的 项目
        user_obj = request.user
        user_group_obj_set = Group.objects.filter(user=user_obj)
        if user_obj.isSuperUser:
            project_obj = TestProjectModel.objects.get(id=project_id)
        else:
            project_obj = TestProjectModel.objects.filter(
                Q(id=project_id) &
                Q(Q(user_group__in=user_group_obj_set))).first()

        if project_obj is None:
            return Response({'message': '无该项目权限'}, status=403)
        # *******************权限控制×××××××××××××××#

        if code:
            # 查找函数名
            if programlang == 'Python':
                re_function = re.search(r'def (.*?)\(.*?\):', code)
            else:
                re_function = re.search(r'function (.*?)\(.*?\){', code)
            if re_function:
                func_name = re_function.group(1)
                func_name = func_name.replace(' ', '')
                if not func_name:
                    return Response({'message': '函数名不能为空', 'success': False}, HTTP_400_BAD_REQUEST)
                if re.match(r'[0-9]', func_name):
                    return Response({'message': '函数名不能以数字开头 Error:%s' %func_name, 'success': False}, HTTP_400_BAD_REQUEST)

                defiend_fn_obj = DefinedFunction()
                if programlang == 'Python':
                    forbid_string = defiend_fn_obj.code_scan(code, rule=FORBID_STRING_RULE)
                    scan_funcname = defiend_fn_obj.code_scan(code, rule=DEF_RULE)
                else:
                    forbid_string = defiend_fn_obj.code_scan(code, rule=JS_FORBID_STRING_RULE)
                    scan_funcname = defiend_fn_obj.code_scan(code, rule=FUNCTION_RULE)

                if forbid_string:
                    forbid_string = ','.join(list(set(forbid_string)))
                    message = '{}函数暂未开放'.format(forbid_string)
                    return Response({'message': message, 'success': False}, HTTP_400_BAD_REQUEST)
                if scan_funcname:
                    if len(scan_funcname) > 1:
                        return Response({'message': '关键字{}有且只能有一个'.format(scan_funcname[0]), 'success': False}, HTTP_400_BAD_REQUEST)

                return Response({'message': '保存成功', 'success': True}, HTTP_200_OK)
                # func_obj = DefinedFunction()
                # ret = func_obj.debug(code=code)
                # success = ret["success"]
                # if success:
                #     return Response({'message': '检验通过', 'success': True}, HTTP_200_OK)
                # # return Response(ret, HTTP_400_BAD_REQUEST)
                # message = ret["message"]
                # return Response({'message': '代码书写错误 %s' % message, 'success': False}, HTTP_400_BAD_REQUEST)

            else:
                return Response({'message': '自定义函数名错误', 'success': False}, HTTP_400_BAD_REQUEST)
        else:
            return Response({'message': '自定函数内容为空', 'success': False}, HTTP_400_BAD_REQUEST)

    @list_route(methods=['GET'])
    def getcode(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"getcode",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        # """后置函数模版"""
        codeid = self.request.query_params.get('codeid')
        # project_id = request.META.get('HTTP_PROJECTID', None)
        project_id = self.kwargs['project_id']
        if project_id is None:
            return Response({'message': '请选择项目', 'success': False}, HTTP_200_OK)

        # ***********单独的权限控制*********#
        # 通过查询集来过滤 拥有权限的 项目
        user_obj = request.user
        user_group_obj_set = Group.objects.filter(user=user_obj)
        if user_obj.isSuperUser:
            project_obj = TestProjectModel.objects.get(id=project_id)
        else:
            project_obj = TestProjectModel.objects.filter(
                Q(id=project_id) &
                Q(Q(user_group__in=user_group_obj_set))).first()

        if project_obj is None:
            return Response({'message': '无该项目权限'}, status=403)
        # *******************权限控制×××××××××××××××#

        data = {'code': ''}
        # [(0, 返回值), (1, for循环), (2, 数组)]
        try:
           codeid = int(codeid)
        except Exception:
            return Response({"message": "参数类型错误"}, HTTP_400_BAD_REQUEST)
        if codeid == 0:
            data["code"] = defined_function.RETURN_VALUE_CODE
        elif codeid == 1:
            data["code"] = defined_function.ITERATE_CODE
        elif codeid == 2:
            data["code"] = defined_function.ARRAY_CODE
        else:
            return Response({"message": "参数错误"}, HTTP_400_BAD_REQUEST)
        return Response(data, HTTP_200_OK)


class CasesModelView(ListAPIView):
    serializer_class = CasesSerializer
    queryset = None
    filter_backends = (filters.SearchFilter, DjangoFilterBackend, OrderingFilter)
    ordering = ('-create_time', )
    search_fields = ('name',)
    filter_fields = ('name', 'case_type')

    def get_queryset(self):
        user_obj = self.request.user
        user_group_obj = Group.objects.filter(user=user_obj)
        project_id = self.kwargs['project_id']
        if project_id:
            try:
                project_obj = TestProjectModel.objects.get(id=project_id)
                query_set = TestTaskModel.objects.filter(is_delete=False).filter(project=project_obj)
                if self.request.user.isSuperUser:
                    query_set = query_set
                else:
                    query_set = query_set.filter(project__user_group__in=user_group_obj)
                return query_set.exclude(case_type=3)
            except Exception as e:
                return TestTaskModel.objects.none()
        else:
            return TestTaskModel.objects.none()

    def get(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"get",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super().get(request, *args, **kwargs)
