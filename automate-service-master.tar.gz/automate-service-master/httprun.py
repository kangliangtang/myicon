
if __name__ == '__main__':
    from httprunner.api import HttpRunner
    obj = HttpRunner()
    obj.run_path(path='/home/python/huazhong/sd/dd/demo-quickstart-0.yml')

