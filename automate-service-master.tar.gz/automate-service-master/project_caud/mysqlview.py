from django.db import models


class InterfaceNumModel(models.Model):
    """接口数量 msyql试图"""
    project_id = models.IntegerField(null=True, verbose_name='项目ID')
    interface_num = models.IntegerField(null=True, verbose_name='接口数量')
    interface_date = models.DateField(primary_key=True, verbose_name='日期')

    class Meta(object):
        managed = False                     # 默认是Ture 设成False django将不会执行建表和删表操作,但会生成迁移文件
        # abstract = True                   # 设置为True将不会生成迁移文件，但无法使用ORM查询
        db_table = 'v_interface_num'        # 视图名


class RunCaseNumModel(models.Model):
    """运行用例数 mysql试图"""
    project_id = models.IntegerField(null=True, verbose_name='项目ID')
    total_cases = models.IntegerField(null=True, verbose_name='用例数量')
    case_date = models.DateField(primary_key=True, verbose_name='日期')

    class Meta(object):
        managed = False
        # abstract = True
        db_table = 'v_total_cases'
