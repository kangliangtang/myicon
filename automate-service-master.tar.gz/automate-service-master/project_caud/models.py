import datetime
import json
from collections import OrderedDict
from colorlog.logging import getLogger
from django.contrib.auth.models import Group, Permission
from django.db import models, transaction

from django.db.models import Manager

from user.models import UserModel
from utils.model import BaseModel
from utils import permission
from automate_test_py3 import settings

debuglog = getLogger('debug')



class SteamProject(BaseModel):
    id = models.AutoField(primary_key=True, verbose_name='项目id')
    name = models.CharField(max_length=225, verbose_name='行云的项目名')
    code = models.CharField(max_length=32, verbose_name='项目code')
    status = models.BooleanField(default=True, verbose_name='项目状态')
    project_lead = models.ManyToManyField('user.UserModel', verbose_name='项目lead')
    user_group = models.OneToOneField(Group, on_delete=models.CASCADE, null=True, blank=True, verbose_name='组成员')
    # objects = ProjectModelManager()

    class Meta:
        db_table = 'tb_steam_project'
        verbose_name = '项目'
        verbose_name_plural = verbose_name

    def addProjectUser(self, user_obj):
        self.user_group.user_set.add(user_obj)

    def addProjectLead(self, user):
        self.project_lead.add(user)
        permission.projectLead(user)
        test_project_queryset = TestProjectModel.objects.filter(project_steam_id=self.id)
        for test_project in test_project_queryset:
            test_project.addProjectLead(user)

    def removeUser(self, user_obj):
        self.user_group.user_set.remove(user_obj)
        test_project_queryset = TestProjectModel.objects.filter(project_steam_id=self.id)
        for test_project in test_project_queryset:
            test_project.project_lead.remove(user_obj)

    def stop(self):
        self.status = False
        self.save()
        for test_project in TestProjectModel.objects.filter(project_steam_id=self.id).all():
            test_project.stop()

    def reopen(self):
        self.status = True
        self.save()
        for test_project in TestProjectModel.objects.filter(project_steam_id=self.id).all():
            test_project.reopen()

    def createProjectGroup(self):
        """
        创建项目组
        :return:
        """
        group_obj = Group.objects.create(
            name = self.name + '用户组_' + str(self.id)
        )
        permission.groupPermissionList(group_obj)
        project_leads = self.project_lead.all()
        for project_lead in project_leads:
            permission.projectLead(project_lead)
        return group_obj

class ProjectModelManager(Manager):

    def importProject(self, name, id, code, username, user_id):
        if not self.model.objects.filter(id=id, is_delete=False).exists():
            obj = self.model.objects.create(
                id=id,
                project_name=name,
                project_code=code,
                project_header_infos=[],
                project_urls=[]
            )
            group_obj = obj.createProjectGroup()
            obj.user_group = group_obj
            obj.save()
            try:
                user = UserModel.objects.get(choerodon_id=user_id)
            except UserModel.DoesNotExist as e:
                user = UserModel.objects.create(username=username, choerodon_id=user_id, email='none.email.com')
            group_obj.user_set.add(user)
            ProjectDataModel.objects.create(project=obj)
            return obj


class TestProjectModel(BaseModel):
    """
    项目code不是唯一的，组织是唯一的
    """
    id = models.AutoField(primary_key=True, verbose_name='应用id')
    project_name = models.CharField(max_length=255, verbose_name='项目名称')
    # project_lead = models.CharField(max_length=64, verbose_name='项目负责人')
    project_lead = models.ManyToManyField('user.UserModel', verbose_name='项目lead')
    user_group = models.ForeignKey(Group, on_delete=models.CASCADE, null=True, blank=True, verbose_name='组成员')

    project_header_infos = models.TextField(verbose_name='头域信息',default=[], blank=True)
    project_urls = models.TextField(verbose_name='域名信息',default=[], blank=True)
    project_statu = models.BooleanField(verbose_name='项目状态', default=True)

    organization = models.IntegerField(null=True, blank=True, verbose_name='组织id')
    project_code = models.CharField(max_length=32, null=True, blank=True, verbose_name='项目代码')
    objects = ProjectModelManager()

    class Meta:
        db_table = 'tb_project'
        verbose_name = '项目'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.project_name

    def setIsdeleteTrue(self):
        self.is_delete = True
        self.save()
        for project_module in self.projectmodulemodel_set.all():
            project_module.setIsdeleteTrue()
        for scene in self.interfacescenemodel_set.all():
            scene.setIsdeleteTrue()
        for task in self.taskmodel_set.all():
            task.setIsdeleteTrue()

    def appendModule(self, module_name):
        """
        创建项目模块
        :param module_name: 模块名字不能为空
        :return: 模块对象
        """
        return ProjectModuleModel.objects.create(module_name = module_name, project = self)

    def getModuleCount(self):
        return self.projectmodulemodel_set.filter(is_delete=False).count()

    def getInterfaceCount(self):
        return sum([i.interfacemodel_set.filter(is_delete=False).count() for i in self.projectmodulemodel_set.filter(is_delete=False).all()])

    def getProjectEnvInfo(self, env_name):
        for env in json.loads(self.project_urls):
            if env['env_name'] == env_name:
                return env['env_host']

    @property
    def getEnv(self):
        env_list = []
        app_env_set = self.app_env.filter(is_delete=False).all()
        env_category_set = app_env_set.values('env__name', 'env_id').distinct()
        for env_obj in env_category_set:
            env = OrderedDict()
            app_env_set.filter(env__name=env_obj['env__name']).select_related('env__name')
            env['env_name'] = env_obj['env__name']
            env['env_id'] = env_obj['env_id']
            # env['app_set'] = [
            #     {'app_id': app_env.application.id, 'app_name': app_env.application.name, 'app_host': app_env.host, 'app_env_id': app_env.id} for
            #     app_env in app_env_set.filter(env__name=env_obj['env__name'])]

            # 环境名可以同名，采用环境id区分 2020-3-28 10:43:50 klt
            env['app_set'] = [
                {'app_id': app_env.application.id, 'app_name': app_env.application.name, 'app_host': app_env.host, 'app_env_id': app_env.id} for
                app_env in app_env_set.filter(env_id=env_obj['env_id'])
            ]
            env_list.append(env)
        return env_list

    @getEnv.setter
    def getEnv(self, data):
        for app_env_ in data:
            if app_env_['env_id'] == '' or app_env_['env_id'] == None:
                env_ = EnvModel.objects.create(name=app_env_['env_name'], project=self)
            else:
                env_ = EnvModel.objects.get(id=app_env_['env_id'])
                env_.name = app_env_['env_name']
                env_.save()
            for app in app_env_['app_set']:
                if app['app_id'] == '' or app['app_id'] == None:
                    app_ = ApplicationModel.objects.get_or_create(name=app['app_name'], project=self, is_delete=False)[0]
                    app_env_ = ApplicationEnvModel.objects.get_or_create(application=app_, env=env_, project=self, is_delete=False)[0]
                    app_env_.host=app['app_host']
                    app_env_.save()
                else:
                    app_ = ApplicationModel.objects.get(id=app['app_id'])
                    app_.name = app['app_name']
                    app_.save()
                    if app['app_env_id'] =='' or app['app_env_id'] == None:
                        ApplicationEnvModel.objects.create(env=env_, application=app_, host=app['app_host'], project=self)
                    else:
                        ApplicationEnvModel.objects.filter(id=app['app_env_id']).update(host=app['app_host'], project=self)

    def createProjectGroup(self):
        """
        创建项目组
        :return:
        """
        group_obj = Group.objects.create(
            name = self.project_name + '用户组_' + str(self.id)
        )
        permission.groupPermissionList(group_obj)
        project_leads = self.project_lead.all()
        for project_lead in project_leads:
            permission.projectLead(project_lead)
        return group_obj

    def closeOrOpenProject(self):
        self.project_statu = not self.project_statu
        self.save()
        return self.project_statu

    def stop(self):
        self.project_statu = False
        self.save()

    def reopen(self):
        self.project_statu = True
        self.save()

    @property
    def getProjectLead(self):
        if self.project_lead.count():
            return [{'id':project_lead_obj.id, 'username': project_lead_obj.username} for project_lead_obj in self.project_lead.all()]
        else:
            return []

    @getProjectLead.setter
    def getProjectLead(self, value):
        pass

    def addProjectUser(self, user_obj):
        self.user_group.user_set.add(user_obj)

    def removeUser(self, user_obj):
        self.user_group.user_set.remove(user_obj)

    def setProjectLead(self, user):
        try:
            if hasattr(self, 'project_lead'):
                for project_lead_old in self.project_lead.all():
                    self.project_lead.remove(project_lead_old)
                    permission.removeProjectLead(project_lead_old)
        except Exception as e:
            pass
        self.project_lead.add(user)
        permission.projectLead(user)

    def addProjectLead(self, user):
        self.project_lead.add(user)
        permission.projectLead(user)

    def removeAllProjectLead(self):
        try:
            if hasattr(self, 'project_lead'):
                for project_lead_old in self.project_lead.all():
                    self.project_lead.remove(project_lead_old)
                    permission.removeProjectLead(project_lead_old)
        except Exception as e:
            debuglog.exception(e)

    def removeAllProjectGroupUser(self):
        for user in self.user_group.user_set.all():
            self.user_group.user_set.remove(user)

    def check_interface(self, interfaces):
        """
        interfaces 接收可迭代对象
        检验 接口是否在该项目下
        :param interfaces:
        :return:
        """
        if not self.objects.projectmodulemodel_set.filter(interfacemodel__id=interfaces.id).exists():
            return  True
        return False

    def check_default_login(self):
        """
        检查是否有默认登陆
        :return:
        """
        print(self.publishcasemodel_set.filter(case_type=0, is_delete=False, is_default=True).exists())
        if not self.publishcasemodel_set.filter(case_type=0, is_delete=False, is_default=True).exists():
            return False, '默认登陆不存在'
        else:
            return True, '成功'

    def addInterface(self, n=1, module_id=None):
        """
        接口数 加 1
        :param n:
        :return:
        """
        self.projectdata.interface_count += n
        self.projectdata.save()
        # 更新模板下的接口数量
        if self.projectmodulemodel_set.filter(id=module_id, is_delete=False):
            interface_num = self.projectmodulemodel_set.get(id=module_id).interface_num
            interface_num += n
            self.projectmodulemodel_set.filter(id=module_id).update(interface_num=interface_num)
        # 更新数据看板的接口数量
        try:
            now_date = datetime.datetime.now()
            project_display_obj = self.project_display.filter(date=now_date)
            if project_display_obj.__len__() <= 0:
                # project_display_obj = self.project_display.create(date=now_data, interface_num=1)
                ProjectDisplay.objects.create(project_id=self.id, date=now_date, total_cases=0, interface_num=n)
            else:
                project_display_obj.update(interface_num=project_display_obj.first().interface_num + n)
        except Exception:
            pass

    def addInterfaceResult(self, env_id, n=1, status=False):
        """
        用例执行情况 加 1
        :param n:
        :return:
        """
        # 更新数据看板的接口执行失败成功数量
        try:
            now_data = datetime.datetime.now()
            case_result_obj = CaseExecutionStatus.objects.filter(date=now_data, env_id=env_id, project_id=self.id)
            if case_result_obj.__len__() <= 0:
                CaseExecutionStatus.objects.create(date=now_data, env_id=env_id, project_id=self.id)
                case_result_obj = CaseExecutionStatus.objects.filter(date=now_data, env_id=env_id, project_id=self.id)
                if status == 'true':
                    case_result_obj.update(success_num=case_result_obj.first().success_num + n)
                else:
                    case_result_obj.update(fail_num=case_result_obj.first().fail_num + n)
                pass
            else:
                if status == 'true':
                    case_result_obj.update(success_num=case_result_obj.first().success_num + n)
                else:
                    case_result_obj.update(fail_num=case_result_obj.first().fail_num + n)
        except Exception as e:
            pass

    def removeInterface(self, n=1, module_id=None):
        """
        接口数 减 1
        :param n:
        :return:
        """
        # 更新模板下的接口数量
        module_query = self.projectmodulemodel_set.filter(id=module_id, is_delete=False)
        if module_query:
            interface_num = module_query.first().interface_num
            if interface_num >= n:
                interface_num -= n
                self.projectmodulemodel_set.filter(id=module_id).update(interface_num=interface_num)
            else:
                self.projectmodulemodel_set.filter(id=module_id).update(interface_num=0)

        if self.projectdata.interface_count >= n:
            self.projectdata.interface_count -= n
            self.projectdata.save()
        else:
            self.projectdata.interface_count = 0
            self.projectdata.save()

        # 更新数据看板的接口数量
        try:
            now_data = datetime.datetime.now()
            project_display_obj = self.project_display.filter(date=now_data)
            if (project_display_obj.__len__() > 0) and (project_display_obj.first().interface_num > 0):
                project_display_obj.update(interface_num=project_display_obj.first().interface_num - n)
        except Exception:
            pass

    def addModule(self, n=1):
        """
        模块数 加 1
        :param n:
        :return:
        """
        if hasattr(self, 'projectdata'):
            self.projectdata.module_count += n
            self.projectdata.save()
        else:
            ProjectDataModel.objects.create(project=self, module_count=1)

    def removeModule(self, n=1):
        """
        模块数 减 1
        :param n:
        :return:
        """
        if hasattr(self, 'projectdata'):
            if self.projectdata.module_count >= n:
                self.projectdata.module_count -= n
                self.projectdata.save()
            else:
                self.projectdata.module_count = 0
                self.projectdata.save()
        else:
            ProjectDataModel.objects.create(project=self)

    def addRunCase(self, n=1):
        """增加运行用例数"""
        try:
            now_date = datetime.datetime.now()
            project_display_obj = self.project_display.filter(date=now_date)
            if project_display_obj.__len__() > 0:
                project_display_obj.update(total_cases=project_display_obj.first().total_cases + n)
            else:
                ProjectDisplay.objects.create(project_id=self.id, date=now_date, total_cases=n, interface_num=0)
        except Exception:
            pass

class ProjectDataModel(models.Model):
    interface_count = models.IntegerField(default=0)
    module_count = models.IntegerField(default=0)
    project = models.OneToOneField(TestProjectModel, on_delete=models.CASCADE, related_name='projectdata', verbose_name='项目')

    class Meta:
        db_table = 'tb_project_data'
        verbose_name='项目数据'
        verbose_name_plural = '项目数据'


class ProjectModuleModel(BaseModel):
    module_name = models.CharField(max_length=128, verbose_name='模块名字')
    project = models.ForeignKey('TestProjectModel', on_delete=models.CASCADE, verbose_name='所属项目',null=False)
    # module_steam_id = models.IntegerField(null=True, blank=True, verbose_name='模块steam的模块id')
    interface_num = models.SmallIntegerField(default=0, null=True, blank=True, verbose_name='接口数量')

    class Meta:
        db_table = 'tb_project_module'
        verbose_name = '项目模块'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.module_name

    @transaction.atomic
    def setIsdeleteTrue(self):
        self.is_delete = True
        self.save()
        self.project.removeModule()
        # todo 优化for循环
        for i in self.interfacemodel_set.all():
            i.setIsdeleteTrue()



class ApplicationModel(BaseModel):
    name = models.CharField(max_length=128, verbose_name='应用名')
    code = models.CharField(max_length=256, null=True, blank=True, verbose_name='应用编码')
    project = models.ForeignKey(TestProjectModel, on_delete=models.CASCADE, related_name='application', verbose_name='所属项目')

    class Meta:
        db_table = 'tb_application'
        verbose_name = '应用'
        verbose_name_plural = '应用'

    def __str__(self):
        return self.name

    @transaction.atomic
    def setIsdeleteTrue(self, project_id):
        self.is_delete = True
        self.save()
        app = TestProjectModel.objects.get(id=project_id).application.filter(is_delete=False).order_by('create_time').first()
        self.interfacemodel_set.update(application=app)


class EnvModel(BaseModel):
    name = models.CharField(max_length=128, verbose_name='环境名称')
    project = models.ForeignKey(TestProjectModel, on_delete=models.CASCADE, related_name='env', verbose_name='所属项目')

    class Meta:
        db_table = 'tb_env'
        verbose_name = '环境'
        verbose_name_plural = '环境'

    def __str__(self):
        return self.name

    @transaction.atomic
    def setIsdeleteTrue(self):
        for application_app_env in self.applicationenvmodel_set.filter(is_delete=False).all():
            application_app_env.setIsdeleteTrue()
        self.is_delete = True
        self.save()


class ApplicationEnvModel(BaseModel):
    project = models.ForeignKey(TestProjectModel, related_name='app_env', on_delete=models.CASCADE, verbose_name='所属项目')
    application = models.ForeignKey(ApplicationModel, on_delete=models.CASCADE, related_name='application_env', verbose_name='应用')
    env = models.ForeignKey(EnvModel, on_delete=models.CASCADE, verbose_name='环境')
    host = models.URLField(max_length=512, verbose_name='环境地址')

    class Meta:
        db_table = 'tb_application_env'
        verbose_name = '应用环境'
        verbose_name_plural = '应用环境'

    @transaction.atomic
    def setIsdeleteTrue(self):
        self.is_delete = True
        self.save()


class ProjectDisplay(models.Model):
    """项目数据看板"""
    interface_num = models.IntegerField(default=0, verbose_name='接口数量')
    total_cases = models.IntegerField(default=0, verbose_name='运行用例数')
    date = models.DateField(auto_now_add=True)
    project = models.ForeignKey(TestProjectModel, on_delete=models.CASCADE, related_name='project_display')

    class Meta:
        db_table = 'tb_project_display'
        verbose_name = '数据看板'
        verbose_name_plural = '数据看板'


class CaseExecutionStatus(models.Model):
    """用例执行情况数据看板"""
    project_id = models.IntegerField(verbose_name='项目id')  # 不需要设置项目外键
    env = models.ForeignKey(EnvModel, on_delete=models.CASCADE, verbose_name='所属环境')
    success_num = models.IntegerField(default=0, verbose_name='用例执行成功数')
    fail_num = models.IntegerField(default=0, verbose_name='用例执行失败数')
    date = models.DateField(auto_now_add=True)

    class Meta:
        db_table = 'tb_case_status_display'
        verbose_name = '用例执行数据看板'
        verbose_name_plural = '用例执行数据看板'
