from django.contrib.auth.models import Group
from django.db.models.query_utils import Q
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import  filters, viewsets
from rest_framework.decorators import detail_route, list_route
from rest_framework.filters import OrderingFilter
from rest_framework.generics import ListAPIView, CreateAPIView, UpdateAPIView, DestroyAPIView, RetrieveAPIView
from rest_framework.response import Response
from rest_framework.status import HTTP_200_OK, HTTP_400_BAD_REQUEST
from rest_framework.views import APIView

from case_flow.models import TestTaskModel
from case_flow.serializers import FlowTreeSerializer
from interface.models import InterfaceModel
from project_caud.models import TestProjectModel, ProjectModuleModel, EnvModel, ApplicationModel, \
    ProjectDisplay, CaseExecutionStatus
from project_caud.serializers import Porjectlizer, Modulelizer, ProjectListSerializer, AllModuleListSerializer, InterfaceNumModelSerializer, RunCaseNumModelSerializer, \
    ApplicationSerializer, CaseStatusModelSerializer


from utils.operation_log import OperationLogDecorator
from django.utils.decorators import method_decorator

from utils.util import DeleteException
from logging import getLogger
from interface.models import InterfaceExecutionTimeModel
from interface.serializers import InterfaceExecutionTimeSerializer

logde = OperationLogDecorator()

logger = getLogger('log')


class Project(viewsets.ModelViewSet):
    #根据项目名称查询项目信息\新建项目
    queryset = None
    serializer_class = Porjectlizer
    filter_backends = (filters.SearchFilter,DjangoFilterBackend,OrderingFilter,)
    search_fields = ('project_name',)
    filter_fields = ('project_statu','id')
    ordering = ('-create_time',)
    # permission_classes = (AutoPlatformProjectPermission, )
    lookup_field = 'project_id'

    def get_queryset(self):
        user_obj = self.request.user
        group_obj = Group.objects.filter(user=user_obj)
        if user_obj.isSuperUser:
            return TestProjectModel.objects.filter(is_delete=False).all()
        return TestProjectModel.objects.filter(is_delete=False).filter(user_group__in=group_obj).all()

    def delete(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"delete",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""

        return Response()

    @detail_route(methods=['GET'])
    def envinfo(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"envinfo",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        self.lookup_field = 'id'
        self.kwargs['id'] = self.kwargs['project_id']
        env_info = self.get_object().getEnv
        return Response(env_info, status=HTTP_200_OK)

    @list_route(methods=['GET'])
    def projectList(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"projectList",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        # """
        # 返回项目列表，只序列化id和project_name
        # 优化响应速度
        # :param request:
        # :return:
        # """
        project_list = self.get_queryset().filter(project_statu = True).order_by('-id').values('id','project_name').all()
        serializer = ProjectListSerializer(project_list, many=True)
        return Response({'list': serializer.data}, status=HTTP_200_OK)

    @detail_route(methods=['GET'])
    def projectDisplay(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"projectDisplay",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        # """项目数据看板"""
        project_id = self.kwargs.get('project_id')
        self.lookup_field = 'id'
        self.kwargs['id'] = self.kwargs['project_id']
        # 接口数
        interface_sum = InterfaceModel.objects.filter(is_delete=False, module__project=project_id).count()
        # project_obj = TestProjectModel.objects.get(id=project_id)
        # interface_sum = project_obj.projectdata.interface_count if hasattr(project_obj,'projectdata') else 0
        # 接口下->总用例数 （用例， 场景， 聚合）
        test_query_obj = TestTaskModel.objects.filter(is_delete=False, project__id=project_id)
        sum_case = test_query_obj.count()
        # 用例 case_type = 1
        case_num = test_query_obj.filter(case_type=1).count()
        # 场景
        scene_num = test_query_obj.filter(case_type=2).count()
        # 聚合
        aggregation_num = test_query_obj.filter(case_type=3).count()
        data = {}
        # 饼图信息
        PiechartInfo = {
            "project_id": project_id,
            "interface_sum": interface_sum,
            "sum_case": sum_case,
            "case_num": case_num,
            "scene_num": scene_num,
            "aggregation_num": aggregation_num
        }
        data["PiechartInfo"] = PiechartInfo
        # 日接口数量
        # interface_num = InterfaceNumModel.objects.filter(project_id=project_id).all()
        # interface_num = interface_num.order_by('interface_date')
        # update 改用数据看板表
        interface_num = ProjectDisplay.objects.filter(project_id=project_id).all()
        interface_num = interface_num.order_by('date')
        inter_num_serializer = InterfaceNumModelSerializer(interface_num, many=True)
        data["InterfaceNum"] = inter_num_serializer.data
        # 日运行用例数
        # runcase_num = RunCaseNumModel.objects.filter(project_id=project_id).all()
        # runcase_num = runcase_num.order_by('case_date')
        # update 改用数据看板表
        runcase_num = ProjectDisplay.objects.filter(project_id=project_id).all()
        runcase_num = runcase_num.order_by('date')
        runcase_num_serializer = RunCaseNumModelSerializer(runcase_num, many=True)
        data["RunCaseNum"] = runcase_num_serializer.data
        # # -----------------------------权限控制-------------------------------------
        # user_obj = request.user
        # user_group_obj_set = Group.objects.filter(user=user_obj)
        # if user_obj.isSuperUser:
        #     project_obj = TestProjectModel.objects.get(id=project_id)
        # else:
        #     project_obj = TestProjectModel.objects.filter(
        #         Q(id=project_id) & Q(Q(user_group__in=user_group_obj_set) | Q(project_lead=user_obj))).first()
        # if not project_obj:
        #     return Response({'message': '无该项目权限', 'code': 400}, status=403)
        # # -----------------------------权限控制-------------------------------------
        # return Response(data=data, status=HTTP_200_OK)

        #　接口运行时间
        env_obj = EnvModel.objects.filter(project_id=project_id, is_delete=False)  # 当前环境
        data["interface_execution_time"] = []#{"env_name":[], "data":[]}
        data["case_status"] = []
        for env in env_obj:
            interface_execution_time = InterfaceExecutionTimeModel.objects.filter(project_id=project_id, env_id=env.id,
                                                                                  is_delete=False).all().order_by(
                '-execution_time')
            interface_execution_time = interface_execution_time[0:10]  # 取执行时间最长的前10个
            interface_execution_time_serializer = InterfaceExecutionTimeSerializer(interface_execution_time, many=True)
            # data["interface_execution_time"] = interface_execution_time_serializer.data
            interface_name_list = list()
            execution_time_list = list()
            for interface_execution_time in interface_execution_time_serializer.data:
                interface_name_list.append(interface_execution_time["interface_name"])
                execution_time_list.append(interface_execution_time["execution_time"])
            # data["interface_execution_time"]['env_name'].append(env.name)
            # data["interface_execution_time"]["data"].append({"interface_name_list": interface_name_list,
            #                                          "execution_time_list": execution_time_list})
            data["interface_execution_time"].append({"env_name": env.name, "env_id": env.id, "interface_name_list": interface_name_list,
                                                     "execution_time_list": execution_time_list})
            # 用例执行成功和失败的数据
            case_obj = CaseExecutionStatus.objects.filter(project_id=project_id, env_id=env.id)
            serializer = CaseStatusModelSerializer(case_obj, many=True)
            data["case_status"].append({"env_name": env.name, "env_id": env.id, "case_list": serializer.data})

        return Response(data=data, status=HTTP_200_OK)

    @detail_route(methods=['GET'])
    def displayPiechart(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"displayPiechart",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        # """项目数据看板-饼图信息"""
        self.lookup_field = 'id'
        self.kwargs['id'] = self.kwargs['project_id']
        project_id = self.kwargs.get('project_id')
        # 接口数
        interface_sum = InterfaceModel.objects.filter(is_delete=False, module__project=project_id).count()
        # 接口下->总用例数 （用例， 场景， 聚合）
        test_query_obj = TestTaskModel.objects.filter(is_delete=False, project__id=project_id)
        sum_case = test_query_obj.count()
        # 用例 case_type = 1
        case_num = test_query_obj.filter(case_type=1).count()
        # 场景
        scene_num = test_query_obj.filter(case_type=2).count()
        # 聚合
        aggregation_num = test_query_obj.filter(case_type=3).count()
        data = {}
        # 饼图信息
        PiechartInfo = {
            "project_id": project_id,
            "interface_sum": interface_sum,
            "sum_case": sum_case,
            "case_num": case_num,
            "scene_num": scene_num,
            "aggregation_num": aggregation_num
        }
        return Response(data=PiechartInfo, status=HTTP_200_OK)

    @detail_route(methods=['GET'])
    def displayInterfaceNum(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"displayInterfaceNum",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""

        self.lookup_field = 'id'
        self.kwargs['id'] = self.kwargs['project_id']
        project_id = self.kwargs['project_id']
        # 接口数
        # 接口下->总用例数 （用例， 场景， 聚合）
        interface_num = ProjectDisplay.objects.filter(project_id=project_id).all()
        interface_num = interface_num.order_by('date')
        inter_num_serializer = InterfaceNumModelSerializer(interface_num, many=True)
        data= inter_num_serializer.data
        return Response(data=data, status=HTTP_200_OK)

    @detail_route(methods=['GET'])
    def displayRunCaseNum(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"displayRunCaseNum",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        # """项目数据看板--日运行用例数"""
        # project_id = self.kwargs.get('project_id')
        self.lookup_field = 'id'
        self.kwargs['id'] = self.kwargs['project_id']
        project_id = self.kwargs['project_id']
        # 日运行用例数
        # update 改用数据看板表
        runcase_num = ProjectDisplay.objects.filter(project_id=project_id).all()
        runcase_num = runcase_num.order_by('date')
        runcase_num_serializer = RunCaseNumModelSerializer(runcase_num, many=True)
        data = runcase_num_serializer.data
        return Response(data=data, status=HTTP_200_OK)

    @detail_route(methods=['GET'])
    def displayRunTime(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"displayRunTime",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        self.lookup_field = 'id'
        self.kwargs['id'] = self.kwargs['project_id']
        project_id = self.kwargs['project_id']
        # 　接口运行时间
        env_obj = EnvModel.objects.filter(project_id=project_id, is_delete=False)  # 当前环境
        data = []  # {"env_name":[], "data":[]}
        for env in env_obj:
            interface_execution_time = InterfaceExecutionTimeModel.objects.filter(project_id=project_id, env_id=env.id,
                                                                                  is_delete=False).all().order_by(
                '-execution_time')
            interface_execution_time = interface_execution_time[0:10]  # 取执行时间最长的前10个
            interface_execution_time_serializer = InterfaceExecutionTimeSerializer(interface_execution_time, many=True)
            # data["interface_execution_time"] = interface_execution_time_serializer.data
            interface_name_list = list()
            execution_time_list = list()
            report_id_list = list()
            for interface_execution_time in interface_execution_time_serializer.data:
                interface_name_list.append(interface_execution_time["interface_name"])
                execution_time_list.append(interface_execution_time["execution_time"])
                report_id_list.append(interface_execution_time['report'])
            # data["interface_execution_time"]['env_name'].append(env.name)
            # data["interface_execution_time"]["data"].append({"interface_name_list": interface_name_list,
            #                                          "execution_time_list": execution_time_list})
            data.append({"env_name": env.name, "env_id": env.id, "interface_name_list": interface_name_list,
                                                     "execution_time_list": execution_time_list, "report_id_list": report_id_list})
        return Response(data=data, status=HTTP_200_OK)

    @detail_route(methods=['GET'])
    def displayCaseStatus(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"displayCaseStatus",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""

        self.lookup_field = 'id'
        self.kwargs['id'] = self.kwargs['project_id']
        project_id = self.kwargs['project_id']
        env_obj = EnvModel.objects.filter(project_id=project_id, is_delete=False)  # 当前环境
        data = []
        for env in env_obj:
            # 用例执行成功和失败的数据
            case_obj = CaseExecutionStatus.objects.filter(project_id=project_id, env_id=env.id)
            serializer = CaseStatusModelSerializer(case_obj, many=True)
            data.append({"env_name": env.name, "env_id": env.id, "case_list": serializer.data})
        return Response(data=data, status=HTTP_200_OK)

    @detail_route(methods=['get'])
    def flowinfo(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"flowinfo",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        self.lookup_field = 'id'
        self.kwargs['id'] = self.kwargs['project_id']
        try:
            # project_obj = TestProjectModel.objects.get(id=self.kwargs.get('project_id'))
            project_obj = TestProjectModel.objects.get(id=self.get_object().id)
        except Exception as e:
            return Response({'code': 404,'message':'project is not Found'})
        else:
            if not hasattr(project_obj,'flowtree'):
                return Response({'code':404,'message':'flow is not Found'})
        flow_obj = project_obj.flowtree
        serializer = FlowTreeSerializer(flow_obj)
        return Response({'message': 'ok', 'data': serializer.data}, status=HTTP_200_OK)

    @list_route(methods=['GET'])
    def checkprojectname(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"checkprojectname",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""

        project_name = request.query_params.get('project_name', None)
        if project_name is None:
            return Response('项目名不能为空')
        if TestProjectModel.objects.filter(project_name=project_name).exists():
            return Response({'status': False}, status=HTTP_200_OK)
        else:
            return Response({'status': True}, status=HTTP_200_OK)

    @detail_route(methods=['GET'])
    def projectmodule(self,  request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"projectmodule",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""

        self.lookup_field = 'id'
        self.kwargs['id'] = self.kwargs['project_id']
        project_id = self.kwargs['project_id']
        if project_id is None :
            return Response({'list':[]}, status=HTTP_200_OK)
        else:
            project_obj = self.get_queryset().get(id=project_id)
            project_module_set = project_obj.projectmodulemodel_set.filter(is_delete=False).order_by('-create_time')
            serializer = AllModuleListSerializer(project_module_set, many=True)
            return Response({'list': serializer.data}, status=HTTP_200_OK)

    @method_decorator(logde.project_update)
    def partial_update(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"partial_update",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        self.lookup_field = 'id'
        self.kwargs['id'] = self.kwargs['project_id']
        return super().partial_update(request, *args, **kwargs)

    @detail_route(methods=['GET'])
    def defaultLogin(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"defaultLogin",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        self.lookup_field = 'id'
        self.kwargs['id'] = self.kwargs['project_id']
        project_obj = self.get_object()
        default_login, msg = project_obj.check_default_login()
        return Response({'login': default_login, 'message': msg}, status=HTTP_200_OK)

    @detail_route(methods=['GET'])
    def application(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"application",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        self.lookup_field = 'id'
        self.kwargs['id'] = self.kwargs['project_id']
        project_obj = self.get_object()
        application_set = project_obj.application.filter(is_delete=False).all()
        serializer = ApplicationSerializer(application_set, many=True)
        return Response({'list':serializer.data}, status=HTTP_200_OK)

    def retrieve(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"retrieve",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        self.lookup_field = 'id'
        self.kwargs['id'] = self.kwargs['project_id']
        return super().retrieve(request, *args, **kwargs)

    def list(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"list",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        self.serializer_class = Porjectlizer
        queryset = self.filter_queryset(self.get_queryset())
        serializer = self.get_serializer(queryset.values('id', 'name'), many=True)
        return Response({'list': serializer.data})

    def update(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"update",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        self.lookup_field = 'id'
        self.kwargs['id'] = self.kwargs['project_id']
        return super().update(request, *args, **kwargs)

    def create(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"create",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        return Response({"message": "不能新建项目"}, status=403)

    def destroy(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"destroy",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        self.lookup_field = 'id'
        self.kwargs['id'] = self.kwargs['project_id']
        return Response({"message": "不能删除项目"}, status=403)


class ProjectModule(CreateAPIView,ListAPIView,RetrieveAPIView):
    queryset = None
    serializer_class = Modulelizer
    filter_backends = [filters.SearchFilter,OrderingFilter,DjangoFilterBackend]
    search_fields = ('module_name',)
    filter_fields = ('module_name','project_id')
    ordering = ('-create_time',)
    # permission_classes = (AutoPlatformPermission,)
    # pagination_class = None    # 关闭分页

    def get_queryset(self):
        user_obj = self.request.user
        group_obj = Group.objects.filter(user=user_obj)
        try:
            project_id = self.kwargs['project_id']
            if user_obj.isSuperUser:
                return ProjectModuleModel.objects.filter(is_delete=False, project__project_statu=True).filter(project__id=project_id)
            return ProjectModuleModel.objects.filter(is_delete=False, project__project_statu=True).filter(Q(project__id=project_id) & Q(Q(project__user_group__in=group_obj)))
        except Exception as e:
            return ProjectModuleModel.objects.none()

    def get(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"get",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        return super().get(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"post",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        return super().post(request, *args, **kwargs)


class ProjectModuleFilter(APIView):
    """模块接口数筛选"""
    def get(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"get",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        try:
            user_obj = self.request.user
            group_obj = Group.objects.filter(user=user_obj)
            project_id = self.kwargs.get('project_id')
            query_set = ProjectModuleModel.objects.filter(is_delete=False, project__project_statu=True)
            if user_obj.isSuperUser:
                query_set = query_set.filter(project__id=project_id)
            else:
                query_set = query_set.filter(
                    Q(project__id=project_id) & Q(Q(project__user_group__in=group_obj)))
            if not query_set:
                return Response({'list': []}, status=HTTP_200_OK)
            else:
                interface_name = request.query_params.get('interface_name')
                app_id = request.query_params.get('app_id')
                module_id = request.query_params.get('module_id')
                module_id_all = dict()
                module_id_list = list()
                if interface_name or app_id:
                    interface_query = InterfaceModel.objects.filter(module__project_id=project_id, is_delete=False)
                    if interface_name:
                        interface_query = interface_query.filter(name__icontains=interface_name)
                    if app_id:
                        interface_query = interface_query.filter(application_id=app_id)
                    from collections import Counter
                    module_id_all = Counter(interface_query.values_list('module_id', flat=True))
                    module_id_list = module_id_all.keys()
                    if not module_id_list:
                        return Response({'list': []}, status=HTTP_200_OK)

                if module_id:
                    query_set = query_set.filter(id=module_id)
                elif module_id_list:
                    query_set = query_set.filter(id__in=module_id_list)

                query_set = query_set.order_by('-create_time')
                new_query_set = list()
                if module_id_all:
                    for module_obj in query_set:
                        module_dict = dict()
                        module_dict["id"] = module_obj.id
                        module_dict["module_name"] = module_obj.module_name
                        module_dict["project"] = module_obj.project_id
                        module_dict["interface_num"] = module_id_all[module_obj.id]
                        module_dict["show"] = False
                        new_query_set.append(module_dict)
                    return Response({'list': new_query_set}, status=HTTP_200_OK)
                else:
                    serializer = Modulelizer(query_set, many=True)
                    return Response({'list': serializer.data}, status=HTTP_200_OK)
        except Exception as e:
            logger.error("ProjectModuleFilter error; request={}, error_msg={}".format(request.query_params, e))
            return Response({'list': []}, status=HTTP_200_OK)


class ProjectModuleupdate(UpdateAPIView,DestroyAPIView,RetrieveAPIView):
    queryset = None
    serializer_class = Modulelizer
    # permission_classes = (AutoPlatformPermission,)

    def get_queryset(self):
        user_obj = self.request.user
        group_obj = Group.objects.filter(user=user_obj)
        try:
            project_id = self.kwargs.get('project_id')
            if user_obj.isSuperUser:
                return ProjectModuleModel.objects.filter(is_delete=False, project__project_statu=True).filter(project__id=project_id)
            return ProjectModuleModel.objects.filter(is_delete=False, project__project_statu=True).filter(
                Q(project__id=project_id) & Q(project__user_group__in=group_obj))
        except Exception as e:
            return ProjectModuleModel.objects.none()

    def delete(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"delete",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        obj =self.get_object()
        obj.setIsdeleteTrue()
        return Response("Delet Success")

    def put(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"put",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        return super().put(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"patch",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        return super().patch(request, *args, **kwargs)

    def get(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"get",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        return super().get(request, *args, **kwargs)


class ApplicationDestroyAPIView(DestroyAPIView):
    queryset = None
    # permission_classes = []
    # authentication_classes = []

    def get_queryset(self):
        return ApplicationModel.objects.filter(is_delete=False).all()

    def destroy(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"destroy",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        result = self.perform_destroy(self.get_object())
        if result[0] == False:
            return Response({'message': result[1]}, status=HTTP_400_BAD_REQUEST)
        return Response({'message': '删除成功'}, status=HTTP_200_OK)

    def perform_destroy(self, instance):
        project_id = self.kwargs.get('project_id')
        try:
            instance.setIsdeleteTrue(project_id=project_id)
            instance.application_env.all().update(is_delete=True)
        except DeleteException as e:
            return False, e.message
        return True, None

    def delete(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"delete",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        return super().delete(request, *args, **kwargs)


class EnvDestroyAPIview(DestroyAPIView):
    queryset = None

    def get_queryset(self):
        return EnvModel.objects.filter(is_delete=False).all()

    def destroy(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"destroy",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        result = self.perform_destroy(self.get_object())
        if result[0] == False:
            return Response({'message':result[1]}, status=HTTP_400_BAD_REQUEST)
        return Response({'message':'删除成功'}, status=HTTP_200_OK)

    def perform_destroy(self, instance):
        try:
            if self.get_queryset().filter(project_id=instance.project_id, is_delete=False).all().__len__() <= 1:
                return False, '至少保留一个环境'
            instance.setIsdeleteTrue()
        except DeleteException as e:
            return False, e.message
        return True, None

    def delete(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"delete",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        return super().delete(request, *args, **kwargs)
