import json

from django.contrib.auth.models import Group
from django.db import transaction
from django.db.models import Count
from rest_framework import serializers
from rest_framework.validators import UniqueValidator

from automate_test_py3 import settings
from project_caud.models import TestProjectModel, ProjectModuleModel, SteamProject, ApplicationEnvModel, \
    ApplicationModel, ProjectDisplay, CaseExecutionStatus
from project_caud.mysqlview import InterfaceNumModel, RunCaseNumModel
from user.models import UserModel
from user.serializers import UserSerializer, GroupSerializer, UserListSerializer
from utils.serializer import ZJsonField, ProjectLeadField, AppcalitionEnvSerializer


class ProjectListSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField()
    project_name = serializers.CharField( label='项目名称', required=True)
    # project_name = serializers.CharField( label='项目名称', required=True,validators=[UniqueValidator(queryset=TestProjectModel.objects.all())])
    # name = serializers.CharField(source='project_name', label='项目名称', required=True)
    # project_lead = ProjectLeadField(source='getProjectLead')
    # user_group = GroupSerializer(read_only=True)
    # project_urls = ZJsonField(label='域名url', required=True)
    # project_header_infos = ZJsonField(label='头域信息', default=[])

    class Meta:
        model=TestProjectModel
        fields = ('id','project_name')


class ProjectSerializer(serializers.ModelSerializer):

    class Meta:
        model = TestProjectModel
        fields = ('project_name', 'id', 'project_code')


class ImportProjectSerializer(serializers.ModelSerializer):
    """
    行云项目 检验
    """
    projectId = serializers.IntegerField(source='id', required=True)
    projectCode = serializers.CharField(source='code', required=True)
    projectName = serializers.CharField(source='name', required=True)
    class Meta:
        model=SteamProject
        fields=('projectName', 'projectId', 'projectCode')

class ApplicationEnv(serializers.ModelSerializer):
    env = serializers.ReadOnlyField(source='getEnv')

    class Meta:
        model = ApplicationEnvModel
        fields = ('id', 'env')


class Porjectlizer(serializers.ModelSerializer):
    #必填参数验证
    project_name = serializers.ReadOnlyField(label='项目名称')
    # project_name = serializers.CharField( label='项目名称', required=True,validators=[UniqueValidator(queryset=TestProjectModel.objects.all())])
    # name = serializers.CharField(source='project_name', label='项目名称', required=True)
    # project_lead = ProjectLeadField(source='getProjectLead')
    # user_group = GroupSerializer(read_only=True)
    mudle_count = serializers.ReadOnlyField(source='getModuleCount')
    interface_count = serializers.ReadOnlyField(source='getInterfaceCount')
    project_urls = ZJsonField(label='域名url', required=True)
    project_header_infos = ZJsonField(label='头域信息', default=[])
    app_env = AppcalitionEnvSerializer(source='getEnv')

    def validate_project_urls(self, project_urls):
        for i in json.loads(project_urls):
            if i['env_host'][0:4] != 'http':
                raise serializers.ValidationError('环境必须以http开头')
        return project_urls

    def validate_project_statu(self, project_statu):
        if self.context['request'].user.is_superuser and self.context['request'].user.is_active:
            return project_statu
        else:
            raise serializers.ValidationError('非管理员不能修改项目状态')

    def validate_project_lead(self, lead):
        if not self.context['request'].user.isSuperUser:
            return None
        return lead

    def validate_app_env(self, app_env):
        return app_env

    class Meta:
        # 指定序列化模型
        model=TestProjectModel
        # 指定序列化字段
        fields = ('id','project_name', 'project_header_infos',
                  'project_urls','project_statu','mudle_count', 'interface_count', 'app_env')

    @transaction.atomic
    def create(self, validated_data):
        instance = super().create(validated_data)
        user_group = instance.createProjectGroup()
        instance.user_group = user_group
        instance.save()
        if validated_data.get('getProjectLead', None):
            project_lead = validated_data['getProjectLead']
            instance.setProjectLead(project_lead)
        return instance

    # @transaction.atomic
    def update(self, instance, validated_data):
        instance = super().update(instance, validated_data)
        if validated_data.get('getProjectLead'):
            project_lead = validated_data['getProjectLead']
            instance.setProjectLead(project_lead)
        return instance


class Modulelizer(serializers.ModelSerializer):
    # project_name = serializers.ReadOnlyField(source='project.project_name')
    show = serializers.ReadOnlyField(default=False)     # 前端附加字段

    class Meta:
        model=ProjectModuleModel
        # fields= ('id', 'module_name', 'project', "project_name", 'interface_num')
        fields= ('id', 'module_name', 'project', 'interface_num', 'show')

    def validate(self, attrs):
        show_value = attrs.get('show')
        if (show_value is False) or show_value:
            attrs.pop('show')
        return attrs

    def create(self, validated_data):
        obj = super().create(validated_data)
        obj.project.addModule()
        return obj


class ProjectModulelizer(serializers.ModelSerializer):

    projectmodulemodel_set = serializers.StringRelatedField(many=True, read_only=True,)
    class Meta:
        model=TestProjectModel
        fields= ('id','create_time','update_time','project_name','projectmodulemodel_set')


class ModuleListSerializer(serializers.ModelSerializer):

    class Meta:
        model=ProjectModuleModel
        fields = ('id', 'module_name')


class AllModuleListSerializer(serializers.ModelSerializer):

    class Meta:
        model=ProjectModuleModel
        fields = ('id', 'module_name')


class InterfaceNumModelSerializer(serializers.ModelSerializer):
    interface_date = serializers.ReadOnlyField(source='date')

    class Meta:
        # model = InterfaceNumModel
        # fields = ('interface_num', 'interface_date')
        model = ProjectDisplay
        fields = ('interface_num', 'interface_date')


class CaseStatusModelSerializer(serializers.ModelSerializer):
    case_date = serializers.ReadOnlyField(source='date')

    class Meta:
        # model = InterfaceNumModel
        # fields = ('interface_num', 'interface_date')
        model = CaseExecutionStatus
        fields = ('case_date', 'success_num', 'fail_num')


class RunCaseNumModelSerializer(serializers.ModelSerializer):
    case_date = serializers.ReadOnlyField(source='date')
    class Meta:
        # model = RunCaseNumModel
        # fields = ('total_cases', 'case_date')
        model = ProjectDisplay
        fields = ('total_cases', 'case_date')


class ApplicationSerializer(serializers.ModelSerializer):

    class Meta:
        model = ApplicationModel
        fields = ('name', 'id')



class CiDataSerializer(serializers.Serializer):
    data = serializers.CharField()

    def validate(self, attrs):
        data = attrs['data']
        from utils.md5_base64_aes import EncryptionAndDecryption
        try:
            # 密文不能超过1024 bity  在生成秘钥时已定义 不能超过此范围  这个和秘钥有关
            descryobj = EncryptionAndDecryption(mode=3, content='', operation=1, SECRET_KEY=settings.SECRET_KEY)
            text = descryobj.rsa_long_decrypt(data=data)
            return text
        except Exception as e:
            raise serializers.ValidationError({"message": "解密失败"})