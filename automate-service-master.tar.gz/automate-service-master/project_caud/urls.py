from django.conf.urls import url, include
from rest_framework import routers

from project_caud import views

router = routers.DefaultRouter(trailing_slash=False)
router.register(r'projects', views.Project, base_name='projects')

urlpatterns = [
   url(r'^projects/(?P<project_id>\d+)/app/(?P<pk>\d+)$', views.ApplicationDestroyAPIView.as_view()),
   url(r'^projects/(?P<project_id>\d+)/module$',views.ProjectModule.as_view()),
   url(r'^projects/(?P<project_id>\d+)/moduleFilter$',views.ProjectModuleFilter.as_view()),
   url(r'^projects/(?P<project_id>\d+)/module/(?P<pk>\d+)$',views.ProjectModuleupdate.as_view()),
   url(r'^projects/(?P<project_id>\d+)/env/(?P<pk>\d+)$',views.EnvDestroyAPIview.as_view()),
   url(r'^', include(router.urls))
   ]
