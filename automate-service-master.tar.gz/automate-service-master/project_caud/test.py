import os
from collections import OrderedDict




def main():
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "automate_test_py3.settings")
    import django
    django.setup()
    from project_caud.models import TestProjectModel
    TestProjectModel.objects.importProject(project_name='ccc',
                                           project_code='111',
                                           project_steam_id=333
                                           )


def fun12():

    pass


if __name__ == '__main__':
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "automate_test_py3.settings")
    import django
    django.setup()
    from utils.md5_base64_aes import EncryptionAndDecryption
    from automate_test_py3 import settings
    obj = EncryptionAndDecryption(SECRET_KEY=settings.SECRET_KEY, mode=3, operation=0,content='')
    pkeyfile = obj.generatPrivateKey()
    obj.savePrivateKey(file_path=os.path.join(settings.PEM_FILE_PATH, 'private_key.pem'))
    bkeyfile = obj.generatPubliKey()
    text = obj.rsa_long_encrypt(data="hahahah")
    print('first----',obj.decryptData(data=text))
    obj.SECRET_KEY = obj.random
    print('last----',obj.decryptData(data=text))


    obj.savePubliKey(file_path=os.path.join(settings.PEM_FILE_PATH, 'public_key.pem'))
    # sidata = '''# pkeyfile = obj.generatPrivateKey()
    # obj.savePrivateKey()
    # bkeyfile = obj.generatPubliKey()
    # obj.saePubliKey()'''
    #
    # obj.rsa_long_encrypt()
    # data = "SVw2vMnmOescYzCYhefwmdPlbUBQBZg63CZS+WOVVtnUL35m2zYiUWvUu9//cBFgwTsxxijuuFi+oXykeXo3j0UubYuyS+mxf9veBBodNRk901OP3wtIsLS25n828ibxrXNUdBhE6KbmDr6R1gvusMZSQWBPuDlVU/9ZB3KVP9A="
    # text = obj.rsa_long_decrypt(data=data, private_key_file_path=os.path.join(settings.BASE_DIR,'utils/pem/pro/private_key.pem'))
    # print(text.decode('utf-8'))
    # from project_caud.models import TestProjectModel
    # pro = TestProjectModel.objects.get(id=1)
    # env_list = []
    #
    # app_env_set = pro.app_env.all()
    # env_category_set = app_env_set.values('env__name', 'env_id').distinct()
    # for env_obj in env_category_set:
    #     env = OrderedDict()
    #     app_env_set.filter(env__name=env_obj['env__name']).select_related('env__name')
    #     env['env_name'] = env_obj['env__name']
    #     env['env_id'] = env_obj['env_id']
    #     env['app_set'] = [{'app_id':app_env.application.id,'app_name':app_env.application.name,'host': app_env.host}  for app_env in app_env_set.filter(env__name=env_obj['env__name'])]
    #     env_list.append(env)
    # for i in env_list:
    #     print(i)
    from utils.runcore import CaseDump
    obj  = CaseDump()
    obj.update_case_json_file('/home/python/Desktop/123')



