import json
from colorlog.logging import getLogger
from case_flow.models import TestTaskModel
from case_flow.tasks import runTestTask_task
from result_report.models import ResultReportModel
from automate_test_py3 import settings
from utils.runcore import CaseDump

# 接入项目同步创建事务 2020-1-7 klt
from django.db import transaction
from project_caud.serializers import ImportProjectSerializer, ProjectSerializer
from user.models import UserModel
from rest_framework.response import Response
from rest_framework.status import HTTP_200_OK, HTTP_201_CREATED, HTTP_400_BAD_REQUEST
from rest_framework.views import APIView
from project_caud.models import TestProjectModel
debuglog = getLogger('log')


class ImportProjectAPIView(APIView):
    authentication_classes = []
    permission_classes = []
    queryset = None
    serializer_class = ImportProjectSerializer

    def get_queryset(self):
        return TestProjectModel.objects.all()

    @transaction.atomic
    def post(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"post",
            "menuLevel":null,
            "permissionLevel":null,
            "roles":[

            ],
            "permissionLogin":false,
            "permissionPublic":false,
            "permissionWithin":true
        },
        "label":null
        }"""
        project_data = request.data
        debuglog.info('post-project--创建项目-{}'.format(project_data))
        TestProjectModel.objects.importProject(
            id=project_data['projectId'],
            name=project_data['projectName'],
            code=project_data['projectCode'],
            username=project_data['userName'],
            user_id=project_data['userId'],
        )
        return Response({'message': '导入项目成功', 'data': project_data}, status=HTTP_201_CREATED)

    @transaction.atomic
    def put(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"put",
            "menuLevel":null,
            "permissionLevel":null,
            "roles":[

            ],
            "permissionLogin":false,
            "permissionPublic":false,
            "permissionWithin":true
        },
        "label":null
        }"""
        project_data_ = request.data
        debuglog.info('update-project--更新项目-{}'.format(project_data_))
        try:
            project_obj = TestProjectModel.objects.get(
                id=project_data_['projectId']
            )
        except TestProjectModel.DoesNotExist as e:
            debuglog.exception(e)
            return Response({'message': '项目不存在'}, status=HTTP_400_BAD_REQUEST)
        project_obj.name = project_data_['projectName']
        project_obj.code= project_data_['projectCode']
        project_obj.save()
        return Response({'message': '更新成功', 'data': project_data_}, status=HTTP_200_OK)


class ProjectGroupAPIView(APIView):
    authentication_classes = []
    permission_classes = []

    @transaction.atomic
    def post(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"post",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":false,
            "permissionPublic":false,
            "permissionWithin":true
        },
        "label":null
        }"""
        project_group_data_ = request.data
        debuglog.info('post--group--添加项目-{}'.format(project_group_data_))
        for user in project_group_data_:
            if user.get('resourceType') == 'project':
                try:
                    project_obj = TestProjectModel.objects.get(id=user.get('resourceId'), is_delete=False)
                except TestProjectModel.DoesNotExist as e:
                    debuglog.exception(e)
                    return Response({'message': '项目不存在', "data": project_group_data_}, status=HTTP_400_BAD_REQUEST)
                else:
                    try:
                        user_obj = UserModel.objects.get(choerodon_id=user.get('userId'))
                    except UserModel.DoesNotExist as e:
                        debuglog.exception(e)
                        user_obj = UserModel.objects.create(choerodon_id=user.get('userId'), username=user.get('username'))
                    project_obj.addProjectUser(user_obj)
        return Response({'message': '成功加入项目组',"data": project_group_data_}, status=HTTP_201_CREATED)

    @transaction.atomic
    def put(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"put",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":false,
            "permissionPublic":false,
            "permissionWithin":true
        },
        "label":null
        }"""
        project_group_data_ = request.data
        debuglog.info('delete--group-删除项目成员--{}'.format(project_group_data_))
        for user in project_group_data_:
            if user.get('resourceType') == 'project':
                try:
                    project_obj = TestProjectModel.objects.get(id=user.get('resourceId'), is_delete=False)
                except TestProjectModel.DoesNotExist as e:
                    debuglog.exception(e)
                else:
                    try:
                        user_obj = UserModel.objects.get(choerodon_id=user.get('userId'))
                    except UserModel.DoesNotExist as e:
                        debuglog.exception(e)
                        user_obj = UserModel.objects.create(choerodon_id=user.get('userId'), username=user.get('username'))
                    # 从项目中移除该名用户，不管是项目管理员还是项目成员
                    project_obj.removeUser(user_obj)
        return Response({"message": "已删除", "data": project_group_data_}, status=HTTP_200_OK)


class ClosedAPIView(APIView):
    authentication_classes = []
    permission_classes = []

    @transaction.atomic
    def post(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"post",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":false,
            "permissionPublic":false,
            "permissionWithin":true
        },
        "label":null
        }"""
        project_data = request.data
        debuglog.info('stop--project--禁用项目{}'.format(project_data))
        pk = project_data.get('projectId')
        try:
            TestProjectModel.objects.get(id=pk).stop()
        except TestProjectModel.DoesNotExist as e:
            debuglog.exception(e)
            return Response({'message': '冇找到项目', "data": project_data}, status=HTTP_400_BAD_REQUEST)
        else:
            return Response({'message': '已禁用项目', "data": project_data}, status=HTTP_200_OK)


class ReopenAPIView(APIView):
    authentication_classes = []
    permission_classes = []

    @transaction.atomic
    def post(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"post",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":false,
            "permissionPublic":false,
            "permissionWithin":true
        },
        "label":null
        }"""
        project_data = request.data
        debuglog.info('reopen--project--重新启用项目-{}'.format(project_data))
        pk = project_data.get('projectId')
        try:
            TestProjectModel.objects.get(id=pk).reopen()
        except TestProjectModel.DoesNotExist as e:
            debuglog.exception(e)
            return Response({'message': '冇找到项目', "data": project_data}, status=HTTP_400_BAD_REQUEST)
        else:
            return Response({'message': '已启用项目', "data": project_data}, status=HTTP_200_OK)

# class ImportProjectAPIView(APIView):
#     permission_classes = []
#
#     @transaction.atomic
#     def post(self, request):
#         project_data = request.data.get('data')
#         print(project_data)
#         from utils.md5_base64_aes import EncryptionAndDecryption
#         try:
#             # 密文不能超过1024bity  在生成秘钥时已定义 不能超过此范围
#             descryobj = EncryptionAndDecryption(mode=3, content='', operation=1, SECRET_KEY=settings.SECRET_KEY)
#             text = descryobj.rsa_long_decrypt(data=project_data)
#         except Exception as e:
#             print('encodeing')
#             return Response({"message": "解密失败"}, status=HTTP_400_BAD_REQUEST)
#         project_obj = json.loads(text.decode('utf-8'))
#         print(project_obj)
#         # project_obj = project_data
#         serializer = ImportProjectSerializer(data=project_obj)
#         serializer.is_valid(raise_exception=True)
#
#         TestProjectModel.objects.importProject(
#             id=serializer.validated_data['id'],
#             name=serializer.validated_data['name'],
#             code=serializer.validated_data['code'],
#             username=project_obj['userName'],
#             user_id=project_obj['userId'],
#         )
#
#         return Response({'message': '导入项目成功'}, status=HTTP_201_CREATED)
#
#     @transaction.atomic
#     def patch(self, request):
#         project_data_ = request.data.get('data')
#         from utils.md5_base64_aes import EncryptionAndDecryption
#         try:
#             # 密文不能超过8192 bity  在生成秘钥时已定义 不能超过此范围
#             descryobj = EncryptionAndDecryption(mode=3, content='', operation=1, SECRET_KEY=settings.SECRET_KEY)
#             project_data = descryobj.rsa_long_decrypt(data=project_data_)
#         except Exception as e:
#             return Response({"message": "解密失败"}, status=HTTP_400_BAD_REQUEST)
#         project_data = json.loads(project_data.decode('utf-8'))
#         print('项目数据-----',project_data)
#         try:
#             project_obj = TestProjectModel.objects.get(
#                 id=project_data['projectId']
#             )
#         except TestProjectModel.DoesNotExist:
#             return Response({'message': '项目不存在'}, status=HTTP_400_BAD_REQUEST)
#         project_obj.project_name = project_data['projectName']
#         project_obj.project_code= project_data['projectCode']
#         project_obj.save()
#         return Response({'message': '更新成功'}, status=HTTP_200_OK)
#
#     def get(self, request):
#         data_content = '{"projectId": 33,"projectCode": "kyle","projectName": "irving"}'
#         from utils.md5_base64_aes import EncryptionAndDecryption
#         descryobj = EncryptionAndDecryption(mode=3, content='', operation=0, SECRET_KEY=settings.SECRET_KEY)
#         text = descryobj.rsa_long_encrypt(data=data_content)
#         print(text.decode('utf-8'))
#         return Response({'message': text.decode('utf-8')}, status=HTTP_200_OK)


# class ProjectGroupAPIView(APIView):
#     permission_classes = []
#
#     @transaction.atomic
#     def post(self, request):
#         project_group_data_ = request.data.get('data')
#         print('r_data---',project_group_data_)
#         try:
#             from utils.md5_base64_aes import EncryptionAndDecryption
#             descryobj = EncryptionAndDecryption(mode=3, content='', operation=1, SECRET_KEY=settings.SECRET_KEY)
#             text = descryobj.rsa_long_decrypt(data=project_group_data_)
#         except Exception as e:
#             return Response({"message": "解密失败"}, status=HTTP_400_BAD_REQUEST)
#         project_group_data = json.loads(text.decode('utf-8'))
#         print('h_data---',project_group_data)
#         print('h_data_type---',type(project_group_data))
#         for user in project_group_data:
#             print('user_data---', user)
#             print('user_data_type---', type(user))
#             if user.get('resourceType') == 'project':
#                 try:
#                     project_obj = TestProjectModel.objects.get(id=user.get('resourceId'), is_delete=False)
#                 except TestProjectModel.DoesNotExist as e:
#                     debuglog.exception(e)
#                     return Response({'message': '项目不存在'} ,status=HTTP_400_BAD_REQUEST)
#                 else:
#                     try:
#                         user_obj = UserModel.objects.get(choerodon_id=user.get('userId'))
#                     except UserModel.DoesNotExist:
#                         user_obj = UserModel.objects.create(choerodon_id=user.get('userId'), username=user.get('username'))
#                     for role in  user.get('roleLabels'):
#                         # if role == 'project.gitlab.owner':
#                         #     project_obj.addProjectLead(user_obj)
#                         # elif role == 'project.gitlab.developer':
#                         #     project_obj.addProjectUser(user_obj)
#                         project_obj.addProjectUser(user_obj)
#         return Response({'message': '成功加入项目组'}, status=HTTP_201_CREATED)
#
#     @transaction.atomic
#     def delete(self, request):
#         project_group_data_ = request.data.get('data')
#         try:
#             from utils.md5_base64_aes import EncryptionAndDecryption
#             descryobj = EncryptionAndDecryption(mode=3, content='', operation=1, SECRET_KEY=settings.SECRET_KEY)
#             text = descryobj.rsa_long_decrypt(data=project_group_data_)
#         except Exception as e:
#             return Response({"message": "解密失败"}, status=HTTP_400_BAD_REQUEST)
#         project_group_data = json.loads(text.decode('utf-8'))
#         for user in project_group_data:
#             if user.get('resourceType') == 'project':
#                 try:
#                     project_obj = TestProjectModel.objects.get(id=user.get('resourceId'), is_delete=False)
#                 except TestProjectModel.DoesNotExist as e:
#                     debuglog.exception(e)
#                 else:
#                     try:
#                         user_obj = UserModel.objects.get(choerodon_id=user.get('userId'))
#                     except UserModel.DoesNotExist:
#                         UserModel.objects.create(choerodon_id=user.get('userId'), username=user.get('username'))
#                     else:
#                         project_obj.removeUser(user_obj)
#         return Response(status=HTTP_200_OK)
#
#     def get(self, request):
#         data_content = '''[
#               {
#                 "userId": 3,
#                 "username": "tankang",
#                 "resourceId": 33,
#                 "resourceType": "project",
#                 "roleLabels": [
#                   "project.gitlab.developer",
#                   "project.gitlab.owner"
#                 ],
#                 "uuid": null
#               }
#             ]'''
#         from utils.md5_base64_aes import EncryptionAndDecryption
#         descryobj = EncryptionAndDecryption(mode=3, content='', operation=0, SECRET_KEY=settings.SECRET_KEY)
#         text = descryobj.signerData(data=data_content)
#         return Response({'message': text}, status=HTTP_200_OK)


# class StopAPIView(APIView):
#     permission_classes = []
#
#     @transaction.atomic
#     def post(self, request):
#         project_data_ = request.data.get('data')
#
#         from utils.md5_base64_aes import EncryptionAndDecryption
#         try:
#             descryobj = EncryptionAndDecryption(mode=3, content='', operation=1, SECRET_KEY=settings.SECRET_KEY)
#             text = descryobj.rsa_long_decrypt(data=project_data_)
#         except Exception:
#             return Response({"message": "解密失败"}, status=HTTP_400_BAD_REQUEST)
#         project_data = json.loads(text.decode('utf-8'))
#         pk = project_data.get('projectId')
#         try:
#             TestProjectModel.objects.get(id=pk).stop()
#         except TestProjectModel.DoesNotExist:
#             return Response({'message': '冇找到项目'}, status=HTTP_400_BAD_REQUEST)
#         else:
#             return Response({'message': '已禁用项目'}, status=HTTP_200_OK)



# class ReopenAPIView(APIView):
#     permission_classes = []
#
#     @transaction.atomic
#     def post(self, request):
#         project_data = request.data.get('data')
#
#         from utils.md5_base64_aes import EncryptionAndDecryption
#         try:
#             # 密文不能超过8192 bity  在生成秘钥时已定义 不能超过此范围
#             descryobj = EncryptionAndDecryption(mode=3, content='', operation=1, SECRET_KEY=settings.SECRET_KEY)
#             text = descryobj.rsa_long_decrypt(data=project_data)
#         except Exception as e:
#             return Response({"message": "解密失败"}, status=HTTP_400_BAD_REQUEST)
#         project_data = json.loads(text.decode('utf-8'))
#         pk = project_data.get('projectId')
#         try:
#             TestProjectModel.objects.get(id=pk).reopen()
#         except TestProjectModel.DoesNotExist:
#             return Response({'message': '冇找到项目'}, status=HTTP_400_BAD_REQUEST)
#         else:
#             return Response({'message': '已启用项目'}, status=HTTP_200_OK)
#
#     def get(self, request):
#         data_content = json.dumps(33)
#         from utils.md5_base64_aes import EncryptionAndDecryption
#         descryobj = EncryptionAndDecryption(mode=3, content='', operation=0, SECRET_KEY=settings.SECRET_KEY)
#         text = descryobj.signerData(data=data_content)
#         return Response({'message': text}, status=HTTP_200_OK)


# 下面的几个视图和应用有关  创建 更新 启用 禁用 -应用

class CreateApplicationAPIView(APIView):
    permission_classes = []

    @transaction.atomic
    def post(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"post",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        # application_data_ = request.data.get('data')
        # from utils.md5_base64_aes import EncryptionAndDecryption
        # try:
        #     # 密文不能超过1024bity  在生成秘钥时已定义 不能超过此范围
        #     descryobj = EncryptionAndDecryption(mode=3, content='', operation=1, SECRET_KEY=settings.SECRET_KEY)
        #     text = descryobj.rsa_long_decrypt(data=application_data_)
        # except Exception as e:
        #     return Response({"message": "解密失败"}, status=HTTP_400_BAD_REQUEST)
        # application_dict = json.loads(text.decode('utf-8'))
        # try:
        #     project_obj = SteamProject.objects.get(id=application_dict['projectId'])
        # except SteamProject.DoesNotExist as e:
        #     return Response({'message':'项目不存在'},status=HTTP_400_BAD_REQUEST)
        # if TestProjectModel.objects.filter(id=application_dict['id']).exists():
        #     print('app is exists')
        #     return Response({'message': '导入项目成功'}, status=HTTP_201_CREATED)
        # else:
        #     test_project_obj = TestProjectModel.objects.create(
        #         id=application_dict['id'],
        #         project_urls=[],
        #         project_header_infos=[],
        #         project_name=application_dict['name'],
        #         project_code=application_dict['code'],
        #         project_steam_id=application_dict['projectId'],
        #         user_group=project_obj.user_group
        #     )
        #     users = project_obj.project_lead.all()
        #     for user in users:
        #         test_project_obj.addProjectLead(user)
        return Response({'message': '导入项目成功'}, status=HTTP_201_CREATED)

    @transaction.atomic
    def patch(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"patch",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        # project_data_ = request.data.get('data')
        # from utils.md5_base64_aes import EncryptionAndDecryption
        # try:
        #     # 密文不能超过8192 bity  在生成秘钥时已定义 不能超过此范围
        #     descryobj = EncryptionAndDecryption(mode=3, content='', operation=1, SECRET_KEY=settings.SECRET_KEY)
        #     application_data_ = descryobj.rsa_long_decrypt(data=project_data_)
        # except Exception as e:
        #     return Response({"message": "解密失败"}, status=HTTP_400_BAD_REQUEST)
        # application_data = json.loads(application_data_.decode('utf-8'))
        # try:
        #     project_obj = TestProjectModel.objects.get(
        #         project_code=application_data['code']
        #     )
        # except TestProjectModel.DoesNotExist:
        #     return Response({'message': '项目不存在'}, status=HTTP_400_BAD_REQUEST)
        # project_obj.project_name = application_data['name']
        # project_obj.save()
        return Response({'message': '更新成功'}, status=HTTP_200_OK)

    def get(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"get",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        from utils.md5_base64_aes import EncryptionAndDecryption
        descryobj = EncryptionAndDecryption(mode=3, content='', operation=1, SECRET_KEY=settings.SECRET_KEY)
        application_data_ = descryobj.rsa_long_encrypt(data='{"code":"qwer","name":"test应用","id":132466,"projectId":1232}')
        return Response({"message": application_data_})

class StopAPPAPIView(APIView):
    """
    停用应用的api接口
    """
    permission_classes = []

    @transaction.atomic
    def post(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"post",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        # application_data_ = request.data.get('data')
        # print('shuju------',application_data_)
        # from utils.md5_base64_aes import EncryptionAndDecryption
        # try:
        #     # 密文不能超过8192 bity  在生成秘钥时已定义 不能超过此范围
        #     descryobj = EncryptionAndDecryption(mode=3, content='', operation=1, SECRET_KEY=settings.SECRET_KEY)
        #     text = descryobj.rsa_long_decrypt(data=application_data_)
        # except Exception as e:
        #     return Response({"message": "解密失败"}, status=HTTP_400_BAD_REQUEST)
        # application_data = json.loads(text.decode('utf-8'))
        # code = application_data.get('code')
        # try:
        #     TestProjectModel.objects.get(project_code=code).stop()
        # except TestProjectModel.DoesNotExist as e:
        #     return Response({'message': '冇找到项目'}, status=HTTP_400_BAD_REQUEST)
        # else:
        #     return Response({'message': '已禁用项目'}, status=HTTP_200_OK)
        return Response({'message': '已禁用项目'}, status=HTTP_200_OK)

class ReopenAPPAPIView(APIView):
    """
    重新开启应用
    """
    permission_classes = []

    @transaction.atomic
    def post(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"post",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        # application_data_ = request.data.get('data')
        #
        # from utils.md5_base64_aes import EncryptionAndDecryption
        # try:
        #     # 密文不能超过8192 bity  在生成秘钥时已定义 不能超过此范围
        #     descryobj = EncryptionAndDecryption(mode=3, content='', operation=1, SECRET_KEY=settings.SECRET_KEY)
        #     text = descryobj.rsa_long_decrypt(data=application_data_)
        # except Exception as e:
        #     return Response({"message": "解密失败"}, status=HTTP_400_BAD_REQUEST)
        # application_data = json.loads(text.decode('utf-8'))
        # code = application_data.get('code')
        # try:
        #     TestProjectModel.objects.get(project_code=code).reopen()
        # except TestProjectModel.DoesNotExist as e:
        #     return Response({'message': '冇找到项目'}, status=HTTP_400_BAD_REQUEST)
        # else:
        return Response({'message': '已启用项目'}, status=HTTP_200_OK)


class CiAPIView(APIView):
    permission_classes = []
    authentication_classes = []

    def post(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"post",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":false,
            "permissionPublic":true,
            "permissionWithin":false
        },
        "label":null
        }"""
        debuglog.info('ci流水线触发冒烟测试--收到数据----->{}'.format(request.data.get('data')))
        # serializer = CiDataSerializer(data=request.query_params.get('data'))
        # if serializer.is_valid():
        if True:
            data = request.data.get('data')
            if data is None or data == '':
                return Response({"message": "body为空"}, status=HTTP_400_BAD_REQUEST)
            else:
                import base64
                data = base64.b64decode(data).decode()
                data_dict = json.loads(data)
                debuglog.info('ci流水线触发冒烟测试--解密数据----->{}'.format(data_dict.get('data')))
            project_obj = TestProjectModel.objects.get(id=data_dict['project_id'])
            case_obj = CaseDump()
            user_obj = UserModel.objects.get(username=data_dict['user_name'])
            try:
                test_task_obj = TestTaskModel.objects.get(job_id=data_dict['job_id'])
            except TestTaskModel.DoesNotExist as e:
                debuglog.exception(e)
                case_file_path = case_obj.copyTaskJsonFileByCaseLevel(project_id=project_obj.id,
                                                                      case_level=data_dict["case_level"])
                case_obj.update_case_json_file(case_file_path)
                test_task_obj = TestTaskModel.objects.create(
                    name=data_dict["job_name"],
                    level=data_dict['case_level'],
                    project=project_obj,
                    case_file_path=case_file_path,
                    case_type=TestTaskModel.CHOICES_CASE_TYPE[2][0],
                    task_content={},
                    publish_case={},
                    job_id=data_dict['job_id']
                )
            else:
                if test_task_obj.is_delete == True:
                    test_task_obj.is_delete = False
                    test_task_obj.save()
                if test_task_obj.name != data_dict['job_name']:
                    test_task_obj.name = data_dict['job_name']
                    test_task_obj.save()
                if test_task_obj.level != data_dict['case_level']:
                    old_path = test_task_obj.case_file_path
                    try:
                        case_file_path = case_obj.copyTaskJsonFileByCaseLevel(project_id=project_obj.id,
                                                                              case_level=data_dict["case_level"])
                        case_obj.update_case_json_file(case_file_path)
                    except Exception as e :
                        debuglog.exception(e)
                        pass
                    else:
                        test_task_obj.case_file_path = case_file_path
                        test_task_obj.save()
                        import os
                        try:
                            os.remove(old_path)
                        except Exception as e:
                            debuglog.exception(e)
                            pass
            report_obj = ResultReportModel.objects.create(
                name='ci构建触发任务',
                project=project_obj,
                status="running",
                testCaseTask=test_task_obj,
                user_exe=user_obj
            )
            runTestTask_task.delay(test_task_id=test_task_obj.id, env_id=data_dict['env_id'], report_id=report_obj.id, project_id=project_obj.id)
            return Response({"message": "接口测试已执行"})
        else:
            return Response({"message": "解密失败，请联系平台管理员"}, status=HTTP_400_BAD_REQUEST)


