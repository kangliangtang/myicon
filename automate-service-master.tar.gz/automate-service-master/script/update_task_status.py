

def main():
    no_result_task_list = []
    from case_flow.models import TestTaskModel
    from result_report.models import ResultReportModel

    task_set = TestTaskModel.objects.filter(is_delete=False).all()
    for task in task_set:
        task_resul = task.resultreportmodel_set.filter(is_delete=False).order_by('-create_time')
        print('exec -- taskid:{}'.format(task.id))
        if len(task_resul):
            task_re = task_resul.first()
            task.task_status = task_re.status
            task.task_exc_time = task_re.create_time
            task.user_exc = task_re.user_exe.username
            task.save(update_fields=['task_status', 'task_exc_time', 'user_exc'])
        else:
            no_result_task_list.append(task.id)
            print('task:{} result report is not exists'.format(task.id))
            task.task_status = 'unexecuted'
            task.save(update_fields=['task_status'])
    for task_id in no_result_task_list:
        print('unexecuted:',task_id)


if __name__ == '__main__':
    import os
    import django

    import os
    os.environ.setdefault("devops_env", "development")
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "automate_test_py3.settings")
    import django
    django.setup()

    main()