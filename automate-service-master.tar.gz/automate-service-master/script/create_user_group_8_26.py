


def main():
    import os
    os.environ.setdefault("devops_env", "production")
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "automate_test_py3.settings")
    import django
    django.setup()
    from project_caud.models import TestProjectModel
    from django.contrib.auth.models import Group

    project_set = TestProjectModel.objects.all()
    for project in project_set:
        if project.user_group is None:
            group_obj = Group.objects.create(name='{}_用户组_{}_'.format(project.project_name, project.id))
            project.user_group = group_obj
            project.save()


# def update_project():
#     import os
#     os.environ.setdefault("devops_env", "production")
#     os.environ.setdefault("DJANGO_SETTINGS_MODULE", "automate_test_py3.settings")
#     import django
#     django.setup()
#     from project_caud.models import TestProjectModel
#
#     project_set = TestProjectModel.objects.all()
#     for project in project_set:
#         if project.env_info is None:
#             project.env_info = []
#             project.save()



def update_interface():
    import os
    os.environ.setdefault("devops_env", "production")
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "automate_test_py3.settings")
    import django
    django.setup()
    from project_caud.models import TestProjectModel
    project_set = TestProjectModel.objects.all()
    # for project_id, app_id in [(20003, 1),(20259, 2),(20015, 3), (20038, 4),(20041, 5),(20192, 6)]: # (project_id, application_id)
    for project_id, app_id in [(20006, 7),(20029, 9),(20370, 10),(20034, 12),(20545, 13)]: # (project_id, application_id)
        module_set = project_set.get(id=project_id).projectmodulemodel_set.all()
        for module_obj in module_set:
            interface_set = module_obj.interfacemodel_set.update(application_id=app_id)
            print(interface_set)
            # for interface_obj in interface_set:
            #     interface_obj.application = ApplicationModel.objects.get(id=app_id)
            #

def update_default_application():
    import os
    os.environ.setdefault("devops_env", "production")
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "automate_test_py3.settings")
    import django
    django.setup()
    from project_caud.models import ProjectDataModel
    from project_caud.models import TestProjectModel
    project_set = TestProjectModel.objects.all()
    for project_obj in project_set:
        if not hasattr(project_obj, 'projectdata'):
            ProjectDataModel.objects.create(project=project_obj)



if __name__ == '__main__':
    update_default_application()
