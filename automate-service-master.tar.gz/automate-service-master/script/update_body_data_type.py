#!/usr/bin/env python3


""""
时间：2019年5月31号
作者：chenhuazhong
功能：用于更新 tb_interface 表中的body_data_type 字段
     根据body_data 中的数据是否是字典，如果是字典将body_data_type 置1 ，body_data_type默认值为0
     之前默认 所有字典都是 json 格式--->raw

    CHOICES_BODY_DATA_TYPE = (
        (0, 'x-formdata'),
        (1, 'raw'),
        (2, 'x-formdata-file'),
        (3, 'xml')
    )

"""
import json
from time import sleep
import pymysql
import os
def execute_script():
    import os
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "automate_test_py3.settings")
    import django
    django.setup()
    from automate_test_py3 import settings

    # 开发数据库
    development_database = {
    }
    # -----------------------------------


    database_ = development_database
    # database_ = test_database

    # ----------------------------------

    print('正在执行--{}--IP {}:{}'.format(database_['env'], database_['host'], database_['port']))
    print('输入y确认 y/n ',end='')
    yes_no = input()
    if yes_no.lower() == 'y':
        import time
        file_name = str(time.time()).replace('.','')
        # 先备份数据库
        os.system('''mysqldump -u{} -p{} -h{} -P{} {} >./{}_6_14_{}.sql'''.format(database_['username'], database_['password'], database_['host'], database_['database'], database_['port'], database_['database'], file_name))

        cont = pymysql.Connect(host=database_['host'],database=database_['database'], user=database_['username'], password=database_['password'], port=database_['port'])
        cur = cont.cursor()
        sql1 = 'select id,body_data,body_data_type from tb_interface'
        update_body_data_sql = 'update tb_interface set body_data_type="raw" where id={}'

        cur.execute(sql1)
        result = cur.fetchall()
        print('数据机构为字典的数据，将body_data_type置为raw')
        for body_data_tuple in result:
            print(body_data_tuple[0])
            if isinstance(json.loads(body_data_tuple[1]), dict):
                cur.execute(update_body_data_sql.format(body_data_tuple[0]))
        else:
            cont.commit()
        sleep(1)
        cur.execute(sql1)
        result2 = cur.fetchall()
        for body_data_tuple in result2:

            print(body_data_tuple[0])
            print(body_data_tuple[1])
            print(body_data_tuple[2])

        cont.commit()
        cur.close()
        cont.close()

        print('创建mysql视图------------------------------')
        command = '''mysql -u{} -p{} -h{} -P{} {} <{}'''.format(
            database_['username'],
            database_['password'],
            database_['host'],
            database_['port'],
            database_['database'],
            os.path.join(settings.BASE_DIR, 'script/mysqlView.sql')
        )
        print(command)
        os.system(command=command)

    elif yes_no.lower() == 'n':
        print('未执行')
    else:
        print('错误输入')




if __name__ == '__main__':
    execute_script()
