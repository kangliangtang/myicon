/*
Navicat MySQL Data Transfer

Source Server         : 10.0.99.136
Source Server Version : 50725
Source Host           : 10.0.99.136:3306
Source Database       : automate_test

Target Server Type    : MYSQL
Target Server Version : 50725
File Encoding         : 65001

Date: 2019-06-05 11:29:39
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for v_interface_num
-- ----------------------------
DROP VIEW IF EXISTS `v_interface_num`;
create view v_interface_num as select t3.project project_id, DATE_FORMAT(t4.create_time,'%Y-%m-%d') as interface_date, COUNT(t4.id) interface_num from
(select t1.id project, t2.id module_id from tb_project as t1 LEFT JOIN tb_project_module as t2 on t1.id=t2.project_id) as t3
LEFT JOIN tb_interface as t4 on t3.module_id=t4.module_id where t4.is_delete=FALSE GROUP BY project_id, interface_date;



-- ----------------------------
-- Table structure for v_total_cases
-- ----------------------------
DROP VIEW IF EXISTS `v_total_cases`;
create view v_total_cases as
select t4.project_id, SUM(t4.total_cases) total_cases, DATE_FORMAT(t4.create_time,'%Y-%m-%d') case_date from
(select t1.create_time, t1.result_report_id, t1.task_result_report_id, t1.total_cases, t2.project_id from tb_summary t1, tb_result_report t2 where t1.result_report_id=t2.id
UNION
select t1.create_time, t1.result_report_id, t1.task_result_report_id, t1.total_cases, t3.project_id from tb_summary t1, tb_task_result_report t3 where t1.task_result_report_id=t3.id) t4
GROUP BY t4.project_id,case_date;
