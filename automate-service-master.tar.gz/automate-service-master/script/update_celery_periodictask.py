

def main():
    """
    更新定时任务运行时间，
    当时区更改时运行，将运行时间置空 解决时间混乱，定时不准确问题
    django_celery_beat 推荐方法
    :return:
    """
    from django_celery_beat.models import PeriodicTask, PeriodicTasks
    PeriodicTask.objects.all().update(last_run_at=None)
    for task in PeriodicTask.objects.all():
        PeriodicTasks.changed(task)

def pro():
    db_name = input('数据库名')
    db_user = input('数据库用户名')
    db_password = input('数据库密码')
    db_host = input('数据库地址')
    db_port = input('数据库端口')
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "automate_test_py3.settings")
    os.environ.setdefault("devops_env", "development")
    os.environ.setdefault("DB_Name", db_name)
    os.environ.setdefault("DB_User", db_user)
    os.environ.setdefault("DB_Password", db_password)
    os.environ.setdefault("DB_Host", db_host)
    os.environ.setdefault("PORT", db_port)
    django.setup()
    main()

def uat():
    db_name = 'automate_test'
    db_user = 'root'
    db_password = 'Mysql!23'
    db_host = '10.0.99.136'
    db_port = '3306'
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "automate_test_py3.settings")
    os.environ.setdefault("devops_env", "development")
    os.environ.setdefault("DB_Name", db_name)
    os.environ.setdefault("DB_User", db_user)
    os.environ.setdefault("DB_Password", db_password)
    os.environ.setdefault("DB_Host", db_host)
    os.environ.setdefault("PORT", db_port)
    django.setup()
    main()

if __name__ == '__main__':
    import os
    import django
    uat()
