

def main():
    import os
    os.environ.setdefault("devops_env", "production")
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "automate_test_py3.settings")
    import django
    django.setup()
    from project_caud.models import SteamProject, TestProjectModel
    from django.contrib.auth.models import Group
    from automate_test_py3 import settings
    print(settings.DATABASES)
    arg = input('y/n')
    if arg == 'y':
        steam_project_set = SteamProject.objects.all()
        for steam_project in steam_project_set:
            if steam_project.user_group is None:
                group_obj = Group.objects.create(name='{}_用户组_{}'.format(steam_project.name,steam_project.id))
                steam_project.user_group = group_obj
                steam_project.save()
            else:
                group_obj = steam_project.user_group
            application_set = TestProjectModel.objects.filter(project_steam_id=steam_project.id)
            for app in application_set:
                app.user_group = group_obj
                app.save()
    else:
        print('exit')

if __name__ == '__main__':
    main()