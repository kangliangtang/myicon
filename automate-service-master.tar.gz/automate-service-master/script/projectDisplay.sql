INSERT INTO `tb_project_display`(interface_num, total_cases, date, project_id)
SELECT SUM(t2.interface_num) AS interface_num, SUM(t2.total_cases) AS total_cases, t2.date, t2.project_id FROM(
SELECT IFNULL(t1.interface_num,0) AS interface_num, IFNULL(t1.total_cases,0) total_cases, date, t1.project_id FROM
(SELECT v1.interface_num, NULL AS total_cases, v1.interface_date AS date, v1.project_id FROM v_interface_num v1
UNION
SELECT NULL AS interface_num, v2.total_cases, v2.case_date AS date, v2.project_id FROM v_total_cases v2) t1) t2
GROUP BY t2.date, t2.project_id
ORDER BY date;