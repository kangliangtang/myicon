#!/usr/bin/env python3

""""
时间：2019年7月24号
作者：chenhuazhong
功能：用于更新 所有表中的projectId  对接 行云的应用id
"""
import pymysql



"""
        {
            "id": 370,
            "name": "云市场测试",
            "steam_name": "云市场服务",
            "project_steam_id": 9,
            "code":"crcloud-market-service"
        },
        {
            "id": 192,
            "name": "行云-测试用例管理",
            "steam_name": "测试基础服务",
            "project_steam_id": 8,
            "code": "test-base-service"
        },
        {
            "id": 3,
            "name": "CI持续集成",
            "steam_name": "devops-ci",
            "project_steam_id": 8,
            "code": "devops-ci"
        },
        {
            "id": 38,
            "name": "行云自动化测试TEST",
            "steam_name": "automate-service",
            "project_steam_id": 8,
            "code": "automate-service"
        },
        {
            "id": 259,
            "name": "三重一大",
            "steam_name": "三重一大系统后端",
            "project_steam_id": 8,
            "code": "szyd-claim"
        },
        {
            "id": 41,
            "name": "公文管理",
            "steam_name": "公文管理系统后端",
            "project_steam_id": 8,
            "code": "odms-claim-impl"
        },
        {
            "id": 29,
            "name": "云门户运营后台",
            "steam_name": "华润云门户-后台运营管理系统",
            "project_steam_id": 9,
            "code": "crcloud-admin-web"
        },
"""


def execute_script():
    import os
    # 接口平台的项目名和行云应用id  对应
    project_name_dict_list = [

    {
        "id": 6,
        "name": "华润云门户网站",
        "steam_name": "华润云门户WEB工程",
        "project_steam_id": 9,
        "code": "crcloud-portal-web"
    }
    ]

    # 需要更新的表
    table_names = ['tb_flow_tree', 'tb_test_task', 'tb_contract', 'tb_contract_result', 'tb_interface_scene',
                   'tb_task', 'tb_pulish', 'tb_mockserver', 'tb_project_module', 'tb_result_report',
                   'tb_task_result_report', 'tb_upload_file', 'tb_common_parameter']

    # 开发数据库
    development_database = {
    }

    # -----------------------------------

    database_ = development_database
    # database_ = test_database

    # ----------------------------------

    print(
        '正在执行--{}--IP {}:{}---{}'.format(database_['env'], database_['host'], database_['port'], database_['database']))
    print('输入y确认 y/n ', end='')
    yes_no = input()
    if yes_no.lower() == 'y':
        import time
        file_name = str(time.time()).replace('.', '')
        # 先备份数据库
        # os.system(
        #     '''mysqldump -u{} -p{} -h{} -P{} {} >./{}_{}.sql'''.format(database_['username'], database_['password'],
        #                                                                database_['host'], database_['database'],
        #                                                                database_['port'], database_['database'],
        #                                                                file_name))

        cont = pymysql.Connect(host=database_['host'], database=database_['database'], user=database_['username'],
                               password=database_['password'], port=database_['port'])
        cur = cont.cursor()
        cur.execute('SET FOREIGN_KEY_CHECKS=0')
        cont.commit()
        # cur.execute('update tb_project set id=id+10000')
        # for table_name in table_names:
        #     cur.execute('update {} set project_id=project_id+10000'.format(table_name))
        # cont.commit()
        for project_name_dict in project_name_dict_list:
            cur.execute("select id ,user_group_id from tb_project where project_name='{}'".format(project_name_dict["name"]))
            project_data = cur.fetchall()[0]
            project_id = project_data[0]
            user_group_id = project_data[1]
            update_steam_project_sql = "update tb_steam_project set user_group_id={} where id={}".format(user_group_id,project_name_dict["project_steam_id"])
            update_project_sql = "update tb_project set id={},project_name='{}',project_code='{}', project_steam_id={} where id={}".format(
                project_name_dict["id"], project_name_dict["steam_name"],project_name_dict["code"], project_name_dict["project_steam_id"],
                project_id)
            print(update_project_sql)
            cur.execute(update_steam_project_sql)
            cur.execute(update_project_sql)
            for table_name in table_names:
                cur.execute(
                    "update {} set project_id={} where project_id={}".format(table_name, project_name_dict["id"],
                                                                             project_id))
            cont.commit()
        cur.execute('SET FOREIGN_KEY_CHECKS=1')
        cont.commit()
        cur.close()
        cont.close()

    elif yes_no.lower() == 'n':
        print('未执行')
    else:
        print('错误输入')

if __name__ == '__main__':
    execute_script()
