from django.contrib.auth.models import AbstractUser, Group
from django.db import models
from utils.model import BaseModel


class UserModel(AbstractUser):
    choerodon_id = models.IntegerField('行云中的用户ID', null=True, blank=True)

    class Meta:
        db_table = 'tb_user'
        verbose_name = '用户'
        verbose_name_plural = '用户'

    @property
    def isSuperUser(self):
        return self.is_active and self.is_superuser

    def userinfo(self, token):
        '''
        该 查询 用户在steam 中的邮箱和昵称等数据
        :return:


        '''
        from utils.innerApi import GatWay
        return GatWay(token).getUserInfo()


class Organization(models.Model):
    name = models.CharField('组织名', max_length=255)
    code = models.CharField('组织编码', max_length=120)
    user = models.ManyToManyField(UserModel)

    class Meta:
        db_table = 'tb_organization'
        verbose_name = '组织'
        verbose_name_plural = '组织'


# class ProjectGroup(models.Model):
#     CHOICES_DELETE = (
#         (0, '未删除'),
#         (1, '已删除')
#     )
#     create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
#     update_time = models.DateTimeField(auto_now=True, verbose_name='更新时间')
#     is_delete = models.SmallIntegerField(default=0, choices=CHOICES_DELETE, verbose_name='逻辑删除')
#
#     project_lead = models.ForeignKey('user.UserModel', default=1, on_delete=models.CASCADE,verbose_name='项目lead')
#     # name = models.CharField('项目组名', max_length=128)
#     # project_user = models.ManyToManyField('user.UserModel', verbose_name='项目成员')
#     project = models.OneToOneField('project_caud.TestProjectModel', related_name='project_group', on_delete=models.CASCADE, verbose_name='所属项目')
#     user_group = models.OneToOneField(Group, on_delete=models.CASCADE, verbose_name='组成员')
#
#     class Meta:
#         db_table = 'tb_project_group'
#         verbose_name = '项目组'
#         verbose_name_plural = verbose_name
#
#     def setPermission(self):
#         self.user_group.permissions.add()
#         pass

