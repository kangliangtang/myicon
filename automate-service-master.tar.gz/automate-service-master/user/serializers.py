from django.contrib.auth.models import Group
from rest_framework import serializers
from rest_framework_jwt.serializers import VerifyJSONWebTokenSerializer

from user.models import UserModel


class UserListSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    username = serializers.CharField()

    class META:
        model = UserModel
        fields = ('id', 'username')


class UserSerializer(serializers.ModelSerializer):

    class Meta:
        model=UserModel
        fields = ('id', 'username', 'is_superuser')


class UserTokenSerializer(serializers.ModelSerializer):

    class Meta:
        model=UserModel
        fields = ('id', 'username', 'last_name')


class GroupSerializer(serializers.ModelSerializer):
    user_set = UserSerializer(many=True, read_only=True)
    class Meta:
        model = Group
        # exlude = ('is_delete', )
        fields = ('user_set',)


class SteamVerifyJSONWebTokenSerializer(VerifyJSONWebTokenSerializer):

    def validate(self, token):
        token = self._token(token['token'])
        payload = self._check_payload(token=token)
        user = self._check_user_by_user_id(payload=payload)
        return {"user": user}

    def _check_user_by_user_id(self, payload):
        user_id = int(payload.get('userId', None))
        try:
            user = UserModel.objects.get(choerodon_id=user_id)
        except UserModel.DoesNotExist as e:
            username = payload.get('username', None)
            email = payload.get('email', None)
            user = UserModel.objects.create(choerodon_id=user_id,username=username,email=email)
        return user

    def _token(self, data):
        if data.startswith('Bearer '):
            data = data.split('Bearer ', 1)[-1]
        return data
