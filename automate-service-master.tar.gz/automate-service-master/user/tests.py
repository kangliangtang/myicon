# from django.test import TestCase

# Create your tests here.


# if __name__ == '__main__':
#     import os
#     os.environ.setdefault("DJANGO_SETTINGS_MODULE", "automate_test_py3.settings")
#     import django
#     django.setup()
#     from automate_test_py3 import settings
#     appllist = settings.INSTALLED_APPS
#     print(appllist)
#     for i in appllist:
#         print(i)
#
#         pass



#
# import filetype
#
# def main():
#     kind = filetype.guess('tests/fixtures/sample.jpg')
#     if kind is None:
#         print('Cannot guess file type!')
#         return
#
#     print('File extension: %s' % kind.extension)
#     print('File MIME type: %s' % kind.mime)

#
# if __name__ == '__main__':
#     main()



def fun1():
    import os
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "automate_test_py3.settings")
    import django
    django.setup()
    from user.serializers import SteamVerifyJSONWebTokenSerializer
    ttt1 = {"token":"Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImFkbWluIiwicGFzc3dvcmQiOiJ1bmtub3duIHBhc3N3b3JkIiwiYXV0aG9yaXRpZXMiOltdLCJhY2NvdW50Tm9uRXhwaXJlZCI6dHJ1ZSwiYWNjb3VudE5vbkxvY2tlZCI6dHJ1ZSwiY3JlZGVudGlhbHNOb25FeHBpcmVkIjp0cnVlLCJlbmFibGVkIjp0cnVlLCJ1c2VySWQiOjEsImVtYWlsIjoiYWRtaW5AY3JjLmNvbS5oayIsInRpbWVab25lIjoiQ1RUIiwibGFuZ3VhZ2UiOiJ6aF9DTiIsIm9yZ2FuaXphdGlvbklkIjoxLCJjbGllbnRJZCI6bnVsbCwiY2xpZW50TmFtZSI6bnVsbCwiY2xpZW50QXV0aG9yaXplZEdyYW50VHlwZXMiOm51bGwsImNsaWVudFJlc291cmNlSWRzIjpudWxsLCJjbGllbnRTY29wZSI6bnVsbCwiY2xpZW50UmVnaXN0ZXJlZFJlZGlyZWN0VXJpIjpudWxsLCJjbGllbnRBY2Nlc3NUb2tlblZhbGlkaXR5U2Vjb25kcyI6bnVsbCwiY2xpZW50UmVmcmVzaFRva2VuVmFsaWRpdHlTZWNvbmRzIjpudWxsLCJjbGllbnRBdXRvQXBwcm92ZVNjb3BlcyI6bnVsbCwiYWRkaXRpb25JbmZvIjpudWxsLCJhZG1pbiI6dHJ1ZX0.o_5yF1OYkfptmRY75x2dGrTsO3dk6erA6H267dT-Y_A"}
    ser = SteamVerifyJSONWebTokenSerializer(data=ttt1)
    # print(ser._check_payload(token=ttt1))
    ser.is_valid()
    print(ser.validated_data)

    # ser.is_valid()
    # print(ser.validated_data)
    # print(ser.validated_data['user'].username)

fun1()