import io

from django.contrib.auth.models import Group

# Create your views here.
from django.http.response import HttpResponse
from rest_framework.decorators import list_route
from rest_framework.response import Response
from rest_framework.status import HTTP_400_BAD_REQUEST, HTTP_200_OK
from rest_framework.views import APIView
from rest_framework.viewsets import ModelViewSet

from project_caud.models import TestProjectModel
from user.models import UserModel
from user.serializers import UserSerializer, GroupSerializer, UserListSerializer

# 操作日志
from utils.operation_log import OperationLogDecorator
from django.utils.decorators import method_decorator
logde = OperationLogDecorator()


class UserModelViewSet(ModelViewSet):
    serializer_class = UserSerializer
    queryset = None

    def get_queryset(self):
        return UserModel.objects.all()

    def create(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"create",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":false,
                "permissionPublic":true,
                "permissionWithin":true
            },
            "label":null
            }
        """
        return Response('ok')

    @list_route(methods=['GET'])
    def userlist(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"userlist",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        user_set = self.get_queryset().all()
        serializer = UserListSerializer(user_set, many=True)
        return Response({'list': serializer.data})

    @list_route(methods=['GET'])
    def userinfo(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"userinfo",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        user_obj = request.user
        serializer = UserSerializer(user_obj)
        return Response(serializer.data, status=HTTP_200_OK)

    @list_route(methods=['GET'])
    def testfile(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"testfile",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":true,
                "permissionPublic":false,
                "permissionWithin":false
            },
            "label":null
            }
        """
        from utils.util import  ExeclSerializer
        execl_obj = ExeclSerializer(args=['name','age'])
        output = io.BytesIO()
        execl_obj.writeExeclMain(out_io=output)
        execl_obj.close()
        output.seek(0)
        filename = 'django_simple.xlsx'
        response = HttpResponse(
            output,
            content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        )
        response['Content-Disposition'] = 'attachment; filename=%s' % filename
        return response


class EurekaInfoAPIView(APIView):
    permission_classes = []

    def get(self, request, *args, **kwargs):
        """
            {
            "permission":{
                "action":"get",
                "menuLevel":null,
                "permissionLevel":"project",
                "roles":[

                ],
                "permissionLogin":false,
                "permissionPublic":true,
                "permissionWithin":false
            },
            "label":null
            }
        """
        return Response(data={}, status=200)


class EurekaHelthAPIView(APIView):
    permission_classes = []
    def get(self, request):
        """
        {
        "permission":{
            "action":"get",
            "menuLevel":null,
            "permissionLevel":null,
            "roles":[

            ],
            "permissionLogin":false,
            "permissionPublic":true,
            "permissionWithin":false
        },
        "label":null
        }
        """
        data = {"status": "UP"}
        return Response(data=data, status=200)


class UserGroup(ModelViewSet):
    serializer_class = GroupSerializer
    queryset = None
    # permission_classes = (AutoPlatformGroupPermission, )

    def get_queryset(self):
        project_id = self.request.META.get('HTTP_PROJECTID')
        project_obj = TestProjectModel.objects.get(id=project_id)
        return Group.objects.filter(testprojectmodel=project_obj).all()


    @list_route(methods=['POST', 'DELETE'])
    @method_decorator(logde.update_permission)
    def user(self, request):
        """
        {
        "permission":{
            "action":"user",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":false,
            "permissionPublic":true,
            "permissionWithin":false
        },
        "label":null
        }
        """
        if self.get_queryset().count() == 0:
            project_id = self.request.META.get('HTTP_PROJECTID')
            project_obj = TestProjectModel.objects.get(id=project_id)
            group_obj = Group.objects.create(
                name=project_obj.project_name + '用户组'
            )
            project_obj.user_group = group_obj
            project_obj.save()
        else:
            group_obj = self.get_queryset().first()
        self.check_object_permissions(request,group_obj)
        user_id = request.data.get('user_id')
        try:
            user_obj = UserModel.objects.get(id=user_id)
        except UserModel.DoesNotExist as e:
            return Response({'message':'用户不存在'}, status=HTTP_400_BAD_REQUEST)
        else:
            if request.method == 'POST':
                group_obj.user_set.add(user_obj)
                return Response({'message': '成功加入用户组'}, status=HTTP_200_OK)
            else:
                try:
                    group_obj.user_set.remove(user_obj)
                except Exception as e:
                    return Response('error', status=HTTP_400_BAD_REQUEST)
                return Response({'message': '成功移除项目组'}, status=HTTP_200_OK)
