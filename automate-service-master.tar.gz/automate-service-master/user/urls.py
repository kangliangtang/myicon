"""automate_test_py3 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url, include
from rest_framework.routers import DefaultRouter
from rest_framework_jwt.views import obtain_jwt_token, refresh_jwt_token, verify_jwt_token
from user import views

router = DefaultRouter(trailing_slash=False)
router.register(r'user', views.UserModelViewSet, base_name='user')
# router.register(r'/projectgroup', views.ProjectGroupmodelView, base_name='projectgroup')


urlpatterns = [
    # url(r'^test', views.TestAPIView.as_view()),
    # url(r'^(?P<pk>\d+)$', views.UserInfoAPIView.as_view()),
    url(r'^/login', obtain_jwt_token), # 登陆
    url(r'^/api-token-refresh', refresh_jwt_token), # 刷新token
    url(r'^/api-token-verify', verify_jwt_token),  # 校验token
]
