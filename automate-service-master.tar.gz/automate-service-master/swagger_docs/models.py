from django.db import models

# Create your models here.

from utils.model import BaseModel
from django.db import models, transaction
import json


class SwaggerDocsModel(BaseModel):
    AUTH_METHOD = (
        (0, '无'),
        (1, '用户名/密码'),
        (2, 'access token'),
        (3, 'OAuth')
    )

    docs_path = models.CharField(max_length=521, verbose_name='swagger文档地址', null=False)
    remark = models.TextField(verbose_name='备注',null=True)
    project = models.ForeignKey('project_caud.TestProjectModel', on_delete=models.CASCADE, verbose_name='所属项目',null=False)
    auth_method = models.SmallIntegerField(default=0, choices=AUTH_METHOD, verbose_name='认证方式')
    user_pass = models.CharField(max_length=521, verbose_name='用户名/密码',null=True)
    # password = models.TextField(verbose_name='密码',null=True)
    token = models.TextField(verbose_name='token',null=True)
    auth = models.TextField(verbose_name='认证密钥',null=True)

    class Meta:
        db_table = 'tb_swagger_docs'
        verbose_name = 'swagger文档信息'
        verbose_name_plural = 'swagger文档信息'

    @transaction.atomic
    def setIsdeleteTrue(self):
        self.is_delete = True
        self.save()
        # for swaggerlist in self.swaggerpathlistmodel_set.all():
        #     swaggerlist.setIsdeleteTrue()


class SwaggerPathListModel(BaseModel):
    path = models.TextField(verbose_name='接口地址',null=False)
    method = models.CharField(max_length=64, verbose_name='请求方式', null=False)
    name = models.CharField(max_length=521, verbose_name='接口名称', null=False)
    request = models.TextField(verbose_name='请求',null=True)
    respond = models.TextField(verbose_name='响应',null=True)
    project = models.ForeignKey('project_caud.TestProjectModel', on_delete=models.CASCADE, verbose_name='所属项目',
                                  null=False)
    swagger_docs = models.ForeignKey('SwaggerDocsModel', on_delete=models.CASCADE, verbose_name='所属swagger',
                                  null=False)


    class Meta:
        db_table = 'tb_swagger_path'
        verbose_name = 'swagger文档内的接口列表'
        verbose_name_plural = 'swagger文档内的接口列表'

    @transaction.atomic
    def setIsdeleteTrue(self):
        self.is_delete = True
        self.save()


