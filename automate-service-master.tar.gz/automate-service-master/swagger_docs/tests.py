from django.test import TestCase
import os, json
# Create your tests here.
path = 'http://127.0.0.1:8000/v2/choerodon/api-docs'
tmpres = os.popen('curl %s' % path).readlines()
tmpres = {
    "extraData": {
        "data": {
            "choerodon_route": {
                "url": None,
                "serviceId": "perf-automate-service",
                "helperService": None,
                "builtIn": None,
                "sensitiveHeaders": "Cookie,Set-Cookie,Access-Control-Allow-Origin,Access-Control-Allow-Credentials",
                "stripPrefix": True,
                "customSensitiveHeaders": True,
                "name": "perf-automate-service",
                "id": None,
                "retryable": None,
                "path": "/perf-automate-service/**"
            }
        }
    },
    "basePath": "/",
    "tags": [
        {
            "name": "perf_projects_interfaceCases_create-controller",
            "description": "perf_projects_interfaceCases_create-controller"
        },
        {
            "name": "perf_projects_scene_report-controller",
            "description": "perf_projects_scene_report-controller"
        },
        {
            "name": "perf_projects_scene_stop-controller",
            "description": "perf_projects_scene_stop-controller"
        },
        {
            "name": "perf_projects_scene_start-controller",
            "description": "perf_projects_scene_start-controller"
        },
        {
            "name": "perf_projects_scene_pressureInfo-controller",
            "description": "perf_projects_scene_pressureInfo-controller"
        },
        {
            "name": "perf_projects_scene_creatorList-controller",
            "description": "perf_projects_scene_creatorList-controller"
        },
        {
            "name": "perf_projects_scene_create-controller",
            "description": "perf_projects_scene_create-controller"
        },
        {
            "name": "perf_projects_scene_list-controller",
            "description": "perf_projects_scene_list-controller"
        },
        {
            "name": "health_list-controller",
            "description": "health_list-controller"
        },
        {
            "name": "perf_projects_scene_sceneTaskList-controller",
            "description": "perf_projects_scene_sceneTaskList-controller"
        },
        {
            "name": "perf_projects_create-controller",
            "description": "perf_projects_create-controller"
        },
        {
            "name": "perf_projects_list-controller",
            "description": "perf_projects_list-controller"
        },
        {
            "name": "perf_projects_report_logs_create-controller",
            "description": "perf_projects_report_logs_create-controller"
        },
        {
            "name": "perf_projects_partial_update-controller",
            "description": "perf_projects_partial_update-controller"
        },
        {
            "name": "perf_projects_update-controller",
            "description": "perf_projects_update-controller"
        },
        {
            "name": "perf_projects_delete-controller",
            "description": "perf_projects_delete-controller"
        },
        {
            "name": "perf_projects_read-controller",
            "description": "perf_projects_read-controller"
        },
        {
            "name": "perf_projects_scene_uploadExcelFile-controller",
            "description": "perf_projects_scene_uploadExcelFile-controller"
        },
        {
            "name": "perf_projects_scene_partial_update-controller",
            "description": "perf_projects_scene_partial_update-controller"
        },
        {
            "name": "perf_projects_scene_update-controller",
            "description": "perf_projects_scene_update-controller"
        },
        {
            "name": "perf_projects_scene_delete-controller",
            "description": "perf_projects_scene_delete-controller"
        },
        {
            "name": "perf_projects_scene_read-controller",
            "description": "perf_projects_scene_read-controller"
        },
        {
            "name": "perf_projects_reportInfo_list-controller",
            "description": "perf_projects_reportInfo_list-controller"
        },
        {
            "name": "sync_projects_create-controller",
            "description": "sync_projects_create-controller"
        },
        {
            "name": "sync_projects_update-controller",
            "description": "sync_projects_update-controller"
        },
        {
            "name": "perf_projects_report_update-controller",
            "description": "perf_projects_report_update-controller"
        },
        {
            "name": "perf_projects_report_partial_update-controller",
            "description": "perf_projects_report_partial_update-controller"
        },
        {
            "name": "perf_projects_report_create-controller",
            "description": "perf_projects_report_create-controller"
        },
        {
            "name": "perf_projects_report_read-controller",
            "description": "perf_projects_report_read-controller"
        },
        {
            "name": "sync_group_create-controller",
            "description": "sync_group_create-controller"
        },
        {
            "name": "sync_group_update-controller",
            "description": "sync_group_update-controller"
        },
        {
            "name": "sync_projects_closed_create-controller",
            "description": "sync_projects_closed_create-controller"
        },
        {
            "name": "sync_projects_reopen_create-controller",
            "description": "sync_projects_reopen_create-controller"
        },
        {
            "name": "perf_projects_scene_sceneList-controller",
            "description": "perf_projects_scene_sceneList-controller"
        },
        {
            "name": "perf_projects_scene_sceneNameList-controller",
            "description": "perf_projects_scene_sceneNameList-controller"
        }
    ],
    "info": {
        "description": "",
        "title": "Pastebin API",
        "version": ""
    },
    "host": "127.0.0.1:8000",
    "swagger": "2.0",
    "paths": {
        "/perf/projects/{project_id}/interfaceCases": {
            "post": {
                "consumes": [
                    "*/*"
                ],
                "operationId": "perf_projects_interfaceCases_create",
                "tags": [
                    "perf_projects_interfaceCases_create-controller"
                ],
                "parameters": [
                    {
                        "required": True,
                        "name": "project_id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    }
                ],
                "summary": "perf_projects_interfaceCases_create",
                "description": "{\n\"permission\":{\n    \"action\":\"post\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":True,\n    \"permissionPublic\":False,\n    \"permissionWithin\":false\n},\n\"label\":null\n}",
                "responses": {
                    "201": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            }
        },
        "/perf/projects/{project_id}/scene/{id}/report": {
            "get": {
                "consumes": [
                    "*/*"
                ],
                "operationId": "perf_projects_scene_report",
                "tags": [
                    "perf_projects_scene_report-controller"
                ],
                "parameters": [
                    {
                        "required": True,
                        "name": "project_id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    },
                    {
                        "required": True,
                        "name": "id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    }
                ],
                "summary": "perf_projects_scene_report",
                "description": "{\n\"permission\":{\n    \"action\":\"report\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":True,\n    \"permissionPublic\":False,\n    \"permissionWithin\":false\n},\n\"label\":null\n}",
                "responses": {
                    "200": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            }
        },
        "/perf/projects/{project_id}/scene/{id}/stop": {
            "post": {
                "consumes": [
                    "application/json"
                ],
                "summary": "perf_projects_scene_stop",
                "operationId": "perf_projects_scene_stop",
                "tags": [
                    "perf_projects_scene_stop-controller"
                ],
                "parameters": [
                    {
                        "required": True,
                        "name": "project_id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    },
                    {
                        "required": True,
                        "name": "id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    },
                    {
                        "name": "data",
                        "in": "body",
                        "schema": {
                            "required": [
                                "name"
                            ],
                            "type": "object",
                            "properties": {
                                "scene_set": {
                                    "type": "string",
                                    "description": ""
                                },
                                "executor": {
                                    "type": "string",
                                    "description": ""
                                },
                                "state": {
                                    "type": "string",
                                    "description": ""
                                },
                                "public_variable": {
                                    "type": "string",
                                    "description": ""
                                },
                                "parametric": {
                                    "type": "string",
                                    "description": ""
                                },
                                "is_delete": {
                                    "type": "string",
                                    "description": ""
                                },
                                "name": {
                                    "type": "string",
                                    "description": ""
                                },
                                "execute_time": {
                                    "type": "string",
                                    "description": ""
                                },
                                "interface_num": {
                                    "type": "integer",
                                    "description": ""
                                },
                                "pressure": {
                                    "type": "string",
                                    "description": ""
                                },
                                "describe": {
                                    "type": "string",
                                    "description": ""
                                }
                            }
                        }
                    }
                ],
                "description": "{\n\"permission\":{\n    \"action\":\"stop\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":True,\n    \"permissionPublic\":False,\n    \"permissionWithin\":false\n},\n\"label\":null\n}",
                "responses": {
                    "201": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            }
        },
        "/perf/projects/{project_id}/scene/{id}/start": {
            "post": {
                "consumes": [
                    "application/json"
                ],
                "summary": "perf_projects_scene_start",
                "operationId": "perf_projects_scene_start",
                "tags": [
                    "perf_projects_scene_start-controller"
                ],
                "parameters": [
                    {
                        "required": True,
                        "name": "project_id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    },
                    {
                        "required": True,
                        "name": "id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    },
                    {
                        "name": "data",
                        "in": "body",
                        "schema": {
                            "required": [
                                "name"
                            ],
                            "type": "object",
                            "properties": {
                                "scene_set": {
                                    "type": "string",
                                    "description": ""
                                },
                                "executor": {
                                    "type": "string",
                                    "description": ""
                                },
                                "state": {
                                    "type": "string",
                                    "description": ""
                                },
                                "public_variable": {
                                    "type": "string",
                                    "description": ""
                                },
                                "parametric": {
                                    "type": "string",
                                    "description": ""
                                },
                                "is_delete": {
                                    "type": "string",
                                    "description": ""
                                },
                                "name": {
                                    "type": "string",
                                    "description": ""
                                },
                                "execute_time": {
                                    "type": "string",
                                    "description": ""
                                },
                                "interface_num": {
                                    "type": "integer",
                                    "description": ""
                                },
                                "pressure": {
                                    "type": "string",
                                    "description": ""
                                },
                                "describe": {
                                    "type": "string",
                                    "description": ""
                                }
                            }
                        }
                    }
                ],
                "description": "{\n\"permission\":{\n    \"action\":\"start\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":True,\n    \"permissionPublic\":False,\n    \"permissionWithin\":false\n},\n\"label\":null\n}",
                "responses": {
                    "201": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            }
        },
        "/perf/projects/{project_id}/scene/{id}/pressureInfo": {
            "get": {
                "consumes": [
                    "*/*"
                ],
                "operationId": "perf_projects_scene_pressureInfo",
                "tags": [
                    "perf_projects_scene_pressureInfo-controller"
                ],
                "parameters": [
                    {
                        "required": True,
                        "name": "project_id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    },
                    {
                        "required": True,
                        "name": "id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    }
                ],
                "summary": "perf_projects_scene_pressureInfo",
                "description": "{\n\"permission\":{\n    \"action\":\"pressureInfo\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":True,\n    \"permissionPublic\":False,\n    \"permissionWithin\":false\n},\n\"label\":null\n}",
                "responses": {
                    "200": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            }
        },
        "/perf/projects/{project_id}/scene/creatorList": {
            "get": {
                "consumes": [
                    "*/*"
                ],
                "operationId": "perf_projects_scene_creatorList",
                "tags": [
                    "perf_projects_scene_creatorList-controller"
                ],
                "parameters": [
                    {
                        "required": True,
                        "name": "project_id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    }
                ],
                "summary": "perf_projects_scene_creatorList",
                "description": "{\n\"permission\":{\n    \"action\":\"creatorList\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":True,\n    \"permissionPublic\":False,\n    \"permissionWithin\":false\n},\n\"label\":null\n}",
                "responses": {
                    "200": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            }
        },
        "/perf/projects/{project_id}/scene": {
            "post": {
                "consumes": [
                    "application/json"
                ],
                "summary": "perf_projects_scene_create",
                "operationId": "perf_projects_scene_create",
                "tags": [
                    "perf_projects_scene_create-controller"
                ],
                "parameters": [
                    {
                        "required": True,
                        "name": "project_id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    },
                    {
                        "name": "data",
                        "in": "body",
                        "schema": {
                            "required": [
                                "name"
                            ],
                            "type": "object",
                            "properties": {
                                "scene_set": {
                                    "type": "string",
                                    "description": ""
                                },
                                "executor": {
                                    "type": "string",
                                    "description": ""
                                },
                                "state": {
                                    "type": "string",
                                    "description": ""
                                },
                                "public_variable": {
                                    "type": "string",
                                    "description": ""
                                },
                                "parametric": {
                                    "type": "string",
                                    "description": ""
                                },
                                "is_delete": {
                                    "type": "string",
                                    "description": ""
                                },
                                "name": {
                                    "type": "string",
                                    "description": ""
                                },
                                "execute_time": {
                                    "type": "string",
                                    "description": ""
                                },
                                "interface_num": {
                                    "type": "integer",
                                    "description": ""
                                },
                                "pressure": {
                                    "type": "string",
                                    "description": ""
                                },
                                "describe": {
                                    "type": "string",
                                    "description": ""
                                }
                            }
                        }
                    }
                ],
                "description": "{\n\"permission\":{\n    \"action\":\"create\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":True,\n    \"permissionPublic\":False,\n    \"permissionWithin\":false\n},\n\"label\":null\n}",
                "responses": {
                    "201": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            },
            "get": {
                "consumes": [
                    "*/*"
                ],
                "operationId": "perf_projects_scene_list",
                "tags": [
                    "perf_projects_scene_list-controller"
                ],
                "parameters": [
                    {
                        "required": True,
                        "name": "project_id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    },
                    {
                        "required": False,
                        "name": "start",
                        "description": "A page number within the paginated result set.",
                        "in": "query",
                        "type": "integer"
                    },
                    {
                        "required": False,
                        "name": "size",
                        "description": "Number of results to return per page.",
                        "in": "query",
                        "type": "integer"
                    },
                    {
                        "required": False,
                        "name": "search",
                        "description": "A search term.",
                        "in": "query",
                        "type": "string"
                    },
                    {
                        "required": False,
                        "name": "ordering",
                        "description": "Which field to use when ordering the results.",
                        "in": "query",
                        "type": "string"
                    }
                ],
                "summary": "perf_projects_scene_list",
                "description": "{\n\"permission\":{\n    \"action\":\"list\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":True,\n    \"permissionPublic\":False,\n    \"permissionWithin\":false\n},\n\"label\":null\n}",
                "responses": {
                    "200": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            }
        },
        "/health": {
            "get": {
                "consumes": [
                    "*/*"
                ],
                "operationId": "health_list",
                "tags": [
                    "health_list-controller"
                ],
                "parameters": [],
                "summary": "health_list",
                "description": "{\n\"permission\":{\n    \"action\":\"get\",\n    \"menuLevel\":None,\n    \"permissionLevel\":None,\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":False,\n    \"permissionPublic\":True,\n    \"permissionWithin\":false\n},\n\"label\":null\n}",
                "responses": {
                    "200": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            }
        },
        "/perf/projects/{project_id}/scene/sceneTaskList": {
            "get": {
                "consumes": [
                    "*/*"
                ],
                "operationId": "perf_projects_scene_sceneTaskList",
                "tags": [
                    "perf_projects_scene_sceneTaskList-controller"
                ],
                "parameters": [
                    {
                        "required": True,
                        "name": "project_id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    }
                ],
                "summary": "perf_projects_scene_sceneTaskList",
                "description": "{\n\"permission\":{\n    \"action\":\"sceneTaskList\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":True,\n    \"permissionPublic\":False,\n    \"permissionWithin\":false\n},\n\"label\":null\n}",
                "responses": {
                    "200": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            }
        },
        "/perf/projects": {
            "post": {
                "consumes": [
                    "application/json"
                ],
                "summary": "perf_projects_create",
                "operationId": "perf_projects_create",
                "tags": [
                    "perf_projects_create-controller"
                ],
                "parameters": [
                    {
                        "name": "data",
                        "in": "body",
                        "schema": {
                            "required": [
                                "env_info"
                            ],
                            "type": "object",
                            "properties": {
                                "env_info": {
                                    "type": "string",
                                    "description": ""
                                }
                            }
                        }
                    }
                ],
                "description": "{\n\"permission\":{\n    \"action\":\"create\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":True,\n    \"permissionPublic\":False,\n    \"permissionWithin\":false\n},\n\"label\":null\n}",
                "responses": {
                    "201": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            },
            "get": {
                "consumes": [
                    "*/*"
                ],
                "operationId": "perf_projects_list",
                "tags": [
                    "perf_projects_list-controller"
                ],
                "parameters": [],
                "summary": "perf_projects_list",
                "description": "{\n\"permission\":{\n    \"action\":\"list\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":True,\n    \"permissionPublic\":False,\n    \"permissionWithin\":false\n},\n\"label\":null\n}",
                "responses": {
                    "200": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            }
        },
        "/perf/projects/{project_id}/report/logs": {
            "post": {
                "consumes": [
                    "*/*"
                ],
                "operationId": "perf_projects_report_logs_create",
                "tags": [
                    "perf_projects_report_logs_create-controller"
                ],
                "parameters": [
                    {
                        "required": True,
                        "name": "project_id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    }
                ],
                "summary": "perf_projects_report_logs_create",
                "description": "{\n\"permission\":{\n    \"action\":\"post\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":False,\n    \"permissionPublic\":True,\n    \"permissionWithin\":false\n},\n\"label\":null\n}",
                "responses": {
                    "201": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            }
        },
        "/perf/projects/{project_id}": {
            "patch": {
                "consumes": [
                    "application/json"
                ],
                "summary": "perf_projects_partial_update",
                "operationId": "perf_projects_partial_update",
                "tags": [
                    "perf_projects_partial_update-controller"
                ],
                "parameters": [
                    {
                        "required": True,
                        "name": "project_id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    },
                    {
                        "name": "data",
                        "in": "body",
                        "schema": {
                            "type": "object",
                            "properties": {
                                "env_info": {
                                    "type": "string",
                                    "description": ""
                                }
                            }
                        }
                    }
                ],
                "description": "{\n\"permission\":{\n    \"action\":\"partial_update\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":True,\n    \"permissionPublic\":False,\n    \"permissionWithin\":false\n},\n\"label\":null\n}",
                "responses": {
                    "200": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            },
            "put": {
                "consumes": [
                    "application/json"
                ],
                "summary": "perf_projects_update",
                "operationId": "perf_projects_update",
                "tags": [
                    "perf_projects_update-controller"
                ],
                "parameters": [
                    {
                        "required": True,
                        "name": "project_id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    },
                    {
                        "name": "data",
                        "in": "body",
                        "schema": {
                            "required": [
                                "env_info"
                            ],
                            "type": "object",
                            "properties": {
                                "env_info": {
                                    "type": "string",
                                    "description": ""
                                }
                            }
                        }
                    }
                ],
                "description": "{\n\"permission\":{\n    \"action\":\"update\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":True,\n    \"permissionPublic\":False,\n    \"permissionWithin\":false\n},\n\"label\":null\n}",
                "responses": {
                    "200": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            },
            "delete": {
                "consumes": [
                    "*/*"
                ],
                "operationId": "perf_projects_delete",
                "tags": [
                    "perf_projects_delete-controller"
                ],
                "parameters": [
                    {
                        "required": True,
                        "name": "project_id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    }
                ],
                "summary": "perf_projects_delete",
                "description": "{\n\"permission\":{\n    \"action\":\"destroy\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":True,\n    \"permissionPublic\":False,\n    \"permissionWithin\":false\n},\n\"label\":null\n}",
                "responses": {
                    "204": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            },
            "get": {
                "consumes": [
                    "*/*"
                ],
                "operationId": "perf_projects_read",
                "tags": [
                    "perf_projects_read-controller"
                ],
                "parameters": [
                    {
                        "required": True,
                        "name": "project_id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    }
                ],
                "summary": "perf_projects_read",
                "description": "{\n\"permission\":{\n    \"action\":\"retrieve\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":True,\n    \"permissionPublic\":False,\n    \"permissionWithin\":false\n},\n\"label\":null\n}",
                "responses": {
                    "200": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            }
        },
        "/perf/projects/{project_id}/scene/uploadExcelFile": {
            "post": {
                "consumes": [
                    "application/json"
                ],
                "summary": "perf_projects_scene_uploadExcelFile",
                "operationId": "perf_projects_scene_uploadExcelFile",
                "tags": [
                    "perf_projects_scene_uploadExcelFile-controller"
                ],
                "parameters": [
                    {
                        "required": True,
                        "name": "project_id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    },
                    {
                        "name": "data",
                        "in": "body",
                        "schema": {
                            "required": [
                                "name"
                            ],
                            "type": "object",
                            "properties": {
                                "scene_set": {
                                    "type": "string",
                                    "description": ""
                                },
                                "executor": {
                                    "type": "string",
                                    "description": ""
                                },
                                "state": {
                                    "type": "string",
                                    "description": ""
                                },
                                "public_variable": {
                                    "type": "string",
                                    "description": ""
                                },
                                "parametric": {
                                    "type": "string",
                                    "description": ""
                                },
                                "is_delete": {
                                    "type": "string",
                                    "description": ""
                                },
                                "name": {
                                    "type": "string",
                                    "description": ""
                                },
                                "execute_time": {
                                    "type": "string",
                                    "description": ""
                                },
                                "interface_num": {
                                    "type": "integer",
                                    "description": ""
                                },
                                "pressure": {
                                    "type": "string",
                                    "description": ""
                                },
                                "describe": {
                                    "type": "string",
                                    "description": ""
                                }
                            }
                        }
                    }
                ],
                "description": "{\n\"permission\":{\n    \"action\":\"uploadExcelFile\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":True,\n    \"permissionPublic\":False,\n    \"permissionWithin\":false\n},\n\"label\":null\n}",
                "responses": {
                    "201": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            }
        },
        "/perf/projects/{project_id}/scene/{id}": {
            "patch": {
                "consumes": [
                    "application/json"
                ],
                "summary": "perf_projects_scene_partial_update",
                "operationId": "perf_projects_scene_partial_update",
                "tags": [
                    "perf_projects_scene_partial_update-controller"
                ],
                "parameters": [
                    {
                        "required": True,
                        "name": "project_id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    },
                    {
                        "required": True,
                        "name": "id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    },
                    {
                        "name": "data",
                        "in": "body",
                        "schema": {
                            "type": "object",
                            "properties": {
                                "scene_set": {
                                    "type": "string",
                                    "description": ""
                                },
                                "executor": {
                                    "type": "string",
                                    "description": ""
                                },
                                "state": {
                                    "type": "string",
                                    "description": ""
                                },
                                "public_variable": {
                                    "type": "string",
                                    "description": ""
                                },
                                "parametric": {
                                    "type": "string",
                                    "description": ""
                                },
                                "is_delete": {
                                    "type": "string",
                                    "description": ""
                                },
                                "name": {
                                    "type": "string",
                                    "description": ""
                                },
                                "execute_time": {
                                    "type": "string",
                                    "description": ""
                                },
                                "interface_num": {
                                    "type": "integer",
                                    "description": ""
                                },
                                "pressure": {
                                    "type": "string",
                                    "description": ""
                                },
                                "describe": {
                                    "type": "string",
                                    "description": ""
                                }
                            }
                        }
                    }
                ],
                "description": "{\n\"permission\":{\n    \"action\":\"partial_update\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":True,\n    \"permissionPublic\":False,\n    \"permissionWithin\":false\n},\n\"label\":null\n}",
                "responses": {
                    "200": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            },
            "put": {
                "consumes": [
                    "application/json"
                ],
                "summary": "perf_projects_scene_update",
                "operationId": "perf_projects_scene_update",
                "tags": [
                    "perf_projects_scene_update-controller"
                ],
                "parameters": [
                    {
                        "required": True,
                        "name": "project_id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    },
                    {
                        "required": True,
                        "name": "id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    },
                    {
                        "name": "data",
                        "in": "body",
                        "schema": {
                            "required": [
                                "name"
                            ],
                            "type": "object",
                            "properties": {
                                "scene_set": {
                                    "type": "string",
                                    "description": ""
                                },
                                "executor": {
                                    "type": "string",
                                    "description": ""
                                },
                                "state": {
                                    "type": "string",
                                    "description": ""
                                },
                                "public_variable": {
                                    "type": "string",
                                    "description": ""
                                },
                                "parametric": {
                                    "type": "string",
                                    "description": ""
                                },
                                "is_delete": {
                                    "type": "string",
                                    "description": ""
                                },
                                "name": {
                                    "type": "string",
                                    "description": ""
                                },
                                "execute_time": {
                                    "type": "string",
                                    "description": ""
                                },
                                "interface_num": {
                                    "type": "integer",
                                    "description": ""
                                },
                                "pressure": {
                                    "type": "string",
                                    "description": ""
                                },
                                "describe": {
                                    "type": "string",
                                    "description": ""
                                }
                            }
                        }
                    }
                ],
                "description": "{\n\"permission\":{\n    \"action\":\"update\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":True,\n    \"permissionPublic\":False,\n    \"permissionWithin\":false\n},\n\"label\":null\n}",
                "responses": {
                    "200": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            },
            "delete": {
                "consumes": [
                    "*/*"
                ],
                "operationId": "perf_projects_scene_delete",
                "tags": [
                    "perf_projects_scene_delete-controller"
                ],
                "parameters": [
                    {
                        "required": True,
                        "name": "project_id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    },
                    {
                        "required": True,
                        "name": "id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    }
                ],
                "summary": "perf_projects_scene_delete",
                "description": "{\n\"permission\":{\n    \"action\":\"destroy\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":True,\n    \"permissionPublic\":False,\n    \"permissionWithin\":false\n},\n\"label\":null\n}",
                "responses": {
                    "204": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            },
            "get": {
                "consumes": [
                    "*/*"
                ],
                "operationId": "perf_projects_scene_read",
                "tags": [
                    "perf_projects_scene_read-controller"
                ],
                "parameters": [
                    {
                        "required": True,
                        "name": "project_id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    },
                    {
                        "required": True,
                        "name": "id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    }
                ],
                "summary": "perf_projects_scene_read",
                "description": "{\n\"permission\":{\n    \"action\":\"retrieve\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":True,\n    \"permissionPublic\":False,\n    \"permissionWithin\":false\n},\n\"label\":null\n}",
                "responses": {
                    "200": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            }
        },
        "/perf/projects/{project_id}/reportInfo": {
            "get": {
                "consumes": [
                    "*/*"
                ],
                "operationId": "perf_projects_reportInfo_list",
                "tags": [
                    "perf_projects_reportInfo_list-controller"
                ],
                "parameters": [
                    {
                        "required": True,
                        "name": "project_id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    },
                    {
                        "required": False,
                        "name": "start",
                        "description": "A page number within the paginated result set.",
                        "in": "query",
                        "type": "integer"
                    },
                    {
                        "required": False,
                        "name": "size",
                        "description": "Number of results to return per page.",
                        "in": "query",
                        "type": "integer"
                    }
                ],
                "summary": "perf_projects_reportInfo_list",
                "description": "{\n\"permission\":{\n    \"action\":\"get\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":True,\n    \"permissionPublic\":False,\n    \"permissionWithin\":false\n},\n\"label\":null\n}",
                "responses": {
                    "200": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            }
        },
        "/sync/projects": {
            "post": {
                "consumes": [
                    "*/*"
                ],
                "operationId": "sync_projects_create",
                "tags": [
                    "sync_projects_create-controller"
                ],
                "parameters": [],
                "summary": "sync_projects_create",
                "description": "{\n\"permission\":{\n    \"action\":\"post\",\n    \"menuLevel\":None,\n    \"permissionLevel\":None,\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":False,\n    \"permissionPublic\":False,\n    \"permissionWithin\":true\n},\n\"label\":null\n}",
                "responses": {
                    "201": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            },
            "put": {
                "consumes": [
                    "*/*"
                ],
                "operationId": "sync_projects_update",
                "tags": [
                    "sync_projects_update-controller"
                ],
                "parameters": [],
                "summary": "sync_projects_update",
                "description": "{\n\"permission\":{\n    \"action\":\"put\",\n    \"menuLevel\":None,\n    \"permissionLevel\":None,\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":False,\n    \"permissionPublic\":False,\n    \"permissionWithin\":true\n},\n\"label\":null\n}",
                "responses": {
                    "200": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            }
        },
        "/perf/projects/{project_id}/report/{id}": {
            "put": {
                "consumes": [
                    "application/json"
                ],
                "summary": "perf_projects_report_update",
                "operationId": "perf_projects_report_update",
                "tags": [
                    "perf_projects_report_update-controller"
                ],
                "parameters": [
                    {
                        "required": True,
                        "name": "project_id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    },
                    {
                        "required": True,
                        "name": "id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    },
                    {
                        "name": "data",
                        "in": "body",
                        "schema": {
                            "required": [
                                "scene"
                            ],
                            "type": "object",
                            "properties": {
                                "executor": {
                                    "type": "string",
                                    "description": ""
                                },
                                "state": {
                                    "type": "string",
                                    "description": ""
                                },
                                "resp_time": {
                                    "type": "integer",
                                    "description": ""
                                },
                                "scene": {
                                    "type": "string",
                                    "description": ""
                                },
                                "report_file": {
                                    "type": "string",
                                    "description": ""
                                },
                                "stats": {
                                    "type": "string",
                                    "description": ""
                                },
                                "log_file": {
                                    "type": "string",
                                    "description": ""
                                },
                                "tps": {
                                    "type": "number",
                                    "description": ""
                                },
                                "is_delete": {
                                    "type": "string",
                                    "description": ""
                                },
                                "requests": {
                                    "type": "integer",
                                    "description": ""
                                },
                                "failure_rate": {
                                    "type": "number",
                                    "description": ""
                                }
                            }
                        }
                    }
                ],
                "description": "{\n\"permission\":{\n    \"action\":\"put\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":False,\n    \"permissionPublic\":True,\n    \"permissionWithin\":false\n},\n\"label\":null\n}",
                "responses": {
                    "200": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            },
            "patch": {
                "consumes": [
                    "application/json"
                ],
                "summary": "perf_projects_report_partial_update",
                "operationId": "perf_projects_report_partial_update",
                "tags": [
                    "perf_projects_report_partial_update-controller"
                ],
                "parameters": [
                    {
                        "required": True,
                        "name": "project_id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    },
                    {
                        "required": True,
                        "name": "id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    },
                    {
                        "name": "data",
                        "in": "body",
                        "schema": {
                            "type": "object",
                            "properties": {
                                "executor": {
                                    "type": "string",
                                    "description": ""
                                },
                                "state": {
                                    "type": "string",
                                    "description": ""
                                },
                                "resp_time": {
                                    "type": "integer",
                                    "description": ""
                                },
                                "scene": {
                                    "type": "string",
                                    "description": ""
                                },
                                "report_file": {
                                    "type": "string",
                                    "description": ""
                                },
                                "stats": {
                                    "type": "string",
                                    "description": ""
                                },
                                "log_file": {
                                    "type": "string",
                                    "description": ""
                                },
                                "tps": {
                                    "type": "number",
                                    "description": ""
                                },
                                "is_delete": {
                                    "type": "string",
                                    "description": ""
                                },
                                "requests": {
                                    "type": "integer",
                                    "description": ""
                                },
                                "failure_rate": {
                                    "type": "number",
                                    "description": ""
                                }
                            }
                        }
                    }
                ],
                "description": "{\n\"permission\":{\n    \"action\":\"patch\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":True,\n    \"permissionPublic\":False,\n    \"permissionWithin\":false\n},\n\"label\":null\n}",
                "responses": {
                    "200": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            },
            "post": {
                "consumes": [
                    "application/json"
                ],
                "summary": "perf_projects_report_create",
                "operationId": "perf_projects_report_create",
                "tags": [
                    "perf_projects_report_create-controller"
                ],
                "parameters": [
                    {
                        "required": True,
                        "name": "project_id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    },
                    {
                        "required": True,
                        "name": "id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    },
                    {
                        "name": "data",
                        "in": "body",
                        "schema": {
                            "required": [
                                "scene"
                            ],
                            "type": "object",
                            "properties": {
                                "executor": {
                                    "type": "string",
                                    "description": ""
                                },
                                "state": {
                                    "type": "string",
                                    "description": ""
                                },
                                "resp_time": {
                                    "type": "integer",
                                    "description": ""
                                },
                                "scene": {
                                    "type": "string",
                                    "description": ""
                                },
                                "report_file": {
                                    "type": "string",
                                    "description": ""
                                },
                                "stats": {
                                    "type": "string",
                                    "description": ""
                                },
                                "log_file": {
                                    "type": "string",
                                    "description": ""
                                },
                                "tps": {
                                    "type": "number",
                                    "description": ""
                                },
                                "is_delete": {
                                    "type": "string",
                                    "description": ""
                                },
                                "requests": {
                                    "type": "integer",
                                    "description": ""
                                },
                                "failure_rate": {
                                    "type": "number",
                                    "description": ""
                                }
                            }
                        }
                    }
                ],
                "description": "{\n\"permission\":{\n    \"action\":\"post\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":False,\n    \"permissionPublic\":True,\n    \"permissionWithin\":false\n},\n\"label\":null\n}",
                "responses": {
                    "201": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            },
            "get": {
                "consumes": [
                    "*/*"
                ],
                "operationId": "perf_projects_report_read",
                "tags": [
                    "perf_projects_report_read-controller"
                ],
                "parameters": [
                    {
                        "required": True,
                        "name": "project_id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    },
                    {
                        "required": True,
                        "name": "id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    }
                ],
                "summary": "perf_projects_report_read",
                "description": "{\n\"permission\":{\n    \"action\":\"get\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":True,\n    \"permissionPublic\":False,\n    \"permissionWithin\":false\n},\n\"label\":null\n}",
                "responses": {
                    "200": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            }
        },
        "/sync/group": {
            "post": {
                "consumes": [
                    "*/*"
                ],
                "operationId": "sync_group_create",
                "tags": [
                    "sync_group_create-controller"
                ],
                "parameters": [],
                "summary": "sync_group_create",
                "description": "{\n\"permission\":{\n    \"action\":\"post\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":False,\n    \"permissionPublic\":False,\n    \"permissionWithin\":true\n},\n\"label\":null\n}",
                "responses": {
                    "201": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            },
            "put": {
                "consumes": [
                    "*/*"
                ],
                "operationId": "sync_group_update",
                "tags": [
                    "sync_group_update-controller"
                ],
                "parameters": [],
                "summary": "sync_group_update",
                "description": "{\n\"permission\":{\n    \"action\":\"put\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":False,\n    \"permissionPublic\":False,\n    \"permissionWithin\":true\n},\n\"label\":null\n}",
                "responses": {
                    "200": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            }
        },
        "/sync/projects/closed": {
            "post": {
                "consumes": [
                    "*/*"
                ],
                "operationId": "sync_projects_closed_create",
                "tags": [
                    "sync_projects_closed_create-controller"
                ],
                "parameters": [],
                "summary": "sync_projects_closed_create",
                "description": "{\n\"permission\":{\n    \"action\":\"post\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":False,\n    \"permissionPublic\":False,\n    \"permissionWithin\":true\n},\n\"label\":null\n}",
                "responses": {
                    "201": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            }
        },
        "/sync/projects/reopen": {
            "post": {
                "consumes": [
                    "*/*"
                ],
                "operationId": "sync_projects_reopen_create",
                "tags": [
                    "sync_projects_reopen_create-controller"
                ],
                "parameters": [],
                "summary": "sync_projects_reopen_create",
                "description": "{\n\"permission\":{\n    \"action\":\"post\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":False,\n    \"permissionPublic\":False,\n    \"permissionWithin\":true\n},\n\"label\":null\n}",
                "responses": {
                    "201": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            }
        },
        "/perf/projects/{project_id}/scene/sceneList": {
            "get": {
                "consumes": [
                    "*/*"
                ],
                "operationId": "perf_projects_scene_sceneList",
                "tags": [
                    "perf_projects_scene_sceneList-controller"
                ],
                "parameters": [
                    {
                        "required": True,
                        "name": "project_id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    }
                ],
                "summary": "perf_projects_scene_sceneList",
                "description": "{\n\"permission\":{\n    \"action\":\"sceneList\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":True,\n    \"permissionPublic\":False,\n    \"permissionWithin\":false\n},\n\"label\":null\n}",
                "responses": {
                    "200": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            }
        },
        "/perf/projects/{project_id}/scene/sceneNameList": {
            "get": {
                "consumes": [
                    "*/*"
                ],
                "operationId": "perf_projects_scene_sceneNameList",
                "tags": [
                    "perf_projects_scene_sceneNameList-controller"
                ],
                "parameters": [
                    {
                        "required": True,
                        "name": "project_id",
                        "description": "",
                        "in": "path",
                        "type": "string"
                    }
                ],
                "summary": "perf_projects_scene_sceneNameList",
                "description": "{\n\"permission\":{\n    \"action\":\"sceneNameList\",\n    \"menuLevel\":None,\n    \"permissionLevel\":\"project\",\n    \"roles\":[\n\n    ],\n    \"permissionLogin\":True,\n    \"permissionPublic\":False,\n    \"permissionWithin\":false\n},\n\"label\":null\n}",
                "responses": {
                    "200": {
                        "description": ""
                    }
                },
                "produces": [
                    "*/*"
                ]
            }
        }
    },
    "securityDefinitions": {
        "basic": {
            "type": "basic"
        }
    },
    "schemes": [
        "http"
    ]
}

for key, value in tmpres['paths'].items():
    path = key
    for _key, _value in value.items():
        method = _key
        summary = _value.get('summmary', '')
        params = _value.get('parameters', [])
        respond = _value.get('responses', {})
        print(path, method, summary, params, respond)
# print(tmpres)