from django.apps import AppConfig


class SwaggerDocsConfig(AppConfig):
    name = 'swagger_docs'
