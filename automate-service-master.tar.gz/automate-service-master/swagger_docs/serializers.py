import json,os,copy
import requests
from swagger_docs.models import SwaggerDocsModel, SwaggerPathListModel
from rest_framework import serializers
from django.db import transaction
from utils.serializer import ZJsonField
from logging import getLogger
log = getLogger('debug')

class SwaggerDocsSerializer(serializers.ModelSerializer):
    user_pass = ZJsonField(default=[])
    token = ZJsonField(default=[])
    auth = ZJsonField(default=[])

    class Meta:
        model = SwaggerDocsModel
        # exclude = ('is_delete',)
        fields = ('id', 'docs_path', 'remark', 'user_pass', 'token', 'auth', 'auth_method')

    def validate_user_pass(self, data):
        if data:
            try:
                data_ = json.loads(data)
            except Exception as e:
                raise serializers.ValidationError('json格式错误')
            if not isinstance(data_, dict):
                raise serializers.ValidationError('格式错误，参数应该为json')
            return data

    def validate_token(self, data):
        if data:
            try:
                data_ = json.loads(data)
            except Exception as e:
                raise serializers.ValidationError('json格式错误')
            if not isinstance(data_, dict):
                raise serializers.ValidationError('格式错误，参数应该为json')
            return data

    def validate_auth(self, data):
        if data:
            try:
                data_ = json.loads(data)
            except Exception as e:
                raise serializers.ValidationError('json格式错误')
            if not isinstance(data_, dict):
                raise serializers.ValidationError('格式错误，参数应该为json')
            return data


    @transaction.atomic
    def create(self, validated_data):
        validated_data['project_id'] = self.context['view'].kwargs['project_id']
        instance = super().create(validated_data)
        # instance = super().create(validated_data)
        return instance

    def get_swagger_data(self, swagger_obj):
        path = swagger_obj.docs_path
        auth_method = swagger_obj.auth_method
        data_list = []
        tmpres = ''
        try:
            if auth_method == 0:
                tmpres = requests.get(path, timeout=2)
            if auth_method == 1:
                body = swagger_obj.user_pass
                tmpres = requests.post(path, body=body, timeout=2)
            if auth_method == 2:
                headers = swagger_obj.token
                if not isinstance(headers, dict):
                    headers = json.loads(headers)
                tmpres = requests.get(path, headers=headers, timeout=2)
            if auth_method == 3:
                headers = swagger_obj.auth
                if not isinstance(headers, dict):
                    headers = json.loads(headers)
                tmpres = requests.get(path, headers=headers, timeout=2)
            tmpres = json.loads(tmpres.text)
            if tmpres:
                for key, value in tmpres['paths'].items():
                    path = key
                    for _key, _value in value.items():
                        method = _key
                        summary = _value.get('summary', '')
                        params = _value.get('parameters', [])
                        respond = _value.get('responses', {})
                        param_list = []
                        details = {"method": "", "path": "", "description": "", "request": [], "respond": []}
                        details['method'] = method
                        details['path'] = path
                        details['description'] = summary
                        request_dict = {'name': '', 'required': '', 'type': '', 'object': '', 'inwhere': ''}
                        respond_dict = {'code': '', 'params': '', 'description': ''}
                        request_list = []
                        respond_list = []
                        for param in params:
                            param_list.append(param.get('name'))
                            request_dict['name'] = param.get('name', '')
                            request_dict['inwhere'] = param.get('in', '')
                            if param.get('in', '') == 'body':
                                schema = param.get('schema', {})
                                request_dict['type'] = schema.get('type', '')
                                request_dict['object'] = schema.get('properties', {})
                                request_dict['required'] = False if schema.get('required', '') else True
                            else:
                                request_dict['type'] = param.get('type', '')
                                request_dict['required'] = param.get('required', True)
                            request_list.append(copy.deepcopy(request_dict))
                        for respond_key, respond_value in respond.items():
                            respond_dict['code'] = respond_key
                            respond_dict['description'] = respond_value.get('description', '')
                            respond_list.append(copy.deepcopy(respond_dict))
                        data_list.append({'summary': summary, 'path':path, 'method':method, 'param':param_list, 'request': request_list, 'respond': respond_list})
                    data_list = sorted(data_list, key=lambda e: e.__getitem__("path"))
            return data_list
        except ValueError as e:
            log.info('获取到的swagger地址解析错误，可能swagger地址或返回格式不对。 error={}'.format(e))
            raise serializers.ValidationError({'message': '获取到的swagger地址解析错误，可能swagger地址或返回格式不对。'})
            # return []

        except Exception as e:
            log.error('获取到的swagger文档解析错误，可能格式不对, error={}'.format(e))
            raise serializers.ValidationError({'message': '获取到的swagger文档解析错误，可能格式不对。'})

