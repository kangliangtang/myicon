from rest_framework import mixins
from rest_framework.viewsets import GenericViewSet
from rest_framework.viewsets import ModelViewSet
from swagger_docs.models import SwaggerDocsModel, SwaggerPathListModel
from swagger_docs.serializers import SwaggerDocsSerializer
from rest_framework.response import Response
from rest_framework.status import HTTP_200_OK, HTTP_400_BAD_REQUEST
from rest_framework.decorators import list_route
from rest_framework.filters import OrderingFilter, SearchFilter
from django_filters.rest_framework import DjangoFilterBackend
from utils.operation_log import OperationLogDecorator

logde = OperationLogDecorator()


class SwaggerAPIView(ModelViewSet):
    serializer_class = SwaggerDocsSerializer
    queryset = None
    filter_backends = (DjangoFilterBackend, OrderingFilter, SearchFilter,)
    search_fields = ('docs_path',)
    ordering = ('-create_time',)

    def get_queryset(self):
        try:
            # project_id = self.request.META.get('HTTP_PROJECTID')
            project_id = self.kwargs['project_id']
            return SwaggerDocsModel.objects.filter(is_delete=False).filter(project_id=project_id)
        except Exception as e:
            return SwaggerDocsModel.objects.none()

    def destroy(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"destroy",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        obj = self.get_object()
        obj.setIsdeleteTrue()
        return Response('删除成功', status=HTTP_200_OK)

    def list(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"list",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super().list(request, *args, **kwargs)

    def create(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"create",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super().create(request, *args, **kwargs)

class SwaggerListAPIView(mixins.ListModelMixin, GenericViewSet):
    serializer_class = SwaggerDocsSerializer
    queryset = None
    filter_backends = (DjangoFilterBackend, OrderingFilter, SearchFilter,)
    # search_fields = ('docs_path',)
    ordering = ('-create_time',)

    def get_queryset(self):
        try:
            # project_id = self.request.META.get('HTTP_PROJECTID')
            project_id = self.kwargs['project_id']
            return SwaggerDocsModel.objects.filter(is_delete=False).filter(project_id=project_id)
        except Exception as e:
            return SwaggerDocsModel.objects.none()

    def destroy(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"destroy",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return Response('删除成功', status=HTTP_200_OK)

    def list(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"list",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        project_id = self.kwargs['project_id']
        swagger_id = request.query_params.get('swagger_id')
        if request.query_params.get('size') and request.query_params.get('start'):
            size = int(request.query_params.get('size'))
            page = int(request.query_params.get('start'))
        else:
            return Response({'message': '没有size或start参数'}, HTTP_400_BAD_REQUEST)
        swagger_obj = SwaggerDocsModel.objects.filter(project_id=project_id, id=swagger_id, is_delete=0)
        if swagger_obj.count() != 1:
            return Response({'message': '暂无数据'}, status=HTTP_200_OK)
        list_data = SwaggerDocsSerializer().get_swagger_data(swagger_obj.first())

        data = {
            'total': len(list_data),
            'list': list_data[(size * (page-1)):(size * (page))] if page > 1 else list_data[0:(size * page)]
        }

        return Response(data, status=HTTP_200_OK)


