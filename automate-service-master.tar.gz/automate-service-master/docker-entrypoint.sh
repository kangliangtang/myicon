#!/bin/bash
echo "==============migrate Database==============="
python manage.py migrate 

if [[ $@ == '' ]];then
   exec uwsgi -i uwsgi.ini
fi

exec $@
