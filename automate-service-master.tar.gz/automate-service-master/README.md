## 自动化接口测试平台

##### 切换到feature分支  git checkout -b feature_branchname origin/feature_branchname
##### 开发时在 feature 分支上开发
##### 合并master分支 需在gitlab上提交 合并请求
##### 收集静态文件python manage.py collectstatic
### 启动uwsgi服务器
```shell
10.0.99.136 上启动
uwsgi --ini uwsgi_99_136.ini
重启
uwsgi --reload uwsgi.pid
停止
uwsgi --stop uwsgi.pid
```
### 启动/重启celery
```bash
方法1
celery -A automate_test_py3 worker -l info
方法2
celery -A automate_test_py3 multi start w1 --logfile=./logs/celerylog.log
停止
celery -A automate_test_py3 multi stop w1 --logfile=./logs/celerylog.log

```

```
.

├── automate_test_py3 项目配置文件
├── case_flow         接口地图
├── helm              k8shelm文件
├── interface         接口 用例 场景 定时任务都在里面
├── logs               测试环境下 将日志保存到这里 生产 日志文件 在项目目录外层做持久化
├── manage.py
├── project_caud    项目 模块 功能在此处
├── README.md 
├── requirements.txt   项目依赖包
├── result_report      测试报告
├── system             操作日志 上传文件
├── user               用户
├── utils                和全局有关， 相关包管理
```

### For Docker
```shell
docker build -t ${image-name} .
docker run -d -p 8000:8000 ${image-name}
```
启动环境变量
- devops_env 运行环境(production生产环境) default:development
- 以下参数仅production有效

配置项|说明|默认值
--|--|--
DB_ENGINE | 数据库引擎 | mysql
DB_Name | 数据库名称 | automate_test
DB_User | 数据库连接用户 | root
DB_Password | 数据库连接密码 | mysql
DB_Host | 数据库连接地址 | 10.54.25.229
DB_Port | 数据库连接端口 | 3306
CELERY_BROKER_URL | celery连接字符串(仅开启celery有效) | amqp://guest:guest@10.0.49.90:5672/celery
开启celery定时器：celery -A automate_test_py3 beat -l info --scheduler django_celery_beat.schedulers:DatabaseScheduler