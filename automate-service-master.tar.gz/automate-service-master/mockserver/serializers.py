import json

from contract.models import ContractTestModel, ContractTestResModel
from rest_framework import serializers
from utils.serializer import ZJsonField,ZCharField
from mockserver.models import MockServerModel
from project_caud.models import TestProjectModel
from interface.models import InterfaceModel
from rest_framework.response import Response
from django.db import transaction


class MockServerSerializer(serializers.ModelSerializer):
    # name = serializers.ReadOnlyField(source='contract.interface.name')
    # project_name = serializers.ReadOnlyField(source='contract.project.project_name')
    # email_to = serializers.ReadOnlyField(source='reportid.create_time')
    # rule = ZCharField(label='规则', required=True)
    # value = ZJsonField(label='规则', required=True)


    class Meta:
        model = MockServerModel
        exclude = ('is_delete',)
        # fields = ('id', 'rule', 'value')


class MockServerListSerializer(serializers.ModelSerializer):
    # interface = serializers.ReadOnlyField(source='interface.name')
    interface_name = serializers.ReadOnlyField(source='interface.name')
    user_exe = serializers.ReadOnlyField(source='user_exe.username')
    interfaceid = serializers.ReadOnlyField(source='interface.id')
    path = ZCharField(label='path', required=True)
    content = ZJsonField(default=[])
    method = ZCharField(label='请求方式', required=True)
    url = serializers.ReadOnlyField(source='getUrl')


    class Meta:
        model = MockServerModel
        exclude = ('is_delete','create_time','project')
        # fields = ('interface', 'user_exe','update_time', 'interface_id')
    def validate_content(self, data):
        try:
            data_ = json.loads(data)
        except Exception as e:
            raise serializers.ValidationError('json格式错误')
        if not isinstance(data_, list):
            raise serializers.ValidationError('格式错误，参数因为数组')
        for dict_data in data_:
            if not isinstance(dict_data, dict):
                raise serializers.ValidationError('格式错误，每个参数对象应该为数组')
            if not dict_data.get('rule', None):
                raise serializers.ValidationError('格式错误，获取不到rule')
            if dict_data.get('rule', None) == '':
                raise serializers.ValidationError('rule不能为空字符串')
            if not isinstance(dict_data.get('value', None), dict) and dict_data.get('value', None) != '':
                if not isinstance(dict_data.get('value', None), list):
                    raise serializers.ValidationError('value参数应该为json串')

        return data

    @transaction.atomic
    def create(self, validated_data):
        interface = self.context['request'].data.get("interface", None)
        # project_id = self.context['request'].META.get('HTTP_PROJECTID')
        project_id = self.context['view'].kwargs['project_id']
        method = InterfaceModel.objects.get(id=int(interface)).method
        user_obj = self.context['request'].user
        path = InterfaceModel.objects.get(id=int(interface)).path
        validated_data['project'] = TestProjectModel.objects.get(id=project_id)
        validated_data['user_exe'] = user_obj
        validated_data['path'] = path
        validated_data['method'] = method
        return super().create(validated_data)


