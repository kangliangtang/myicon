from django.apps import AppConfig


class MockserverConfig(AppConfig):
    name = 'mockserver'
