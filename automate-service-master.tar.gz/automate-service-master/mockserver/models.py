from utils.model import BaseModel
from django.db import models, transaction


class MockServerModel(BaseModel):
    interface = models.ForeignKey('interface.InterfaceModel', on_delete=models.CASCADE, verbose_name='接口id')
    # rule = models.TextField(verbose_name='规则',null=True)
    # value = models.TextField(verbose_name='返回值',null=True)
    path = models.TextField(verbose_name='path', null=False)
    project = models.ForeignKey('project_caud.TestProjectModel', on_delete=models.CASCADE, verbose_name='所属项目',null=False)
    user_exe = models.ForeignKey('user.UserModel', on_delete=models.CASCADE, null=True, blank=True, verbose_name='操作人')
    method = models.TextField(verbose_name='规则', null=True)
    content = models.TextField(verbose_name='规则内容', null=True)

    class Meta:
        db_table = 'tb_mockserver'
        verbose_name = 'mockserver'
        verbose_name_plural = 'mockserver'

    @transaction.atomic
    def setIsdeleteTrue(self):
        self.is_delete = True
        self.save()

    def getUrl(self):
        path = self.path
        project_id = self.project_id
        return "/mock/{}{}".format( project_id, path)
