from interface.models import InterfaceModel
from mockserver.models import MockServerModel
from mockserver.serializers import  MockServerListSerializer
from rest_framework.filters import OrderingFilter, SearchFilter
from django.db.models.query_utils import Q
from project_caud.models import TestProjectModel, ProjectModuleModel
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.response import Response
from rest_framework.status import HTTP_200_OK, HTTP_400_BAD_REQUEST
from rest_framework.viewsets import ModelViewSet
from logging import getLogger
from rest_framework.decorators import list_route
from rest_framework.views import APIView
from utils.operation_log import OperationLogDecorator
logde = OperationLogDecorator()
logger = getLogger("log")


class MockServerListAPIView(ModelViewSet):
    serializer_class = MockServerListSerializer
    queryset = None
    filter_backends = (DjangoFilterBackend, SearchFilter, OrderingFilter)
    search_fields = ('interface__name',)
    ordering = ('-create_time',)

    def get_queryset(self):
        try:
            # project_id = self.request.META.get('HTTP_PROJECTID')
            project_id = self.kwargs['project_id']
            return MockServerModel.objects.filter(is_delete=False).filter(project_id=project_id)
        except Exception as e:
            return MockServerModel.objects.none()

    @list_route(methods=['GET'])
    def mockList(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"mockList",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        query_set = self.get_queryset().order_by('-create_time')
        serializer = MockServerListSerializer(query_set, many=True)
        return Response({'list': serializer.data}, status=HTTP_200_OK)

    @list_route(methods=['POST'])
    def checkexits(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"checkexits",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        data = request.data
        interface = data['interface_id']
        interface_obj = MockServerModel.objects.filter(Q(interface=interface)&Q(is_delete=0))
        if interface_obj.count() == 0:
            return Response({'message': 'mock规则未存在该接口', 'success': True}, HTTP_200_OK)
        else:
            return Response({'message': 'mock规则已经存在该接口', 'success': False}, HTTP_200_OK)

    def create(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"create",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        data = self.request.data
        # project_id = self.request.META.get('HTTP_PROJECTID', None)
        project_id = self.kwargs['project_id']
        if project_id is None:
            return Response({'message': '请选择项目', 'success': False}, HTTP_200_OK)
        # ------------校验接口和项目---------------------------------------------------------
        interface = data.get("interface", None)
        try:
            module_id = InterfaceModel.objects.get(id=int(interface)).module_id
            get_project_id = ProjectModuleModel.objects.get(id=module_id).project_id
        except Exception as e:
            return Response({'message': '没有该接口', 'success': False}, status=403)
        if get_project_id != int(project_id):
            return Response({'message': '该项目下不存在此接口', 'success': False}, status=HTTP_200_OK)
        project_obj = TestProjectModel.objects.get(id=project_id)
        if not project_obj:
            return Response({'message': '项目不存在', 'success': False}, status=HTTP_200_OK)
        if not project_obj.project_statu:
            return Response({'message': '项目已停用', 'success': False}, status=HTTP_200_OK)
        mock_obj = MockServerModel.objects.filter(Q(interface_id=interface)&Q(is_delete=0))
        if mock_obj.count() >= 1:
            return Response({'message': 'mock规则已经存在该接口', 'success': False}, HTTP_200_OK)
        try:
            request.data['path']=InterfaceModel.objects.get(id=int(interface)).path
            request.data['method']=InterfaceModel.objects.get(id=int(interface)).method
            serializer = self.get_serializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            self.perform_create(serializer)
        except Exception as e:
            logger.exception("输入规则参数request.data={}不正确，请重新确认。异常信息={}".format(request.data, e))
            return Response({'message': '输入规则格式不正确，请重新确认', 'success': False}, status=HTTP_400_BAD_REQUEST)
        return Response({'message': '保存成功', 'success': True}, HTTP_200_OK)

    def destroy(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"destroy",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        obj = self.get_object()
        obj.setIsdeleteTrue()
        return Response('删除成功', status=HTTP_200_OK)

    def update(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"update",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        try:
            interface = request.data.get("interface", None)
            request.data['path'] = InterfaceModel.objects.get(id=int(interface)).path
            request.data['method'] = InterfaceModel.objects.get(id=int(interface)).method
            intance = super().update(request, *args, **kwargs)
        except Exception as e:
            logger.exception("输入规则参数request.data={}不正确，请重新确认。异常信息={}".format(request.data, e))
            return Response({'message': '输入规则格式不正确，请重新确认', 'success': False}, status=HTTP_400_BAD_REQUEST)
        return Response({'message': '更新成功', 'success': True}, HTTP_200_OK)

    def retrieve(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"retrieve",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super().retrieve(request, *args, **kwargs)

    def partial_update(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"partial_update",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super().partial_update(request, *args, **kwargs)

    def list(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"list",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super().list(request, *args, **kwargs)


class MockServerAPIView(APIView):
    permission_classes = ()

    def post(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"post",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        message = self.run(request)
        return Response(message, HTTP_200_OK)

    def get(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"get",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        message = self.run(self.request)
        return Response(message, HTTP_200_OK)

    def put(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"put",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        message = self.run(self.request)
        return Response(message, HTTP_200_OK)

    def delete(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"delete",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        message = self.run(request)
        return Response(message, HTTP_200_OK)

    def patch(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"patch",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        message = self.run(request)
        return Response(message, HTTP_200_OK)

    def run(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"run",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        project_id = request.META.get('PATH_INFO').split('/')[2]
        path = request.META.get('PATH_INFO')[6+len(project_id):]
        method = request.META.get('REQUEST_METHOD')
        mock_path = MockServerModel.objects.filter(Q(project_id=int(project_id))&Q(path=path)&Q(method=method)&Q(is_delete=0))
        if mock_path.count() < 1:
            message = '未定义path={},method={}的mock数据'.format(path,method)
            return message
        data = request.data
        if len(data) == 0:
            data = request.query_params

        if len(data) < 1:
            message = '未定义参数值，请确认'
            return message
        #---------------获取参数-------------
        param_key = list(data.keys())
        #---------------获取规则-------------
        try:
            content = MockServerModel.objects.get(Q(project_id=int(project_id))&Q(path=path)&Q(method=method)&Q(is_delete=0)).content
            for line in eval(content):
                rule = line['rule']
                value = line['value']
                if '==' in rule:
                    rule_data = rule.split('==')[1].strip()
                    rule = rule.split('==')[0].strip()
                    if rule in param_key:
                        try:
                            rule_data = float(rule_data)
                            f_data = float(data[rule])
                        except:
                            rule_data = rule_data
                            f_data = data[rule]
                        if rule_data == f_data:
                            return value
                elif '!=' in rule:
                    rule_data = rule.split('!=')[1].strip()
                    rule = rule.split('!=')[0]
                    if rule in param_key:
                        try:
                            rule_data = float(rule_data)
                            f_data = float(data[rule])
                        except:
                            rule_data = rule_data
                            f_data = data[rule]
                        if rule_data != f_data:
                            return value
                elif 'contains' in rule:
                    rule_data = rule.split('contains')[1].strip()
                    rule = rule.split('contains')[0].strip()
                    if rule in param_key:
                        if data[rule] and rule_data in data[rule]:
                            return value
                elif 'in' in rule:
                    rule_data = rule.split('in')[1].strip()
                    rule = rule.split('in')[0].strip()
                    if rule in param_key:
                        if data[rule] and data[rule] in rule_data:
                            return value
                elif '<=' in rule:
                    rule_data = rule.split('<=')[1]
                    rule = rule.split('<=')[0]
                    if rule in param_key:
                        try:
                            rule_data = float(rule_data)
                            if float(data[rule]) <= rule_data:
                                return value
                        except:
                            pass
                elif '>=' in rule:
                    rule_data = rule.split('>=')[1]
                    rule = rule.split('>=')[0]
                    if rule in param_key:
                        try:
                            rule_data = float(rule_data)
                            if float(data[rule]) >= rule_data:
                                return value
                        except:
                            pass

                elif '<' in rule:
                    rule_data = rule.split('<')[1]
                    rule = rule.split('<')[0]
                    if rule in param_key:
                        try:
                            rule_data = float(rule_data)
                            if float(data[rule]) < rule_data:
                                return value
                        except:
                            pass

                elif '>' in rule:
                    rule_data = rule.split('>')[1]
                    rule = rule.split('>')[0]
                    if rule in param_key:
                        try:
                            rule_data = float(rule_data)
                            if float(data[rule]) > rule_data:
                                return value
                        except:
                            pass
            return '未找到匹配的规则，请确认。'
        except Exception as e:
            logger.exception("mock匹配规则失败request.data={}。异常信息={}。".format(request.data, e))
            return '匹配规则失败，可能存在相同path的规则，请确认，并删除其中一个。'






