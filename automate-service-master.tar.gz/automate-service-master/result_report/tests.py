import os
import shutil

from django.test import TestCase


# Create your tests here.

def copy_dirfile_to_dir(new_path, old_path):
    """
    把所有文件复制到新的文件夹
    递归函数
    :param new_path:
    :param old_path:
    :return:
    """
    if os.path.isfile(old_path):
        shutil.copy(old_path, new_path)
    elif os.path.isdir(old_path):
        for file_name in os.listdir(old_path):
            file_path = os.path.join(old_path, file_name)
            if os.path.isdir(file_path):
                copy_dirfile_to_dir(new_path, file_path)
            else:
                shutil.copy(file_path, new_path)


if __name__ == '__main__':
    copy_dirfile_to_dir('./dir2', './dir1')
