from rest_framework import serializers

from result_report.models import ResultReportModel, TaskResultReportModel, SummaryModel


class ResultReportSerializer(serializers.ModelSerializer):
    project_name = serializers.ReadOnlyField(source='project.project_name')
    interface_or_scene_name = serializers.ReadOnlyField(source='getCaseOrSceneName')
    # result_json = serializers.ReadOnlyField(source = 'summary.summary_count')
    result_json = serializers.ReadOnlyField(source='getSummaryCountData')
    user_exe_name = serializers.ReadOnlyField(source='user_exe.username')

    class Meta:
        model = ResultReportModel
        # exclude = ('is_delete', 'name', 'report_file_path')
        exclude = ('is_delete', 'name')


class TaskResultReportSerializer(serializers.ModelSerializer):
    task_name = serializers.ReadOnlyField(source='task.name')
    crontab_code = serializers.ReadOnlyField(source='task.crontab_code')

    class Meta:
        model = TaskResultReportModel
        exclude = ('is_delete', 'report_file_path', 'task', 'project')

class SummaryModelSerializer(serializers.ModelSerializer):

    class Meta:
        model = SummaryModel
        exclude= ('id','is_delete')