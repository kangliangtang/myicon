import json
import os

from django.db import models

# Create your models here.
from automate_test_py3 import settings
from case_flow.models import TestTaskModel
from utils.model import BaseModel
from utils.minio_service_file import MinioServiceFile


class ResultReportModel(BaseModel):
    CHOICES_STATUS = (
        ('running', '执行中'),
        ('false', '执行失败'),
        ('true', '执行成功'),
        ('error', '出错了')
    )
    name = models.CharField(max_length=128, verbose_name='测试报告名称')
    project = models.ForeignKey('project_caud.TestProjectModel', on_delete=models.CASCADE, verbose_name='所属项目')
    # mudole = models.ForeignKey('project_caud.ProjectModuleModel', on_delete=models.CASCADE, verbose_name='所属模块')
    interface = models.ForeignKey('interface.InterfaceModel', null=True, blank=True, on_delete=models.CASCADE, verbose_name='所属接口')
    interface_scen = models.ForeignKey('interface.InterfaceSceneModel',null=True, blank=True, on_delete=models.CASCADE, verbose_name='所属场景')
    status = models.CharField(default='running', max_length=20, choices=CHOICES_STATUS, verbose_name='测试执行状态')
    report_file_path = models.FilePathField(verbose_name='测试报告路径',null=True, blank=True)
    interface_case = models.ForeignKey('interface.InterfaceCaseModel', null=True, blank=True, on_delete=models.CASCADE, verbose_name='用例')
    testCaseTask = models.ForeignKey('case_flow.TestTaskModel', null=True, blank=True, on_delete=models.CASCADE, verbose_name='测试任务')
    user_exe = models.ForeignKey('user.UserModel', on_delete=models.CASCADE, null=True, blank=True, verbose_name='执行人')
    # count_exe = models.SmallIntegerField(default=1, verbose_name='执行次数') #执行次数


    class Meta:
        db_table = 'tb_result_report'
        verbose_name = '测试报告'
        verbose_name_plural = '测试报告'

    def getCaseOrSceneName(self):
        # if self.interface_scen is None:
        #     return self.name
        # return self.interface_scen.name
        return self.name

    def setIsdeleteTrue(self):
        self.is_delete = True
        self.save()

    # 任务中保存 最后执行人和最后执行时间 最后状态
    # def updateLastUserexec(self, username=None):
    #     if username is None:
    #         username = self.user_exe.username
    #     TestTaskModel.objects.filter(id=self.testCaseTask_id).update(user_exc=username)
    #
    # def updateLastTime(self, create_time=None):
    #     if create_time is None:
    #         create_time = self.create_time
    #     TestTaskModel.objects.filter(id=self.testCaseTask_id).update(task_Exc_time=create_time)
    #
    # def updateLastExecStatus(self, status=None):
    #     if status is None:
    #         status = self.status
    #     TestTaskModel.objects.filter(id=self.testCaseTask_id).update(task_status=status)

    def getSummaryCountData(self):
        """获取summary_count 文件的数据"""
        # data = ''
        # if self.summarymodel.summary_count:
        #     with open(self.summarymodel.summary_count, 'r') as f:
        #         data = f.read()
        # return json.dumps(data)

        summary_obj = SummaryModel.objects.filter(result_report_id=self.id).first()
        data = None
        try:
            if summary_obj and summary_obj.summary_count:
                # with open(summary_obj.summary_count, 'r') as f:
                #     data = json.loads(f.read())
                data = summary_obj.summary_count_data()
                data = json.loads(data)
        except Exception as e:
            pass
        return data



class TaskResultReportModel(BaseModel):
    CHOICES_STATUS = (
        ('running', '执行中'),
        ('false', '执行失败'),
        ('true', '执行成功'),
        ('error', '出错了')
    )
    task = models.ForeignKey('interface.TaskModel', on_delete=models.CASCADE, verbose_name='所属任务')
    status = models.CharField(default='running', choices=CHOICES_STATUS, max_length=10, verbose_name='测试执行状态')
    report_file_path = models.FilePathField(verbose_name='测试报告', null=True, blank=True)
    project = models.ForeignKey('project_caud.TestProjectModel', on_delete=models.CASCADE, verbose_name='所属项目')

    class Meta:
        db_table = 'tb_task_result_report'
        verbose_name_plural = '定时任务报告'
        verbose_name = '定时任务报告'

    def setIsdeleteTrue(self):
        self.is_delete = True
        self.save()
        SummaryModel.objects.filter(task_result_report_id=self.id, is_delete=False).update(is_delete=True)

    def task_report_html(self):
        """获取定时任务html文件"""
        if os.path.exists(self.report_file_path):
            return self.report_file_path

        file_path = ''
        if self.report_file_path:
            ret = self.report_file_path.split('/')
            bucket_name = ret[-2]
            file_name = ret[-1]
            minio_obj = MinioServiceFile()
            result = minio_obj.get_file(bucket_name=bucket_name, file_name=file_name, save_file_path=settings.REPORT_DIR)
            if result:
                # file_path = '{0}/{1}'.format(settings.REPORT_DIR, file_name)
                file_path = os.path.join(settings.REPORT_DIR, file_name)
        return file_path


class SummaryModel(BaseModel):
    result_report = models.OneToOneField('result_report.ResultReportModel', null=True, blank=True, on_delete=models.CASCADE, verbose_name='所属报告')
    task_result_report = models.OneToOneField('result_report.TaskResultReportModel', null=True, blank=True, on_delete=models.CASCADE, verbose_name='所属定时任务报告')
    # summary_count = models.TextField(verbose_name='summary数据')
    summary_count = models.FilePathField(null=True, blank=True, verbose_name='测试报告文件')    # summary数据文件路径（.json文件）
    total_cases = models.IntegerField(null=True, blank=True, verbose_name='运行用例数量')

    class Meta:
        db_table = 'tb_summary'
        verbose_name = '报告详情'
        verbose_name_plural = '报告详情'

    def summary_count_data(self):
        """获取summary count文件中的数据"""
        summary_count_data = json.dumps('')
        if self.summary_count:
            # todo 暂时先保留从本地获取，后期可删除
            if os.path.exists(self.summary_count):
                with open(self.summary_count, 'r') as f:
                    summary_count_data = f.read()
            else:
                # 从minio获取
                minio_obj = MinioServiceFile()
                # summary_count_path保存方式为 /桶名/文件名 示例：/bucket_name/test.json
                file_name = os.path.basename(self.summary_count)
                file_data = minio_obj.get_file_data(bucket_name=settings.REPORT_BUCKET_NAME, file_name=file_name)
                summary_count_data = file_data.decode()
        return summary_count_data
