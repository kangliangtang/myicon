import json
import os

import pytz
from django.contrib.auth.models import Group
from django.utils import timezone
from django.http.response import FileResponse

from rest_framework import viewsets
from rest_framework.decorators import detail_route
from rest_framework.generics import ListAPIView, DestroyAPIView, RetrieveAPIView
from rest_framework.response import Response
from rest_framework.status import HTTP_200_OK


from result_report.models import SummaryModel
from result_report.serializers import ResultReportSerializer, TaskResultReportSerializer, SummaryModelSerializer
from result_report.models import ResultReportModel, TaskResultReportModel

from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import filters

# 操作日志
from utils.operation_log import OperationLogDecorator
from django.utils.decorators import method_decorator
logde = OperationLogDecorator()


class ResultReportListAPIView(ListAPIView):
    serializer_class = ResultReportSerializer
    queryset = None
    filter_backends = [filters.SearchFilter,filters.OrderingFilter,DjangoFilterBackend]
    search_fields = ('project__project_name', 'interface_scen__name', 'interface__name')
    # filter_fields = ('create_time',)
    ordering = ('-create_time',)

    def get_queryset(self):
        user_obj = self.request.user
        user_group_obj = Group.objects.filter(user=user_obj)
        try:
            # project_id = self.request.META.get('HTTP_PROJECTID')
            project_id = self.kwargs['project_id']
            query_set = ResultReportModel.objects.filter(is_delete=False, project__project_statu=True).filter(project__id=project_id)
            if self.request.query_params.get('time_start'):
                start_time_str = self.request.query_params.get('time_start')
                end_time_str = self.request.query_params.get('time_end')
                start_time = timezone.datetime.strptime(start_time_str,'%Y-%m-%dT%H:%M:%S.%fZ').replace(tzinfo=pytz.utc)
                end_time = timezone.datetime.strptime(end_time_str,'%Y-%m-%dT%H:%M:%S.%fZ').replace(tzinfo=pytz.utc)
                end_time += timezone.timedelta(days=1)
                query_set = query_set.filter(create_time__range=(start_time, end_time))
            if user_obj.isSuperUser:
                return query_set
            else:
                return query_set.filter(project__user_group__in=user_group_obj)
        except Exception as e:
            return ResultReportModel.objects.none()

    def get(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"get",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super().get(request, *args, **kwargs)


class ResultReportAPIView(DestroyAPIView, RetrieveAPIView, viewsets.ViewSet):
    serializer_class = ResultReportSerializer
    queryset = None

    def get_queryset(self):
        user_obj = self.request.user
        user_group_obj = Group.objects.filter(user=user_obj)
        project_id = self.kwargs.get('project_id')
        if project_id:
            try:
                query_set = ResultReportModel.objects.filter(is_delete=False, project__project_statu=True).filter(project__id=project_id)
                if user_obj.isSuperUser:
                    return query_set
                else:
                    return query_set.filter(project__user_group__in=user_group_obj)
            except Exception as e:
                return ResultReportModel.objects.none()
        else:
            return ResultReportModel.objects.none()

    @method_decorator(logde.del_test_report)
    def destroy(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"destroy",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        obj =self.get_object()
        obj.setIsdeleteTrue()
        return Response('删除成功')

    def retrieve(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"retrieve",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        if self.get_object().status == 'running':
            return Response('任务状态为运行中，请待运行结束，或联系平台管理员')
        #下载报告
        if request.query_params.get('download', None):
            report_file_path_ = self.get_object().report_file_path
            # file_name = report_file_path_.split('/')[-1]
            # with open(report_file_path_, 'r') as f:
            #     file_ = f.read()
            if os.path.exists(report_file_path_):
                file_name = report_file_path_.split('/')[-1]
                with open(report_file_path_, 'r') as f:
                    file_ = f.read()
            else:
                # 从Minio 文件服务器获取文件数据
                from utils.minio_service_file import MinioServiceFile
                minio_obj = MinioServiceFile()
                ret = report_file_path_.split('/')
                bucket_name = ret[-2]
                file_name = ret[-1]
                file_data = minio_obj.get_file_data(bucket_name=bucket_name, file_name=file_name)
                file_ = file_data.decode()
            response = FileResponse(file_)
            response['Content-Type'] = 'application/octet-stream'
            response['Content-Disposition'] = 'attachment;filename={}'.format(file_name)
            response['Access-Control-Expose-Headers'] = 'Content-Disposition'  # 网关 跨域获取  Content-Disposition
            return response

        # resultJson = self.get_object().summarymodel.summary_count
        summary_count_data = None
        summary_obj = SummaryModel.objects.filter(result_report_id=self.get_object().id).first()
        try:
            if summary_obj and summary_obj.summary_count:
                # with open(summary_obj.summary_count, 'r') as f:
                #     summary_count_data = json.loads(f.read())
                summary_count_data = summary_obj.summary_count_data()
                summary_count_data = json.loads(summary_count_data)
        except Exception as e:
            pass
        return Response(summary_count_data)

    @detail_route(methods=['GET'])
    def status(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"status",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return Response({'status': self.get_object().status}, status=HTTP_200_OK)

    def get(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"get",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super().get(request, *args, **kwargs)


class TaskResultReportView(ResultReportListAPIView):
    serializer_class = TaskResultReportSerializer
    queryset = None
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ('task__name',)
    ordering = ('-create_time',)

    def get_queryset(self):
       return TaskResultReportModel.objects.filter(is_delete=False, project__project_statu=True).all()

class TaskResultReportViewSet(ResultReportAPIView):
    serializer_class = TaskResultReportSerializer
    queryset = None

    def get_queryset(self):
        user_obj = self.request.user
        user_group_obj = Group.objects.filter(user=user_obj)
        project_id = self.kwargs.get('project_id')
        if project_id:
            try:
                # project_id = self.request.META.get('HTTP_PROJECTID')
                query_set = TaskResultReportModel.objects.filter(is_delete=False, project__project_statu=True).filter(project__id=project_id)
                if user_obj.isSuperUser:
                    return query_set
                else:
                    return query_set.filter(project__user_group__in=user_group_obj)
            except Exception as e:
                return TaskResultReportModel.objects.none()
        else:
            return TaskResultReportModel.objects.none()

    @method_decorator(logde.del_report)
    def destroy(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"destroy",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        obj = self.get_object()
        obj.setIsdeleteTrue()
        return Response('删除成功')

class SummaryModelReportView(ResultReportAPIView):
    serializer_class = SummaryModelSerializer
    queryset = None

    def get_queryset(self):
        return SummaryModel.objects.filter(is_delete=False,result_report__project__project_statu=True).all()
