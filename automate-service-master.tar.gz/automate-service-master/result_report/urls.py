"""automate_test_py3 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url, include
from django.contrib import admin
from . import views
from rest_framework import routers

route = routers.DefaultRouter(trailing_slash=False)
route.register(r'task', views.TaskResultReportViewSet, base_name='task')
route.register(r'', views.ResultReportAPIView, base_name='result')


urlpatterns = [
   url(r'^report$',views.ResultReportListAPIView.as_view()),
   url(r'^report/task$',views.TaskResultReportView.as_view()),
   url(r'^report/',include(route.urls)),

   # url(r'^report/(?P<pk>\d+)/$',views.ResultReportAPIView.as_view()),
]
