from django.apps import AppConfig


class ResultReportConfig(AppConfig):
    name = 'result_report'
