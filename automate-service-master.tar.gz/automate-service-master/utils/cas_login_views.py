# from django.contrib.auth.models import User
from rest_framework.response import Response
from rest_framework.status import HTTP_401_UNAUTHORIZED

from user.models import Organization, UserModel
from rest_framework.authentication import BaseAuthentication
from rest_framework import exceptions

from user.serializers import SteamVerifyJSONWebTokenSerializer
from .innerApi import GatWay
from logging import getLogger
logger_debug = getLogger('log')


class SessionAuthentication(BaseAuthentication):

    def authenticate(self, request):
        include_url = ['API'] # URL root path
        if request._request.path.strip('/').split('/')[0] in include_url:
            meta = request._request.META
            print(meta)
            token = meta.get('HTTP_JWT_TOKEN')
            serializer = SteamVerifyJSONWebTokenSerializer(data={'token': token})
            serializer.is_valid(raise_exception=True)
            user = serializer.validated_data['user']
            return user, None

    def authenticate_header(self, request):
        return Response(status=HTTP_401_UNAUTHORIZED)


class LocalAuthentication(BaseAuthentication):
    def authenticate(self, request):
        return UserModel.objects.get(username='admin'), None

    def authenticate_header(self, request):
        return Response(status=HTTP_401_UNAUTHORIZED)
