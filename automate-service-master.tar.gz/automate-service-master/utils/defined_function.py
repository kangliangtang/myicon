import datetime
import shutil
import yara
import os
import sys
import subprocess
import tempfile
import time
import re
from functools import wraps
import signal
from django.conf import settings

from logging import getLogger
logger_debug = getLogger('log')


# 新增debugtalk.py 到testcase文件夹下
try:
    debugtalk_file = os.path.join(settings.TESTCASE_DIR, 'debugtalk.py')
    if not os.path.exists(debugtalk_file):
        shutil.copyfile('./debugtalk.py', debugtalk_file)
except Exception:
    pass


# 代码静态扫描 规则
FORBID_STRING_RULE = '''
                 rule Rule1
                    {   
                        strings:
                            //nocase 忽略大小写   fullword 全字搜索
                            $import = "import" nocase
                            $del = "del" nocase
                            $with_open = "with open" nocase fullword 
                            $open = "open" nocase fullword 
                            $os = "os.system" nocase fullword 
                        condition:
                            any of them
                    }
              '''

DEF_RULE = '''
                 rule Rule
                    {   
                        strings:
                            $def = "def" fullword 
                        condition:
                            //any of them
                            #def >1
                    }
              '''


JS_FORBID_STRING_RULE = '''
                 rule Rule
                    {   
                        strings:
                            // var fso=new ActiveXObject("Scripting.FileSystemObject")  禁止js文件操作
                            $ActiveXObject = "ActiveXObject" nocase fullword 
                            $Scripting_FileSystemObject = "Scripting.FileSystemObject"  nocase fullword 
                            // 禁止js加载第三方模块
                            $require = "require" fullword 
                        condition:
                            any of them
                    }
              '''

FUNCTION_RULE = '''
                 rule Rule
                    {   
                        strings:
                             $function = "function" fullword 
                        condition:
                            #function >1
                    }
              '''



# 返回值代码 模块
RETURN_VALUE_CODE = """def alter_response(response):
    response.status_code = 500
    response.headers["Content-Type"] = "html/text"
"""

# for循环代码 模块
ITERATE_CODE = """def alter_response(response):
    response.status_code = 500
    response.headers["Content-Type"] = "html/text"
"""

# 数组代码 模块
ARRAY_CODE = """def alter_response(response):
    response.status_code = 500
    response.headers["Content-Type"] = "html/text"
"""


# 默认代码
DEFAULT_CODE = """#!/usr/bin/python
# -*- coding: utf-8 -*-
def fn():
    pass


if __name__ == '__main__':
    fn()
"""

# js代码转化为python可执行code
JS2PYTHON_CODE = """def %s(response):
    code = '''%s'''
    import re
    import execjs
    function_name = re.search(r'function (.*?)\(.*?\){', code)
    function_name = function_name.group(1)
    js_comp = execjs.compile(code)
    resp_dict = dict()
    for attr in dir(response.resp_obj):
        if attr.startswith('_') or attr.endswith('_') or attr.endswith('()'):
            continue
        resp_dict[attr] = str(getattr(response.resp_obj, attr))
    result = js_comp.eval('{0}({1})'.format(function_name, resp_dict))
    if result and isinstance(result, dict):
        for key, value in result.items():
            try:
                setattr(response.resp_obj, key, value)
            except Exception:
                continue
"""



class KeywordException(Exception):
    """关键字错误"""
    def __init__(self, forbid_string=None, multiple_def=None):
        super().__init__()
        self.forbid_string = forbid_string
        self.multiple_def = multiple_def

    def __str__(self):
        if self.forbid_string:
            return '{0}函数暂时未开放'.format(self.forbid_string)
        elif self.multiple_def:
            return '只允许存在一个def关键字'


class FunctionRuntimeError(RuntimeError):
    def __init__(self, func_name=None, timeout=None):
        super().__init__()
        self.func_name = func_name
        self.timeout = timeout

    def __str__(self):
        return '{0}函数执行时间超时'.format(self.func_name)


class MemoryUseError(Exception):
    def __init__(self, func_name=None, memory_maxsize=None):
        super().__init__()
        self.func_name = func_name
        self.memory_maxsize = memory_maxsize

    def __str__(self):
        return '{0}函数消耗内存过大'.format(self.func_name)


class UnknownError(Exception):
    def __init__(self, func_name=None, msg=None):
        super().__init__()
        self.func_name = func_name
        self.msg = msg

    def __str__(self):
        return '{0}函数错误{1}'.format(self.func_name, self.msg)


class DefinedFunction(object):
    """自定义函数"""
    def __init__(self):
        self.TempFile = tempfile.mkdtemp(suffix='_test', prefix='python_')   # 临时文件夹
        self.FileNum = int(time.time() * 1000)                               # 文件名
        # self.EXEC = sys.executable                                         # python编译器位置
        self.EXEC = 'python3'                                                 # python编译器位置
        self.timeout = 10                                                     # 执行超时时间（秒）
        self.memory_maxsize = 400 * 1024 * 1024                              # 单位(字节 B)
        # self.file_path = settings.TESTCASE_DIR +'/' + 'debugtalkload.py'
        self.file_path = settings.TESTCASE_DIR
        # self.file_path = './'

    @staticmethod
    def msg_decode(msg):
        """编码"""
        try:
            return msg.decode('utf-8')
        except UnicodeDecodeError:
            return msg.decode('gbk')

    @staticmethod
    def get_version():
        """获取python版本"""
        v = sys.version_info
        version = "python %s.%s" % (v.major, v.minor)
        return version

    def get_pyname(self):
        """获得py文件名"""
        return 'test_%d' % self.FileNum

    def __write_file(self, pyname, code):
        """接收代码写入文件"""
        fpath = os.path.join(self.TempFile, '%s.py' % pyname)
        with open(fpath, 'w', encoding='utf-8') as f:
            f.write(code)
        return fpath

    def error_msg(self, error_msg):
        """错误信息处理"""
        error_msg = self.msg_decode(error_msg)
        message = error_msg.replace('\r', '').replace('\n', '')
        re_match = re.search(r'File \"(.*?)\",', message)
        if re_match:
            message = message.replace(re_match.group(0), '')
        message = 'Error: %s' % message
        return message

    def code_scan(self, code, rule):
        """代码静态扫描"""
        code = str(code)
        rules = yara.compile(source=rule)
        matches = rules.match(data=code)
        forbid_string = []
        if matches:
            matches_result = matches[0].strings  # 匹配结果
            forbid_string = [self.msg_decode(ret[2]) for ret in matches_result]
        return forbid_string

    def limit_memory(self, maxsize):
        """进程内存限制"""
        import resource
        soft, hard = resource.getrlimit(resource.RLIMIT_AS)
        resource.setrlimit(resource.RLIMIT_AS, (maxsize, hard))
        resource.setrlimit(resource.RLIMIT_CPU, (self.timeout, hard))
        # size = resource.getpagesize()
        # print('进程自身', resource.getrusage(resource.RUSAGE_SELF))
        # print('子进程', resource.getrusage(resource.RUSAGE_CHILDREN))
        # print('当前线程', resource.getrusage(resource.RUSAGE_THREAD))

    @staticmethod
    def set_timeout(num):
        """超时限制"""
        def wrap(func):
            def handle(signum, frame):  # 收到信号 SIGALRM 后的回调函数，第一个参数是信号的数字，第二个参数是the interrupted stack frame.
                raise RuntimeError
            def to_do(*args):
                try:
                    signal.signal(signal.SIGALRM, handle)  # 设置信号和回调函数
                    signal.alarm(num)  # 设置 num 秒的闹钟
                    print('start alarm signal.')
                    resp = func(*args)
                    print('close alarm signal.')
                    signal.alarm(0)  # 关闭闹钟
                    return resp
                except RuntimeError as e:
                    raise RuntimeError
            return to_do
        return wrap

    def debug(self, code):
        """代码执行测试"""
        run_result = dict()
        forbid_string = self.code_scan(code=code, rule=FORBID_STRING_RULE)
        if forbid_string:
            forbid_string = ','.join(forbid_string)
            run_result["message"] = '%s函数暂未开放' % forbid_string
            run_result["success"] = False
            return run_result

        run_result["version"] = self.get_version()
        pyname = self.get_pyname()
        fpath = self.__write_file(pyname, code)
        try:
            self.limit_memory(maxsize=self.memory_maxsize)
            # subprocess.check_output 父进程等待子进程完成，返回子进程向标准输出的输出结果   stderr是标准输出的类型
            outdata = self.msg_decode(subprocess.check_output([self.EXEC, fpath], stderr=subprocess.STDOUT, timeout=self.timeout))
        except subprocess.CalledProcessError as e:
            # e.output 错误信息标准输出
            message = self.error_msg(e.output)
            run_result["message"] = message
            run_result["success"] = False
            return run_result
        except subprocess.TimeoutExpired as e:
            msg = 'Error: timed out after %d seconds' % self.timeout
            run_result["message"] = msg
            run_result["success"] = False
            return run_result
        except Exception as e:
            run_result = {"message": "Error: %s" % e, "success": False}
            return run_result
        else:
            # 成功返回的数据
            run_result["message"] = outdata
            run_result["success"] = True
            return run_result
        finally:
            try:
                os.remove(fpath)       # 删除临时文件
            except Exception as e:
                exit(1)

    def write_debugtalk(self, code, funname, programlang):
        """将自定义函数写入debugtalk"""
        funname_file = funname + '.py'
        self.file_path = os.path.join(self.file_path, funname_file)
        try:
            if not os.path.exists(self.file_path):
                with open(self.file_path, 'w') as f:
                    t = datetime.datetime.utcnow()
                    import_lib = 'from utils.defined_function import safetyControl'
                    f.write('# %s' % t + '\n')
                    f.write(import_lib)
                    f.write('\n\n')
            with open(self.file_path, 'a') as f:
                # write_code = self.write_code(code=code)
                if programlang == 'JavaScript':
                    write_code = self.write_js_code(funname=funname, js_code=code)
                else:
                    write_code = self.write_code(code=code)
                    f.write('@safetyControl' + '\n')
                # f.write('\n')
                f.write(write_code)
                f.write('\n\n')
        except Exception as e:
            logger_debug.info('自定义函数代码写入debugtalk.py出错:%s' % e)

    @staticmethod
    def write_code(code):
        regexp1 = r"""(if __name__ == '__main__':.*?)"""
        # regexp2 = r"print\(.*?\)"
        ret1 = re.findall(regexp1, code, re.S)
        if ret1:
            for rest in ret1:
                code = code.replace(rest, '')
        return code

    @staticmethod
    def write_js_code(funname, js_code):
        """将js代码转化为python可执行代码"""
        return JS2PYTHON_CODE % (funname, js_code)


def safetyControl(func):
    """安全控制"""
    @wraps(func)
    def wrapper(data, *args, **kwargs):
        func_name_ = func.__name__
        fn_list = func_name_.split('_')
        func_name = '_'.join(fn_list[:-1])
        try:
            def handle(signum, frame):
                raise RuntimeError
            obj = DefinedFunction()
            ret = obj.code_scan(data, rule=FORBID_STRING_RULE)
            if ret:
                # 未开放函数
                forbid_string = ','.join(list(set(ret)))
                raise KeywordException(forbid_string=forbid_string)
            scan_def = obj.code_scan(data, rule=DEF_RULE)
            if scan_def:
                if len(scan_def) > 1:
                    raise KeywordException(multiple_def=scan_def)
            obj.limit_memory(maxsize=obj.memory_maxsize)
            signal.signal(signal.SIGALRM, handle)
            signal.alarm(obj.timeout)
            resp = func(data, *args, **kwargs)
            signal.alarm(0)
            return resp
        except RuntimeError as e:
            raise FunctionRuntimeError(func_name)
        except MemoryError as e:
            raise MemoryUseError(func_name)
        except Exception as e:
            raise UnknownError(func_name=func_name, msg=e)
    return wrapper


if __name__ == '__main__':
    code = 'import def del defied DEF  function'
    obj = DefinedFunction()
    # ret = obj.code_scan(code, rule=DEF_RULE)
    # print(ret)

    js_code = """function set_test(response){
                       response.status_code = 403;
                       response.headers= 'html/test';
                       return response;
            };"""

    obj.write_debugtalk(code=js_code, funname='test_js_00001', programlang='JavaScript')


