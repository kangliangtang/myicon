import hashlib
import base64
from Crypto.Cipher import AES
from binascii import b2a_hex, a2b_hex
from automate_test_py3 import settings
import os
from Crypto.Cipher import PKCS1_v1_5 as Cipher_pkcs1_v1_5

class EncryptionAndDecryption(object):
    """MD5 base64 AES加解密"""
    def __init__(self, mode, content, operation, SECRET_KEY=None, aes_key=None):
        self.mode = mode
        self.content = str(content)
        self.operation = operation
        # 加解密方式
        self.__mode = ((0, 'MD5'), (1, 'base64'), (2, 'AES'), (3, 'rsa'))
        # 加密or解密
        self.__operation = ((0, '加密'), (1, '解密'))
        # AES加解密模式
        self.aes_mode = AES.MODE_ECB
        # AES秘钥(自定义)
        # self.aes_key = 'EncryptionAndDecryptionAESKey'
        self.aes_key = aes_key

        # 公私钥
        self.SECRET_KEY = SECRET_KEY
        self.private_key = None
        self.publi_key = None
        self.rsa = None

    def generatPrivateKey(self):
        """
        生成私钥
        :return:
        """
        from Crypto.PublicKey import RSA
        from Crypto import Random
        random_generator = Random.new().read
        self.random = random_generator
        rsa = RSA.generate(1024, random_generator)   # 1024 key的最大值
        self.rsa = rsa
        private_pem = rsa.exportKey()
        self.private_key = private_pem
        return private_pem

    def savePrivateKey(self, file_path = None):
        """
        保存私钥
        :param file_path:
        :return:
        """
        file_path = file_path if file_path else os.path.join(settings.PEM_FILE_PATH, 'private_key.pem')
        with open(file_path, 'wb') as f:
            f.write(self.private_key)

    def generatPubliKey(self):
        """
        生成公钥
        :return:
        """
        publi_key = self.rsa.publickey().exportKey()
        self.publi_key = publi_key
        return publi_key

    def savePubliKey(self, file_path=None):
        """
        保存公钥
        :param file_path:
        :return:
        """
        file_path = file_path if file_path else os.path.join(settings.PEM_FILE_PATH, 'public_key.pem')
        with open(file_path, 'wb') as f:
            f.write(self.publi_key)

    def signerData_(self, data=None, public_key_file_path=None):
        """
        加密数据
        :param message:
        :return:
        """
        from Crypto.PublicKey import RSA
        if public_key_file_path is None:
            public_key_file_path = os.path.join(settings.PEM_FILE_PATH, 'public_key.pem')
        with open(public_key_file_path) as f:
            key = f.read()
            rsakey = RSA.importKey(str(key))
            cipher = Cipher_pkcs1_v1_5.new(rsakey)
            if not isinstance(data, bytes):
                data = data.encode('utf-8')
            cipher_text = cipher.encrypt(data)
        return cipher_text

    def signerData(self, data=None, public_key_file_path=None):
        return base64.b64encode(self.signerData_(data=data, public_key_file_path=public_key_file_path))

    def rsa_long_encrypt(self, data):
        """
        分段加密
        :param data:
        :return:
        """
        data = data.encode('utf-8')
        length = len(data)
        default_length = 117
        # 公钥加密

        # 长度不用分段
        if length < default_length:
            return base64.b64encode(self.signerData_(data))
        # 需要分段
        offset = 0
        res = []
        while length - offset > 0:
            if length - offset > default_length:
                res.append(self.signerData_(data[offset:offset + default_length]))
            else:
                res.append(self.signerData_(data[offset:]))
            offset += default_length
        byte_data = b''.join(res)

        return base64.b64encode(byte_data)

    def decryptData_(self, data, private_key_file_path=None):
        """
        解密数据
        :param data: 密文
        :param secret_key: 安全密钥 默认是django的 SECRET_KEY
        :return:
        """
        from Crypto.PublicKey import RSA
        from Crypto.Cipher import PKCS1_v1_5 as Cipher_pkcs1_v1_5
        if private_key_file_path is None:
            private_key_file_path = os.path.join(settings.PEM_FILE_PATH, 'private_key.pem')
        if not hasattr(self,'cipher'):
        # if self.cipher is None:
            with open(private_key_file_path) as f:
                key = f.read()
                rsakey = RSA.importKey(key)
                self.cipher = Cipher_pkcs1_v1_5.new(rsakey)
        text = self.cipher.decrypt(data, self.SECRET_KEY)
        return text # 返回解密的数据

    def decryptData(self, data, private_key_file_path=None):
        data = base64.b64decode(data)
        return self.decryptData_(data, private_key_file_path)

    def rsa_long_decrypt(self, data, private_key_file_path=None):
        """
        分段解密
        :param data:
        :param private_key_file_path:
        :return:
        """
        result_data = []
        default_len = 128
        data = base64.b64decode(data)
        private_key_file_path = os.path.join(settings.PEM_FILE_PATH, 'private_key.pem')
        with open(private_key_file_path) as f:
            key = f.read()
            from Crypto.PublicKey import RSA
            rsakey = RSA.importKey(key)
            self.cipher = Cipher_pkcs1_v1_5.new(rsakey)

        while True:
            if data[:default_len].__len__():
                data_ = data[:default_len]
                result_data.append(self.decryptData_(data=data_))
            else:
                break
            data = data[default_len:]
        return b''.join(result_data)

    def generate_aes_key(self):
        """AES秘钥检验"""
        aes_key = self.aes_key
        if type(aes_key) == str:
            aes_key = bytes(aes_key, 'utf-8')
        # aes_key必须为16的倍数
        while len(aes_key) % 16 != 0:
            aes_key += b' '
        return aes_key

    def md5_encry(self):
        """md5加密"""
        plaintext = self.content
        obj = hashlib.md5()
        # 声明encode
        obj.update(plaintext.encode(encoding='utf-8'))
        encry_ret = obj.hexdigest()
        return encry_ret

    def base64_encry(self):
        """base64加密"""
        plaintext = self.content
        base64_encry = base64.b64encode(plaintext.encode('utf-8'))
        return base64_encry

    def base64_decry(self):
        """base64解密"""
        ciphertext = self.content
        base64_decry = (base64.b64decode(ciphertext)).decode('utf-8')
        return base64_decry

    def aes_encrypt(self):
        """AES加密 """
        aes_mode = self.aes_mode
        message = self.content
        if type(message) == str:
            message = bytes(message, 'utf-8')
        # message必须为16的倍数
        while len(message) % 16 != 0:
            message += b' '
        aes_key = self.generate_aes_key()
        # 加密对象aes
        aes = AES.new(key=aes_key, mode=aes_mode)
        encrypt_message = aes.encrypt(plaintext=message)
        return b2a_hex(encrypt_message)

    def aes_decrypt(self):
        """AES解密"""
        aes_mode = self.aes_mode
        aes_key = self.generate_aes_key()
        encrypt_message = self.content
        aes = AES.new(key=aes_key, mode=aes_mode)
        decrypted_text = aes.decrypt(a2b_hex(encrypt_message))
        decrypted_text = decrypted_text.rstrip()                 # 去空格
        return decrypted_text.decode()

    def translate(self):
        """加解密"""
        resp_content = ''
        self.mode = int(self.mode)
        self.operation = int(self.operation)
        # 加密
        if self.operation == 0:
            if self.mode == 0:
                resp_content = self.md5_encry()
            elif self.mode == 1:
                resp_content = self.base64_encry()
            elif self.mode == 2:
                resp_content = self.aes_encrypt()
        # 解密
        elif self.operation == 1:
            if self.mode == 0:
                resp_content = 'MD5暂不支持解密'
            elif self.mode == 1:
                resp_content = self.base64_decry()
            elif self.mode == 2:
                resp_content = self.aes_decrypt()
        else:
            resp_content = '不支持此方式'
        return resp_content


if __name__ == '__main__':
    obj = EncryptionAndDecryption(mode=0, content=1111, operation=0)
    ret = obj.translate()
    print(ret)
