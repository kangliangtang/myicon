import json
from django.utils.translation import ugettext_lazy as _
from rest_framework import serializers
from rest_framework.serializers import Serializer

from automate_test_py3 import settings
from user.models import UserModel


class ZJsonField(serializers.JSONField):
    """
    Color objects are serialized into 'rgb(#, #, #)' notation.
    """
    default_error_messages = {
        'invalid_json': _('无效的json格式.')
    }
    def to_representation(self, value):
        try:
            value = json.loads(value)
        except Exception as e:
            print('utils-->serializer--->',e)
            value = None
        return value

    def to_internal_value(self, data):

        if isinstance(data, str):
            try:
               json.loads(data)
            except (TypeError, ValueError):
                self.fail('invalid_json')
            return data
        return json.dumps(data)


class BodyDataJsonXmlField(ZJsonField):
    def to_representation(self, value):
        try:
            value = json.loads(value)
        except Exception as e:
            pass
            #xml
        return value

    def to_internal_value(self, data):
        try:
            return json.dumps(data)
        except Exception as e:
            #xml
            return data


class ProjectLeadField(serializers.Field):

    def to_representation(self, value):
        return value

    def to_internal_value(self, data):
        user_obj = UserModel.objects.get(id=data)
        return user_obj


class ZCharField(serializers.CharField):

    default_error_messages = {
        'invalid': _('无效的字符串'),
        'blank': _('此字段不能为空'),
        'max_length': _('此字段不超过最大长度{max_length}个字符'),
        'min_length': _('此字段不低于最小长度{min_length}个字符')
    }
    pass


class BodyDataJsonField(ZJsonField):
    def to_internal_value(self, data):

        if isinstance(data, str):
            try:
                data = json.loads(data)
            except (TypeError, ValueError):
                self.fail('invalid_json')
        # body_data = json.dumps(data)
        if isinstance(data, dict):
            body_data_list = []
            for body_data_key in data.keys():
                body_data_list.append(
                    {
                        'key': body_data_key,
                        'value': data[body_data_key],
                        'type': settings.PYTHON_DATA_TYPE_TO_JS_DATA_TYPE[type(data[body_data_key]).__name__]
                    })
            return json.dumps(body_data_list)
        return json.dumps(data)


class ZReadOnlyField(serializers.ReadOnlyField):
    pass

class ZStringRelatedField(serializers.StringRelatedField):
    pass

class ZModelSerializer(serializers.ModelSerializer):
    pass


class ZCharFields(serializers.CharField):
    """
    用于接口导入是检验接口名
    """

    # def to_representation(self, value):
    #     # if value.__len__() > 64:
    #     #     value = value[:63]
    #     return value
    #
    # def to_internal_value(self, data):
    #     return '123/123'


class AppcalitionEnvSerializer(serializers.Field):

    def to_representation(self, value):
        return value

    def to_internal_value(self, data):
        return data


class PublishUserNameReadOnlyField(serializers.Field):
    def to_representation(self, value):
        return value

    def to_internal_value(self, data):
        # 创建人 取 当前用户
        return data

    def get_value(self, dictionary):
        return self.context['request'].user.username


class UserTokenSeralizer(Serializer):
    userId = serializers.IntegerField()
    username = serializers.CharField(max_length=128)
    email = serializers.EmailField(default='steam@example.org')

    class Meta:
        fields = ('userId', 'username', 'email')

    def get_user(self):
        try:
            user = UserModel.objects.get(choerodon_id=self.data['userId'])
        except UserModel.DoesNotExist:
            user = UserModel.objects.create(username=self.data.get('username'), choerodon_id=self.data.get('userId'), email=self.data.get('email'))
        return user