# encoding=utf8
import time
import json
from utils.minio_service_file import MinioServiceFile
from automate_test_py3 import settings
from logging import getLogger
log = getLogger('log')


def email_report(project_name, task_date, env_name, last_executor, report_file, task_name, request=None):
    data = b''
    try:
        minio_obj = MinioServiceFile()
        ret = report_file.split('/')
        bucket_name = ret[-2]
        file_name = ret[-1]
        minio_file_data = (minio_obj.get_file_data(bucket_name, file_name)).decode()
        file_data = json.loads(minio_file_data)
        caseSumarryInfo = file_data.get("caseSumarryInfo", [])
        caseDetails = file_data.get("caseDetails", [])
        zip_list = zip(caseSumarryInfo, caseDetails)
        report_data = dict()
        report_data["zip_list"] = zip_list
        report_data["baseInfo"] = file_data.get("baseInfo", [])
        report_data["caseSumarryInfo"] = caseSumarryInfo
        report_data["date"] = task_date
        report_data["env_name"] = env_name
        report_data["last_executor"] = last_executor
        report_data["project_name"] = project_name
        report_data["task_name"] = task_name
        report_data["logo_url"] = settings.LOGO_URL
        from django.shortcuts import render
        minio_resp = render(request, 'minio_email_template.html', report_data)
        # report_file_name = '{}.{}'.format(int(time.time() * 10 ** 3), 'html')
        report_file_name = file_name.replace('.json', '.html')
        metadata = {'Content-Type': 'text/html'}
        # Minio动态报告模板-> 在线查看
        minio_report_link = minio_obj.put_filebytes(bucket_name=settings.REPORT_BUCKET_NAME,
                                                    file_name=report_file_name,
                                                    data_bytes=minio_resp.content,
                                                    content_type='text/html',
                                                    metadata=metadata
                                                    )
        # 下载minio 邮件报告到本地
        minio_obj.get_file(bucket_name=bucket_name, file_name=report_file_name, save_file_path=settings.REPORT_DIR)
        report_data["minio_report_link"] = minio_report_link
        resp = render(request, 'email_template.html', report_data)
        return resp.content.decode()
    except Exception as e:
        log.exception(e)
        return data.decode()
