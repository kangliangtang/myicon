from requests import request
from django.conf import settings


class GatWay:
    def __init__(self, token):
        self.token = token
        self.timeout = 3.05

    def req(self, method, url, **kwargs):
        # print('token:', self.token)
        return request(method=method, url=url, headers={'AUTHORIZATION': self.token}, timeout=self.timeout, **kwargs)

    def getUserInfo(self):
        url = settings.GATEWAY_URL + '/iam/v1/users/self'
        # print(url)
        r = self.req('get', url).json()
        # print(r)
        return r
