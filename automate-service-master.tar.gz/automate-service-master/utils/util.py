import json
import logging
import os

from rest_framework.response import Response
from rest_framework.status import HTTP_500_INTERNAL_SERVER_ERROR
from rest_framework.viewsets import ModelViewSet

from automate_test_py3 import settings


class FilterTime(logging.Filter):
    def filter(self, record):
        print(record)
        return 1


from rest_framework.views import exception_handler


def custom_exception_handler(exc, context):
    # Call REST framework's default exception handler first,
    # to get the standard error response.

    response = exception_handler(exc, context)
    django_logger = logging.getLogger('log')
    django_logger.error(exc)
    django_logger.error(context)

    if response is not None:
        response.data['status_code'] = response.status_code

    # if response.status_code == 500:
    #     response = Response('服务器内部错误', status=HTTP_500_INTERNAL_SERVER_ERROR)
    # Now add the HTTP status code to the response.
    if response is None:
        response = Response({"message": '服务器内部错误'}, status=HTTP_500_INTERNAL_SERVER_ERROR)
    return response


class ExportInterfaceException(BaseException):

    def __init__(self, *args, **kwargs):
        self.interface_name = None
        self.message = ''
        if kwargs.get('interface_name',None):
            self.interface_name = kwargs.get('interface_name')
            del kwargs['interface_name']
        if kwargs.get('msg_detail',None):
            self.message = kwargs.get('msg_detail','没有异常信息')
            del kwargs['msg_detail']
        super().__init__(*args, **kwargs)

    def __str__(self):
        return self.interface_name


class BaseExcel(object):
    """
    读取excel表格使用的是 xlsrd
    写入xlsx表格使用的是  xlswt
    """
    def __init__(self, file_path=None, args=None):
        self.file_path = file_path
        self.sheet = None
        self.Execl = None
        self.body_args_column_count = 0
        self.header = {}
        self.args_values = []
        self.arg_keys = args if args else []
        self.args_count = args.__len__() if args else 0

    def write(self, row, colum, value, *args, **kwargs):
        self.sheet.write(row, colum, value, *args, **kwargs)

    def selectSheet(self, sheet_index=0, sheetname='sheet1'):
        if self.model == 'r':
            self.sheet = self.Execl.sheet_by_index(sheet_index)
        elif self.model == 'w':
            self.sheet = self.Execl.add_worksheet()
        else:
            class ModelError(Exception):
                def __str__(self):
                    return '模型错误，因为【r或者w】'
            raise ModelError

    def openExcelFile(self, model, x_io=None):
        self.model = model
        if model == 'r':
            import xlrd
            self.Execl = xlrd.open_workbook(self.file_path)
        elif model == 'w':
            import xlsxwriter
            self.Execl = xlsxwriter.Workbook(x_io)
        else:
            class ModelError(Exception):
                def __str__(self):
                    return '模型错误，因为【r或者w】'
            raise ModelError

    def init(self, *args, **kwargs):
        self.__init__(*args, **kwargs)

    def close(self):
        self.Execl.close()

    def writeMerge(self, first_row, first_col, last_row, last_col, data, *args, **kwargs):
        """

        :param first_row: 从第几行开始
        :param first_col: 从第几列开始
        :param last_row: 到第几行结束
        :param last_col: 到第几列结束
        :param data: 要写入的数据
        :param args:
        :param kwargs:
        :return:
        """
        if (first_col == last_col) and (first_row == last_row):
            self.write(first_row,first_col, data)
        else:
            self.sheet.merge_range(first_row, first_col, last_row, last_col, data, *args, **kwargs)

    def getMergedCellsValue(self, row_index, col_index):
        """
        先判断给定的单元格，是否属于合并单元格；
        如果是合并单元格，就返回合并单元格的内容
        :return:
        """
        merged = self.getMergedCells()
        for (rlow, rhigh, clow, chigh) in merged:
            if (row_index >= rlow and row_index < rhigh):
                if (col_index >= clow and col_index < chigh):
                    cell_value = self.sheet.cell_value(rlow, clow)
                    # print('该单元格[%d,%d]属于合并单元格，值为[%s]' % (row_index, col_index, cell_value))
                    return cell_value, rlow, rhigh, clow, chigh
        return None

    def getMergedCells(self):
        """
        获取所有的合并单元格，格式如下：
        [(4, 5, 2, 4), (5, 6, 2, 4), (1, 4, 3, 4)]
        (4, 5, 2, 4) 的含义为：行 从下标4开始，到下标5（不包含）  列 从下标2开始，到下标4（不包含），为合并单元格
        :param sheet:
        :return:
        """
        return self.sheet.merged_cells

    def readCommit(self, row, col):
        """
        读取行列对应的注释
        :param row: 行
        :param col: 列
        :return: 注释
        """
        return self.sheet.cell_note_map.get((row, col)).text

    def writeCommit(self, row, col, data):
        """
        写入行列对应的注释
        :param row: 行
        :param col: 列
        :param data: 注释
        :return:
        """
        self.sheet.write_comment(row, col, data)

class ExeclSerializer(BaseExcel):
    __ARGS_START_ROW = 1
    __ARGS_START_COLUMN = 1
    __TABLE_HEADER_ROW = 0
    __ARGS_HEADER_ROW = 1
    __TABLE_HEADER = ('用例名称', 'body数据', '断言')
    __VALIDATA_ = ('提取参数', '比较器', '预期值')
    __DATA_ROW = 2  # 从0开始 第三行索引为2

    def readExeclMain(self):
        self.openExcelFile(model='r')
        self.selectSheet()
        self.readHeader()
        self.readData()


    def writeExeclMain(self, out_io):
        '''写入不带数据的模板'''
        self.openExcelFile(model='w', x_io=out_io)
        self.selectSheet()
        self.writeHeader()
        self.writeArgsData()
        self.writeValidata()

    def writedata(self):
        self.selectSheet()
        self.writeHeader()
        self.writeArgsData()
        self.writeValidata()

    def writeTest(self, out_io):
        self.openExcelFile(model='w', x_io=out_io)
        self.selectSheet()
        self.write(1,2,'ttt')

    def readHeader(self):
        data = self.getHeaderLocation(self.__TABLE_HEADER_ROW, 0)
        self.col = 0
        if data[0] == self.__TABLE_HEADER[0]:
            self.col = 1
        merge_values_body = self.getHeaderLocation(self.__TABLE_HEADER_ROW, self.col)
        body_args = []
        for cloum in range(merge_values_body[3], merge_values_body[4]):
            body_value = self.sheet.cell_value(self.__TABLE_HEADER_ROW + 1, cloum)
            if body_value is not None:
                body_args.append(body_value)
            else:
                body_args.append(None)
        self.header['body'] = body_args

        merge_values_validata = self.getHeaderLocation(self.__TABLE_HEADER_ROW, merge_values_body[4])

        validata_args = []
        for cloum in range(merge_values_validata[3], merge_values_validata[4]):
            validata_value = self.sheet.cell_value(self.__TABLE_HEADER_ROW + 1, cloum)
            if validata_value is not None:
                validata_args.append(validata_value)
            else:
                validata_args.append(None)
        self.header['validata'] = validata_args

    def readData(self):
        total_rows = self.sheet.nrows
        if total_rows >=2:
            self.args_values = [self.sheet.row(now_row) for now_row in range(self.__DATA_ROW, total_rows)]

    @property
    def argsValues(self):
        """
        [[number:1.0, number:2.0, empty:'', empty:'', empty:'']]
        :return:
        """
        total_rows = self.sheet.nrows
        if total_rows >=2:
            return [self.sheet.row(now_row) for now_row in range(self.__DATA_ROW, total_rows)]
        else:
            return []

    def argsValueGenerator(self):
        """
        生成器 第一段返回 body数据
        第二段返回 断言
        :return:
        """
        data = self.argsValues
        body_data_len = self.header['body'].__len__()
        for index, arg_row in enumerate(self.argsValues):
            if self.col == 0:
                yield None
            else:
                yield arg_row[0].value
            if (self.header['body'].__len__() == 1) and (self.header['body'][0] == 'json数据'):
                yield json.loads(arg_row[self.col:][0].value)
            elif self.header['body'][0] == 'xml数据':
                yield arg_row[self.col:][0].value
            else:
                yield [{"key": self.header['body'][index], "value":arg.value} for index, arg in enumerate(arg_row[self.col:body_data_len + self.col])]
            if (arg_row[body_data_len + self.col:][1].value == '') or (arg_row[body_data_len + self.col:][0].value == ''):
                yield []
            else:
                # yield [{"assert": arg_row[body_data_len:][1].value, "key": arg_row[body_data_len:][0].value,"value": arg_row[body_data_len:][2].value} ]
                # yield [
                #          {
                #              "assert": arg_row[body_data_len:][i *3 + 1].value,
                #              "key": arg_row[body_data_len:][i * 3].value,
                #              "value": str(int(arg_row[body_data_len:][i * 3 + 2].value)) if isinstance(arg_row[body_data_len:][i * 3 + 2].value, float) else str(arg_row[body_data_len:][i * 3 + 2].value)
                #          } for i in range(arg_row[body_data_len:].__len__() // 3)
                #       ]
                yield self.readAssert(arg_row[body_data_len + self.col:])
                #  返回 httprunner 支持的断言 格式 [{"assert": "eq", "key": "content.code", "value": "20000"}]
    def readAssert(self, args_row):
        lll_ = []
        for i in range(args_row.__len__() // 3):
            if args_row[i * 3].value != '' and args_row[i * 3 + 1].value != '':
                try:
                  assert_ = settings.ASSERT_DICT[args_row[i * 3 + 1].value]
                except KeyError as e:
                    raise AssertKeyError(e.args[0])
                lll_.append({
                        "assert": assert_,  # 做断言映射，和前端保持一致 'A==B' ==> 'eq'
                        "key": args_row[i * 3].value,
                        "value": str(int(args_row[i * 3 + 2].value)) if isinstance(
                            args_row[i * 3 + 2].value, float) else str(args_row[i * 3 + 2].value)
                    })
        return lll_

    def writeHeader(self):
        self.writeMerge(0, 0, 1, 0, self.__TABLE_HEADER[0])
        args_count = self.args_count
        self.writeMerge(0, 1, 0, args_count, self.__TABLE_HEADER[1])
        self.writeMerge(0, args_count + 1, 0, args_count + 2, self.__TABLE_HEADER[2])

    def writeArgsData(self):
        args_keys = self.arg_keys
        for index, arg in enumerate(args_keys):
            self.write(1, index + 1, arg.value)             # 写值
            self.writeCommit(1, index + 1, arg.valueType)  # 写注释 type

    def writeValidata(self):
        args_count = self.args_count
        for index, validata in enumerate(self.__VALIDATA_):
            self.write(1, args_count + index + 1, validata)

    def getHeaderLocation(self, row_index, col_index):
        merged = self.getMergedCellsValue(row_index, col_index)
        if merged is None:
            value = self.sheet.cell_value(row_index, col_index)
            return value, row_index, row_index, col_index, col_index + 1
        return merged

    @property
    def excelValue(self):
        """
        {
            "name": ["hua", "zhang", "li"],
            "age": [23, 25, 24]
        }
        :return:
        """
        body_data = {}
        body_key_list = self.header['body']
        for index, body_key in enumerate(body_key_list):
            col_data_ = self.sheet.col(index + 1)
            body_data[col_data_[1].value] = [arg.value for arg in col_data_[2:]]
        return body_data

    @property
    def caseName(self):
        col_data_ = self.sheet.col(0)
        if col_data_[0].value != self.__TABLE_HEADER[0]:
            return []
        body_data = [arg.value for arg in col_data_[2:]]
        return body_data

    @property
    def assertValue(self):
        assert_value_data = []
        body_key_len = self.header['body'].__len__()
        for row_data in self.argsValues:
            l_ = []
            for index_ in range(len(row_data[body_key_len:]) // 3):
                if (row_data[body_key_len:][index_ * 3].value != '' and row_data[body_key_len:][index_ * 3].value != ''):
                    l_.append({
                        "assert": row_data[body_key_len:][index_ * 3 + 1].value,
                        "key": row_data[body_key_len:][index_ * 3].value,
                        "value": row_data[body_key_len:][index_ * 3 + 2].value,
                        })
                else:
                    continue
        return assert_value_data

    def writeData(self, case_name_list, old_value):
        list_new_args = self.arg_keys
        for r_index, arg in enumerate(case_name_list):
            self.sheet.write(r_index + 2, 0, arg)

        for r_index, arg in enumerate(list_new_args):
            values = old_value.get(arg.value, [])
            for c_index, value in enumerate(values):
                self.sheet.write(c_index + 2, r_index + 1, value)

    def writeAssert(self, data):
        list_new_args = self.arg_keys
        for r_index, arg in enumerate(list_new_args):
            values = data.get(arg.value, [])
            for c_index, value in enumerate(values):
                self.sheet.write(c_index + 2, r_index, value)


def checkXML(xml_str):
    """
    检验xml字符串
    :param xml_str:
    :return:
    """
    import xml
    from xml.sax.handler import ContentHandler
    try:
        xml.sax.parseString(xml_str, ContentHandler())
    except Exception as e:
        return False
    else:
        return True


def formatData(type, value):
    """
    格式化Excel表格数据
    :param type:
    :param value:
    :return: 格式化后的数据
    """
    import json
    type_dict = {
        'String': str,
        'Array': json.loads,
        'Object': json.loads,
        'Boolean': bool_fun,
        'Int': int_fun,
        'Number': float
    }

    try:
        formatValue = type_dict[type](value)
    except Exception as e:
        formatValue = value
    return formatValue

def bool_fun(value):
    bool_ = {
        'false': False,
        'true': True,
        'True': True,
        'False': False,
        '1': True,
        '0': False,
        1: True,
        0: False,
        False: False,
        True: True
    }
    return bool_[value]


def int_fun(value):
    try:
        value = int(value)
    except ValueError as e:
        value = int(float(value))
    except Exception as e:
        value = value
    return value

class Args(object):

    def __init__(self, value, value_type):
        self.value = value
        self.value_type = value_type

    @property
    def valueType(self):
        return self.value_type

    def __str__(self):
        return self.value


class RSACLASS(object):

    def __init__(self, SECRET_KEY):
        self.private_key = None
        self.publi_key = None
        self.rsa = None
        self.SECRET_KEY = SECRET_KEY

    def generatPrivateKey(self):
        """
        生成秘钥
        :return:
        """
        from Crypto.PublicKey import RSA
        rsa = RSA.generate(2048, self.SECRET_KEY)
        self.rsa = rsa
        private_pem = rsa.exportKey()
        self.private_key = private_pem
        return private_pem

    def savePrivateKey(self, file_path = None):
        """
        保存秘钥
        :param file_path:
        :return:
        """
        file_path = file_path if file_path else os.path.join(settings.PEM_FILE_PATH, 'private_key.pem')
        with open(file_path, 'wb') as f:
            f.write(self.private_key)

    def generatPubliKey(self):
        """
        生成公钥
        :return:
        """
        publi_key = self.rsa.publickey().exportKey()
        self.publi_key = publi_key
        return publi_key

    def savePubliKey(self, file_path=None):
        """
        保存公钥
        :param file_path:
        :return:
        """
        file_path = file_path if file_path else os.path.join(settings.PEM_FILE_PATH, 'public_key.pem')
        with open(file_path, 'wb') as f:
            f.write(self.publi_key)

    def signerData(self, message=None, public_key_file_path=None):
        """
        加密数据
        :param message:
        :return:
        """
        from Crypto.PublicKey import RSA
        from Crypto.Cipher import PKCS1_v1_5 as Cipher_pkcs1_v1_5
        import base64
        if public_key_file_path is None:
            public_key_file_path = os.path.join(settings.PEM_FILE_PATH, 'public_key.pem')
        with open(public_key_file_path) as f:
            key = f.read()
            rsakey = RSA.importKey(str(key))
            cipher = Cipher_pkcs1_v1_5.new(rsakey)
            cipher_text = base64.b64encode(cipher.encrypt(bytes(message.encode("utf8"))))
        return cipher_text

    def decryptData(self, data, private_key_file_path=None):
        """
        解密数据
        :param data: 密文
        :param secret_key: 安全密钥 默认是django的 SECRET_KEY
        :return:
        """
        from Crypto.PublicKey import RSA
        from Crypto.Cipher import PKCS1_v1_5 as Cipher_pkcs1_v1_5
        import base64
        if private_key_file_path is None:
            private_key_file_path = os.path.join(settings.PEM_FILE_PATH, 'private_key.pem')
        with open(private_key_file_path) as f:
            key = f.read()
            rsakey = RSA.importKey(key)
            cipher = Cipher_pkcs1_v1_5.new(rsakey)
            text = cipher.decrypt(base64.b64decode(data), self.SECRET_KEY)
        return text # 返回解密的数据


class DeleteException(BaseException):

    def __init__(self, *args, **kwargs):
        self.message = kwargs['message']
        super().__init__(*args, **kwargs)


def changeValue(name, list_data, case_content):
    # 接口修改，同步修改key, 原有的key存在时，则保留原有的数据
    if isinstance(list_data, str):
        list_data = json.loads(list_data)
    old_list = case_content.get(name, [])
    old_keys = [dic.get('key') for dic in old_list]
    new_list_data = list()
    for data in list_data:
        key_name = data.get('key')
        if key_name not in old_keys:
            data['value'] = ''
        new_list_data.append(data)
    return new_list_data



class AssertKeyError(KeyError):
    assert_ = {
        "eq": "A==B",
        "str_eq": "str(A)==str(B)",
        "contains": "[1,2] contains 1",
        "contained_by": "A in B",
        "type_match": "isinstance(A,B)",
        "regex_match": "re.match(B,A)",
        "startswith": "A.startswith(B) is True",
        "endswith": "A.endswith(B) is True"
               }
    def __init__(self, args):
        if args in self.assert_.keys():
            self.message = '断言类型错误,应该是:{},实际是：{}'.format(self.assert_.get(args), args)
        else:
            self.message = '断言错误，请填写正确断言：{}'.format([key for key in self.assert_.keys()])

    def __str__(self):
        return self.message


class DescribetionModelViewSet(ModelViewSet):

    def create(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"create",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super(DescribetionModelViewSet, self).create(request, *args, **kwargs)

    def retrieve(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"retrieve",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super(DescribetionModelViewSet, self).retrieve(request, *args, **kwargs)

    def update(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"update",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super(DescribetionModelViewSet, self).update(request, *args, **kwargs)

    def partial_update(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"partial_update",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super(DescribetionModelViewSet, self).partial_update(request, *args, **kwargs)

    def destroy(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"destroy",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super(DescribetionModelViewSet, self).destroy(request, *args, **kwargs)

    def list(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"list",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super(DescribetionModelViewSet, self).list(request, *args, **kwargs)
