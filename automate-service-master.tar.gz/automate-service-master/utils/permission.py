from django.contrib.auth.models import  Permission

from rest_framework.permissions import  DjangoModelPermissions

SAFE_METHODS = ('GET', 'HEAD', 'OPTIONS')
PER_MAP = {
    'project_caud': [
        'delete_projectmodulemodel',
        'change_projectmodulemodel',
        'add_projectmodulemodel'
    ],
    'interface': [
        'add_interfacemodel',
        'change_interfacemodel',
        'delete_interfacemodel',
        'add_interfacecasemodel',
        'change_interfacecasemodel',
        'delete_interfacecasemodel',
        'add_taskmodel',
        'change_taskmodel',
        'delete_taskmodel',
        'add_interfacescenemodel',
        'change_interfacescenemodel',
        'delete_interfacescenemodel',
        "add_publishcasemodel",
        "change_publishcasemodel",
        "delete_publishcasemodel"
    ],
    'result_report': [
        'add_resultreportmodel',
        'change_resultreportmodel',
        'delete_resultreportmodel',
        'add_taskresultreportmodel',
        'change_taskresultreportmodel',
        'delete_taskresultreportmodel'
    ],
    'user': [],
    'django_celery_beat': [],
    'flow': [
        'add_testtaskmodel',
        'change_testtaskmodel',
        'delete_testtaskmodel'
    ],
    'system':[
        'add_uploadfilemodel',
        'change_uploadfilemodel',
        'delete_uploadfilemodel',
        'add_commonparametermodel',
        'change_commonparametermodel',
        'delete_commonparametermodel'
    ],
    'mockserver': [
        'add_mockservermodel',
        'change_mockservermodel',
        'delete_mockservermodel'
    ]
}

PER_MAP_PROJECT_LEAD = {
    'project_caud': [
        'delete_projectmodulemodel',
        'change_projectmodulemodel',
        'add_projectmodulemodel',
        'change_testprojectmodel'
    ],
    'user': [
        'add_group',
        'delete_group'
    ],
    'flow': [
        'add_flowtree',
        'change_flowtree',
        'delete_flowtree'
    ],
    'system':[
            'add_uploadfilemodel',
            'change_uploadfilemodel',
            'delete_uploadfilemodel',
            'add_commonparametermodel',
            'change_commonparametermodel',
            'delete_commonparametermodel'
        ]
}

class AutoPlatformPermission(DjangoModelPermissions):

    def has_permission(self, request, view):
        if not is_authenticated(request.user):
            return False
        if request.method in SAFE_METHODS:
            return True
        if request.user.is_active and request.user.is_superuser:
            return True
        return super().has_permission(request, view)


class AutoPlatformGroupPermission(AutoPlatformPermission):

    def has_object_permission(self, request, view, obj):
        if request.user.is_active and request.user.is_superuser:
            return True
        if view.action == 'retrieve':
            return True
        elif obj.testprojectmodel.project_lead.filter(username=request.user.username):
            return True
        else:
            return False


class AutoPlatformProjectPermission(AutoPlatformPermission):

    def has_object_permission(self, request, view, obj):
        if request.user.is_active and request.user.is_superuser:
            return True
        if view.action == 'retrieve' or view.action == 'defaultLogin' or view.action == 'checkexits':
            return True
        elif obj.project_lead.filter(username=request.user.username):
            return True
        else:
            return False


class AutoPlatformFlowPermission(AutoPlatformPermission):

    def has_object_permission(self, request, view, obj):
        if request.user.is_active and request.user.is_superuser:
            return True
        if view.action == 'retrieve':
            return True
        elif obj.project_lead.filter(username=request.user.username):
            return True
        else:
            return False


def groupPermissionList(per_obj):
    addpermission(per_obj, PER_MAP)


def addpermission(per_obj,per_map):

    for key_ in per_map.keys():
        for codename_str in per_map[key_]:
            per_obj.permissions.add(Permission.objects.get(codename=codename_str))
    # return [per_obj.Permission.add(Permission.objects.get(codename=codename_str)) for key_ in per_map.keys() for codename_str in per_map[key_]]



def addUserpermission(user_obj,per_map):

    for key_ in per_map.keys():
        for codename_str in per_map[key_]:
            user_obj.user_permissions.add(Permission.objects.get(codename=codename_str))
    # return [per_obj.Permission.add(Permission.objects.get(codename=codename_str)) for key_ in per_map.keys() for codename_str in per_map[key_]]

def removeUserpermission(user_obj,per_map):

    for key_ in per_map.keys():
        for codename_str in per_map[key_]:
            user_obj.user_permissions.add(Permission.objects.get(codename=codename_str))

def projectLead(user):
    addUserpermission(user, PER_MAP_PROJECT_LEAD)
    addUserpermission(user, PER_MAP)


def removeProjectLead(user):
    removeUserpermission(user, PER_MAP_PROJECT_LEAD)
    removeUserpermission(user, PER_MAP)