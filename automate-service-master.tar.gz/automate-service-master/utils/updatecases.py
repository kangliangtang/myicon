import json
from case_flow.models import TestTaskModel
from interface.models import InterfaceModel
from logging import getLogger
logger = getLogger('debug')


def update_cases(case_json_data, task_id=None):
    """更新用例"""
    if not isinstance(case_json_data, str):
        return case_json_data
    try:
        update_case_data = list()
        case_data = json.loads(case_json_data)
        # 先尝试从用例中直接获取接口id, 再尝试从用例表中test_content中获取接口id，二者都无 直接跳过
        test_task_obj = TestTaskModel.objects.filter(id=task_id).first()
        extract_variables_keys = list()
        for idx, case_test in enumerate(case_data):
            extract_variables_keys.extend(case_test_extract_variables(case_test))
            test_dict = case_test.get("test")
            if not all([test_dict, isinstance(test_dict, dict)]):
                config = case_test.get('config', dict())
                case_test['config'] = case_variables_handle(extract_variables_keys, config)
                update_case_data.append(case_test)
                continue
            # 测试用例中参数提取处理
            test_dict = case_variables_handle(extract_variables_keys, test_dict)
            new_case_test = test_dict
            case_test_request = new_case_test["request"]
            interface_id = new_case_test["request"]["headers"].get("AutomateInterfaceID")
            if not interface_id:
                if test_task_obj:
                    task_content = test_task_obj.task_content
                    publish_case = test_task_obj.publish_case
                    login = (json.loads(publish_case)).get('login') if publish_case else False
                    if login and idx == 0:
                        continue
                    task_content = json.loads(task_content)
                    if not task_content:
                        continue
                    interface_id = task_content[idx].get("interface_id")
            # else:
            #     del new_case_test["request"]["headers"]["AutomateInterfaceID"]
            interface_query = InterfaceModel.objects.filter(id=interface_id, is_delete=False)
            if not interface_query:
                continue
            interface_obj = interface_query.first()
            new_name = interface_obj.name
            # new_path = interface_obj.path
            new_method = interface_obj.method
            new_application_id = interface_obj.application_id
            # from urllib.parse import urlparse
            # request_url = case_test_request['url']
            # request_path = urlparse(request_url).path
            # new_request_path = '$app_host_{}{}'.format(new_application_id, new_path)
            # case_test_request["url"] = request_url.replace(request_path, new_request_path)
            # 接口url带参数处理
            case_request_url = case_test_request['url']
            new_request_path = handle_request_path(interface_obj.path, case_request_url)
            new_request_url = '$app_host_{}{}'.format(new_application_id, new_request_path)
            case_test_request["url"] = new_request_url

            case_test_request["method"] = new_method
            if task_id and test_task_obj:                                                    # 任务存在数据驱动文件时，不做接口名称替换
                new_case_test["name"] = new_name if not test_task_obj.excel_file_path else test_dict['name']
            test_data = {"test": new_case_test}
            update_case_data.append(test_data)
        case_json_data = json.dumps(update_case_data)
    except Exception as e:
        logger.exception(e)
        logger.error('case_data:{}, msg:{}'.format(case_json_data, e))
    finally:
        return case_json_data


def handle_request_path(interface_path, case_request_url):
    """接口path带参数 处理"""
    try:
        from urllib.parse import urlparse
        interface_path_ = urlparse(interface_path).path
        interface_path_query = urlparse(interface_path).query
        case_url_query = urlparse(case_request_url).query
        if case_url_query:
            if interface_path_query:
                interface_parmas = interface_path_query.split('&')
                case_parmas = case_url_query.split("&")
                interface_parmas.extend(case_parmas)
                from functools import reduce
                func = lambda x, y: x if y in x else x + [y]
                interface_parmas_list = reduce(func, [[], ] + interface_parmas)
                url_query = '&'.join(interface_parmas_list)
                new_request_path = '{}?{}'.format(interface_path_, url_query)
            else:
                new_request_path = '{}?{}'.format(interface_path_, case_url_query)
        else:
            new_request_path = interface_path
        return new_request_path
    except Exception as e:
        logger.exception(e)
        return interface_path


def case_test_extract_variables(case_test):
    """ 用例中参数传递 不存在是脱传
    :param case_test: {
                        "test": {
                            "validate": [],
                            "name": "\u751f\u4ea7\u6d4b\u8bd5\u4e13\u7528",
                            "variables": {},
                            "extract": [{"Authorization": "content.access_token"}],
                            "teardown_hooks": [],
                            "request": {
                                "method": "POST",
                                "headers": {
                                    "Authorization": "bearer 4de5a75e-aecd-4c00-b8db-1591febe1f08",
                                    "AutomateInterfaceID": "2904",
                                    "projectid": "902",
                                    "Content-Type": "application/json"
                                },
                                "url": "$app_host_66/oauth/oauth/token?client_id=choerodon&grant_type=password&username=htt-1&password=MTIzNDU2&client_secret=secret"
                            }
                        }
                    }
    :return:
    """
    if 'config' in case_test.keys():
        config = case_test['config']
        variables = config.get('variables', dict())
        extract_dict_keys = list(variables.keys())
    else:
        case_test_dict = case_test['test']
        extract = case_test_dict.get('extract', list())
        variables = case_test_dict.get('variables', dict())
        extract_dict_keys = list(variables.keys())
        for extract_dict in extract:
            if not extract_dict:
                continue
            extract_dict_keys.extend(list(extract_dict.keys()))
    return extract_dict_keys


def case_variables_handle(extract_dict_keys, case_test_data):
    try:
        case_extract_variables = extract_variables(json.dumps(case_test_data))
        variables = case_test_data.get('variables', dict())
        for case_extract_variable in case_extract_variables:
            if case_extract_variable not in extract_dict_keys:
                variables[case_extract_variable] = '${}'.format(case_extract_variable)
        case_test_data['variables'] = variables
        return case_test_data
    except Exception as e:
        logger.exception(e)
        return case_test_data


def extract_variables(content):
    try:
        import re
        variable_regexp = r"\$([\w_]+)"
        return re.findall(variable_regexp, content)
    except TypeError:
        return []

