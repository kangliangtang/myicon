import datetime
import json
from functools import wraps
from django.http import QueryDict
from rest_framework.request import Request
from project_caud.models import TestProjectModel
from interface.models import InterfaceModel, TaskModel
from result_report.models import ResultReportModel, TaskResultReportModel
from system.models import OperationLogModel


class OperationLogDecorator(object):
    """操作日志装饰器"""
    def __init__(self):
        pass

    @staticmethod
    def get_parameter_dic(request):
        """将请求参数转化为dict形式"""
        try:
            if isinstance(request, Request) == False:
                return {}
            query_params = request.query_params
            if isinstance(query_params, QueryDict):
                query_params = query_params.dict()
            result_data = request.data
            if isinstance(result_data, QueryDict):
                result_data = result_data.dict()
            if query_params != {}:
                return query_params
            else:
                return result_data
        except Exception:
            pass

    @staticmethod
    def _get_project_name(project_id):
        """获取项目名称"""
        project_name = None
        try:
            project_id = int(project_id)
            project_obj = TestProjectModel.objects.filter(id=project_id).values("project_name")
            project_name = ''.join([i.get("project_name", None) for i in list(project_obj)])
        except Exception:
            pass
        finally:
            return project_name

    @staticmethod
    def _get_interface_name(module_id=None, action_time=None, pk=None):
        """获取接口名称"""
        interface_names = None
        try:
            if pk:
                pk = int(pk)
                interface_obj_list = list(InterfaceModel.objects.filter(id=pk).values('name'))
            else:
                module_id = int(module_id)
                interface_obj_list = list(InterfaceModel.objects.filter(module_id=module_id, create_time__gte=action_time).values('name'))
            interface_names = [i.get("name", None) for i in interface_obj_list]
            if len(interface_names) == 1:
                interface_names = ''.join(interface_names)
        except Exception:
            pass
        finally:

            return interface_names

    @staticmethod
    def __operation_log_create(action=None, data=None, user=None, project_id=None):
        """操作日志表 添加数据"""
        try:
            project_id = int(project_id)
            if len(action) > 64:
                action = '{0} .... {1}'.format(action[0:28], action[-28:])
            if len('{0}'.format(data)) > 512:
                if isinstance(data, dict):
                    data = json.dumps(data)
                data = '{0} .... {1}'.format(data[0:252], data[-252:])
            OperationLogModel.objects.create(
                action=action,
                data=data,
                user=user,
                project_id=project_id
            )
        except Exception as e:
            print('日志记录Error:%s'% e)
            pass

    @staticmethod
    def _flowAPI_data(data):
        """接口流程数据过长处理"""
        # 当数据过长时,将interfaces接口信息省略
        if len('{0}'.format(data)) > 512:
            try:
                data2 = data["data"]
                nodes = data2["nodes"]
                interfaces = ['...']
                for node in nodes:
                    node["interfaces"] = interfaces
                if len('{0}'.format(data)) > 512:
                    data2 = data["data"]
                    data2["nodes"] = ['...']
            except Exception:
                data = {}
            finally:
                return data
        else:
            return data

    def open_close_project(self, func):
        """项目启用/禁用"""
        @wraps(func)
        def wrapper(request, *args, **kwargs):
            project_id = kwargs.get('project_id')
            project_name = self._get_project_name(project_id)
            user = request.user
            data = self.get_parameter_dic(request)
            api_response = func(request, *args, **kwargs)
            # 当返回 200 认为接口操作成功，记录下操作日志
            if api_response.status_code == 200:
                # 操作行为
                action = '禁用{}项目'.format(project_name)
                if api_response.data:
                    action = '启用{}项目'.format(project_name)
                # 添加到数据库
                self.__operation_log_create(action=action, data=data, user=user, project_id=project_id)
            return api_response
        return wrapper

    def project_update(self, func):
        """修改 项目信息"""
        @wraps(func)
        def wrapper(request, *args, **kwargs):
            project_id = kwargs.get('project_id')
            project_name = self._get_project_name(project_id)
            user = request.user
            data = self.get_parameter_dic(request)
            api_response = func(request, *args, **kwargs)
            # 当返回 200 认为接口操作成功，记录下操作日志
            if api_response.status_code == 200:
                action = '修改了{}项目信息'.format(project_name)
                # 添加到数据库
                self.__operation_log_create(action=action, data=data, user=user, project_id=project_id)
            return api_response
        return wrapper

    def createFlowAPI(self, func):
        """创建接口流程"""
        @wraps(func)
        def wrapper(request, *args, **kwargs):
            project_id = kwargs.get('project_id')
            project_name = self._get_project_name(project_id)
            user = request.user
            data = self.get_parameter_dic(request)
            # 操作行为
            action = '创建{}的接口流程'.format(project_name)
            api_response = func(request, *args, **kwargs)
            # 当返回 200 认为接口操作成功，记录下操作日志
            if api_response.status_code == 201:
                data = self._flowAPI_data(data)
                # 添加到数据库
                self.__operation_log_create(action=action, data=data, user=user, project_id=project_id)
            return api_response
        return wrapper

    def updateFlowAPI(self, func):
        """修改接口流程"""
        @wraps(func)
        def wrapper(request, *args, **kwargs):
            project_id = kwargs.get('project_id')
            project_name = self._get_project_name(project_id)
            user = request.user
            data = self.get_parameter_dic(request)
            api_response = func(request, *args, **kwargs)
            # 当返回 200 认为接口操作成功，记录下操作日志
            if api_response.status_code == 200:
                action = '修改了{}的接口流程'.format(project_name)
                data = self._flowAPI_data(data)
                self.__operation_log_create(action=action, data=data, user=user, project_id=project_id)
            return api_response
        return wrapper

    def create_interface(self, func):
        """创建接口"""
        @wraps(func)
        def wrapper(request, *args, **kwargs):
            project_id = kwargs.get('project_id')
            req_data = request.data
            module_id = req_data.get('module_id')
            user = request.user
            data = self.get_parameter_dic(request)
            action_time = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%fZ')
            api_response = func(request, *args, **kwargs)
            # 当返回 200 认为接口操作成功，记录下操作日志
            if (api_response.status_code == 200) or (api_response.status_code == 201):
                # 获取所有新创建的接口名称
                interface_names = self._get_interface_name(module_id=module_id, action_time=action_time)
                if interface_names:
                    action = '创建了{}接口'.format(interface_names)
                    # 添加到数据库
                    self.__operation_log_create(action=action, data=data, user=user, project_id=project_id)
            return api_response
        return wrapper

    def create_one_interface(self, func):
        """创建接口"""
        @wraps(func)
        def wrapper(request, *args, **kwargs):
            project_id = kwargs.get('project_id')
            req_data = request.data
            name = req_data.get('name')
            user = request.user
            data = self.get_parameter_dic(request)
            api_response = func(request, *args, **kwargs)
            # 当返回 200 认为接口操作成功，记录下操作日志
            if (api_response.status_code == 200) or (api_response.status_code == 201):
                action = '创建了{}接口'.format(name)
                # 添加到数据库
                self.__operation_log_create(action=action, data=data, user=user, project_id=project_id)
            return api_response
        return wrapper

    def update_interface(self, func):
        """修改接口"""
        @wraps(func)
        def wrapper(request, *args, **kwargs):
            project_id = kwargs.get('project_id')
            pk = kwargs["pk"]
            # 获取接口名称
            interface_name = self._get_interface_name(pk=pk)
            user = request.user
            data = self.get_parameter_dic(request)
            api_response = func(request, *args, **kwargs)
            # 当返回 200 认为接口操作成功，记录下操作日志
            if api_response.status_code == 200:
                action = '修改{}接口'.format(interface_name)
                # 添加到数据库
                self.__operation_log_create(action=action, data=data, user=user, project_id=project_id)
            return api_response
        return wrapper

    def del_interface(self, func):
        """删除接口"""
        @wraps(func)
        def wrapper(request, *args, **kwargs):
            # project_id = request.META.get('HTTP_PROJECTID')
            project_id = kwargs.get('project_id')
            pk = kwargs["pk"]
            # 获取接口名称
            interface_name = self._get_interface_name(pk=pk)
            user = request.user
            data = self.get_parameter_dic(request)
            api_response = func(request, *args, **kwargs)
            # 当返回 200 认为接口操作成功，记录下操作日志
            if api_response.status_code == 200:
                action = '删除{}接口'.format(interface_name)
                # 添加到数据库
                self.__operation_log_create(action=action, data=data, user=user, project_id=project_id)
            return api_response
        return wrapper

    def del_report(self, func):
        """删除报告 (定时任务报告)"""
        @wraps(func)
        def wrapper(request, *args, **kwargs):
            project_id = kwargs.get('project_id')
            pk = kwargs["pk"]
            # 获取任务名
            # TaskModel
            report_obj = TaskResultReportModel.objects.get(id=pk)
            task_obj = report_obj.task
            report_name = task_obj.name
            # report_name = ''.join([i.get("name", None) for i in report_obj_list])
            # 获取报告名称
            # report_obj_list = list(ResultReportModel.objects.filter(id=pk).values("name"))
            # report_name = ''.join([i.get("name", None) for i in report_obj_list])
            user = request.user
            data = self.get_parameter_dic(request)
            api_response = func(request, *args, **kwargs)
            # 当返回 200 认为接口操作成功，记录下操作日志
            if api_response.status_code == 200:
                action = '删除{}的报告'.format(report_name)
                # 添加到数据库
                self.__operation_log_create(action=action, data=data, user=user, project_id=project_id)
            return api_response
        return wrapper

    def del_test_report(self, func):
        """删除报告 (测试报告)"""
        @wraps(func)
        def wrapper(request, *args, **kwargs):
            project_id = kwargs.get('project_id')
            pk = kwargs["pk"]
            # 获取报告名称
            report_obj = ResultReportModel.objects.get(id=pk)
            report_name = report_obj.name
            user = request.user
            data = self.get_parameter_dic(request)
            api_response = func(request, *args, **kwargs)
            # 当返回 200 认为接口操作成功，记录下操作日志
            if api_response.status_code == 200:
                action = '删除{}的报告'.format(report_name)
                # 添加到数据库
                self.__operation_log_create(action=action, data=data, user=user, project_id=project_id)
            return api_response
        return wrapper

    def create_timetask(self, func):
        """新增定时任务"""
        @wraps(func)
        def wrapper(request, *args, **kwargs):
            project_id = kwargs.get('project_id')
            user = request.user
            req_data = request.data
            task_name = req_data.get('name')
            data = self.get_parameter_dic(request)
            api_response = func(request, *args, **kwargs)
            # 当返回 201 认为接口操作成功，记录下操作日志
            if api_response.status_code == 201:
                action = '新增{}定时任务'.format(task_name)
                # 添加到数据库
                self.__operation_log_create(action=action, data=data, user=user, project_id=project_id)
            return api_response
        return wrapper

    def change_timetask(self, func):
        """变更定时任务 open close run"""
        @wraps(func)
        def wrapper(request, *args, **kwargs):
            project_id = kwargs.get('project_id')
            pk = kwargs["pk"]
            # 获取定时任务名称
            report_obj_list = list(TaskModel.objects.filter(id=pk).values("name"))
            report_name = ''.join([i.get("name", None) for i in report_obj_list])
            user = request.user
            data = self.get_parameter_dic(request)
            api_response = func(request, *args, **kwargs)
            # 当返回 200 认为接口操作成功，记录下操作日志
            if api_response.status_code == 200:
                action = '修改{}定时任务-({})'.format(report_name, api_response.data)
                # 添加到数据库
                self.__operation_log_create(action=action, data=data, user=user, project_id=project_id)
            return api_response
        return wrapper

    def update_timetask(self, func):
        """修改定时任务"""
        @wraps(func)
        def wrapper(request, *args, **kwargs):
            project_id = kwargs.get('project_id')
            pk = kwargs["pk"]
            # 获取定时任务名称
            report_obj_list = list(TaskModel.objects.filter(id=pk).values("name"))
            report_name = ''.join([i.get("name", None) for i in report_obj_list])
            user = request.user
            data = self.get_parameter_dic(request)
            api_response = func(request, *args, **kwargs)
            # 当返回 200 认为接口操作成功，记录下操作日志
            if api_response.status_code == 200:
                action = '修改{}定时任务'.format(report_name)
                # 添加到数据库
                self.__operation_log_create(action=action, data=data, user=user, project_id=project_id)
            return api_response

        return wrapper

    def update_permission(self, func):
        """修改权限配置"""
        @wraps(func)
        def wrapper(request, *args, **kwargs):
            project_id = kwargs.get('project_id')
            user = request.user
            data = self.get_parameter_dic(request)
            api_response = func(request, *args, **kwargs)
            # 当返回 200 认为接口操作成功，记录下操作日志
            if api_response.status_code == 200:
                project_name = self._get_project_name(project_id)
                action = '修改了{}项目权限配置'.format(project_name)
                # 添加到数据库
                self.__operation_log_create(action=action, data=data, user=user, project_id=project_id)
            return api_response
        return wrapper
