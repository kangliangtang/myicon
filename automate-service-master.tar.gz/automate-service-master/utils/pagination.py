# coding=utf-8
# by "nieyunfeng3@crc.com.hk"

from rest_framework.pagination import PageNumberPagination
from rest_framework.response import Response


class CustomPagination(PageNumberPagination):
    page_size = 10
    page_query_param = 'start'
    page_size_query_param = 'size'


    def get_paginated_response(self, data):
        return Response({
            'total': self.page.paginator.count,
            'list': data
        })
