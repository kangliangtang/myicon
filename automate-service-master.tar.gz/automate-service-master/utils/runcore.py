import re
import os
import random
import shutil
import traceback
from utils import util
from utils.sendemail import SendEmail
from urllib.parse import urlparse
import json
from collections import OrderedDict
from urllib import parse
import time
import json_tools
from logging import getLogger
from rest_framework import serializers
from django.conf import settings
from django.db import transaction
from httprunner.api import HttpRunner
from contract.models import ContractTestModel, ContractTestResModel
from result_report.models import ResultReportModel, SummaryModel
from case_flow.models import TestTaskModel
from user.models import UserModel
from interface.models import InterfaceCaseModel, InterfaceModel, InterfaceSceneModel, PublishCaseModel
from project_caud.models import TestProjectModel
from har2case.core import HarParser
from system.models import UploadFileModel
from utils.serializer import ZJsonField, ZCharFields
from utils.util import ExportInterfaceException
from utils.minio_service_file import MinioServiceFile
from utils.common_parameter import ReplaceCommonParameter
from django.db.models import Q
logger_debug = getLogger('celery')

from utils.defined_function import DefinedFunction
from httprunner import loader


class HttpRunnerCore(HttpRunner):
    def __init__(self, failfast=False, save_tests=False, report_template=None, report_dir=None, log_level="INFO",
                 log_file=None, validate=None, instance=None, project_id=None):
        self.test_case_tem = []
        self.res_response_data = {"被删除字段": [], "被增加字段": [], "值的类型被改变字段": []}
        self.validate_  = validate
        self.instance_ = instance
        self.test_content = None  #单个接口测试内容
        self.project_id = project_id
        super().__init__(failfast, save_tests, report_template, report_dir, log_level, log_file)

    @staticmethod
    def __change_testcase_content(file_path, project_id, task_id=None):
        """更改用例内容"""
        try:
            replace_obj = ReplaceCommonParameter(project_id=project_id)
            case_file_path = file_path
            if os.path.exists(case_file_path):
                from utils.updatecases import update_cases
                # 定时任务中公共参数替换
                if os.path.isdir(case_file_path):
                    new_path = case_file_path + 'run'
                    if os.path.exists(new_path):
                        shutil.rmtree(new_path)
                    os.makedirs(new_path)
                    for s in os.listdir(case_file_path):
                        case_file = os.path.join(case_file_path, s)
                        with open(case_file, 'r') as f:
                            file_ = f.read()
                        file_ = update_cases(file_, task_id)                 # 用例内容与接口做同步更新
                        json_data = replace_obj.json_common_param(file_)
                        new_file_path = new_path + '/' + s
                        with open(new_file_path, 'w') as f2:
                            f2.write(json_data)
                    return new_path
                else:
                    # 测试用例中公共参数替换
                    with open(case_file_path, 'r', encoding='utf-8') as f:
                        file_data = f.read()
                    filepath = os.path.dirname(case_file_path)
                    # filename = os.path.basename(case_file_path)
                    # file_name = "{0}{1}".format('run', filename)
                    file_name = "{0}{1}.json".format('run', (time.time()) * 10 ** 7)
                    path_or_tests = filepath + '/' + file_name
                    file_data = update_cases(file_data, task_id)                       # 用例内容与接口做同步更新
                    json_data = replace_obj.json_common_param(file_data)
                    with open(path_or_tests, 'w', encoding='utf-8') as fil:
                        fil.write(json_data)
                    case_file_path = path_or_tests
                    return case_file_path
            return case_file_path
        except Exception:
            return file_path


    def uploadFileMinio(self, file_path):
        """上传测试报告到Minio"""
        try:
            minio_obj = MinioServiceFile()
            down_url = minio_obj.fput_get_url(bucket_name=settings.REPORT_BUCKET_NAME, put_file_path=file_path)
            # 上传成功返回Minio服务url
            if down_url:
                os.remove(file_path)
                file_path = down_url
        except Exception as e:
            logger_debug.error('Upload file to Minio fail;file_path={0} error:{1}'.format(file_path, e))
        finally:
            return file_path

    def run(self, path_or_tests, dot_env_path=None, mapping=None, project_id=None, task_id=None):
        """
        httprunner 运行测试用例
        :param path_or_tests : 用例路径
        :param dot_env_path:  环境变量路径
        :param mapping:  字典  可用于替换 用例变量
        :param project_id:
        :return:
        """
        new_path_or_tests = self.__change_testcase_content(path_or_tests, project_id, task_id)
        # 加载debugtalk函数
        try:
            # loader.load_debugtalk_functions()
            loader.load_project_tests(settings.TESTCASE_DIR)
        except Exception as e:
            logger_debug.exception('debugtalk中的函数加载错误settings.TESTCASE_DIR={},异常信息={}'.format(settings.TESTCASE_DIR, e))

        # 报告文件目录
        self.report_dir = settings.REPORT_DIR
        # return super().run(path_or_tests, dot_env_path, mapping)
        resp = super().run(new_path_or_tests, dot_env_path, mapping)

        # 删除临时运行文件
        try:
            if new_path_or_tests != path_or_tests:
                if os.path.isdir(new_path_or_tests):
                    shutil.rmtree(new_path_or_tests)
                elif os.path.isfile(new_path_or_tests):
                    os.remove(new_path_or_tests)
        except Exception:
            pass
        # return resp
        return self.uploadFileMinio(resp)


    # def runByCaseId(self, case_id, host_url):
    #     test_case = InterfaceCaseModel.objects.get(id=case_id)
    #     report_obj = test_case.createReport()
    #     case_file_path = test_case.case_file_path
    #     self.runCaseByPath(case_file_path=case_file_path, host_url=host_url, report_obj=report_obj)

    def runCaseByPath(self, case_file_path, env_id, report_obj,suumarry_obj, project_id=None, task_id=None):
        try:
            mapping_ = self.get_app_host_by_env(env_id, project_id)
            report_path = self.run(path_or_tests=case_file_path, mapping=mapping_, project_id=project_id, task_id=task_id)
            # #解析sumarry
            sumarry =self.get_summary(self.summary, suumarry_obj, project_id=project_id, report_id=report_obj.id, env_id=env_id)

            report_obj.status = 'true' if self.summary['success'] else 'false'
            report_obj.report_file_path = report_path
            # suumarry_obj.summary_count = sumarry

        except Exception as e:
            logger_debug.exception(e)
            msg = traceback.format_exc()  # 打印报错信息
            path_ = settings.REPORT_DIR
            report_path = os.path.join(path_, 'error_{}.html'.format(time.time().__str__().replace('.', '')))
            with open(report_path, 'w') as f:
                f.write(msg)
            # 将错误报告上传到Minio
            report_path = self.uploadFileMinio(report_path)
            report_obj.report_file_path = report_path
            report_obj.status = 'error'
        finally:
            report_obj.save(update_fields=['status', 'report_file_path', 'update_time'])
            suumarry_obj.save()
            if isinstance(report_obj, ResultReportModel):
                task_obj = report_obj.testCaseTask
                task_obj.task_status =report_obj.status
                task_obj.save(update_fields=['task_status', 'update_time'])
        try:
            if hasattr(report_obj, "testCaseTask_id"):
                logger_debug.info('测试结果：{}；任务类型：{}'.format(
                    report_obj.status,
                    TestTaskModel.objects.get(id=report_obj.testCaseTask_id).case_type
                ))
            if hasattr(report_obj, "testCaseTask_id") and report_obj.status == 'true' and TestTaskModel.objects.get(id=report_obj.testCaseTask_id).case_type == 1:
               self.runContractTest(report_obj, sumarry)
        except Exception as e:
            logger_debug.exception('契约测试执行失败，异常信息={}'.format(e))
        return report_path

    def runBySceneById(self, scene_id, host_url = None):
        scene_obj = InterfaceSceneModel.objects.get(id=scene_id)
        case_file_path = scene_obj.case_file_path
        report_obj = scene_obj.createReport()
        try:
            report_path = self.run(path_or_tests=case_file_path, mapping={"BASE_URL": host_url})
            report_obj.status = self.summary['success']
            report_obj.report_file_path = report_path
        except Exception as e:
            path_ = settings.REPORT_DIR
            report_path = os.path.join(path_, 'error_{}.html'.format(time.time().__str__().replace('.','')))
            with open(report_path, 'w') as f:
                f.write(e.__str__())
            report_obj.status = 'false'
        finally:
            report_obj.save()
        return report_path

    @property
    def summary(self):
        return super().summary

    def contractSendEmail(self, res, to, subjent):
        logger_debug.info("邮件内容：{}，to：{}".format(res,to))
        email = SendEmail(subject=subjent, body=res, to=to)
        email.send_email()

    def getUserGroupEmail(self, projectid):
        group_id = TestProjectModel.objects.get(id=projectid).user_group_id
        user_groups = UserModel.objects.filter(groups=group_id)
        get_emial = []
        for user in user_groups:
            get_emial.append(user.email)
        return get_emial

    def cmpJson(self, src_json, cmp_json):
        """
        比较两个json文件
        :param src_json:
        :param cmp_json:
        :return:
        """
        if isinstance(src_json, dict) and isinstance(cmp_json, dict):
            try:
                result = json_tools.diff(src_json, cmp_json)
            except Exception as e:
                logger_debug.exception("对比dict失败：src={},cmp={},异常信息={}".format(src_json,cmp_json,e))
                return 'false'
            if result == []:
                return 'true'
            else:
                for res in result:
                    if 'remove' in res.keys():
                        self.res_response_data["被删除字段"].append(res['remove'].strip("/"))
                    if 'add' in res.keys():
                        self.res_response_data["被增加字段"].append(res['add'].strip("/"))
                    if 'replace' in res.keys() and 'details' in res.keys():
                        self.res_response_data["值的类型被改变字段"].append(res['replace'].strip("/") +
                                ": 当前值类型=%s" % str(type(res['value'])).split("'")[1] + ",参考值类型=%s" % str(type(res['prev'])).split("'")[1])
                if self.res_response_data["被增加字段"] == [] and self.res_response_data["被删除字段"] == [] and self.res_response_data["值的类型被改变字段"] == []:
                    return 'true'
                return self.res_response_data
        else:
            return 'false'

    def runContractTest(self, report_obj, sumarry):
        """
        执行契约测试
        :param report_obj:
        :param sumarry:
        :return:
        """
        get_same_id = ContractTestModel.objects.filter(
            Q(interface_id=TestTaskModel.objects.get(id=report_obj.testCaseTask_id).interface_id) & Q(
                task_id=report_obj.testCaseTask_id))
        logger_debug.info("获取契约测试是否存在 {}".format(get_same_id.count()))
        try:
            cur_summary = json_tools.loads(sumarry)
            case_details_len = len(cur_summary["caseDetails"])
            summary = cur_summary["caseDetails"][case_details_len-1]["response"]["body"]
            if summary == 'None':
                summary = {}
            if not isinstance(summary, dict):
                return
        except Exception as e:
            logger_debug.exception("json格式化失败：sumarry={},异常信息={}".format(sumarry, e))
            return
        if get_same_id.count() == 0:
            """写入报告数据"""
            logger_debug.info("创建契约测试模板,interfaceid_id:{},reportid_id:{};projectid_id:{};taskid_id:{}".format(
                TestTaskModel.objects.get(id=report_obj.testCaseTask_id).interface_id,
                report_obj.id, report_obj.project_id, report_obj.testCaseTask_id
            ))
            ContractTestModel.objects.create(interface_id=TestTaskModel.objects.get(id=report_obj.testCaseTask_id).interface_id,
                                             report_id=report_obj.id,
                                             project_id=report_obj.project_id,
                                             task_id=report_obj.testCaseTask_id)
            logger_debug.info("创建契约测试模板")
            return
        reportid = ResultReportModel.objects.get(id=get_same_id.get(interface_id=TestTaskModel.objects.get(
            id=report_obj.testCaseTask_id).interface_id).report_id).id  # logger_debug.info("获取对比值(参考和对比)：{}和{}".format(get_summary,cur_summary))
        # get_summary = json_tools.loads(SummaryModel.objects.get(result_report_id=reportid).summary_count)
        # summary_count 更改为文件路径 2019-8-27 14:01:58
        # with open(SummaryModel.objects.get(result_report_id=reportid).summary_count, 'r') as f:
        #     summary_count_data = f.read()
        summary_count_data = SummaryModel.objects.get(result_report_id=reportid).summary_count_data()
        get_summary = json_tools.loads(summary_count_data)

        get_cDetails_len = len(get_summary["caseDetails"])
        get_body = get_summary["caseDetails"][get_cDetails_len-1]["response"]["body"]
        if get_body == 'None':
            get_body = {}
        if get_summary != "" and cur_summary != "":
            res = self.cmpJson(get_body, summary)
            logger_debug.info("对比结果：{}".format(res))
            if res == 'false':
                return
            if res != 'true':
                try:
                    # get_email = ContractTestModel.objects.get(interfaceid_id=report_obj.interface_id).email_to
                    res = json.dumps(res, ensure_ascii=False, sort_keys=True, indent=4, separators=(',', ': '))
                    project_name = TestProjectModel.objects.get(id=get_same_id.get(interface_id=TestTaskModel.objects.get(id=report_obj.testCaseTask_id).interface_id).project_id).project_name
                    interface_name = InterfaceModel.objects.get(id=TestTaskModel.objects.get(id=report_obj.testCaseTask_id).interface_id).name
                    body = "项目名称: " + project_name
                    body += "\n" + "接口名称: " + interface_name
                    body += "\n" + "接口地址: " + str(cur_summary["caseSumarryInfo"][0]["url"])
                    body += "\n" + "任务名称：" + TestTaskModel.objects.get(id=report_obj.testCaseTask_id).name
                    body += "\n" + "当前报告时间：" + cur_summary["baseInfo"]["start_time"]
                    body += "\n" + "参考报告时间：" + get_summary["baseInfo"]["start_time"]
                    body += "\n" + "对比后发生改变的内容: " + res
                    get_email = self.getUserGroupEmail(report_obj.project_id)
                    ContractTestResModel.objects.create(
                        contract_id=get_same_id.get(Q(interface_id=TestTaskModel.objects.get(id=report_obj.testCaseTask_id).interface_id) & Q(task_id=report_obj.testCaseTask_id)).id,
                        result=body,
                        email_to=get_email,
                        project_id=report_obj.project_id
                    )
                    if get_email == "":
                        logger_debug.info('未获取到项目下的用户邮件')
                        logger_debug.info('未获取到项目下的用户邮件，项目id：{}'.format(report_obj.project_id))
                    else:
                        subject = "契约测试失败-{}-{}".format(project_name, interface_name)
                        self.contractSendEmail(body, get_email, subject)
                except Exception as e:
                    logger_debug.exception("发送契约测试邮件失败:body={},get_eamil={},异常信息={}".format(body,get_email,e))
            get_same_id.update(report_id=report_obj.id,
                               task_id=TestTaskModel.objects.get(id=report_obj.testCaseTask_id).id)

    def dumpTestCaseByPath(self, file_path, case_name=None):
        """
        :param:
        :return:
        """
        self.dumpConfig()
        self.dumpTest(case_name=case_name)
        if self.is_need_login():
            # 用户勾选默认登陆
            self.insert_login_case()
        case_json = json.dumps(self.test_case_tem)
        case_file_name = '{}.json'.format(str(time.time()).replace('.', ''))
        file_path = os.path.join(file_path, case_file_name)
        with open(file_path, 'w') as f:
            f.write(case_json)

    def dumpTestCase(self):
        """
        根据用户传递参数 生成任务json
        :param:
        :return:
        """
        self.dumpConfig()
        self.dumpTest()
        if self.is_need_login():
            # 用户勾选默认登陆
            self.insert_login_case()
        case_json = json.dumps(self.test_case_tem, indent=4)  # indent=4 可将json格式化
        case_name = '{}.json'.format(str(time.time()).replace('.', ''))
        file_path = os.path.join(settings.TESTCASE_DIR, case_name)
        with open(file_path, 'w') as f:
            f.write(case_json)
        return file_path

    def get_app_host_key(self) -> dict:
        '''

        :return: {
        "app_host_1":"< input app host >"
        "app_host_2":"< input app host >"
        }
        '''
        project_obj = self.get_project()
        app_set = project_obj.application.filter(is_delete=False).all()
        app_host = dict()
        for app_ in app_set:
            app_host['app_host_{}'.format(app_.id)] = 'input app host'
        return app_host

    def get_app_host_by_env(self,env_id, project_id) -> dict:
        '''
        :return: {
        "app_host_1":"http://Example.com"
        "app_host_2":"http://Example2.com"
        }
        '''
        project_obj = self.get_project(project_id)
        app_host_ = project_obj.app_env.filter(env_id=env_id, is_delete=False).all()
        app_host_key_value = dict()
        for app_env in app_host_:
            app_host_key_value['app_host_{}'.format(app_env.application_id)] = app_env.host
        return app_host_key_value

    def dumpConfig(self):
        header_dict = {
            "config": {
              "name": self.validate_['name'] if self.validate_.get('name') else self.instance_.name ,
              "variables": self.get_app_host_key()
            }
        }
        self.test_case_tem.insert(0,header_dict)

    def is_need_login(self):
        """
        判断是否需要登陆
        :return:
        """
        publish_case = self.validate_['publish_case'] if self.validate_.get('publish_case', None) else self.instance_.publish_case
        if publish_case is not None:
            return json.loads(publish_case).get('login', False)
        else:
            return False

    def insert_login_case(self):
        """
        插入登陆用例
        该方法会在解释完所有用例后执行，
        :param publish_case:
        :return:
        """
        # 这里需要用到 project_id   项目id
        publish_case_obj = PublishCaseModel.objects.filter(case_type=0, is_default=True, is_delete=False, project_id=self.project_id).first() #case_type=0 为登陆接口
        # self.validate_['case_content'] =json.loads(publish_case_obj.case_content)
        self.test_content = json.loads(publish_case_obj.case_content)
        self.validate_['interface'] = publish_case_obj.interface
        case_content = self.dumpCase_() # 返回的是一个包含用例内容的字典
        case_content['test']['name'] = self.test_content["name"]
        # case_content['test']['request']['url'] = case_content['test']['request']['url']
        extract_list = self.test_content.get('extract', [])  # extract 参数提取
        header_args = dict()
        for extract_dict in extract_list:
            header_args[extract_dict['key']] = '$' + extract_dict['key']
        for case_content_index in range(1, self.test_case_tem.__len__()):
            self.test_case_tem[case_content_index]['test']['request']['headers'].update(header_args)
        del self.validate_['interface']
        self.test_case_tem.insert(1, case_content)

    def dumpTest(self, case_name=None):
        #目前只有可能是任务，没有用例和场景
        if self.validate_.get('case_content') or hasattr(self.instance_, 'case_content'):
            self.test_content = json.loads(self.validate_['case_content'] if self.validate_.get('case_content') else self.instance_.case_content)
            self.dumpCase_()
        # 生成任务文件json
        elif self.validate_.get('task_content') or hasattr(self.instance_, 'task_content'):
            #task_content_list 任务数据 中包含本次测试的一个或多个测试接口和测试数据
            self.task_content_list = json.loads(self.validate_['task_content'] if self.validate_.get('task_content') else self.instance_.task_content)
            for case_info in self.task_content_list:
                self.test_content = case_info
                self.validate_['interface'] = InterfaceModel.objects.get(id=case_info['interface_id'])
                case_info_ = self.dumpCase_(case_name=case_name) # 返回一个用例字典
                # test_case_tem 数据结构=> [{本次测试header}{用例1}{用例2}{用例3}{...}] 用例头包含base_url 变量本次测试名等
                self.test_case_tem.append(case_info_)
            else:
                del self.validate_['interface']

    def dumpCase_(self, case_name=None):
        # 返回 一个用例对象

        if isinstance(self.test_content.get('case_validate', []), str):
            case_validate_ = json.loads(self.test_content.get('case_validate')) # 空数组loads成 字符串 bug
        else:
            case_validate_ = self.test_content.get('case_validate', [])

        validate = [
            {
                vali['assert']:[vali['key'], vali['value']]
            } for vali in case_validate_
        ]
        variables_obj = self.test_content.get('case_params', [])
        if isinstance(variables_obj, str):
            variables_obj = json.loads(variables_obj)
        var = {} #参数传递到url上
        for index, veriable_dict in enumerate(variables_obj):
            if veriable_dict.get('key').startswith('$'):
                tmp_var = variables_obj.pop(index)
                var[tmp_var['key'][1:]] = tmp_var.get('value')

        # params = None
        method = self.validate_['interface'].method
        # url_ = self.validate_['interface'].path if not variables_obj.__len__() else self.validate_['interface'].path + '?' + '&'.join(
        #     ['{}={}'.format(i['key'], i['value']) for i in variables_obj])
        url_ = self.interface_path_params(interface_path=self.validate_['interface'].path, case_params=variables_obj)

        #url 前面加上 $app_host_<app_id>
        url = '$app_host_{}'.format(self.validate_['interface'].application_id) + url_
        #解释请求头
        # request_head = self.dumpHeader() # 请求头数据全部从用例中得到
        request_head = {}
        for i in self.test_content.get('case_header_info', []):
            # request_head[i['key']] = i.get('value','')
            request_head[self.strHeader(i['key'])] = self.strHeader(i.get('value',''))
        #　2019-10-30 获取接口运行耗时
        request_head["AutomateInterfaceID"] = "{}".format(self.validate_['interface'].id)

        extract_ = self.test_content.get('extract', [])
        extract = [{i['key']: i['value']} for i in extract_]

        # 增加后置函数 2019-6-24
        code = self.test_content.get('code', '')
        programlang = self.test_content.get('programlang', '')
        teardown_hooks = []
        if code:
            # extract_ = self.write_func_to_extract(code, extract_)
            teardown_hooks = self.test_content.get("teardown_hooks", [])
            if teardown_hooks:
                teardown_hooks = []
            # teardown_hooks = self.write_teardown_hooks(code=code, teardown_hooks=teardown_hooks)
            teardown_hooks = self.write_teardown_hooks(code=code, teardown_hooks=teardown_hooks, programlang=programlang)
        print("*" * 12)
        print(case_name) if case_name else print(self.validate_['interface'].name)
        print("*" * 12)
        case_tmp = {
            "test": {
                "name": case_name if case_name else self.validate_['interface'].name ,
                "variables": var,
                "request": {
                    "url": url,
                    "method": method,
                    "headers": request_head,
                },
                "validate": validate,
                "teardown_hooks": teardown_hooks,
                "extract": extract
            }
        }
        print("*" * 12)
        print(case_tmp)
        print("*" * 12)
        # get 请求没有请求体
        if method.lower() != "get":
            # json_body = dict()
            # json格式
            if self.test_content.get('case_body_type') == 'raw':
                case_tmp['test']['request']['json'] = self.test_content.get('case_body_data')
                if case_tmp['test']['request']['headers'].get('Content-Type', None) is None:
                    case_tmp['test']['request']['headers']['Content-Type'] = 'application/json'
            # 表单格式 可上传文件-文件通过files关键字参数传参
            elif self.test_content.get('case_body_type') == 'x-formdata-file':
                for index, case_body_data_dict in enumerate(self.test_content.get('case_body_data', [])):
                    file_key = 'file_%s' % index
                    if case_body_data_dict['type'].lower() == 'file':
                        try:
                            file_name = case_body_data_dict.get('value', '')
                            upload_file_obj = UploadFileModel.objects.get(project_id=self.project_id, file_name=file_name,  is_delete=False)
                            file_full_name = file_name + '.' + upload_file_obj.suffix
                            # file_full_name = os.path.basename(upload_file_obj.file_path)
                            case_tmp['test']['variables'][file_key] = file_full_name
                            case_tmp['test']['variables'][file_key + '_path'] = upload_file_obj.file_path
                            case_tmp['test']['variables'][file_key + '_type'] = self.guess_type(upload_file_obj.file_path)
                            # 文件类型 需要 通过 files 参数上传
                            if case_tmp['test']['request'].get('files') is None:
                                case_tmp['test']['request']['files'] = dict()

                            # 修复Exception Value: unexpected '{' in field name
                            # case_tmp['test']['request']['files'][case_body_data_dict['key']] = '[${},${open(${},rb)},${}]'.format()
                            case_tmp['test']['request']['files'][case_body_data_dict['key']] = ['{0}'.format(file_full_name),
                                                                                                '${{open(${0},rb)}}'.format(file_key + '_path'),
                                                                                                '${0}'.format(file_key + '_type')
                                                                                                ]
                        except UploadFileModel.DoesNotExist as e:
                            pass
                    else:
                        if case_tmp['test']['request'].get('data') is None:
                            case_tmp['test']['request']['data'] = dict()
                        case_tmp['test']['request']['data'][case_body_data_dict['key']] = case_body_data_dict.get('value', '')

            # key-value 格式 平台独有 其实也是json格式
            elif self.test_content.get('case_body_type') == 'x-formdata':
                for i in self.test_content.get('case_body_data', []):
                    if case_tmp['test']['request'].get('json') is None:
                        case_tmp['test']['request']['json'] = dict()
                    case_tmp['test']['request']['json'][i['key']] = i.get('value', '')
                if case_tmp['test']['request']['headers'].get('Content-Type', None) is None:
                    case_tmp['test']['request']['headers']['Content-Type'] = 'application/json'

            # xml格式
            elif self.test_content.get('case_body_type') == 'xml':
                if util.checkXML(self.test_content.get('case_body_data')):
                    # for i in self.test_content.get('case_body_data', []):
                    #     params[i['key']] = i.get('value', '')
                    case_tmp['test']['request']['data'] = self.test_content.get('case_body_data')
                    if case_tmp['test']['request']['headers'].get('Content-Type', None) is None:
                        case_tmp['test']['request']['headers']['Content-Type'] = 'text/xml'
                else:
                    logger_debug.error('xml文件格式不正确，case_body_data={}，项目id：{}'.format(self.test_content.get('case_body_data'), self.project_id))
        return case_tmp

    def interface_path_params(self, interface_path, case_params):
        """接口path带参数时，与params中参数结合"""
        if not case_params.__len__():
            url_ = interface_path
        else:
            interface_path_query = urlparse(interface_path).query
            if interface_path_query:
                url_ = interface_path + '&' + '&'.join(['{}={}'.format(param['key'], param['value']) for param in case_params])
            else:
                url_ = interface_path + '?' + '&'.join(['{}={}'.format(param['key'], param['value']) for param in case_params])

        return url_


    def guess_type(self, file_path):
        """
        识别文件类型，返回 content-type 类型
        :param file_path:
        :return:
        """
        import filetype
        file_type = filetype.guess(file_path)
        if file_type is None:
            return 'text/html'
        else:
            return file_type.mime

    def strHeader(self, param):
        """将请求头中的$xxx返回值强转为str"""
        try:
            # regex = re.compile(r"\$(.+)", re.S)
            # ret = re.search(regex, param)
            # if ret is None:
            #     return param
            # replace_param = "${{str(${0})}}".format(ret.group(1))
            # new_param = re.sub(regex, replace_param, param)
            # return new_param
            regex = re.compile(r"\$([\w_]+)", re.S)
            ret_list = re.findall(regex, param)
            if not ret_list:
                return param
            for ret in ret_list:
                replace_param = "${{str(${0})}}".format(ret)
                param = param.replace('${0}'.format(ret), replace_param)
            return param
        except Exception:
            return param

    def dumpHeader_(self):
        pass

    def dumpHeader(self):
        request_head_ = InterfaceModel.objects.get(id=self.validate_['interface']).request_head
        request_head_infos = InterfaceModel.objects.get(id=self.validate_['interface']).module.project.project_header_infos
        try:
            request_head_info_list = json.loads(request_head_infos)
            if isinstance(request_head_info_list, list):
                request_head_info = OrderedDict()
                for i in request_head_info_list:
                    if i['key'] == '':
                        continue
                    request_head_info[i['key']]= i.get('value', '')
                try:
                    request_head_ = json.loads(request_head_)
                except Exception as e:
                    request_head = request_head_info
                else:
                    if isinstance(request_head_, dict):
                        for i in request_head_.keys():
                            request_head_info[i] = request_head_[i]
                        else:
                            request_head = request_head_info
                    else:
                        request_head = request_head_info
            else:
                request_head = None
        except Exception as e:
            request_head = None
        return request_head

    def updateTestCase(self):
        try:
            os.remove(self.instance_.case_file_path)
        except Exception as e:
            logger_debug.exception('移除旧用例失败，用例地址={}，遗产信息={}'.format(self.instance_.case_file_path, e))
        return self.dumpTestCase()

    def dumpTestScenc(self):
        self.dumpConfig()
        self.dumpTest()
        pass

    def createProjectDir(self, project_name):
        """
        创建项目目录---> 测试用例结构
        :param project_name:
        :return:
        """
        project_path = os.path.join(settings.TEST_PROJECT_PATH, project_name)
        from httprunner.utils import create_scaffold
        create_scaffold(project_path)

    def dumpTestCases(self, case_id_list, name_set=None):
        cases = []
        for id in case_id_list:
            case = InterfaceCaseModel.objects.filter(is_delete=False).get(id=id)
            case_file_path = case.case_file_path
            try:
                with open(case_file_path, 'r') as f:
                    case_json = f.read()
                case_obj = json.loads(case_json)
                if cases.__len__() == 0 :
                    cases = case_obj
                else:
                    cases.extend(case_obj[1:])
            except Exception as e:
                logger_debug.exception('添加用例失败，case_file_path={}，异常信息={}'.format(case_file_path,e))
                pass
            if name_set is not None:
                name_set.add(case.name)
        time_p = time.time().__str__().replace('.', '')
        case_json_file_path = os.path.join(settings.TESTCASE_DIR,'{}.json'.format(time_p))
        with open(case_json_file_path, 'w') as f:
            f.write(json.dumps(cases))
        return case_json_file_path

    @staticmethod
    def timeP():
        return time.time().__str__().replace('.', '')

    @classmethod
    def createTempDIR(cls):
        path = os.path.join(settings.TESTCASE_DIR, 'tem/{}'.format(cls.timeP()))
        try:
            os.makedirs(path)
        except Exception as e:
            logger_debug.info('新建用例地址失败,再次创建，path={},异常信息={}'.format(path,e))
            path = os.path.join(settings.TESTCASE_DIR, 'tem/{}_{}'.format(cls.timeP(), random.randint(1, 1000)))
            os.makedirs(path)
        return path

    @staticmethod
    def copyCase(old_path, new_par_path):
        if os.path.isdir(old_path):
            for s in os.listdir(old_path):
                case_file = os.path.join(old_path, s)
                shutil.copy(case_file, new_par_path)
        else:
            new_path = os.path.join(new_par_path, old_path.split('/')[-1])
            with open(old_path, 'r') as f:
                file_ = f.read()
            with open(new_path, 'w') as f:
                f.write(file_)

    # @staticmethod
    # def copyDir(old_dir, new_par_dir):
    #     if os.path.isdir(old_dir):
    #         for s in os.listdir(old_dir):
    #             case_file = os.path.join(old_dir, s)
    #             shutil.copy(case_file, new_par_dir)

    def copyLevelAllCase(self, task_instance):
        try:
            #删除目录下的用例
            for file_path in os.listdir(task_instance.case_file_path):
                file_path = os.path.join(task_instance.case_file_path, file_path)
                os.remove(file_path)
        except Exception as e:
            # 日志记录在debug.log
            logger_debug.exception('删除目录下的用例失败，file_path={},异常信息={}'.format(file_path, e))

        task_content = json.loads(task_instance.task_content)

        for case_or_secen_level in task_content['level_obj']:
            if case_or_secen_level['type'] == 1 or case_or_secen_level['type'] == 2 or case_or_secen_level['type'] == 3:     #type=0是等级及以前的case和secen用level，1是用例,2是场景,3是聚合用task_id
                task_set = TestTaskModel.objects.filter(id=case_or_secen_level['task_id'])
                for task in task_set:
                    try:
                        self.copyCase(task.case_file_path, task_instance.case_file_path)
                    except Exception as e:
                        logger_debug.exception('复制用例失败，task.case_file_path={}, task_instance.case_file_path={},异常信息='.format(task.case_file_path, task_instance.case_file_path,e))
            else:
                case_set = TestTaskModel.objects.filter(
                    level=case_or_secen_level['level'],
                    project_id=task_content['project_id'],
                    is_delete=False
                )
                for case in case_set:
                    try:
                        self.copyCase(case.case_file_path, task_instance.case_file_path)
                    except Exception as e:
                        logger_debug.exception(
                            '复制用例失败，case.case_file_path={}, task_instance.case_file_path={},异常信息='.format(
                                case.case_file_path, task_instance.case_file_path, e))



    def get_summary(self,summary=None, suumarry_obj=None, project_id=None, report_id=None, env_id=None):
        #处理HttpRunner源生的报告数据
        reportAllInfo = {}
        # 左上角的概要信息
        baseInfo = {}
        baseInfo["start_time"] = time.strftime('%Y/%m/%d %H:%M:%S', time.localtime(summary["time"]["start_at"]))
        baseInfo["execution_time"] =float('%.2f' % summary["time"]["duration"])
        baseInfo["total_cases"] = summary["stat"]["teststeps"]["total"]
        # update 将运行的用例数记录到数据库
        try:
            total_cases = baseInfo["total_cases"]
            suumarry_obj.total_cases = total_cases
        except Exception as e:
            logger_debug.exception('运行用例数保存至数据库错误baseInfo={},异常信息={} %s'.format(baseInfo,e))

        baseInfo["pass_cases"] = summary["stat"]["teststeps"]["successes"]
        baseInfo["fail_cases"] = summary["stat"]["teststeps"]["errors"] + summary["stat"]["teststeps"]["failures"]


        # 用例概要信息
        caseSumarryInfo = []
        # 用例详情
        caseDetails = []
        request ={}
        response= {}
        validatorList = []
        i = 0
        # 如果传的是文件夹，需要最外层循环
        for all in summary["details"]:
            for csf in all["records"]:
                caseSumarryInfo.append({"status": csf["status"],
                                        "name": csf["name"],
                                        "url": csf["meta_datas"]["data"][0]["request"]["url"],
                                        "id": i
                                        })
                # update 显示单个接口运行时间 2019-7-15 10:07:08
                response_time = csf["response_time"]
                request["url"] = csf["meta_datas"]["data"][0]["request"]["url"]
                request["method"] = csf["meta_datas"]["data"][0]["request"]["method"]
                request["headers"] = csf["meta_datas"]["data"][0]["request"]["headers"]

                # 2019-10-30 获取接口id,将接口运行耗时写入数据库
                interface_id = request["headers"].get('AutomateInterfaceID', None)
                try:
                    if interface_id:
                        interface_query = InterfaceModel.objects.filter(id=interface_id, is_delete=False)
                        if interface_query:
                            from interface.models import InterfaceExecutionTimeModel
                            interface_time_obj = InterfaceExecutionTimeModel.objects.filter(interface_id=interface_id, env_id=env_id)
                            if not interface_time_obj:
                                InterfaceExecutionTimeModel.objects.create(interface_id=interface_id, execution_time=response_time, project_id=project_id, report_id=report_id, env_id=env_id)
                            else:
                                interface_time_obj.update(execution_time=response_time, report_id=report_id, is_delete=False)
                        request["headers"].pop("AutomateInterfaceID")
                except Exception as e:
                    logger_debug.error("Update interface execution_time fail;interface_id={}, error={}".format(interface_id, e))

                if csf['meta_datas']['data'][0]['response']['status_code'] != 'N/A':
                    csf_request = csf["meta_datas"]["data"][0]["request"]
                    # request["body"] = csf_request.get("body", '')

                    csf_request_body_ = csf_request.get("body", '')
                    # bug修复json格式不正确 'body': Markup('{&#34;mode&#34;: 0, &#34;content&#34;: &#34;1234&#34;, &#34;operation&#34;: 0}')
                    if hasattr(csf_request_body_, 'unescape'):
                        from markupsafe import Markup
                        _striptags_re = re.compile(r"(<!--.*?-->|<[^>]*>)")
                        stripped = u" ".join(_striptags_re.sub("", csf_request_body_).split())
                        request["body"] = Markup(stripped).unescape()
                    else:
                        request["body"] = csf_request_body_
                        
                    # request body格式转换
                    try:
                        request["body"] = json.loads(request["body"])
                    except Exception:
                        pass

                    response["code"] = csf["meta_datas"]["data"][0]["response"]["status_code"]
                    response["headers"] = csf["meta_datas"]["data"][0]["response"]["headers"]
                    if "text" in csf["meta_datas"]["data"][0]["response"]:
                        response["body"] = csf["meta_datas"]["data"][0]["response"]["text"]
                    elif "body" in csf["meta_datas"]["data"][0]["response"]:
                        response["body"] = csf["meta_datas"]["data"][0]["response"]["body"]
                    else:
                        response["body"] = csf["meta_datas"]["data"][0]["response"]["json"]
                # update 增加 N/A 报告的显示
                if csf['meta_datas']['data'][0]['response']['status_code'] == 'N/A':
                    request["body"] = {}
                    response["code"] = 'N/A'
                    response["headers"] = {}
                    response["body"] = {}

                # response["attachment"] = csf["attachment"]
                attachment = csf["attachment"]
                validator = {}
                for v in csf["meta_datas"]["validators"]:
                    validator["check"] = v["check"]
                    validator["comparator"] = v["comparator"]
                    validator["expect"] = v["expect"]
                    validator["check_value"] = v["check_value"]
                    validatorList.append(validator)
                    validator = {}
                caseDetails.append({
                    "id": i,
                    "request": request,
                    "response": response,
                    "validator": validatorList,
                    "attachment": attachment,  # 失败信息
                    "response_time": response_time
                })
                request = {}
                response = {}
                validatorList = []
                i = i + 1
        reportAllInfo["baseInfo"] = baseInfo
        reportAllInfo["caseSumarryInfo"] = caseSumarryInfo
        reportAllInfo["caseDetails"] = caseDetails
        # 将summary_count存储内容更改为文件路径 2019-8-28 11:01:05
        report_file_name = '{0}.{1}'.format(int((time.time()) * 10 ** 6), 'json')
        report_file = os.path.join(settings.REPORT_DIR, report_file_name)
        with open(report_file, 'w') as f:
            f.write(json.dumps(reportAllInfo, indent=4))
        # suumarry_obj.summary_count = report_file

        # update 报告上传Minio服务器 2019-9-4 14:42:51
        minio_obj = MinioServiceFile()
        put_ret = minio_obj.put_file(bucket_name=settings.REPORT_BUCKET_NAME, put_file_path=report_file)
        if put_ret:
            suumarry_obj.summary_count = '/{0}/{1}'.format(settings.REPORT_BUCKET_NAME, report_file_name)
            os.remove(report_file)
        return json.dumps(reportAllInfo)

    def get_project(self, project_id=None):
        if project_id:
            self.project_id = project_id
        return TestProjectModel.objects.get(id=self.project_id)

    # update 获取接口ID 2019-5-15 15:46:18
    def get_interface_obj(self):
        interface_obj = None
        try:
            case_type = self.validate_.get('case_type', None)
            if case_type != 1:
                return interface_obj
            if self.validate_.get('task_content') or hasattr(self.instance_, 'task_content'):
                scene_content = json.loads(self.validate_['task_content'] if self.validate_.get('task_content') else self.instance_.task_content)
                for i in scene_content:
                    # 这里可能接口已经删除
                    interface_obj = InterfaceModel.objects.filter(id=i['interface_id'], is_delete=False).all()
                    if interface_obj.__len__():
                        return interface_obj.first()
                    else:
                        return None
        except Exception as e:
            logger_debug.exception(e)
            return interface_obj
        
    def interface_use_case_count(self):
        try:
            case_type = self.validate_.get('case_type', None)
            if case_type == 3:
                return None

            if self.validate_.get('task_content'):
                scene_content = json.loads(self.validate_['task_content'])
                for i in scene_content:
                    # 这里可能接口已经删除
                    interface_objs = InterfaceModel.objects.filter(id=i['interface_id'], is_delete=False).all()
                    for interface_obj in interface_objs:
                        interface_obj.use_case += 1
                        interface_obj.save(update_fields=['use_case', ])
            if hasattr(self.instance_, 'task_content'):
                #原来的减1
                scene_content = json.loads(self.instance_.task_content)
                for i in scene_content:
                    # 这里可能接口已经删除
                    interface_objs = InterfaceModel.objects.filter(id=i['interface_id'], is_delete=False).all()
                    for interface_obj in interface_objs:
                        interface_obj.use_case -= 1
                        interface_obj.use_case = interface_obj.use_case if interface_obj.use_case > 0 else 0
                        interface_obj.save(update_fields=['use_case', ])

        except Exception as e:
            logger_debug.exception(e)


    @staticmethod
    def write_func_to_extract(code, extract_):
        """将后置函数写入返回值列表中 -> 弃用"""
        try:
            # 获取code函数名
            re_function = re.search(r'def (.*?)\((.*?)\):', code)
            func_name = dict()
            if re_function:
                code_func_name = re_function.group(1)
                code_func_name = code_func_name.replace(' ', '')
                param = re_function.group(2)
                param = '${0}'.format(param)
                talk_func_name = '{0}_{1}'.format(code_func_name, int((time.time()) * 10 ** 7))
                write_code = code.replace(code_func_name, talk_func_name, 1)
                # 写入返回值列表中
                func_name['key'] = code_func_name
                func_name['value'] = '${{{0}({1})}}'.format(talk_func_name, param)
                extract_.append(func_name)
                # 写入debugtalk.py 文件
                defined_func_obj = DefinedFunction()
                run_result = defined_func_obj.debug(code)
                if run_result["success"] is True:
                    logger_debug.info('自定义函数代码写入debugtalk')
                    defined_func_obj.write_debugtalk(code=write_code)
        except Exception as e:
            logger_debug.exception('后置函数写入错误code={},异常信息={}'.format(code, e))
        finally:
            return extract_

    @staticmethod
    def write_teardown_hooks(code, teardown_hooks, programlang='Python'):
        """将后置函数写入teardown_hooks"""
        try:
            # 获取code函数名
            if programlang == 'JavaScript':
                re_function = re.search(r'function (.*?)\((.*?)\){', code)
            else:
                re_function = re.search(r'def (.*?)\((.*?)\):', code)
            if re_function:
                code_func_name1 = re_function.group(1)
                code_func_name = code_func_name1.replace(' ', '')
                param = re_function.group(2)
                param = param.replace(' ', '')
                if param:
                    param = param.split(',')
                    # 第一个参数默认为response
                    param[0] = '$response'
                    param = ','.join(param)
                talk_func_name = '{0}_{1}'.format(code_func_name, int((time.time()) * 10 ** 7))

                # 写入debugtalk.py 文件
                defined_func_obj = DefinedFunction()
                # run_result = defined_func_obj.debug(code)
                run_result = {"success": True}
                if run_result["success"] is True:
                    logger_debug.info('自定义函数代码写入debugtalk')
                    write_code = code.replace(code_func_name1, talk_func_name, 1)
                    defined_func_obj.write_debugtalk(code=write_code, funname=talk_func_name, programlang=programlang)
                    # 添加至teardown_hooks
                    # teardown_hook_func = '${{{0}({1})}}'.format(talk_func_name, param)
                    teardown_hook_func = '${{{0}({1},{2})}}'.format('debugtalkfun', '$response', talk_func_name)
                    teardown_hooks.append(teardown_hook_func)
                    # 加载debugtalk中的函数
                    try:
                        # loader.load_debugtalk_functions()
                        loader.load_project_tests(settings.TESTCASE_DIR)
                    except Exception as e:
                        logger_debug.exception('debugtalk中的函数加载错误 Error:%s' % e)
        except Exception as e:
            logger_debug.exception('后置函数写入错误code={}, Error:{}'.format(code, e))
        finally:
            return teardown_hooks




class CaseDump(object):
    def __init__(self, json_file=None, file_type=None, project = None, module= None):
        self.json_file = json_file
        self.interface_list = []
        self.create_interface_count = 0
        self.create_case_count = 0
        self.case_list = []
        self.file_type = file_type
        self.success = False
        self.__file_type = ((0, 'postman'), (1, 'swagger'), (2, 'fiddler'))
        self.project = project
        self.module = module
        super().__init__()

    def copyCase(self, old_path, new_par_path):
        """
        把所有文件复制到新的文件夹
        递归函数
        :param new_path:
        :param old_path:
        :return:
        """
        if os.path.isfile(old_path):
            shutil.copy(old_path, new_par_path)
        elif os.path.isdir(old_path):
            for file_name in os.listdir(old_path):
                file_path = os.path.join(old_path, file_name)
                if os.path.isdir(file_path):
                    self.copyCase(new_par_path, file_path)
                else:
                    shutil.copy(file_path, new_par_path)

    def copyTaskJsonFileToTempFileDIR(self, task_id_list):
        '''
        复制任务勾选的任务的json文件到临时文件夹，
        :param task_list:
        :return:
        '''
        task_temp_file_path = os.path.join(settings.TESTCASE_DIR, 'tmp')
        if not os.path.exists(task_temp_file_path):
            os.makedirs(task_temp_file_path)
        task_file_path = os.path.join(task_temp_file_path, self.timeP)
        os.makedirs(task_file_path)
        for task_id in task_id_list:
            task_obj = TestTaskModel.objects.filter(is_delete=False).get(id=task_id)
            self.copyCase(task_obj.case_file_path,task_file_path)
        return task_file_path

    def copyTaskJsonFileByCaseLevel(self, case_level, project_id):
        task_temp_file_path = os.path.join(settings.TESTCASE_DIR, 'tmp')
        if not os.path.exists(task_temp_file_path):
            os.makedirs(task_temp_file_path)
        task_file_path = os.path.join(task_temp_file_path, "ci" + self.timeP)
        os.makedirs(task_file_path)
        task_dict_list = TestTaskModel.objects.filter(is_delete=False,project_id=project_id, level=case_level).values("case_file_path").all()
        for task_dict in task_dict_list:
            self.copyCase(task_dict["case_file_path"], task_file_path)
        return task_file_path

    def update_case_json_file(self, task_file_path):
        """
        更新用例的json文件
        只用于 聚合场景
        :return:
        """
        if os.path.isdir:
            for json_file in os.listdir(task_file_path):
                file_path = os.path.join(task_file_path, json_file)
                if os.path.isfile(file_path):
                    with open(file_path, 'r') as f:
                        json_text = f.read()
                    # os.remove(file_path)
                    with open(file_path, 'w') as f:
                        case_json_obj = json.loads(json_text)
                        case_name = case_json_obj[0]["config"]["name"]
                        for test_index in range(1, case_json_obj.__len__()):
                            case_json_obj[test_index]["test"]["name"] = case_name
                        f.write(json.dumps(case_json_obj, indent=4))

    @property
    def timeP(self):
        return time.time().__str__().replace('.','')

    @property
    def timePJsonName(self):
        return self.timeP + '.json'

    def copyLevelAllCase(self, task_instance):
        """
        1 清空该任务目录下 json文件
        2 重新复制 用例的json文件到该目录下
        :param task_instance:
        :return:
        """
        try:
            #删除目录下的用例
            for file_path in os.listdir(task_instance.case_file_path):
                os.remove(file_path)
        except Exception as e:
            pass

        task_content = json.loads(task_instance.task_content)

        for case_or_secen_level in task_content['level_obj']:
            if case_or_secen_level['type'] == 'case':
                case_set = InterfaceCaseModel.objects.filter(
                    level=case_or_secen_level['level'],
                    interface__module__project_id=task_content['project_id'],
                    is_delete=False
                )
                for case in case_set:
                    try:
                        self.copyCase(case.case_file_path, task_instance.case_file_path)
                    except Exception as e:
                        pass
            else:
                secen_set = InterfaceSceneModel.objects.filter(
                    level=case_or_secen_level['level'],
                    project_id=task_content['project_id'],
                    is_delete=False
                )
                for scene in secen_set:
                    try:
                        self.copyCase(scene.case_file_path, task_instance.case_file_path)
                    except Exception as e:
                        pass

    @transaction.atomic
    def generateInterfaceByJson(self, application_id=None):
        """
        根据interface_list 生成接口 入库
        :return:
        """
        for interface_ in self.interface_list:
            if not self.module.interfacemodel_set.filter(path=interface_['path'], is_delete=False, application_id=application_id, method=interface_['method'].upper()).count():
                self.create_interface_count += 1
                InterfaceModel.objects.create(
                    name=interface_['name'],
                    path=interface_['path'],
                    method=interface_['method'].upper(),
                    request_head=interface_['request_head'],
                    # body_data=interface_['body_data_key'],
                    body_data=interface_['body_data'],
                    module=self.module,
                    params=interface_['params_key'],
                    result=[],  # postman 的返回值
                    application_id=application_id,    # 绑定应用
                    body_data_type=interface_['body_data_type'],
                    use_case=0
                )

    def generateCaseByInterfaceJson(self, interface_json, interface_instance):
        """
        根据interface_json 生成一个用例
        :param interface_json:
        :param interface_instance:
        :return:
        """
        self.create_case_count += 1
        case_content = {}
        case_content['case_name'] = interface_json['name'] + '用例'
        case_content['case_params'] = interface_json['params']
        case_content['case_header_info'] = interface_json['request_head']
        case_content['interface_id'] = interface_instance.id
        case_content['case_validate'] = []
        case_content['case_body_data'] = interface_json['body_data']
        case_validate = {}
        case_validate['interface'] = interface_instance
        case_validate['case_content'] = json.dumps(case_content)
        case_validate['name'] = interface_json['name'] + '用例'
        case_validate['level'] = 1
        runner = HttpRunnerCore(validate=case_validate)
        case_file_path = runner.dumpTestCase()
        interface_instance.createCase(
            name = case_validate['name'],
            case_content = case_validate['case_content'],
            case_file_path = case_file_path
        )

    def parameters_handle(self, parameters):
        """swagger parameters参数处理"""
        request_head = []
        query_params = []
        query_params_key = []
        body_params = []
        body_data_ = []
        # update
        if isinstance(parameters, list):
            for parameter in parameters:
                parameter_key = parameter["name"]
                parameter_in = parameter["in"]
                if parameter.get("type"):
                    parameter_type = parameter.get("type")
                    type_ = self.typetransform(parameter_type)
                else:
                    type_ = settings.PYTHON_DATA_TYPE_TO_JS_DATA_TYPE["dict"]

                single_line_data = {"key": parameter_key, "type": type_, "value": ""}
                single_line_key_type = {"key": parameter_key, "type": type_}
                # 添加到不同的选项中（头域信息， url参数， body数据）
                if (parameter_in == "header") or (parameter_in == "query"):
                    request_head.append(single_line_data)
                elif parameter_in == "path":
                    query_params.append(single_line_data)
                    query_params_key.append(single_line_key_type)
                elif (parameter_in == "body") or (parameter_in == "form"):
                    body_params.append(single_line_key_type)
                    body_data_.append(single_line_data)
                else:
                    pass

        parameters_dict = {"request_head": request_head, "query_params": query_params,
                           "query_params_key": query_params_key, "body_params": body_params,
                           "body_data_": body_data_
                           }

        return parameters_dict

    @staticmethod
    def typetransform(parameter_type):
        """swagger类型（字段）转换"""
        # 默认设置string
        type_ = settings.PYTHON_DATA_TYPE_TO_JS_DATA_TYPE['str']
        if parameter_type == 'string':
            type_ = settings.PYTHON_DATA_TYPE_TO_JS_DATA_TYPE['str']
        elif parameter_type == 'integer':
            type_ = settings.PYTHON_DATA_TYPE_TO_JS_DATA_TYPE['int']
        elif parameter_type == 'object':
            type_ = settings.PYTHON_DATA_TYPE_TO_JS_DATA_TYPE['dict']
        elif parameter_type == 'list':
            type_ = settings.PYTHON_DATA_TYPE_TO_JS_DATA_TYPE['list']
        elif parameter_type == 'bool':
            type_ = settings.PYTHON_DATA_TYPE_TO_JS_DATA_TYPE['bool']
        else:
            pass
        return type_

    @staticmethod
    def fiddler_to_testcase(fiddler_data):
        """fiddler数据转测试用例形式(自身)"""
        fiddler_log_entries = fiddler_data["log"].get("entries", [])
        testcase = []
        for entry in fiddler_log_entries:
            har_parser = FiddlerHarParser(har_file_path=None)
            test_dict = har_parser._prepare_teststep(entry_json=entry)
            testcase.append({"test": test_dict})
        return testcase

    def dumpUploadJsonFile(self):
        json_obj = json.loads(self.json_file)
        if self.file_type == 0:
            self.findPostmanRequestInterface(json_obj['item'])
            self.success = True
        # update 增加Swagger方式导入接口
        elif self.file_type == 1:
            self.analyzeSwaggerRequestData(json_obj)
            self.success = True
        # update 增加Fiddler方式导入接口
        elif self.file_type == 2:
            self.analyzeFiddlerData(json_obj)
            self.success = True
        else:
            raise TypeError('错误的文件类型')

    def get_body_data_type(self, mode, body_dict):
        body_data_type = 'x-formdata'
        if mode == 'raw':
            options = body_dict.get('options', '')
            if options and options.get('raw'):
                language = options['raw'].get('language', '')
                if language == 'xml':
                    body_data_type = 'xml'
                else:
                    body_data_type = 'raw'
            else:
                body_data_type = 'raw'
        elif mode == 'formdata':
            # text -> Text   file->File
            body_data_type = 'x-formdata-file'
        elif mode == 'urlencoded':
            # text String
            body_data_type = 'x-formdata'
        else:
            body_data_type = 'x-formdata'
        return body_data_type

    def findPostmanRequestInterface(self, item):
        """PostMan方式接口导入"""
        # 递归函数
        # postman中通过文件夹来管理接口，文件夹中还可以创建文件夹，我们不确定用户的目录是几层
        # 通过递归函数将目录打平，查找出所有接口

        if isinstance(item, list):
            for i in item:

                interface_name = i['name']
                try:
                    if i.get('request'):
                        request_ = i.get('request')
                        body_data_type = 'x-formdata'
                        try:
                            mode = request_['body']['mode']
                            body_data_type = self.get_body_data_type(mode, request_['body'])
                            body_date = request_['body'][request_['body']['mode']]
                            if isinstance(json.loads(body_date), dict):
                                body_date = json.loads(body_date)
                            else:
                                pass
                        except Exception as e:
                            body_date = []
                        if isinstance(request_.get('url', None), str):
                            path, query_params_, query_params_key = self.load_url(request_.get('url'))
                        else:
                            if not request_.get('url').get('path'):
                                raise ExportInterfaceException(interface_name=interface_name, msg_detail='path不能为空,请检查url是否为空')
                            query_params_ = [
                                {'key': query_['key'], 'value': query_['value'], 'type': settings.PYTHON_DATA_TYPE_TO_JS_DATA_TYPE[type(query_['value']).__name__] if query_['value'] is not None else 'String'}
                                for query_ in request_.get('url').get('query', [])]
                            query_params_key = [
                                {'key': query_['key'], 'type': settings.PYTHON_DATA_TYPE_TO_JS_DATA_TYPE[type(query_['value']).__name__] if query_['value'] is not None else 'String'}
                                for query_ in request_.get('url').get('query', [])]
                            path = '/' + '/'.join(request_.get('url').get('path'))
                        request_header = request_.get('header',[])
                        for header in request_.get('header',[]): #将头域type  都改为 string
                            header.update({'type': 'String'})

                        body_data_key = []
                        body_data = []
                        # update body为json字符串时，直接传json转化后的dict
                        if isinstance(body_date, dict):
                            # body_date = json.dumps(body_date)
                            body_data_key = body_date
                            body_data = body_date
                        if isinstance(body_date, list):
                            if body_data_type == 'x-formdata':
                                body_data_key = [{'key': body_date_['key'],'type':'String' if body_date_['type'] is 'text' else body_date_['type']} for body_date_ in body_date]
                                body_data = [{'key': body_date_['key'],'type': 'String' if body_date_['type'] is 'text' else body_date_['type'], 'value': body_date_['value']} for body_date_ in body_date]
                            elif body_data_type == 'x-formdata-file': # text -> Text   file->File
                                body_data_key = [{'key': body_date_['key'],'type': 'File' if body_date_['type'] is 'file' else 'Text'} for body_date_ in body_date]
                                body_data = [{'key': body_date_['key'],'type': 'File' if body_date_['type'] is 'file' else 'Text', 'value': body_date_['value']} for body_date_ in body_date]
                            else:
                                body_data_key = [{'key': body_date_['key'],'type': settings.PYTHON_DATA_TYPE_TO_JS_DATA_TYPE[type(body_date_['value']).__name__] if body_date_['value'] is not None else 'String'} for body_date_ in body_date]
                                body_data = [{'key': body_date_['key'],'type': settings.PYTHON_DATA_TYPE_TO_JS_DATA_TYPE[type(body_date_['value']).__name__] if body_date_['value'] is not None else 'String','value': body_date_['value']} for body_date_ in body_date]
                        _interface_dict_ = {
                                'name': i['name'],
                                'path': path,
                                'method': request_.get('method'),
                                'request_head': request_header,
                                'body_data_key': body_data_key,
                                'body_data': body_data,               #用于生成用例
                                'params': query_params_,              # 查询参数 用于生成用例
                                'params_key':query_params_key,         # 只包含查询参数的key和type
                                'body_data_type': body_data_type
                            }
                        """
                        name = models.CharField(max_length=64, verbose_name='接口名称')
                        path = models.CharField(max_length=512, verbose_name='URL')
                        method = models.CharField(default='GET', max_length=12, choices=CHOICES_METHODS,
                                                  verbose_name='请求方法')
                        request_head = models.TextField(null=True, blank=True, verbose_name='请求头')
                        params = models.CharField(max_length=512, null=True, blank=True, verbose_name='get参数(类型)')
                        result = models.CharField(max_length=512, null=True, blank=True, verbose_name='返回参数')
                        module = models.ForeignKey('project_caud.ProjectModuleModel', on_delete=models.CASCADE,
                                                   verbose_name='所属模块')
                        body_data = models.TextField(null=True, blank=True,
                                                     verbose_name='body参数(类型)')  # 部分接口body参数较大 使用textfield
                        """
                        _interface_dict_ = self.checkinTerfaceFunction(_interface_dict_)  #返回检验并清洗后的数据
                        self.interface_list.append(_interface_dict_)
                except Exception as e:
                    raise ExportInterfaceException(interface_name = interface_name)
                if i.get('item'):
                    #递归
                    # item 是postman导出文件中文件夹标识，
                    self.findPostmanRequestInterface(i.get('item'))
        #递归出口
        return None

    def analyzeSwaggerRequestData(self, data_dict):
        """Swagger方式接口导入 数据解析"""
        if isinstance(data_dict, dict):
            base_path = ''
            if data_dict.get('basePath'):
                base_path = data_dict["basePath"]
            paths = data_dict['paths']
            for path_ in paths.keys():
                url = base_path + path_
                url = (urlparse(url)).path
                path_data = paths[path_]
                for path_method in path_data:
                    method = path_method
                    method_data = path_data[path_method]
                    name = ''.join(method_data.get('tags'))
                    parameters = method_data.get('parameters')
                    parameters_dict = self.parameters_handle(parameters)
                    body_data_type = 'x-formdata'
                    _interface_dict_ = {
                            'name': name[0:64],
                            'path': url,
                            'method': method.upper(),
                            'request_head': parameters_dict["request_head"],
                            'body_data_key': parameters_dict["body_params"],
                            'body_data': parameters_dict["body_data_"],                    # 用于生成用例
                            'params': parameters_dict["query_params"],                # 查询参数 用于生成用例
                            'params_key': parameters_dict["query_params_key"],   # 只包含查询参数的key和type
                            'body_data_type':body_data_type
                        }
                    try:
                        _interface_dict_ = self.checkinTerfaceFunction(_interface_dict_) #返回检验并清洗后的数据
                        self.interface_list.append(_interface_dict_)
                    except Exception as e:
                        raise ExportInterfaceException(interface_name=name)
        return None

    def analyzeFiddlerData(self, fiddler_data):
        """Fiddler方式接口导入 数据解析"""
        if isinstance(fiddler_data, dict):
            list_data = self.fiddler_to_testcase(fiddler_data)
            for dic in list_data:
                test_val = dic["test"]
                name = test_val["name"]
                request = test_val["request"]
                # request 字段数据处理
                url = request["url"]
                url = (urlparse(url)).path
                method = request["method"]
                headers_dict = request.get("headers", {})
                params_dict = request.get("params", {})
                # 请求体的字段名为 'data' 或 'json'
                body_data = request.get("data", {})
                # headers, params, body字段处理
                request_head = [
                    {"key": headers_key, 'type': settings.PYTHON_DATA_TYPE_TO_JS_DATA_TYPE[type(headers_val).__name__],
                     "value": headers_val} for headers_key, headers_val in headers_dict.items()
                ]

                query_params = [
                    {"key": params_key, 'type': settings.PYTHON_DATA_TYPE_TO_JS_DATA_TYPE[type(params_val).__name__],
                     "value": params_val} for params_key, params_val in params_dict.items()
                ]

                query_params_key = [
                    {"key": params_key, 'type': settings.PYTHON_DATA_TYPE_TO_JS_DATA_TYPE[type(params_val).__name__]}
                    for params_key, params_val in params_dict.items()
                ]

                body_params = []
                body_data_ = []
                body_data_type = 'x-formdata'
                body_data_type_text = None
                if body_data:
                    ContentType = headers_dict.get('Content-Type')
                    if re.search('application/x-www-form-urlencoded', ContentType):
                        body_data_type = 'x-formdata-file'
                        body_data_type_text = 'Text'
                    body_data_ = [
                        {"key": body_data_key,
                         # 'type': settings.PYTHON_DATA_TYPE_TO_JS_DATA_TYPE[type(body_data_val).__name__],
                         'type': body_data_type_text if body_data_type_text else settings.PYTHON_DATA_TYPE_TO_JS_DATA_TYPE[type(body_data_val).__name__],
                         "value": body_data_val} for body_data_key, body_data_val in body_data.items()
                    ]
                    body_params = [
                        {"key": body_data_key,
                         # 'type': settings.PYTHON_DATA_TYPE_TO_JS_DATA_TYPE[type(body_data_val).__name__]}
                         'type':body_data_type_text if body_data_type_text else settings.PYTHON_DATA_TYPE_TO_JS_DATA_TYPE[type(body_data_val).__name__]}
                        for body_data_key, body_data_val in body_data.items()
                    ]

                # update body为json字符串时，直接传json转化后的dict
                if not body_data:
                    body_data_type = 'raw'
                    json_data = request.get("json", {})
                    body_params = json_data
                    body_data_ = json_data

                _interface_dict_ = {
                        'name': name,
                        'path': url,
                        'method': method.upper(),
                        'request_head': request_head,
                        'body_data_key': body_params,
                        'body_data': body_data_,
                        'params': query_params,
                        'params_key': query_params_key,
                        'body_data_type': body_data_type
                    }
                try:
                    _interface_dict_ = self.checkinTerfaceFunction(_interface_dict_) #返回检验并清洗后的数据
                    self.interface_list.append(_interface_dict_)
                except Exception as e:
                    raise ExportInterfaceException(interface_name=name)

        return None

    def query_string_to_dict(self, query_string):
        """
        传入查询字符串，返回相应的键值对
        :param query_string:
        :return:
        """
        query_params_parse =  parse.parse_qs(query_string)
        query_params = []
        query_params_key = []
        for query_params_key_ in query_params_parse.keys():
            query_params.append(
                {
                    'key': query_params_key_,
                    'type': settings.PYTHON_DATA_TYPE_TO_JS_DATA_TYPE[type(query_params_parse[query_params_key_][0]).__name__],
                    'value': query_params_parse[query_params_key_][0]
                })
            query_params_key.append(
                {
                    'key': query_params_key_,
                    'type': settings.PYTHON_DATA_TYPE_TO_JS_DATA_TYPE[type(query_params_parse[query_params_key_][0]).__name__]
                })
        return query_params, query_params_key

    def load_url(self, url):
        """
        :param url:  例 ：/api/project?kw=3&test=4
        :return:返回一个元组
        url_path 数据格式： /api/project
        query_params 数据格式: [{'key':'kw', 'type':'Int','value':3},{'key':'test', 'type':'Int','value':4}]
        query_params_key 数据格式: [{'key':'kw', 'type':'Int'},{'key':'test', 'type':'Int'}]
        """
        url_obj = parse.urlparse(url)
        url_path = url_obj.path
        query_string = url_obj.query
        query_params, query_params_key = self.query_string_to_dict(query_string=query_string)
        return url_path, query_params, query_params_key

    def checkinTerfaceFunction(self, __interface_dict_):
        """
        检验函数 检验导入的接口参数是否合法，不合法抛出异常

        抛出异常中 消息 包含 接口名和报错信息
        无异常返回 检验后的数据
        该函数可对数据进行清洗
        :param __interface_dict_:
        :return:
        """

        class UploadInterfaceSerializer(serializers.ModelSerializer):
            name = ZCharFields()
            params = ZJsonField(default=[])
            body_data = ZJsonField(default=[])
            request_head = ZJsonField(default=[])
            result = ZJsonField(default=[])
            body_data_key = ZJsonField(default=[])
            params_key = ZJsonField(default=[])

            class Meta:
                model = InterfaceModel
                # filter='__all__'
                exclude=('create_time', 'update_time', 'is_delete', 'module', 'use_case')

            def validate_name(self, data):
                # 检验名字 把接口名大于64位的都 切成64位
                return data[:64]

        serializer = UploadInterfaceSerializer(data=__interface_dict_)
        try:
            serializer.is_valid(raise_exception=True)
        except serializers.ValidationError as validation_e:

            msg_detail = self.error_message(validation_e)
            raise ExportInterfaceException(
             msg_detail=msg_detail, interface_name=__interface_dict_.get('name'))
        return serializer.validated_data

    @staticmethod
    def error_message(validation_e):
        fields_name_dict = {
                        'name': '接口名',
                        'path': '接口path',
                        'method': '方法',
                        'request_head': '请求头',
                        'body_data_key': 'body_data_key',
                        'body_data': '请求体',
                        'params': 'url参数',
                        'params_key': 'params_key'
                    }

        error_list = []
        if validation_e.detail.keys().__len__():
            for error_name in validation_e.detail.keys():
                error_value = validation_e.detail.get(error_name)
                error_list.append({fields_name_dict.get(error_name): error_value})
            return json.dumps(error_list, ensure_ascii=False)
        else:
            return validation_e.__str__()

class FiddlerHarParser(HarParser):
    """fiddler数据格式转(HarParser自身)测试用例"""
    def _make_validate(self, teststep_dict, entry_json):
        """改写"""
        pass


if __name__ == '__main__':
    import json
    with open('/home/python/choerodonGitlab/postman_case/automate_test.json') as f:
        json_file = f.read()
        pass

    case_obj = CaseDump(json_file)
    case_obj.dumpUploadJsonFile()
