from django.http.response import HttpResponse
from django.utils.deprecation import MiddlewareMixin
from rest_framework.response import Response

from project_caud.models import TestProjectModel
# import django.contrib.auth.middleware.AuthenticationMiddleware

class ProjectMiddlewareMixin(MiddlewareMixin):
    """
    项目中间件， 将项目对象塞进request
    """
    def process_request(self, request):

        # project_id = request.META.get('HTTP_PROJECTID')
        # try:
        #     int(project_id)
        # except Exception as e:
        #     project = TestProjectModel.objects.none()
        # else:
        #     try:
        #         project = TestProjectModel.objects.get(id=project_id)
        #     except TestProjectModel.DoesNotExist as e:
        #         project = TestProjectModel.objects.none()
        # request.project = project
        import time
        request.t1 = time.time()

    def process_response(self,request, response,*args,**kwargs):
        import time
        print('hanshu------',time.time() - request.t1)
        return response

class testMixin(MiddlewareMixin):
    """
    项目中间件， 将项目对象塞进request
    """
    def process_request(self, request):

        # project_id = request.META.get('HTTP_PROJECTID')
        # try:
        #     int(project_id)
        # except Exception as e:
        #     project = TestProjectModel.objects.none()
        # else:
        #     try:
        #         project = TestProjectModel.objects.get(id=project_id)
        #     except TestProjectModel.DoesNotExist as e:
        #         project = TestProjectModel.objects.none()
        # request.project = project
        import time
        print('testrequest---', time.time())
        request.t1 = time.time()

    def process_response(self,request, response,*args,**kwargs):
        import time
        print('testresponse------',time.time() - request.t1)
        return response



class ContentTypeMiddlewareMixin(MiddlewareMixin):

    def process_response(self, request, response: HttpResponse):
        if not response._headers.get('content-type', '')[0].endswith('charset=utf-8'):
            response._headers['content-type'] = (response._headers['content-type'][0] + ';charset=utf-8')
        return response
