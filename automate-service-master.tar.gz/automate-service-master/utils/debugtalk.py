def debugtalkfun(response, fun):
    import sys
    sys.path.append('/app/testcase')
    debugtalkload = __import__(fun)

    fun_ = getattr(debugtalkload, fun)
    fun_(response)
