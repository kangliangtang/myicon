from __future__ import absolute_import, unicode_literals
import os
from datetime import datetime
import logging
from celery import Celery

# set the default Django settings module for the 'celery' program.
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'automate_test_py3.settings')
app = Celery('automate_test_py3')

from celery.app.log import Logging as CeleryLog
#  celery 的日志需要单独配置  在django中配置不生效
celerylog = CeleryLog(app)
from automate_test_py3.settings import LOGGING_DIR
log_file_path = os.path.join(LOGGING_DIR, 'celery_.log')
# celerylog.setup(loglevel=logging.WARN, logfile=log_file_path)
celerylog.setup_task_loggers(loglevel=logging.WARN, logfile=log_file_path, propagate=121)

app.config_from_object('django.conf:settings', namespace='cat')
# app.conf.task_routes = {'case_flow.tasks.runTestTask_task': {'queue': 'cat_flow'},'interface.*': {'queue': 'cat_crontab'}}
# Load task modules from all registered Django app configs.
app.conf.timezone = 'Asia/Shanghai'
app.autodiscover_tasks()
