from django.contrib.auth.models import AnonymousUser
from rest_framework import exceptions
from rest_framework.permissions import AllowAny
from rest_framework.renderers import CoreJSONRenderer
from rest_framework.response import Response
from rest_framework.schemas import SchemaGenerator
from rest_framework.views import APIView
from rest_framework_swagger import renderers
import json



class ChorodonRender(renderers.OpenAPIRenderer):

    def render(self, *args, **kwargs):
        data = json.loads(super().render(*args, **kwargs).decode('utf-8'))  # type bytes
        tags_ = []
        for key, value in data['paths'].items():
            for k, v in value.items():
                v['tags'] = [v['operationId'] + '-controller']
                tags_.append({"name": v['tags'][0],"description": v['tags'][0]})
                v['summary'] = v['operationId']
                v['consumes'] = v['consumes'] if v.get('consumes') else ['*/*']
                v['produces'] = v['produces'] if v.get('produces') else ['*/*']
                # v['description'] = "{\"permission\":{\"action\":\"" +v['operationId'] + "\",\"menuLevel\":null," \
                #                    "\"permissionLevel\":null,\"roles\":[],\"permissionLogin\":true," \
                #                    "\"permissionPublic\":false,\"permissionWithin\":false},\"label\":null}"
        data["extraData"] = {
            "data": {
                "choerodon_route": {
                    "id": None,
                    "name": data['info']['title'],
                    "path": "/" + data['info']['title'] + "/**",
                    "serviceId": data['info']['title'],
                    "url": None,
                    "stripPrefix": True,
                    "retryable": None,
                    "sensitiveHeaders": "Cookie,Set-Cookie,Access-Control-Allow-Origin,Access-Control-Allow-Credentials",
                    "customSensitiveHeaders": True,
                    "helperService": None,
                    "builtIn": None
                }
            }
        }
        data["tags"] = tags_
        data['basePath'] = '/'
        return bytes(json.dumps(data), encoding="utf-8")


def get_swagger_view(title=None, url=None, patterns=None, urlconf=None):
    """
    Returns schema view which renders Swagger/OpenAPI.
    """

    class SwaggerSchemaView(APIView):
        _ignore_model_permissions = True
        exclude_from_schema = True
        permission_classes = [AllowAny]
        # authentication_classes = []
        renderer_classes = [
            # OpenAPIRenderer,
            ChorodonRender,
            CoreJSONRenderer,
            # renderers.SwaggerUIRenderer
        ]

        def get(self, request):
            generator = SchemaGenerator(
                title="automate-service",
                url=url,
                patterns=patterns,
                urlconf=urlconf
            )
            request.user = AnonymousUser()
            schema = generator.get_schema(request=request)

            if not schema:
                raise exceptions.ValidationError(
                    'The schema generator did not return a schema Document'
                )
            return Response(schema)

    return SwaggerSchemaView.as_view()
