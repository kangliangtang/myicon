"""automate_test_py3 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import include
from django.contrib import admin
from rest_framework.routers import DefaultRouter

from interface.urls import router as interface_router
from project_caud import api_views
from user import views as userView

from django.conf.urls import url
from .swagger_views import get_swagger_view

schema_view = get_swagger_view(title="automate")

group_router = DefaultRouter(trailing_slash=False)
group_router.register(r'group', userView.UserGroup, base_name='group')
from user.urls import router as user_router
from user import views as user_view
from contract.urls import router as contract_router
from mockserver.urls import router as mrouter
from swagger_docs.urls import router as swagger_router

urlpatterns = [
    url(r'^mock/', include('mockserver.urls')),
    url(r'^v2/choerodon/api-docs$', schema_view),
    url(r'^$', schema_view),
    url(r'^admin/', admin.site.urls),
    url(r'^API/projects/(?P<project_id>\d+)/user', include('user.urls'), name="user_controller"),
    url(r'^API/projects/(?P<project_id>\d+)/', include(interface_router.urls)),
    url(r'^API/projects/(?P<project_id>\d+)/', include('result_report.urls')),
    url(r'^API/projects/(?P<project_id>\d+)/', include('case_flow.urls')),
    url(r'^API/projects/(?P<project_id>\d+)/', include(contract_router.urls)),
    url(r'^API/projects/(?P<project_id>\d+)/', include(mrouter.urls)),
    url(r'^API/',include('project_caud.urls')),
    url(r'^API/projects/(?P<project_id>\d+)/', include(group_router.urls)),
    url(r'API/', include(user_router.urls)),
    url(r'^API/projects/(?P<project_id>\d+)/system/', include('system.urls')),   # 新增 操作日志
    url(r'^sync/projects$', api_views.ImportProjectAPIView.as_view()),            # 导入单个项目
    # url(r'^sync/project/group$', api_views.ProjectGroupAPIView.as_view()),      # 导入用户组
    url(r'^sync/group$', api_views.ProjectGroupAPIView.as_view()),                # 导入用户组
    # url(r'^sync/projects/stop$', api_views.StopAPIView.as_view()),              # 停用项目
    url(r'^sync/projects/closed$', api_views.ClosedAPIView.as_view()),            # 停用项目
    url(r'^sync/projects/reopen$', api_views.ReopenAPIView.as_view()),   # 启用项目
    url(r'^platform/project/run$', api_views.CiAPIView.as_view()),   # ci运行接口启用项目
    url(r'^eureka/info$', user_view.EurekaInfoAPIView.as_view()),   # eureka info
    url(r'^health$', user_view.EurekaHelthAPIView.as_view()),  # eureka helth
    url(r'^API/projects/(?P<project_id>\d+)/', include(swagger_router.urls))
]
