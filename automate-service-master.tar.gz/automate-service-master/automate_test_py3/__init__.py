from __future__ import absolute_import, unicode_literals

import traceback

from .celery import app as celery_app
import os
# from . import settings

import pymysql
from logging import getLogger

debug_log = getLogger('debug')

__all__ = ('celery_app',)
pymysql.install_as_MySQLdb()
