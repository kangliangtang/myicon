from django.db import models, transaction
from utils.model import BaseModel
# Create your models here.


class OperationLogModel(BaseModel):
    """操作日志"""
    action = models.CharField(max_length=128, verbose_name='操作行为')
    data = models.CharField(max_length=512, verbose_name='操作数据')
    user = models.CharField(max_length=64, verbose_name='操作人')
    project_id = models.IntegerField(verbose_name='所属项目')

    class Meta:
        db_table = 'tb_operation_log'
        verbose_name = '操作日志'
        verbose_name_plural = '操作日志'


class UploadFileModel(BaseModel):
    """上传文件"""
    file_name = models.CharField(max_length=256, verbose_name='文件名')
    suffix = models.CharField(max_length=64, null=True, verbose_name='文件名后缀')
    user = models.CharField(max_length=64, verbose_name='上传人')
    file_path = models.FilePathField(verbose_name='文件存储路径', null=True, blank=True)
    project = models.ForeignKey('project_caud.TestProjectModel', on_delete=models.CASCADE, verbose_name='所属项目')

    class Meta:
        db_table = "tb_upload_file"
        verbose_name = '文件管理'
        verbose_name_plural = '文件管理'

    @transaction.atomic
    def setIsdeleteTrue(self):
        self.is_delete = True
        self.save()


class CommonParameterModel(BaseModel):
    """公共参数"""
    CHOICES_TYPES = (
        ('Time', '时间戳'),
        ('Random', '随机数'),
        ('Str', '字符串'),
        ('Choices', '指定随机值')
    )
    name = models.CharField(max_length=64, verbose_name='参数名')
    param_type = models.CharField(default='Str', max_length=64, choices=CHOICES_TYPES, null=True, verbose_name='参数类型')
    days = models.CharField(max_length=64, null=True, blank=True, verbose_name='时间偏移天数')
    minnum = models.BigIntegerField(null=True, blank=True, verbose_name='随机数开始值')
    maxnum = models.BigIntegerField(null=True, blank=True, verbose_name='随机数结束值')
    value = models.CharField(max_length=512, verbose_name='参数值')
    project = models.ForeignKey('project_caud.TestProjectModel', on_delete=models.CASCADE, verbose_name='所属项目')
    time_format = models.CharField(max_length=512, null=True, blank=True, verbose_name='时间格式')


    class Meta:
        db_table = "tb_common_parameter"
        verbose_name = '公共参数'
        verbose_name_plural = '公共参数'

    @transaction.atomic
    def setIsdeleteTrue(self):
        self.is_delete = True
        self.save()

    def getTimeOffset(self):
        if self.days:
            time_offset = 1
        else:
            time_offset = 0
        return time_offset
