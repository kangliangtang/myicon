from rest_framework import serializers
from system.models import OperationLogModel, UploadFileModel,CommonParameterModel


class OperationLogModelSerializer(serializers.ModelSerializer):
    """操作日志 序列化"""
    class Meta:
        model = OperationLogModel
        fields = ('id', 'action', 'data', 'create_time', 'user')


class UploadFileSerializer(serializers.ModelSerializer):
    """上传文件 序列化"""
    class Meta:
        model = UploadFileModel
        fields = ('id', 'file_name', 'suffix', 'user', 'create_time')


class CommonParameterSerializer(serializers.ModelSerializer):
    """公共参数 序列化"""
    # choices字段
    # param_type = serializers.CharField(source='get_param_type_display')
    time_offset = serializers.ReadOnlyField(source='getTimeOffset')

    class Meta:
        model = CommonParameterModel
        # fields = ('id', 'name', 'param_type', 'value', 'create_time')
        exclude = ('update_time', 'is_delete')
