import random
import re
import time
from colorlog.logging import getLogger
from django.conf import settings
# 权限控制
from django.contrib.auth.models import Group
from django.db.models.query_utils import Q
from rest_framework.generics import ListAPIView, ListCreateAPIView, DestroyAPIView
from rest_framework.views import APIView

from project_caud.models import TestProjectModel

from system.models import OperationLogModel, UploadFileModel, CommonParameterModel
from system.serializers import OperationLogModelSerializer, UploadFileSerializer, CommonParameterSerializer
from django.utils import timezone
import pytz
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import filters, viewsets
from rest_framework.response import Response
from rest_framework.status import HTTP_200_OK, HTTP_400_BAD_REQUEST
from rest_framework.viewsets import ModelViewSet
from utils.md5_base64_aes import EncryptionAndDecryption
from utils.common_parameter import get_timestamp, check_time_format


class OperationLogAPIView(ListAPIView):
    """操作日志 视图"""
    serializer_class = OperationLogModelSerializer
    queryset = None
    filter_backends = [filters.SearchFilter,filters.OrderingFilter, DjangoFilterBackend]
    ordering = ('-create_time',)
    # permission_classes = (AutoPlatformPermission,)

    def get_queryset(self):
        """根据项目名称（project_id） 获取操作日志记录"""
        try:
            user_obj = self.request.user
            project_id = self.kwargs['project_id']
            project_id = int(project_id)
            # 增加权限控制，只允许本项目成员查看
            user_group_obj = Group.objects.filter(user=user_obj)
            # 超级管理员查看所有
            if user_obj.isSuperUser:
                query_set = OperationLogModel.objects.filter(project_id=project_id, is_delete=False)
            else:
                ret = TestProjectModel.objects.filter(
                    Q(id=project_id) & Q(user_group__in=user_group_obj)
                )
                if ret:
                    query_set = OperationLogModel.objects.filter(project_id=project_id, is_delete=False)
                else:
                    return OperationLogModel.objects.none()

            # 时间查询
            if self.request.query_params.get('time_start') and self.request.query_params.get('time_end'):
                start_time_str = self.request.query_params.get('time_start')
                end_time_str = self.request.query_params.get('time_end')
                tzinfo_ = None  # 因settings 中USE_TZ = False 2019-11-5
                if settings.USE_TZ:
                    tzinfo_ = pytz.utc
                start_time = timezone.datetime.strptime(start_time_str, '%Y-%m-%dT%H:%M:%S.%fZ').replace(
                    tzinfo=tzinfo_)
                end_time = timezone.datetime.strptime(end_time_str, '%Y-%m-%dT%H:%M:%S.%fZ').replace(
                    tzinfo=tzinfo_)
                # 前端日期插件，发送的时间比选择日期慢8h。 例如：选择2019-05-08，实际发送时间为2019-05-07T16:00:00.000Z
                start_time += timezone.timedelta(hours=8)
                end_time += timezone.timedelta(days=1, hours=8)
                query_set = query_set.filter(create_time__range=(start_time, end_time))
            return query_set
        except Exception:
            return OperationLogModel.objects.none()

    def get(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"get",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super().get(request, *args, **kwargs)


class UplodFileAPIView(ListCreateAPIView, DestroyAPIView, viewsets.ViewSet):
    """文件上传 视图类"""
    serializer_class = UploadFileSerializer
    queryset = None
    filter_backends = [filters.SearchFilter, filters.OrderingFilter, DjangoFilterBackend]
    search_fields = ('file_name',)
    filter_fields = ('file_name', 'project_id')
    ordering = ('-create_time',)
    upload_file_path = settings.UPLOAD_FILE_PATH
    # permission_classes = (AutoPlatformPermission, )

    def get_queryset(self):
        """获取当前项目下所有文件"""
        user_obj = self.request.user
        user_group_obj = Group.objects.filter(user=user_obj)
        try:
            project_id = self.kwargs['project_id']
            # 超级管理员查看所有
            if user_obj.isSuperUser:
                return UploadFileModel.objects.filter(project__id=project_id, is_delete=False)
            else:
                # 本项目成员可查看
                ret = TestProjectModel.objects.filter(
                    Q(id=project_id) & Q(user_group__in=user_group_obj)
                )
                if ret:
                    return UploadFileModel.objects.filter(project__id=project_id, is_delete=False)
                else:
                    return UploadFileModel.objects.none()
        except Exception as e:
            return UploadFileModel.objects.none()

    def create(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"create",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        project_id = self.kwargs.get('project_id')
        file_obj = self.request.FILES.get('file', None)
        if project_id is None:
            return Response({'message': '请选择项目', 'success': False}, HTTP_200_OK)
        if file_obj is None:
            return Response({'message': '未选择文件', 'success': False}, HTTP_200_OK)
        # ------------权限控制---------------------------------------------------------
        user_obj = self.request.user
        user_group_obj_set = Group.objects.filter(user=user_obj)
        if user_obj.isSuperUser:
            project_obj = TestProjectModel.objects.get(id=project_id)
        else:
            project_obj = TestProjectModel.objects.filter(
                Q(id=project_id) &
                Q(user_group__in=user_group_obj_set)).first()
        if not project_obj:
            return Response({'message': '无该项目权限', 'success': False}, status=403)
        # ------------权限控制---------------------------------------------------------
        file_obj_name = file_obj.name.split('.')
        file_name = file_obj_name[0]
        suffix = ''
        if len(file_obj_name) > 1:
            file_name = '.'.join(file_obj_name[0:-1])
            suffix = file_obj_name[-1]
        # 同一项目下，文件名不可重复
        db_file_name = UploadFileModel.objects.filter(is_delete=False, project__id=project_id, file_name=file_name)
        if db_file_name:
            return Response({'message': '文件名重复', 'success': False}, HTTP_200_OK)
        file_size = file_obj.size                              # 单位：字节B
        if (suffix == 'exe') or (file_size > (1024*1024)):
            message = '不允许上传.exe的文件，文件大小不超过1M'
            return Response({'message': message, 'success': False}, HTTP_200_OK)

        user = self.request.user
        # file_path = self.upload_file_path + file_obj.name
        store_file_name = '{0}.{1}'.format(int(time.time()*10**3), suffix)    # 实际保存文件名
        file_path = '{0}{1}'.format(self.upload_file_path, store_file_name)

        project_obj = TestProjectModel.objects.get(id=project_id)
        if not project_obj:
            return Response({'message':'项目不存在', 'success': False}, status=HTTP_200_OK)
        if not project_obj.project_statu:
            return Response({'message':'项目已停用', 'success': False}, status=HTTP_200_OK)
        logger = getLogger('log')
        try:
            with open(file_path, 'wb') as f:
                for chunk in file_obj.chunks():
                    f.write(chunk)
        except Exception as e:
            logger.exception(e)
            return Response({'message': '%s' % e, 'success': False}, HTTP_400_BAD_REQUEST)
        else:
            UploadFileModel.objects.create(
                file_name=file_name,
                suffix=suffix,
                user=user,
                file_path=file_path,
                project=project_obj
            )
        return Response({'message': '文件上传成功', 'success': True}, HTTP_200_OK)

    def destroy(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"destroy",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        obj = self.get_object()
        obj.setIsdeleteTrue()
        return Response('删除成功', status=HTTP_200_OK)

    def get(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"get",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super().get(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"post",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super().post(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"delete",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super().delete(request, *args, **kwargs)

    def list(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"list",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super(UplodFileAPIView, self).list(request, *args, **kwargs)


class EncryptionAndDecryptionView(APIView):
    """加解密 视图"""
    permission_classes = ()    # 不做权限检验

    def post(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"post",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        data = self.request.data
        # 加解密 方式
        mode = data.get('mode', None)
        # 需要处理的字符串
        content = data.get('content', None)
        # 处理操作（加密或解密）
        operation = data.get('operation', None)
        if (mode not in [0,1,2]) or (operation not in [0,1]):
            return Response({'message': '加解密方式参数有误', 'success': False}, HTTP_400_BAD_REQUEST)

        if (mode is None) or (content is None) or (operation is None):
            return Response({'message': '参数不完整', 'success': False}, HTTP_400_BAD_REQUEST)
        try:
            aes_key = None
            if int(mode) == 2:
                aes_key = data.get('aes_key', '')
                if not aes_key:
                    return Response({'message': '请传入AES密钥', 'success': False}, HTTP_400_BAD_REQUEST)
            encry_decry_obj = EncryptionAndDecryption(mode=mode, content=content, operation=operation,aes_key=aes_key)
            message = encry_decry_obj.translate()
        except UnicodeError:
            message = '您输入的字符串格式不符合要求'
            return Response({'message': message, 'success': False}, HTTP_200_OK)
        except Exception:
            message = '您输入的字符串格式不符合要求'
            # message = '加解密错误 Error:%s' % e
            return Response({'message': message, 'success': False}, HTTP_200_OK)
        else:
            return Response({'message': message, 'success': True}, HTTP_200_OK)


class CommonParameterView(ModelViewSet):
    """公共参数"""
    serializer_class = CommonParameterSerializer
    queryset = None
    filter_backends = [filters.SearchFilter, filters.OrderingFilter, DjangoFilterBackend]
    search_fields = ('name',)
    filter_fields = ('name', 'project_id')
    ordering = ('-create_time',)
    # permission_classes = (AutoPlatformPermission,)

    def get_queryset(self):
        """获取当前项目下所有公共参数"""
        user_obj = self.request.user
        user_group_obj = Group.objects.filter(user=user_obj)
        try:
            project_id = self.kwargs['project_id']
            # 超级管理员查看所有
            if user_obj.isSuperUser:
                return CommonParameterModel.objects.filter(is_delete=False).filter(project__id=project_id)
            else:
                # 本项目成员可查看
                ret = TestProjectModel.objects.filter(
                    Q(id=project_id) & Q(user_group__in=user_group_obj)
                )
                if ret:
                    return CommonParameterModel.objects.filter(is_delete=False).filter(project__id=project_id)
                else:
                    return CommonParameterModel.objects.none()
        except Exception as e:
            return CommonParameterModel.objects.none()

    def create(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"create",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        days = None
        minnum = None
        maxnum = None
        time_format = None
        try:
            project_id = self.kwargs['project_id']
            if not project_id:
                return Response({'message': '请选择项目', 'success': False}, HTTP_200_OK)
            data = self.request.data
            name = data.get('name')                   # 参数名
            param_type = data.get('param_type')       # [(Time,'时间戳'), (Random, '随机数'), (Str,'字符串')]
            if param_type == 'Time':
                # param_type = '时间戳'
                days = data.get('days', None)         # [(0, 当前时间), (1, '时间偏移天数')]
                time_format = data.get('time_format', None)
                if not check_time_format(time_format):
                    return Response({'message': '时间格式输入有误', 'code': 400}, HTTP_400_BAD_REQUEST)
                timestamp = get_timestamp(days, time_format)
                if timestamp is None:
                    return Response({'message': '时间偏移参数输入有误', 'code': 400}, HTTP_400_BAD_REQUEST)
                value = '--'
            elif param_type == 'Random':
                # param_type = '随机数'
                minnum = data.get('minnum', None)           # 起始数值 (可能为0)
                maxnum = data.get('maxnum', None)           # 结束数值
                if (minnum is not None) and (maxnum is not None):
                    try:
                        minnum = int(minnum)
                        maxnum = int(maxnum)
                        # DB最大保存长度  models.BigIntegerField: (-9223372036854775808, 9223372036854775807)
                        if (minnum not in range(-9223372036854775808, 9223372036854775807)) or (maxnum not in range(-9223372036854775808, 9223372036854775807)):
                            return Response({'message': '随机数值输入超长', 'code':400}, HTTP_400_BAD_REQUEST)
                        random.randint(minnum, maxnum)
                    except Exception as e:
                        return Response({'message': '随机数值输入有误', 'code':400}, HTTP_400_BAD_REQUEST)
                    value = '{0}-{1}'.format(minnum, maxnum)
                else:
                    return Response({'message': '参数不完整', 'code':400}, HTTP_400_BAD_REQUEST)
            elif param_type == 'Str':
                # param_type = '字符串'
                value = data.get('value')
                if not value:
                    return Response({'message': '参数不完整', 'code':400}, HTTP_400_BAD_REQUEST)
            elif param_type == 'Choices':
                # 指定随机值的数组
                value = data.get('value')
                if not value:
                    return Response({'message': '参数不完整', 'code':400}, HTTP_400_BAD_REQUEST)
                try:
                    # array = ast.literal_eval(value)
                    new_value = value.replace('(', '').replace(')', '').replace('[', '').replace(']','').replace(' ','')
                    array = new_value.split(',')
                    random.choice(array)
                except Exception:
                    return Response({'message': '参数有误', 'code': 400}, HTTP_400_BAD_REQUEST)
            else:
                return Response({'message': '参数类型暂不支持', 'code':400}, HTTP_400_BAD_REQUEST)
        except Exception:
            return Response({'message': '参数有误', 'code':400}, HTTP_400_BAD_REQUEST)

        if not all([name, param_type, value]):
            return Response({'message': '参数不完整', 'code':400}, HTTP_400_BAD_REQUEST)

        #　参数不支持中文和特殊符号
        re_name = re.findall(r"[^\-_ A-Za-z0-9]+", name)
        # re_value = re.findall(r"[^-!?,.@#%^&*()_/ A-Za-z0-9]+", value)
        # if re_name or re_value:
        if re_name:
            return Response({'message': '公共参数不支持中文和特殊符号', 'code':400}, HTTP_400_BAD_REQUEST)

        # -----------------------------权限控制-------------------------------------
        user_obj = request.user
        user_group_obj_set = Group.objects.filter(user=user_obj)
        if user_obj.isSuperUser:
            project_obj = TestProjectModel.objects.get(id=project_id)
        else:
            project_obj = TestProjectModel.objects.filter(
                Q(id=project_id) & Q(user_group__in=user_group_obj_set)).first()
        if not project_obj:
            return Response({'message': '无该项目权限', 'code':400}, status=403)
        # -----------------------------权限控制-------------------------------------

        # 同一项目下，参数名不可重复
        db_name = CommonParameterModel.objects.filter(is_delete=False, project__id=project_id, name=name)
        if db_name:
            return Response({'message': '参数名重复', 'success': False}, HTTP_200_OK)
        project_obj = TestProjectModel.objects.get(id=project_id)
        CommonParameterModel.objects.create(
            name=name,
            param_type=param_type,
            days=days,
            minnum=minnum,
            maxnum=maxnum,
            value=value,
            project=project_obj,
            time_format=time_format
        )
        return Response({'message': '保存成功', 'success': True}, HTTP_200_OK)

    def destroy(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"destroy",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        obj = self.get_object()
        obj.setIsdeleteTrue()
        return Response('删除成功', status=HTTP_200_OK)

    def partial_update(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"partial_update",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        pk = kwargs["pk"]
        if not pk:
            return Response({'message': '请求方式错误', 'success': False}, HTTP_400_BAD_REQUEST)

        pk = int(pk)
        days = None
        minnum = None
        maxnum = None
        time_format = None
        try:
            project_id = self.kwargs['project_id']
            if not project_id:
                return Response({'message': '请选择项目', 'success': False}, HTTP_200_OK)
            data = self.request.data
            name = data.get('name')  # 参数名
            param_type = data.get('param_type')  # [(Time,'时间戳'), (Random, '随机数'), (Str,'字符串')]
            if param_type == 'Time':
                days = data.get('days', None)  # [(0, 当前时间), (1, '时间偏移天数')]
                time_format = data.get('time_format', None)
                if not check_time_format(time_format):
                    return Response({'message': '时间格式输入有误', 'code': 400}, HTTP_400_BAD_REQUEST)
                timestamp = get_timestamp(days, time_format)
                if timestamp is None:
                    return Response({'message': '时间偏移参数输入有误', 'code': 400}, HTTP_400_BAD_REQUEST)
                value = '--'
            elif param_type == 'Random':
                minnum = data.get('minnum', None)  # 起始数值 (可能为0)
                maxnum = data.get('maxnum', None)  # 结束数值
                if (minnum is not None) and (maxnum is not None):
                    try:
                        minnum = int(minnum)
                        maxnum = int(maxnum)
                        # DB最大保存长度  models.BigIntegerField: (-9223372036854775808, 9223372036854775807)
                        if (minnum not in range(-9223372036854775808, 9223372036854775807)) or (
                                maxnum not in range(-9223372036854775808, 9223372036854775807)):
                            return Response({'message': '随机数值输入超长', 'code': 400}, HTTP_400_BAD_REQUEST)
                        random.randint(minnum, maxnum)
                    except Exception as e:
                        return Response({'message': '随机数值输入有误', 'code': 400}, HTTP_400_BAD_REQUEST)
                    value = '{0}-{1}'.format(minnum, maxnum)
                else:
                    return Response({'message': '参数不完整', 'code': 400}, HTTP_400_BAD_REQUEST)
            elif param_type == 'Str':
                value = data.get('value')
                if not value:
                    return Response({'message': '参数不完整', 'code': 400}, HTTP_400_BAD_REQUEST)
            elif param_type == 'Choices':
                # 指定随机值的数组
                value = data.get('value')
                if not value:
                    return Response({'message': '参数不完整', 'code': 400}, HTTP_400_BAD_REQUEST)
                try:
                    # array = ast.literal_eval(value)
                    new_value = value.replace('(', '').replace(')', '').replace('[', '').replace(']', '').replace(' ',
                                                                                                                  '')
                    array = new_value.split(',')
                    random.choice(array)
                except Exception:
                    return Response({'message': '参数有误', 'code': 400}, HTTP_400_BAD_REQUEST)
            else:
                return Response({'message': '参数类型暂不支持', 'code': 400}, HTTP_400_BAD_REQUEST)
        except Exception:
            return Response({'message': '参数有误', 'code': 400}, HTTP_400_BAD_REQUEST)

        if not all([name, param_type, value]):
            return Response({'message': '参数不完整', 'code': 400}, HTTP_400_BAD_REQUEST)

        # 　参数不支持中文和特殊符号
        re_name = re.findall(r"[^\-_ A-Za-z0-9]+", name)
        if re_name:
            return Response({'message': '公共参数不支持中文和特殊符号', 'code': 400}, HTTP_400_BAD_REQUEST)

        # -----------------------------权限控制-------------------------------------
        user_obj = request.user
        user_group_obj_set = Group.objects.filter(user=user_obj)
        if user_obj.isSuperUser:
            project_obj = TestProjectModel.objects.get(id=project_id)
        else:
            project_obj = TestProjectModel.objects.filter(
                Q(id=project_id) & Q(user_group__in=user_group_obj_set)).first()
        if not project_obj:
            return Response({'message': '无该项目权限', 'code': 400}, status=403)
        # -----------------------------权限控制-------------------------------------

        # 同一项目下，参数名不可重复
        db_name = CommonParameterModel.objects.filter(Q(is_delete=False, project__id=project_id, name=name) & (~Q(id=pk)))
        if db_name:
            return Response({'message': '参数名重复', 'success': False}, HTTP_200_OK)
        project_obj = TestProjectModel.objects.get(id=project_id)
        obj = CommonParameterModel.objects.filter(id=pk)
        obj.update(
                name=name,
                param_type=param_type,
                days=days,
                minnum=minnum,
                maxnum=maxnum,
                value=value,
                project=project_obj,
                time_format=time_format
            )
        return Response({'message': '修改成功', 'success': True}, HTTP_200_OK)

    def retrieve(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"retrieve",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super().retrieve(request, *args, **kwargs)

    def update(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"update",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return Response({"message":"OK"}, status=200)

    def list(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"list",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super().list(request, *args, **kwargs)

