import json

from django.db import transaction
from logging import  getLogger
from case_flow.models import FlowTree
from project_caud.models import TestProjectModel, ProjectModuleModel
from .tasks import TimeTask
from rest_framework import serializers

from interface.models import InterfaceModel, InterfaceCaseModel, InterfaceSceneModel, TaskModel, PublishCaseModel, \
    InterfaceExecutionTimeModel
from utils.runcore import HttpRunnerCore
from utils.serializer import ZJsonField, BodyDataJsonXmlField, PublishUserNameReadOnlyField
from django.utils.translation import ugettext_lazy as _
from utils.util import checkXML


class InterfaceSerializer(serializers.ModelSerializer):
    module_name = serializers.ReadOnlyField(source='module.module_name')
    params = ZJsonField(default=[])
    body_data = BodyDataJsonXmlField(default=[])
    request_head = ZJsonField(default=[])
    result = ZJsonField(default=[])
    project_name = serializers.ReadOnlyField(source='module.project.project_name')
    project = serializers.ReadOnlyField(source='module.project.id')
    app_name = serializers.ReadOnlyField(source='application.name')

    class Meta:
        model = InterfaceModel
        # exclude = ('is_delete', 'result')
        exclude = ('is_delete',)
        # fields = '__all__'

    def validate_params(self, data):
        try:
            data_ = json.loads(data)
        except Exception as e:
            raise serializers.ValidationError('json格式错误')
        if not isinstance(data_, list):
            raise serializers.ValidationError('格式错误，参数因为数组')
        for dict_data in data_:
            if not isinstance(dict_data, dict):
                raise serializers.ValidationError('格式错误，每个参数对象应该为数组')
            if not dict_data.get('key', None):
                raise serializers.ValidationError('格式错误，获取不到key')
            if dict_data.get('key', None) == '':
                raise serializers.ValidationError('key不能为空字符串')
        return data

    def validate(self, attrs):
        body_data_type = attrs.get("body_data_type")
        body_data = attrs.get("body_data")
        if body_data_type == 'xml':
            try:
                body_data_ = json.loads(body_data)
            except Exception:
                raise serializers.ValidationError({'message': 'xml格式不正确'})
            if not checkXML(body_data_):
                raise serializers.ValidationError({'message': 'xml格式不正确'})
        return attrs

    def create(self, validated_data):
        json_empty_list = json.dumps([])
        request_head = validated_data.get("request_head", json_empty_list)
        params = validated_data.get("params", json_empty_list)
        body_data = validated_data.get("body_data", json_empty_list)
        # update 接口参数去重
        try:
            if isinstance(request_head, str):
                request_head = json.loads(request_head)
                key_list = []
                new_request_head = []
                if isinstance(request_head, list):
                    [(key_list.append(dic["key"]), new_request_head.append(dic)) for dic in request_head if
                     dic["key"] not in key_list]
                    request_head = json.dumps(new_request_head)
        except Exception:
            raise serializers.ValidationError({'message':'头域信息参数错误'})
        try:
            if isinstance(params, str):
                params = json.loads(params)
                key_list = []
                new_params = []
                if isinstance(params, list):
                    [(key_list.append(dic["key"]), new_params.append(dic)) for dic in params if
                     dic["key"] not in key_list]
                    params = json.dumps(new_params)
        except Exception:
            raise serializers.ValidationError({'message':'URL参数错误'})
        validated_data["request_head"] = request_head
        validated_data["params"] = params
        validated_data["body_data"] = body_data
        validated_data["use_case"] = 0
        obj = super().create(validated_data)
        # obj.module.project.addInterface()  # 接口数 加 1
        obj.module.project.addInterface(module_id=obj.module_id)
        return obj

    def update(self, instance, validated_data):
        if instance.name != validated_data['name']:
            # 更新接口名后 同步更新 接口地图
            try:
                FlowTree.objects.get(project_id=instance.module.project_id).updateInterface(interface_id=instance.id,
                                                                                           interface_name=validated_data['name'])
            except Exception as e:
                logger = getLogger('log')
                logger.exception(e)
        json_empty_list = json.dumps([])
        request_head = validated_data.get("request_head", json_empty_list)
        params = validated_data.get("params", json_empty_list)
        body_data = validated_data.get("body_data", json_empty_list)
        module_obj = validated_data["module"]
        old_module_obj = instance.module
        # 模块绑定变更，减少相应模块下的接口数
        if module_obj != old_module_obj:
            if old_module_obj.interface_num > 0:
                old_module_obj.interface_num -= 1
                old_module_obj.save(update_fields=['interface_num'])
            module_obj.interface_num += 1
            module_obj.save(update_fields=['interface_num'])

        # 接口参数去重
        try:
            if isinstance(request_head, str):
                request_head = json.loads(request_head)
                key_list = []
                new_request_head = []
                if isinstance(request_head, list):
                    [(key_list.append(dic["key"]), new_request_head.append(dic)) for dic in request_head if
                     dic["key"] not in key_list]
                    request_head = json.dumps(new_request_head)
        except Exception:
            raise serializers.ValidationError({'message':'头域信息参数错误'})

        try:
            if isinstance(params, str):
                params = json.loads(params)
                key_list = []
                new_params = []
                if isinstance(params, list):
                    [(key_list.append(dic["key"]), new_params.append(dic)) for dic in params if
                     dic["key"] not in key_list]
                    params = json.dumps(new_params)
        except Exception:
            raise serializers.ValidationError({'message':'URL参数错误'})
        validated_data["request_head"] = request_head
        validated_data["params"] = params
        validated_data["body_data"] = body_data
        instance = super().update(instance, validated_data)
        # 同步更新关联的公共接口 2019-10-31
        publishcase_query = PublishCaseModel.objects.filter(interface_id=instance.id, is_delete=False).all()
        if publishcase_query:
            for publishcase_obj in publishcase_query:
                publishcase_obj.update_case_content(instance)
        return instance


class InterfaceCaseSerializer(serializers.ModelSerializer):
    interface_name = serializers.ReadOnlyField(source='interface.name')
    case_content = ZJsonField()
    project_id = serializers.ReadOnlyField(source='interface.module.project_id')
    module_id = serializers.ReadOnlyField(source='interface.module_id')

    class Meta:
        model = InterfaceCaseModel
        exclude = ('is_delete', 'case_file_path')
        # fields = ('id', 'name', 'level', 'case_content', 'interface_name', 'interface')

    def validate_case_content(self, data):
        try:
            data_ = json.loads(data)
        except Exception as e:
            raise serializers.ValidationError('json格式错误')
        if not isinstance(data_, dict):
            raise serializers.ValidationError('格式错误，用例内容应为js对象')
        params = data_.get('case_params',None)
        if not isinstance(params, list):
            raise serializers.ValidationError('格式错误，case_params因为数组')
        for dict_data in params:
            if not isinstance(dict_data, dict):
                raise serializers.ValidationError('params格式错误，每个参数对象应该为js对象')
            if not dict_data.get('key', None):
                raise serializers.ValidationError('params格式错误，获取不到key')
            if dict_data.get('key', None) == '':
                raise serializers.ValidationError('params格式错误,key不能为空字符串')
        case_body_data = data_.get('case_body_data')
        if not isinstance(case_body_data, list):
            raise serializers.ValidationError('格式错误，case_body_data因为数组')
        for dict_data in case_body_data:
            if not isinstance(dict_data, dict):
                raise serializers.ValidationError('case_body_data格式错误，每个参数对象应该为js对象')
            if not dict_data.get('key', None):
                raise serializers.ValidationError('case_body_data格式错误，获取不到key')
            if dict_data.get('key', None) == '':
                raise serializers.ValidationError('case_body_data格式错误,key不能为空字符串')
        case_header_info = data_.get('case_header_info')
        if not isinstance(case_header_info, list):
            raise serializers.ValidationError('格式错误，case_header_info因为数组')
        for dict_data in case_header_info:
            if not isinstance(dict_data, dict):
                raise serializers.ValidationError('case_header_info格式错误，每个参数对象应该为js对象')
            if not dict_data.get('key', None):
                raise serializers.ValidationError('case_header_info格式错误，获取不到key')
            if dict_data.get('key', None) == '':
                raise serializers.ValidationError('case_header_info格式错误,key不能为空字符串')
        case_validate = data_.get('case_validate')
        if not isinstance(case_validate, list):
            raise serializers.ValidationError('格式错误，case_header_info因为数组')
        for dict_data in case_validate:
            if not isinstance(dict_data, dict):
                raise serializers.ValidationError('case_validate格式错误，每个参数对象应该为js对象')
            if not dict_data.get('key', None):
                raise serializers.ValidationError('case_validate格式错误，获取不到key')
            if not dict_data.get('assert', None):
                raise serializers.ValidationError('case_validate格式错误，获取不到assert')
            if dict_data.get('key', None) == '':
                raise serializers.ValidationError('case_validate格式错误,key不能为空字符串')
        return data

    def create(self, validated_data):
        # 创建测试用例，保存本地，路径存数据库
        case_file_path = HttpRunnerCore(
            validate=validated_data,
            # project_id=self.context['request'].META.get('HTTP_PROJECTID')
            project_id=self.context['view'].kwargs['project_id']
        ).dumpTestCase()
        validated_data['case_file_path'] = case_file_path
        instance = super().create(validated_data)
        return instance

    def update(self, instance, validated_data):
        case_file_path = HttpRunnerCore(
            validate=validated_data,
            instance=instance,
            project_id=self.context['view'].kwargs['project_id']
        ).updateTestCase()
        validated_data['case_file_path'] = case_file_path
        instance = super().update(instance, validated_data)
        return instance


class InterfaceSceneSerializer(serializers.ModelSerializer):
    scene_content = ZJsonField(required=True)

    class Meta:
        model = InterfaceSceneModel
        exclude = ('is_delete', 'case_file_path')

    def validate_project(self, project):
        if project.project_statu == False:
            raise serializers.ValidationError('项目已停用')
        return project

    def validate_scene_content(self, date):
        try:
            date_ = json.loads(date)
        except Exception as e:
            raise serializers.ValidationError('json格式错误')
        else:
            if not isinstance(date_, list):
                raise serializers.ValidationError('json格式错误')
            # for i in date_:
            #     if set(i.keys()) != {'case_header_info', 'interface_id', 'case_params', 'case_body_data', 'case_validate', 'case_name', 'extract', 'case_id'}:
            #         # raise serializers.ValidationError('json格式错误, 缺少其中之一{"case_header_info", "interface_id", "case_params", "case_body_data", "case_validate", "case_name", "extract"}')
            #         pass
        return date

    def create(self, validated_data):
        case_file_path = HttpRunnerCore(validate = validated_data).dumpTestCase()
        validated_data['case_file_path'] = case_file_path
        instance = super().create(validated_data)
        return instance

    def update(self, instance, validated_data):
        case_file_path = HttpRunnerCore(validate = validated_data, instance=instance).updateTestCase()
        validated_data['case_file_path'] = case_file_path
        instance = super().update(instance, validated_data)
        return instance


class TimeTaskSerializer(serializers.ModelSerializer):
    task_content = ZJsonField()
    task_status = serializers.ReadOnlyField(source='periodic_task.enabled')
    # project_name = serializers.ReadOnlyField(source='project.project_name')

    class Meta:
        model=TaskModel
        exclude=('is_delete', 'periodic_task', 'case_file_path', 'create_time', 'update_time')

    def validate_crontab_code(self, data):
        data_ = data.strip()
        if len(data_.split()) == 5:
            return data_
        else:
            raise serializers.ValidationError('无效的定时命令')

    @transaction.atomic
    def create(self, validated_data):
        validated_data['case_file_path'] = HttpRunnerCore.createTempDIR()
        instance = super().create(validated_data)
        instance.periodic_task = TimeTask(instance.crontab_code, instance).timeTask()
        instance.save()
        return instance

    @transaction.atomic
    def update(self, instance, validated_data):
        TimeTask(validated_data['crontab_code'], instance).updateTimeTask()
        return super().update(instance, validated_data)

class InterfaceListSerializer(serializers.Serializer):
    name = serializers.CharField()
    id = serializers.IntegerField()

    class Meta:
        model=InterfaceModel
        fields = '__all__'

class InterfaceMockSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    name = serializers.CharField()
    path = serializers.CharField()
    method = serializers.CharField()
    params = ZJsonField()
    body_data = ZJsonField()
    body_data_type = serializers.CharField()
    url = serializers.ReadOnlyField(source='getUrl')

    class Meta:
        model=InterfaceModel
        fields = '__all__'


class PublishSerializer(serializers.ModelSerializer):
    case_content = ZJsonField()
    interface_name = serializers.ReadOnlyField()
    # interface_name = serializers.ReadOnlyField(source='getInterfaceName')
    username = PublishUserNameReadOnlyField(required=False)

    class Meta:
        model= PublishCaseModel
        exclude = ('is_delete', 'update_time', 'project')

    def validate(self, attrs):
        attrs['interface_name'] = attrs.get('interface').name
        attrs['project'] = TestProjectModel.objects.get(id=self.context['view'].kwargs['project_id'])
        return attrs

    def validate_interface(self, data):
        project_obj = TestProjectModel.objects.get(id=self.context['view'].kwargs['project_id'])
        # if not project_obj.check_interface(data):
        #     raise  serializers.ValidationError('接口不在该项目下')
        return data


class PublishContentSeralizer(serializers.Serializer):
    case_content = ZJsonField()

    class Meta:
        model=PublishCaseModel
        filter=('case_content',)


class CheckPathSerializer(serializers.Serializer):
    module = serializers.CharField(required=True)
    path = serializers.CharField(required=True)
    method = serializers.CharField(required=True)
    application = serializers.CharField(required=True)


class DebugSerializer(serializers.Serializer):
    env_id = serializers.IntegerField()
    application = serializers.IntegerField()

    pass


class InterfaceExecutionTimeSerializer(serializers.ModelSerializer):
    interface_name = serializers.ReadOnlyField(source='interface.name')

    class Meta:
        model = InterfaceExecutionTimeModel
        fields = ('interface_name', 'execution_time', 'report')
        # fields = '__all__'
