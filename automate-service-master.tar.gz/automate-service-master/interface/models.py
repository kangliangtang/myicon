import datetime
from django.db import models, transaction

from case_flow.models import FlowTree
from project_caud.models import ProjectModuleModel, EnvModel

from result_report.models import ResultReportModel
from mockserver.models import MockServerModel
from utils.model import BaseModel
from django_celery_beat.models import PeriodicTask
from django.db.models.query_utils import Q
import json
from utils.util import changeValue

from logging import getLogger

debug_loging = getLogger('log')

class InterfaceModel(BaseModel):

    CHOICES_METHODS = (
        ('GET', 'GET'),
        ('POST', 'POST'),
        ('DELETE', 'DELETE'),
        ('PATCH', 'PATCH'),
        ('PUT', 'PUT'),
        ('HEAD', 'HEAD'),
        ('OPTIONS', 'OPTIONS')
    )

    CHOICES_BODY_DATA_TYPE = (
        ("x-formdata", "x-formdata"),
        ("raw", "raw"),
        ("x-formdata-file", "x-formdata-file"),
        ("xml", "xml")
    )

    name = models.CharField(max_length=64, verbose_name='接口名称')
    path = models.CharField(max_length=512, verbose_name='URL')
    method = models.CharField(default='GET', max_length=12, choices=CHOICES_METHODS, verbose_name='请求方法')
    request_head = models.TextField(null=True, blank=True, verbose_name='请求头')
    params = models.TextField(null=True, blank=True, verbose_name='get参数(类型)')
    result = models.CharField(max_length=5120, null=True, blank=True, verbose_name='返回参数')
    module = models.ForeignKey('project_caud.ProjectModuleModel', on_delete=models.CASCADE, verbose_name='所属模块')
    body_data = models.TextField(null=True, blank=True, verbose_name='body参数(类型)')  # 部分接口body参数较大 使用textfield
    # 2019.5.31 添加body_data_type  用于区分多种body数据类型
    body_data_type = models.CharField(max_length=64, default='x-formdata', choices=CHOICES_BODY_DATA_TYPE, verbose_name='body_数据类型')
    application = models.ForeignKey('project_caud.ApplicationModel', on_delete=models.CASCADE, verbose_name='所属应用', null=True)
    #增加此接口关联用例或场景数的统计
    use_case = models.IntegerField(null=False, verbose_name='此接口使用的用例数')

    class Meta:
        db_table = 'tb_interface'
        verbose_name = '接口'
        verbose_name_plural = '接口'

    def __str__(self):
        return self.name

    @transaction.atomic
    def setIsdeleteTrue(self):
        self.is_delete = True
        self.save()
        # 接口数量 减 1
        self.module.project.removeInterface(module_id=self.module_id)
        # 删除 接口地图中的 相应的接口数据
        try:
            self.module.project.flowtree.deleteInterface(self.id)
        except Exception:
            debug_loging.error('因项目中没有 接口地图导致删除报错，项目id---{}'.format(self.module.project_id))
        # 删除mock规则中相应的接口数据
        for mock in self.mockservermodel_set.filter(Q(interface=self.id) & Q(is_delete=0)).all():
            mock.setIsdeleteTrue()
        # update 删除接口下的所有用例/报告
        for test_task in self.testtaskmodel_set.all():
            test_task.setIsdeleteTrue()
        # 接口删除时 将公共接口删除
        self.publishcasemodel_set.update(is_delete=True)
        # 删除此接口运行时间记录
        if hasattr(self, 'interfaceexecutiontimemodel'):
            self.interfaceexecutiontimemodel.is_delete = True
            self.interfaceexecutiontimemodel.save(update_fields=['is_delete'])

    def createCase(self, name=None, case_content=None, case_file_path=None):
        InterfaceCaseModel.objects.create(
            name=name,
            interface=self,
            level=1,
            case_content=case_content,
            case_file_path=case_file_path
        )

    def getUrl(self):
        path = self.path
        project_id = ProjectModuleModel.objects.get(id=self.module_id).project_id
        return "/mock/{}{}".format(project_id,path)


class InterfaceExecutionTimeModel(BaseModel):
    """接口运行时间"""
    interface = models.ForeignKey('interface.InterfaceModel', on_delete=models.CASCADE, verbose_name='所属接口')
    execution_time = models.DecimalField(default=0, max_digits=10, decimal_places=2, verbose_name='执行耗时')
    project_id = models.IntegerField(verbose_name='项目id')   # 不需要设置项目外键
    env = models.ForeignKey(EnvModel, on_delete=models.CASCADE, verbose_name='所属环境')
    report = models.ForeignKey('result_report.ResultReportModel', on_delete=models.CASCADE, verbose_name='对应报告')

    class Meta:
        db_table = 'tb_interface_time'
        verbose_name = '接口运行时间'
        verbose_name_plural = '接口运行时间'


class InterfaceCaseModel(BaseModel):
    CHOICES_LEVEL = (
        (1, '一级用例'),
        (2, '二级用例'),
        (3, '三级用例'),
        (4, '四级用例'),
        (5, '五级用例')
    )
    interface = models.ForeignKey('InterfaceModel', on_delete=models.CASCADE, verbose_name='所属接口')
    name = models.CharField(max_length=128, verbose_name='用例名称')
    level = models.SmallIntegerField(default=5, choices=CHOICES_LEVEL, verbose_name='用例分级')
    # params = models.CharField(max_length=512, verbose_name='入参')
    # result_description = models.CharField(max_length=512, verbose_name='预期结果说明')
    # result_value = models.CharField(max_length=512, verbose_name='预期结果值')
    # extract = models.CharField()
    case_content = models.TextField(verbose_name='用例内容')
    case_file_path = models.FilePathField(verbose_name='测试用例路径')

    class Meta:
        db_table = 'tb_interface_case'
        verbose_name = '接口用例'
        verbose_name_plural = '接口用例'

    def __str__(self):
        return self.name

    def createReport(self):
        return ResultReportModel.objects.create(
            name = '{}-{}-{}'.format(self.id, self.name, datetime.datetime.now().strftime('%Y-%m-%d_%H:%M:%S')),
            project = self.interface.module.project,
            interface = self.interface,
            status = 'running'
        )

    @transaction.atomic
    def setIsdeleteTrue(self):
        self.is_delete = True
        self.save()
        for caseReport in self.resultreportmodel_set.all():
            caseReport.setIsdeleteTrue()


class InterfaceSceneModel(BaseModel):
    CHOICES_LEVEL = (
        (1, '一级用例'),
        (2, '二级用例'),
        (3, '三级用例'),
        (4, '四级用例'),
        (5, '五级用例')
    )
    name = models.CharField(max_length=128, verbose_name='场景名称')
    project = models.ForeignKey('project_caud.TestProjectModel', on_delete=models.CASCADE, verbose_name='所属项目')
    level = models.SmallIntegerField(default=5, choices=CHOICES_LEVEL, verbose_name='用例分级')
    description = models.CharField(max_length=512, null=True, blank=True, verbose_name='场景描述')
    scene_content = models.TextField(verbose_name='用例内容')
    case_file_path = models.FilePathField(null=True, blank=True, verbose_name='场景用例路径')

    class Meta:
        db_table = 'tb_interface_scene'
        verbose_name = '测试场景'
        verbose_name_plural = '测试场景'

    def __str__(self):
        return self.name

    def createReport(self):
        return ResultReportModel.objects.create(
            name = '{}{}报告'.format(self.__str__(), self.id),
            project = self.project,
            interface_scen = self,
            status = 'running'
        )

    @transaction.atomic
    def setIsdeleteTrue(self):
        self.is_delete = True
        self.save()


class TaskModel(BaseModel):
    CHOICES_INTERFACE_LEVEL = (
        (1, '用例级别一'),
        (2, '用例级别二'),
        (3, '用例级别三'),
        (4, '用例级别四'),
        (5, '用例级别五')
    )
    CHOICES_SCENE_LEVEL = (
        (1, '用例级别一'),
        (2, '用例级别二'),
        (3, '用例级别三'),
        (4, '用例级别四'),
        (5, '用例级别五')
    )
    name = models.CharField(max_length=128, verbose_name='任务名')
    # interface_level = models.SmallIntegerField(null=True, blank=True, choices=CHOICES_INTERFACE_LEVEL, verbose_name='用例级别')
    # scene_level = models.SmallIntegerField(null=True, blank=True, choices=CHOICES_SCENE_LEVEL, verbose_name='场景级别')
    task_content = models.TextField(max_length=258, verbose_name="任务内容")
    project = models.ForeignKey('project_caud.TestProjectModel', on_delete=models.CASCADE, verbose_name='所属项目')
    crontab_code = models.CharField(max_length=50, verbose_name='定时命令')
    periodic_task = models.OneToOneField(PeriodicTask, null=True, blank=True, on_delete=models.CASCADE, verbose_name='定时任务')
    case_file_path = models.FilePathField(verbose_name='用例路径')
    # update 增加邮件地址
    to_emails = models.CharField(max_length=300, null=True, blank=True, verbose_name='收件邮件地址')
    last_executor = models.CharField(max_length=512, null=True, blank=True, verbose_name='最后执行人')

    class Meta:
        db_table = 'tb_task'
        verbose_name_plural = '定时任务'
        verbose_name = '定时任务'

    def __str__(self):
        return self.name

    @transaction.atomic
    def setIsdeleteTrue(self):
        self.is_delete = True
        self.save()
        self.close()
        self.taskresultreportmodel_set.update(is_delete=True)

    def start(self):
        p_task = self.periodic_task
        p_task.enabled = True
        p_task.save()

    def close(self):
        p_task = self.periodic_task
        p_task.enabled = False
        p_task.save()


class PublishCaseModel(BaseModel):
    """
    公共用例,登陆
    """
    CHOICES_CASE_TYPE = (
        (0, '登录'),
        (1, '登出'),
        (2, '其他')
    )

    interface = models.ForeignKey('interface.InterfaceModel', on_delete=models.CASCADE, verbose_name='接口')
    case_content = models.TextField(verbose_name='用例内容')
    interface_name = models.CharField(max_length=64, verbose_name='接口名')
    case_type = models.SmallIntegerField(choices=CHOICES_CASE_TYPE, default=0, verbose_name='用例类型')
    host_env = models.CharField(max_length=128, blank=True, null=True, verbose_name='绑定的环境url')
    is_default = models.BooleanField(default=0, verbose_name='是否默认')
    project = models.ForeignKey('project_caud.TestProjectModel', on_delete=models.CASCADE, verbose_name='项目')
    username = models.CharField(max_length=128, null=True, blank=True, verbose_name='操作人')

    class Meta:
        db_table = 'tb_pulish'
        verbose_name='公共用例'
        verbose_name_plural=verbose_name

    @transaction.atomic
    def setIsdeleteTrue(self):
        self.is_delete = True
        self.save()

    @transaction.atomic
    def set_default_interface(self, project_id):
        """
        设置为默认接口，与其类型相同的就扣将被置为非默认
        :param project_id:
        :return:
        """
        PublishCaseModel.objects.filter(case_type=self.case_type, project_id = project_id).update(is_default = False)
        self.is_default = True
        self.save()

    def update_host(self, host_env):
        """
        更新host
        :param host_env:
        :return:
        """
        self.host_env = host_env
        self.save()

    def getInterfaceName(self):
        interface_query = InterfaceModel.objects.filter(id=self.interface_id, is_delete=False)
        if interface_query:
            interface_name = interface_query.first().name
        else:
            interface_name = self.interface_name
        return interface_name

    def update_case_content(self, interface_obj):
        """更新case_content"""
        instance = interface_obj
        # instance = self.interface
        old_case_content = json.loads(self.case_content)
        params = changeValue('case_params', instance.params, old_case_content)
        request_head = changeValue('case_header_info', instance.request_head, old_case_content)
        # 只同步接口名称、头域/URL数据的key值, 将body数据、返回值保持原有的数据
        case_content = {
            # "case_body_data": [],
            "case_body_data": old_case_content["case_body_data"],
            "name": instance.name,
            "case_params": params,
            # "extract": [],
            "extract": old_case_content["extract"],
            "status": "enable",
            # "case_body_type": instance.body_data_type,
            "case_body_type": old_case_content["case_body_type"],
            "case_header_info": request_head,
            "id": instance.id,
            # "case_validate": [],
            "case_validate": old_case_content["case_validate"],
            "interface_id": instance.id,
            "case_name": instance.name
        }
        self.case_content = json.dumps(case_content)
        self.interface_name = instance.name
        self.save(update_fields=['case_content', 'interface_name'])
