# import os
#
# from django.contrib.auth.backends import UserModel
# from django.test import TestCase
#
# # Create your tests here.
#
# os.environ.setdefault("DJANGO_SETTINGS_MODULE", "automate_test_py3.settings")
# import  django
#
# django.setup()
# from interface.tasks import runTest, TimeTask
#
#
# def main():
#     from django_celery_beat.models import PeriodicTask, CrontabSchedule
#     schedule, _ = CrontabSchedule.objects.get_or_create(
#         minute = '*/1',
#         hour='*',
#         day_of_week='*',
#         day_of_month='*',
#         month_of_year='*',
#     )
#     task_ = PeriodicTask.objects.create(
#         crontab = schedule,
#         name = 'test1221',
#         task = 'interface.tasks.add',
#         args  = [1,2]
#     )
#
#
# if __name__ == '__main__':
#     user_obj = UserModel.objects.get(id=1)


from xml.sax.handler import ContentHandler
from xml.sax import make_parser




def main():
    ttt = '''<?xml version="1.0" encoding="utf-8"?>
<root>
 <person age="18">
    <name>hzj</name>
    <sex>man</sex>
 </person>
 <person age="19" des="hello">
    <name>kiki</name>
    <sex>female</sex>
 </person>
</root>'''
    from xml.etree import ElementTree as ET
    ET.parse(ttt)

if __name__ == '__main__':
    import httprunner
    import os
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "automate_test_py3.settings")
    import django
    django.setup()
    from automate_test_py3 import settings
    from utils.util import RSACLASS
    obj = RSACLASS(settings.SECRET_KEY)
    # p_key = obj.generatPrivateKey()
    # b_key = obj.generatPubliKey()
    # obj.savePrivateKey()
    # obj.savePubliKey()
    skey = obj.signerData(message='haha')
    print(skey)
    print(obj.decryptData(skey))



