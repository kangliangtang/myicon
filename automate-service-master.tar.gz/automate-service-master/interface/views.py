import json
import chardet
import time
import os
from colorlog.logging import getLogger
from django.contrib.auth.models import Group
from django.db.models.query_utils import Q
from django.utils.itercompat import is_iterable
from rest_framework.decorators import list_route, detail_route
from rest_framework import filters
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.status import HTTP_200_OK, HTTP_400_BAD_REQUEST
from rest_framework.viewsets import ModelViewSet
from rest_framework.filters import OrderingFilter
from interface.models import InterfaceModel, InterfaceCaseModel, InterfaceSceneModel, TaskModel, PublishCaseModel
from interface.serializers import InterfaceSerializer, InterfaceCaseSerializer, InterfaceSceneSerializer, \
    TimeTaskSerializer, InterfaceListSerializer, PublishSerializer, PublishContentSeralizer, InterfaceMockSerializer, \
    CheckPathSerializer, DebugSerializer
from interface.tasks import runTimeTask
from project_caud.models import TestProjectModel, ApplicationEnvModel, EnvModel
from result_report.models import ResultReportModel, TaskResultReportModel, SummaryModel
from system.models import UploadFileModel
from utils import util
from utils.runcore import CaseDump
from utils.util import ExportInterfaceException, DescribetionModelViewSet

# 操作日志
from utils.operation_log import OperationLogDecorator
from django.utils.decorators import method_decorator
logde = OperationLogDecorator()
import requests
# 公共参数
from utils.common_parameter import ReplaceCommonParameter

class InterfaceAPIView(ModelViewSet):
    serializer_class = InterfaceSerializer
    queryset = None
    filter_backends = (filters.SearchFilter, OrderingFilter, DjangoFilterBackend)
    search_fields = ('name',)
    ordering = ('-create_time',)
    # permission_classes = (AutoPlatformPermission, )

    def get_queryset(self):
        user_obj = self.request.user
        user_group_obj = Group.objects.filter(user=user_obj)
        try:
            # project_id = self.request.META.get('HTTP_PROJECTID')
            project_id = self.kwargs['project_id']
            if user_obj.isSuperUser:
                query_set = InterfaceModel.objects.filter(is_delete=False, module__project__project_statu=True).filter(module__project_id=project_id)
            else:
                query_set = InterfaceModel.objects.filter(is_delete=False, module__project__project_statu=True).filter(
                    Q(module__project_id=project_id) &
                    Q(Q(module__project__user_group__in=user_group_obj)))
            if self.request.query_params.get('app_id'):
                app_id = self.request.query_params.get('app_id')
                query_set = query_set.filter(application_id=app_id)
            if self.request.query_params.get('module_id'):
                query_set = query_set.filter(module__id=self.request.query_params.get('module_id'))
            if self.request.query_params.get('interface_name'):
                query_set = query_set.filter(name__icontains=self.request.query_params.get('interface_name'))
            return query_set
        except Exception as e:
            return InterfaceModel.objects.none()

    def retrieve(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"retrieve",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super().retrieve(request, *args, **kwargs)

    def update(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"update",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super().update(request, *args, **kwargs)

    def list(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"list",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super().list(request, *args, **kwargs)

    @method_decorator(logde.del_interface)
    def destroy(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"destroy",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        obj =self.get_object()
        obj.setIsdeleteTrue()
        return Response('删除成功', status=HTTP_200_OK)

    @list_route(methods=['POST'])
    @method_decorator(logde.create_interface)
    def upload(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"upload",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        # self.check_permissions(request) # 权限检验

        # project_id = request.META.get('HTTP_PROJECTID')
        project_id = self.kwargs['project_id']
        logger = getLogger('log')
        t1 = time.time()
        data = request.data
        module_id = data.get('module_id')
        application_id = data.get('application_id', None)
        file_type = int(data.get('file_type'))

        #***********单独的权限控制*********#
        # 通过查询集来过滤 拥有权限的 项目
        user_obj = request.user
        user_group_obj_set = Group.objects.filter(user = user_obj)
        if user_obj.isSuperUser:
            project_obj = TestProjectModel.objects.get(id=project_id)
        else:
            project_obj = TestProjectModel.objects.filter(Q(id=project_id) & Q(Q(user_group__in=user_group_obj_set))).first()
        if project_obj is None:
            return Response({'message':'无该项目权限'}, status=403)
        if not project_obj.projectmodulemodel_set.filter(id=module_id).exists():
            return Response({"message": "该项目下无对应模块"}, status=HTTP_400_BAD_REQUEST)
        #*******************权限控制×××××××××××××××#

        module_obj = project_obj.projectmodulemodel_set.get(id=module_id)
        json_file = request.FILES.get('json_file')
        try:
            file_data = json_file.read()
            # 编码格式兼容
            decode_stye_ = chardet.detect(file_data)['encoding']
            decode_stye = decode_stye_ if decode_stye_ else 'utf-8'
            json_file_data = file_data.decode(decode_stye)

            case_dump_obj = CaseDump(json_file=json_file_data, file_type=file_type, project=project_obj, module=module_obj)
            case_dump_obj.dumpUploadJsonFile()
            case_dump_obj.generateInterfaceByJson(application_id=application_id)
        except ExportInterfaceException as interface_e:
            message = '异常接口:{},异常消息:{}'.format(interface_e.interface_name, interface_e.message)
            logger.exception(interface_e)
            return Response(
                {
                    'message': message,
                    'success': False
                },
                status=HTTP_200_OK
            )
        except Exception as e:
            # msg = traceback.format_exc()
            # print(msg)
            # message_ = e.args
            # print('导入接口报错，，，报错原因,---->',message_)
            # message = '未能正确解析json文件'
            message = '文件中包含非json格式数据,未能正确解析'
            # post_man_interface_load_file_path = os.path.join(settings.POSTMAN_INTERFACE_DIR,'{}--fail'.format(json_file_name))
            # with open(post_man_interface_load_file_path, 'w') as f:
            #     f.write('请查看debug日志')
            logger.exception(e)
            return Response(
                {
                    'message': message,
                    'success': False
                },
                status=HTTP_200_OK
            )
        else:
            # 接口数 加 n
            project_obj.addInterface(n=case_dump_obj.create_interface_count, module_id=module_id)

            success = case_dump_obj.success
            return Response(
                {
                    'data':
                        {
                            'interface_count':case_dump_obj.create_interface_count,
                            'case_count': case_dump_obj.create_case_count
                        },
                    'success': success
                },
                status=HTTP_200_OK
            )

    @list_route(methods=['POST'])
    def debug(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"debug",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        logger = getLogger('log')
        logger.info(request.data)
        data = request.data
        env_id = data["env_id"]
        application_id = data["application"]
        serializer = DebugSerializer(data=data)
        serializer.is_valid(raise_exception=True)
        host = ApplicationEnvModel.objects.get(env_id=env_id, application_id=application_id).host
        path_ = data.get('path', None)
        #需要验证url是否带/
        if path_ is not None:
            if path_.startswith("/"):
                url = host + path_
            else:
                url = host + '/' + path_
        else:
            url = host
        headerlist = data["request_head"]
        bodylist = data["body_data"]
        body_data_type = data['body_data_type']
        paramlist = data["params"]
        headers = {}
        params = {}
        method = data["method"]
        # project_id = self.request.META.get('HTTP_PROJECTID')
        project_id = self.kwargs['project_id']

        # 公共参数替换
        replace_obj = ReplaceCommonParameter(project_id=project_id)
        url = replace_obj.common_param(url)
        for heaser in headerlist:
            headers[replace_obj.common_param(heaser["key"])] = replace_obj.common_param(heaser["value"])

        # data_json_file = {}
        # if body_data_type == 'raw':
        #     headers.update({'Content-Type':'application/json'})
        #     data_json_file["json"] = bodylist
        # elif body_data_type == 'x-formdata':
        #     headers.update({'Content-Type': 'application/json'})
        #     json_ = {}
        #     for json_data in bodylist:
        #         json_[json_data['key']] = json_data['value']
        #     data_json_file["json"] = json_
        # elif body_data_type == 'x-formdata-file':
        #     file_dict = {}
        #     body_dict = {}
        #     for formdata_ in bodylist:
        #         if formdata_.get('type') == 'file':
        #             try:
        #                 file_obj = UploadFileModel.objects.get(file_name=formdata_.get('value'))
        #             except UploadFileModel.DoesNotExist as e:
        #                 pass
        #             else:
        #                 #files = {'file': ('report.xls', open('report.xls', 'rb'), 'application/vnd.ms-excel', {'Expires': '0'})}
        #                 file_dict[formdata_.get('key')] = open(file_obj.file_path, 'rb')
        #
        #         else:
        #             body_dict[formdata_.get('key')] = formdata_.get('value')
        #
        #     if file_dict.__len__() > 0:
        #         data_json_file["files"] = file_dict
        #     if body_dict.__len__() > 0:
        #         data_json_file['data'] = body_dict
        # elif body_data_type == 'xml':
        #     headers.update({'Content-Type': 'application/xml'})
        #     data_json_file['data'] = bodylist

        # -------------------body 中的公共参数替换------------------------
        upload_file_path = None
        upload_file_name = None
        upload_file_suffix = None
        data_json_file = {}
        if body_data_type == 'raw':
            headers.update({'Content-Type': 'application/json'})
            # data_json_file["json"] = replace_obj.json_common_param(bodylist)
            data_json_file["json"] = replace_obj.replace_serialized_obj(bodylist)
        elif body_data_type == 'x-formdata':
            headers.update({'Content-Type': 'application/json'})
            if isinstance(bodylist, list) and (not bodylist):
                data_json_file["json"] = None
            else:
                json_ = {}
                for json_data in bodylist:
                    json_[json_data['key']] = json_data['value']
                data_json_file["json"] = replace_obj.replace_serialized_obj(json_)
        elif body_data_type == 'x-formdata-file':
            file_dict = {}
            body_dict = {}
            for formdata_ in bodylist:
                if formdata_.get('type').lower() == 'file':
                    try:
                        file_obj = UploadFileModel.objects.get(project_id=project_id, file_name=formdata_.get('value'), is_delete=False)
                    except UploadFileModel.DoesNotExist as e:
                        pass
                    else:
                        # files = {'file': ('report.xls', open('report.xls', 'rb'), 'application/vnd.ms-excel', {'Expires': '0'})}
                        upload_file_path = file_obj.file_path
                        upload_file_name = file_obj.file_name
                        upload_file_suffix = file_obj.suffix
                        full_file_name = '{}.{}'.format(upload_file_name, upload_file_suffix)
                        file_dict[replace_obj.common_param(formdata_.get('key'))] = (full_file_name, open(upload_file_path, 'rb'))
                        # file_dict[replace_obj.common_param(formdata_.get('key'))] = (os.path.basename(upload_file_path), open(upload_file_path, 'rb'))
                else:
                    body_dict[replace_obj.common_param(formdata_.get('key'))] = replace_obj.common_param(formdata_.get('value'))

            if file_dict.__len__() > 0:
                data_json_file["files"] = file_dict
            if body_dict.__len__() > 0:
                data_json_file['data'] = body_dict
        elif body_data_type == 'xml':
            if not util.checkXML(bodylist):
                return Response({
                 "success":False,
                 "message":"xml格式不正确"
             },status=HTTP_200_OK)
            if not headers.get('Content-Type'):
                headers.update({'Content-Type': 'text/xml'})
            data_json_file['data'] = replace_obj.json_common_param(bodylist)
            # data_json_file['data'] = replace_obj.replace_serialized_obj(bodylist)
        # -------------------body 中的公共参数替换----------------------------------

        for param in paramlist:
            if param['key'].startswith('$'):
                # 替换url参数
                url = url.replace(param['key'], replace_obj.common_param(param["value"]))
                # parameters[params['key']] = replace_obj.common_param(param["value"])
            else:
                params[replace_obj.common_param(param["key"])] = replace_obj.common_param(param["value"])

        try:
            import requests
            r = requests.request(method=method, url=url, headers=headers, params=params,allow_redirects=1, **data_json_file)
        except Exception as e:
             print('except:', e)
             logger.exception(e)
             return  Response({
                 "success":False,
                 "message":"请检查你的URL是否正确，当前URL为{}".format(url)
             },status=HTTP_200_OK)
        _response = {}
        _request = {}
        request_data = {}
        #组装请求信息
        _request["url"] = r.url
        _request["method"] = data["method"]
        _request["headers"] = headers
        # _request["body"] = r.request.body
        try:
            request_body = r.request.body.decode('utf-8', 'ignore')
        except Exception as e:
            logger.exception(e)
            request_body = r.request.body
        try:
            _request["body"] = json.loads(request_body)
        except Exception as e:
            logger.exception(e)
            _request["body"] = request_body

        # 将文件名改为用户上传的文件名
        if upload_file_name and upload_file_path:
            db_file_name = os.path.basename(upload_file_path)
            if upload_file_suffix:
                upload_file_name = '{0}.{1}'.format(upload_file_name, upload_file_suffix)
            _request["body"] = (_request["body"]).replace('filename="{}"'.format(db_file_name), 'filename="{}"'.format(upload_file_name), 1)

        # 组装返回信息
        _response["code"] = r.status_code
        _response["headers"] = r.headers._store
        _response["body"] = r.text
        # _response_content_type = _response["headers"].get("content-type")
        # if is_iterable(_response_content_type) and 'application/json' in _response_content_type:


        # response返回数据格式标明 {"content-type":["Content-Type", "application/json;charset=utf-8"]}
        # if is_iterable(_response_content_type) and 'application/json' in _response_content_type:
        try:
            _response["body"] = json.loads(r.text)
        except Exception as e:
            logger.exception(e)

        #组装返回体
        request_data["response"] = _response
        request_data["request"] = _request

        # print (json.dumps(request_data))
        return Response({
                 "success":True,
                 "request_data":request_data
             },status=HTTP_200_OK)

    @list_route(methods=['GET'])
    def interfaceList(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"interfaceList",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        query_set = self.filter_queryset(self.get_queryset())
        serializer = InterfaceListSerializer(query_set, many=True)
        return Response({'list': serializer.data}, status=HTTP_200_OK)

    @list_route(methods=['GET'])
    def interfaceMock(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"interfaceMock",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        query_set = self.get_queryset().order_by('-create_time')
        serializer = InterfaceMockSerializer(query_set, many=True)
        return Response({'list': serializer.data}, status=HTTP_200_OK)

    @list_route(methods=['POST'])
    def flowInterface(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"flowInterface",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        interface_id_list = request.data.get('interface_id_list', None)
        if interface_id_list is None:
            return Response(status=HTTP_400_BAD_REQUEST)
        if isinstance(interface_id_list, list):
            interface_set = InterfaceModel.objects.filter(id__in=interface_id_list).order_by('-create_time')
            # serializer = InterfaceSerializer(interface_set, many=True)
            # return Response({'list': serializer.data}, status=HTTP_200_OK)
            #update 增加搜索功能
            search = request.data.get('search', None)
            if search:
                interface_set = interface_set.filter(name__icontains=search)
            serializer = InterfaceSerializer(interface_set, many=True)
            return Response({'list': serializer.data}, status=HTTP_200_OK)
        else:
            interface_set = InterfaceModel.objects.none()
            serializer = InterfaceSerializer(interface_set, many=True)
            return Response({'list': serializer.data}, status=HTTP_400_BAD_REQUEST)

    @method_decorator(logde.update_interface)
    def partial_update(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"partial_update",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        module = request.data.get("module")
        path = request.data.get("path")
        method = request.data.get("method")
        pk = kwargs["pk"]
        if not path.startswith("/"):
            return Response({'message': 'PATH必须以/开头'}, HTTP_400_BAD_REQUEST)
        if InterfaceModel.objects.filter(module_id=module, path=path, method=method, is_delete=False).filter(~Q(id=pk)):
            return Response({'message': '此PATH已存在'}, HTTP_400_BAD_REQUEST)
        return super().partial_update(request, *args, **kwargs)

    @method_decorator(logde.create_one_interface)
    def create(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"create",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        module = request.data.get("module")
        path = request.data.get("path")
        method = request.data.get("method")
        application = request.data.get("application", None)
        request.data['use_case'] = 0
        if not path.startswith("/"):
            return Response({'message': 'PATH必须以/开头'}, HTTP_400_BAD_REQUEST)
        for interface in InterfaceModel.objects.filter(module_id=module, path=path, method=method, is_delete=False, application_id=application).all():
            if interface.path == path:
                return Response({'message': '此PATH已存在'}, HTTP_400_BAD_REQUEST)
        return super().create(request, *args, **kwargs)

    @list_route(methods=['POST'])
    def checkPath(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"checkPath",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        # """PATH唯一性校验（指定模块下）"""
        module = request.data.get("module", None)
        path = request.data.get("path", None)
        method = request.data.get("method", None)
        application = request.data.get('application', None)
        serializer = CheckPathSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        id = request.data.get("id")
        if not all([module, path, method]):
            return Response("请填写PATH", HTTP_200_OK)
        if not path.startswith("/"):
            return Response("PATH必须以/开头", HTTP_200_OK)
        # 接口修改时
        interface_query_set_ = InterfaceModel.objects.filter(module_id=module, path__exact=path, method=method, is_delete=False,
                                      application_id=application)
        if id:
            interface_query_set = interface_query_set_.filter(~Q(id=id))
            for interface in interface_query_set:
                # 项目中的数据表 不支持 字符串大小排序 这是mysql问题  需要修改 接口表的排序规则，
                """
                默认情况下，使用UTF-8数据库，MySQL将使用 utf8_general_ci排序规则。
                这导致所有字符串相等性比较以不区分大小写的方式完成。
                也就是说，"Fred"并且 "freD"被认为是在数据库级别相等。
                如果你有一个字段的唯一约束，这将是非法的尝试将两者"aa"并 "AA"到同一列，
                因为它们的比较结果相等（和，因此，非唯一）与默认排序规则。
                如果要对特定列或表进行区分大小写的比较，请更改列或表以使用 utf8_bin排序规则。
                请注意，根据MySQL Unicode字符集，比较的比较utf8_general_ci更快，但比正确性稍差utf8_unicode_ci。
                如果您的应用程序可以接受，那么您应该使用utf8_general_ci它，因为它更快。
                如果这是不可接受的（例如，如果您需要德语字典顺序），请使用，utf8_unicode_ci 因为它更准确。
                """
                if interface.path == path:
                    return Response("此PATH已存在", HTTP_200_OK)
            else:
                return Response("OK", HTTP_200_OK)
        # 接口新增时
        for interface in interface_query_set_:
            if interface.path == path:
                return Response("此PATH已存在", HTTP_200_OK)
        else:
            return Response("OK", HTTP_200_OK)


class InterfaceCaseAPIView(DescribetionModelViewSet):
    serializer_class = InterfaceCaseSerializer
    queryset = None
    filter_backends = (filters.SearchFilter, OrderingFilter, DjangoFilterBackend)
    search_fields = ('interface__name', 'name')
    filter_fields = ('interface__module__project_id',)
    ordering = ('-create_time',)
    # permission_classes = (AutoPlatformPermission, )

    def get_queryset(self):
        user_obj = self.request.user
        user_group_obj_set = Group.objects.filter(user=user_obj)
        try:
            # project_id = self.request.META.get('HTTP_PROJECTID')
            project_id = self.kwargs['project_id']
            if user_obj.isSuperUser:
                return InterfaceCaseModel.objects.filter(is_delete=False, interface__module__project__project_statu=True).filter(interface__module__project_id=project_id)
            return InterfaceCaseModel.objects.filter(is_delete=False, interface__module__project__project_statu=True).filter(
                    Q(interface__module__project_id=project_id) &
                    Q(interface__module__project__user_group__in=user_group_obj_set))
        except Exception as e:
            return InterfaceCaseModel.objects.none()

    @list_route(methods=['POST'])
    def run(self, request):
        """
        {
        "permission":{
            "action":"run",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        case_id_list = request.data.get('cases')
        host = request.data.get('host')
        project_id = host.get('project_id', None)

        #***********单独的权限控制*********#
        # 通过查询集来过滤 拥有权限的 项目
        user_obj = request.user
        user_group_obj_set = Group.objects.filter(user = user_obj)
        if user_obj.isSuperUser:
            project_obj = TestProjectModel.objects.get(id=project_id)
        else:
            project_obj = TestProjectModel.objects.filter(id=project_id, user_group__in=user_group_obj_set).first()

        if project_obj is None:
            return Response({'message':'无该项目权限'}, status=403)
        #*******************权限控制×××××××××××××××#

        project_obj = TestProjectModel.objects.get(id=host['project_id'])
        if project_obj.project_statu == False:
            return Response({"message": "项目已停用"}, status=HTTP_400_BAD_REQUEST)
        env = project_obj.env.filter(is_delete=False, id=None)
        if env.__len__():
            return Response('找不到项目环境(host)', status=HTTP_400_BAD_REQUEST)
        # 异步执行 用例
        report_obj = ResultReportModel.objects.create(
            project=InterfaceCaseModel.objects.get(id=case_id_list[0]).interface.module.project,
            name='',
        )
        # runTestTask.delay(case_id_list=case_id_list, host_url=None, report_id = report_obj.id)
        return Response('已加入测试任务队列', status=HTTP_200_OK)

    def destroy(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"destroy",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        obj =self.get_object()
        obj.setIsdeleteTrue()
        return Response('删除成功', status=HTTP_200_OK)

    #临时改成同步
    # def runTestTask(self,case_id_lists, host_url, report_id):
    #     runner = HttpRunnerCore()
    #     name_set = set()
    #     case_file_path = runner.dumpTestCases(case_id_list=case_id_lists, name_set=name_set)
    #     report_obj = ResultReportModel.objects.get(id=report_id)
    #     report_obj.name = ','.join(name_set)
    #     suumarry_obj = SummaryModel.objects.create(result_report=report_obj)
    #     runner.runCaseByPath(case_file_path, host_url=host_url, report_obj=report_obj, suumarry_obj=suumarry_obj)suumarry_obj


class InterfaceSceneAPIView(ModelViewSet):
    serializer_class = InterfaceSceneSerializer
    queryset = None
    filter_backends = (filters.SearchFilter,OrderingFilter, DjangoFilterBackend)
    search_fields = ('name',)
    ordering = ('-create_time',)
    filter_fields = ('project_id',)

    def get_queryset(self):
        user_obj = self.request.user
        user_group_obj_set = Group.objects.filter(user=user_obj)
        try:
            # project_id = self.request.META.get('HTTP_PROJECTID')
            project_id = self.kwargs['project_id']
            if user_obj.isSuperUser:
                return InterfaceSceneModel.objects.filter(is_delete=False, project__project_statu=True).filter(project__id=project_id)
            return InterfaceSceneModel.objects.filter(is_delete=False, project__project_statu=True).filter(
                Q(project_id=project_id) &
                Q(project__user_group__in=user_group_obj_set))
        except Exception as e:
            return InterfaceSceneModel.objects.none()

    def destroy(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"destroy",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        obj =self.get_object()
        obj.setIsdeleteTrue()
        return Response('删除成功', status=HTTP_200_OK)

    @list_route(methods=["POST"])
    def run(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"run",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        scenes = request.data.get('scenes')
        host = request.data.get('host')
        project_id = host.get('project_id')
        # ***********单独的权限控制*********#
        # 通过查询集来过滤 拥有权限的 项目
        user_obj = request.user
        user_group_obj_set = Group.objects.filter(user=user_obj)
        if user_obj.isSuperUser:
            project_obj = TestProjectModel.objects.get(id=project_id)
        else:
            project_obj = TestProjectModel.objects.filter(
                Q(id=project_id) &
                Q(user_group__in=user_group_obj_set)).first()

        if project_obj is None:
            return Response({'message': '无该项目权限'}, status=403)
        # *******************权限控制×××××××××××××××#

        project_obj = TestProjectModel.objects.get(id=host['project_id'])
        if project_obj.project_statu == False:
            return Response('项目停用', status=HTTP_400_BAD_REQUEST)
        for i in json.loads(project_obj.project_urls):
            if i['env_name'] == host['env_name']:
                host_url = i['env_host']
                break
        else:
            return Response('没有找到项目环境', status=HTTP_400_BAD_REQUEST)
        # 异步执行 场景测试
        # runSceneTask.delay(scenes, host_url)
        return Response('已加入任务队列', status=HTTP_200_OK)

    def create(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"create",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super().create(request, *args, **kwargs)

    def retrieve(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"retrieve",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super().retrieve(request, *args, **kwargs)

    def update(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"update",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super().update(request, *args, **kwargs)

    def partial_update(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"partial_update",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super().partial_update(request, *args, **kwargs)

    def list(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"list",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super().list(request, *args, **kwargs)


class TimeTaskAPIView(ModelViewSet):
    serializer_class = TimeTaskSerializer
    queryset = None
    filter_backends = (filters.SearchFilter,OrderingFilter, OrderingFilter)
    search_fields = ('name',)
    ordering = ('-create_time',)

    def get_queryset(self):
        user_obj = self.request.user
        user_group_obj = Group.objects.filter(user=user_obj)
        try:
            # project_id = self.request.META.get('HTTP_PROJECTID')
            project_id = self.kwargs['project_id']
            if user_obj.isSuperUser:
                return TaskModel.objects.filter(is_delete=False, project__project_statu=True).filter(project__id=project_id)
            return TaskModel.objects.filter(is_delete=False, project__project_statu=True).filter(
                Q(project__id=project_id) & Q(project__user_group__in=user_group_obj)
            )
        except Exception as e:
            return TaskModel.objects.none()

    def destroy(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"destroy",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        self.get_object().setIsdeleteTrue()
        return Response('删除成功', status=HTTP_200_OK)

    @detail_route(methods=['POST'])
    @method_decorator(logde.change_timetask)
    def start(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"start",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        # """
        # 开启定时任务
        # :param request:
        # :param pk:
        # :return:
        # """
        self.get_object().start()
        return Response('定时任务开启', status=HTTP_200_OK)

    @detail_route(methods=['POST'])
    @method_decorator(logde.change_timetask)
    def close(self,request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"close",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        # """
        # 关闭定时任务
        # :param request:
        # :param pk:
        # :return:
        # """
        self.get_object().close()
        return Response('定时任务关闭', HTTP_200_OK)

    @detail_route(methods=['POST'])
    @method_decorator(logde.change_timetask)
    def run(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"run",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""

        # task = self.get_object()
        # runTimeTask.delay(task.id)

        # 增加最后执行人更新 2020-4-3 liangtang
        task = self.get_object()
        task_id = task.id
        user_obj = self.request.user
        user_name = user_obj.username
        TaskModel.objects.filter(id=task_id).update(last_executor=user_name)
        runTimeTask.delay(task_id, user_name)
        return Response('加入运行队列', status=HTTP_200_OK)

    @method_decorator(logde.create_timetask)
    def create(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"create",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""

        return super().create(request, *args, **kwargs)

    def list(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"list",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        rep = super().list(request, *args, **kwargs)
        return rep

    @detail_route(methods=['GET'])
    def report(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"report",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        # """获取定时任务报告(最新的一份)"""
        try:
            # project_id = self.request.META.get('HTTP_PROJECTID')
            project_id = self.kwargs['project_id']
            task_report_obj = TaskResultReportModel.objects.filter(project_id=project_id, task_id=self.kwargs['pk'], is_delete=False).order_by('-create_time').first()
            if not task_report_obj:
                return Response({'message':'无报告'}, status=HTTP_400_BAD_REQUEST)
            status = task_report_obj.status
            if status == 'running':
                return Response({'message':'任务状态为运行中，请待运行结束，或联系平台管理员'}, status=HTTP_400_BAD_REQUEST)
            summary_obj = SummaryModel.objects.get(task_result_report_id=task_report_obj.id)
            # resultJson = summary_obj.summary_count
            summary_count_data = json.dumps('')
            if summary_obj.summary_count:
                # with open(summary_obj.summary_count, 'r') as f:
                #     summary_count_data = f.read()
                summary_count_data = summary_obj.summary_count_data()
            resultJson = summary_count_data
            return Response(json.loads(resultJson))
        except Exception as e:
            return Response({'message':'获取报告失败%s' % e}, status=HTTP_400_BAD_REQUEST)

    def retrieve(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"retrieve",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super().retrieve(request, *args, **kwargs)

    def update(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"update",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super().update(request, *args, **kwargs)

    def partial_update(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"partial_update",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super().partial_update(request, *args, **kwargs)



class PublishAPIView(ModelViewSet):
    """
    公共用例，视图集
    包含增删改查
    """
    serializer_class = PublishSerializer
    queryset = None
    filter_backends = (OrderingFilter, )
    ordering = ('-create_time',)

    def get_queryset(self):
        user_obj = self.request.user
        user_group_obj = Group.objects.filter(user=user_obj)
        try:
            # project_id = self.request.META.get('HTTP_PROJECTID')
            project_id = self.kwargs['project_id']
            if user_obj.isSuperUser:
                return PublishCaseModel.objects.filter(is_delete=False).filter(project_id=project_id)
            return PublishCaseModel.objects.filter(is_delete=False).filter(
                Q(project_id=project_id) & Q(project__user_group__in=user_group_obj)
            )
        except Exception as e:
            return PublishCaseModel.objects.none()

    def destroy(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"destroy",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        self.get_object().setIsdeleteTrue()
        return Response('删除成功', status=HTTP_200_OK)

    @detail_route(methods=['POST'])
    def host(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"host",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        # """
        # 绑定环境，需要传参数 env_name
        # :param request:
        # :param pk:
        # :return:
        # """
        data = request.data
        env_id = data.get('env_id')
        # project_id = request.META.get('HTTP_PROJECTID')
        project_id = self.kwargs['project_id']
        application_id = self.get_object().interface.application_id
        if not EnvModel.objects.filter(is_delete=False, id=env_id,project_id=project_id).exists():
            return Response({'message': '没有找到项目环境'}, status=HTTP_400_BAD_REQUEST)
        host = ApplicationEnvModel.objects.get(
            application_id=application_id,
            env_id=env_id,
            is_delete=False,
            project_id=project_id
        ).host
        self.get_object().update_host(
            host_env=host
        )
        return Response({'message': '成功设置项目环境'}, status=HTTP_200_OK)

    @detail_route(methods=['patch'])
    def content(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"content",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        # """
        # 编辑公共接口，接口内容case_content
        # :param request:
        # :param pk:
        # :return:
        # """
        instance = self.get_object()
        data_ = request.data
        serializer = PublishContentSeralizer(instance=instance, data=data_)
        serializer.is_valid(raise_exception=True)
        instance.case_content = json.dumps(data_.get('case_content'))
        instance.save()
        return Response({'message': '修改成功'}, status=HTTP_200_OK)

    @detail_route(methods=['post'])
    def default(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"default",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""

        project_id = self.kwargs['project_id']
        # if self.get_object().host_env is None:
        #     return Response({'message': '未绑定环境，请先绑定环境','code': 400})
        self.get_object().set_default_interface(project_id=project_id)
        return Response({'message': '已切换默认接口', 'code':200})

    # 这里更新接口没有用update 方法
    @method_decorator(logde.update_timetask)
    def update(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"update",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        return super().update(request, *args, **kwargs)

    @method_decorator(logde.update_timetask)
    def partial_update(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"partial_update",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }"""
        return super().partial_update(request, *args, **kwargs)

    def create(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"create",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super().create(request, *args, **kwargs)

    def retrieve(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"retrieve",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super().retrieve(request, *args, **kwargs)

    def list(self, request, *args, **kwargs):
        """
        {
        "permission":{
            "action":"list",
            "menuLevel":null,
            "permissionLevel":"project",
            "roles":[

            ],
            "permissionLogin":true,
            "permissionPublic":false,
            "permissionWithin":false
        },
        "label":null
        }
        """
        return super().list(request, *args, **kwargs)
