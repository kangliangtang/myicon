from logging import getLogger
import pytz
from celery.utils.log import base_logger
from automate_test_py3 import settings

logger = base_logger

import json
import time
import os
from celery import shared_task
from django.utils import timezone
from interface.models import TaskModel
from project_caud.models import TestProjectModel
from result_report.models import TaskResultReportModel, SummaryModel
from utils.runcore import HttpRunnerCore
from django_celery_beat.models import PeriodicTask, CrontabSchedule

log = getLogger('celery')


@shared_task
def runTimeTask(case_task_id, last_executor=None):
    """
    :param case_id:
    :return:
    """
    runner = HttpRunnerCore()
    task_instance = TaskModel.objects.get(id=case_task_id)
    task_content = json.loads(task_instance.task_content)
    # 复制用例到定时任务文件夹
    runner.copyLevelAllCase(task_instance)
    project_id = task_content['project_id']
    project_obj = TestProjectModel.objects.get(id=task_content['project_id'])
    report_obj = TaskResultReportModel.objects.create(
        task = task_instance,
        project=project_obj
    )
    suumarry_obj = SummaryModel.objects.create(task_result_report=report_obj)
    runner.runCaseByPath(
        case_file_path=task_instance.case_file_path,
        env_id=task_content['env_id'],
        report_obj=report_obj,
        suumarry_obj=suumarry_obj,
        project_id=project_id
    )

    # 发送邮件（定时任务报告）
    try:
        to_emails = task_instance.to_emails
        # last_executor = task_instance.last_executor
        if to_emails:
            to_emails = list(to_emails.split(';'))
            # 去空
            if not all(to_emails):
                to_emails = [email for email in to_emails if email]
            project_name = project_obj.project_name
            task_name = task_instance.name
            status = report_obj.status
            # 邮件中结果状态与UI平台统一
            if status == 'false':
                status = 'fail'
            elif status == 'true':
                status = 'success'
            task_time = report_obj.create_time
            if settings.USE_TZ:
                task_time += timezone.timedelta(hours=8)
            # report_file_path = report_obj.task_report_html()
            env_name = task_content.get('env_name')
            task_date = task_time.strftime('%Y-%m-%d')
            report_file = suumarry_obj.summary_count
            from utils.emailreport import email_report
            from utils.sendemail import SendEmail
            report_data = email_report(project_name, task_date, env_name, last_executor, report_file, task_name)
            report_file_path_name = report_file.split('/')
            report_file_name = report_file_path_name[-1]
            report_file_name = report_file_name.replace('.json', '.html')
            report_file_path = os.path.join(settings.REPORT_DIR, report_file_name)
            send_email_obj = SendEmail(subject='接口平台定时任务报告', body=report_data, to=to_emails, bodytype="html", attachments=report_file_path)
            send_email_obj.send_email()
    except Exception as e:
        log.error('邮件发送失败：%s' % e)
        log.exception(e)

    # 更新数据看板的执行用例数
    # TestProjectModel.objects.get(id=project_id).addRunCase(n=suumarry_obj.total_cases)
    TestProjectModel.objects.get(id=project_id).addRunCase(n=1)  # 场景、聚合场景均视为运行用例1次
    TestProjectModel.objects.get(id=project_id).addInterfaceResult(env_id=task_content['env_id'],
                                                                   status=report_obj.status)

class TimeTask():
    def __init__(self, schedule, case_task):
        self.schedule = schedule
        self.case_task = case_task
        self.schedule_list = []

    def timeTask(self):
        self.splitSchedule()
        schedule, _ = CrontabSchedule.objects.get_or_create(
            minute= self.schedule_list[0],
            hour= self.schedule_list[1],
            day_of_month= self.schedule_list[2],
            month_of_year= self.schedule_list[3],
            day_of_week=self.schedule_list[4],
            timezone=pytz.timezone(settings.TIME_ZONE)
        )
        task_ = PeriodicTask.objects.create(
            crontab=schedule,
            name=self.taskName,
            task='interface.tasks.runTimeTask',
            args=[self.case_task.id],
            enabled=True
        )
        return task_

    def updateTimeTask(self):
        self.splitSchedule()
        schedule, _ = CrontabSchedule.objects.get_or_create(
            minute=self.schedule_list[0],
            hour=self.schedule_list[1],
            day_of_month=self.schedule_list[2],
            month_of_year=self.schedule_list[3],
            day_of_week=self.schedule_list[4],
            timezone=pytz.timezone(settings.TIME_ZONE)
        )
        task_ = self.case_task.periodic_task
        task_.crontab = schedule
        task_.save()
        return task_

    def splitSchedule(self):
        self.schedule_list = self.schedule.strip().split()
        if len(self.schedule) == 5:
            return False
        return True

    @property
    def taskName(self):
        return time.time().__str__().replace('.', '')

    def run(self, *args, **kwargs):
        pass
